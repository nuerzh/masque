use std::collections::HashMap;
use std::net::IpAddr;
use std::sync::{Arc, OnceLock};

use ipnet::IpNet;
use parking_lot::RwLock;
use regex::Regex;

/// What happens to a connection once a rule, or the default, has picked it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    /// Refuse the connection.
    Block,
    /// Connect from this machine, outside every tunnel.
    Direct,
    /// Hand the name or address to the tunnel as it is; the tunnel resolves a name on its side.
    Tunnel,
    /// Resolve the name on this machine, then hand the address to the tunnel.
    Resolve,
}

impl Action {
    pub fn label(self) -> &'static str {
        match self {
            Action::Block => "block",
            Action::Direct => "direct",
            Action::Tunnel => "tunnel",
            Action::Resolve => "dns-tunnel",
        }
    }

    /// The word that names an action in a routes file section or a setting.
    pub fn parse(word: &str) -> Option<Self> {
        match word.trim().to_lowercase().as_str() {
            "block" => Some(Action::Block),
            "direct" => Some(Action::Direct),
            "tunnel" => Some(Action::Tunnel),
            "dns" | "dns-tunnel" | "resolve" => Some(Action::Resolve),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub enum Host<'a> {
    Domain(&'a str),
    Ip(IpAddr),
}

/// One connection as the rules see it: where it goes, and whether its first datagram is a
/// WireGuard message.
#[derive(Debug, Clone, Copy)]
pub struct Flow<'a> {
    pub host: Host<'a>,
    pub port: u16,
    pub wireguard: bool,
}

impl<'a> Flow<'a> {
    pub fn new(host: Host<'a>, port: u16) -> Self {
        Self {
            host,
            port,
            wireguard: false,
        }
    }
}

#[derive(Debug)]
enum Matcher {
    DomainSuffix(String),
    DomainFull(String),
    DomainKeyword(String),
    DomainRegex(Regex),
    Net(IpNet),
    Ports(u16, u16),
    Private,
    WireGuard,
}

/// One item of a rule list: a rule, or a reference to a rule set by its tag.
#[derive(Debug)]
enum Entry {
    Rule(Matcher),
    Set(String),
}

impl Matcher {
    fn matches(&self, flow: &Flow<'_>) -> bool {
        match self {
            Matcher::WireGuard => flow.wireguard,
            Matcher::Ports(lo, hi) => flow.port >= *lo && flow.port <= *hi,
            Matcher::Private => match flow.host {
                Host::Ip(ip) => is_private(ip),
                Host::Domain(name) => name.eq_ignore_ascii_case("localhost"),
            },
            Matcher::Net(net) => match flow.host {
                Host::Ip(ip) => net.contains(&ip),
                Host::Domain(_) => false,
            },
            _ => self.matches_name_of(flow.host),
        }
    }

    /// The domain matchers. A name is never an address, so they only ever look at domains.
    fn matches_name_of(&self, host: Host<'_>) -> bool {
        let Host::Domain(name) = host else {
            return false;
        };
        match self {
            Matcher::DomainSuffix(suffix) => {
                let name = name.to_lowercase();
                name == *suffix || name.ends_with(&format!(".{suffix}"))
            }
            Matcher::DomainFull(full) => name.eq_ignore_ascii_case(full),
            Matcher::DomainKeyword(needle) => name.to_lowercase().contains(needle),
            Matcher::DomainRegex(pattern) => pattern.is_match(name),
            _ => false,
        }
    }

    fn is_domain(&self) -> bool {
        matches!(
            self,
            Matcher::DomainSuffix(_)
                | Matcher::DomainFull(_)
                | Matcher::DomainKeyword(_)
                | Matcher::DomainRegex(_)
        )
    }
}

/// Reads one item of a rule list. Blank lines and comments give nothing.
fn parse_entry(raw: &str) -> Option<Entry> {
    let entry = raw.trim();
    if entry.is_empty() || entry.starts_with('#') {
        return None;
    }

    let (kind, value) = match entry.split_once(':') {
        Some((kind, value)) if !kind.contains('.') && !kind.contains('/') => {
            (kind.trim().to_lowercase(), value.trim())
        }
        _ => (String::new(), entry),
    };

    match kind.as_str() {
        "ruleset" | "rule-set" => {
            let tag = value.trim();
            (!tag.is_empty()).then(|| Entry::Set(tag.to_string()))
        }
        "protocol" => match value.to_lowercase().as_str() {
            "wireguard" | "wg" => Some(Entry::Rule(Matcher::WireGuard)),
            _ => None,
        },
        _ => parse_matcher(entry).map(Entry::Rule),
    }
}

fn parse_matcher(entry: &str) -> Option<Matcher> {
    let (kind, value) = match entry.split_once(':') {
        Some((kind, value)) if !kind.contains('.') && !kind.contains('/') => {
            (kind.trim().to_lowercase(), value.trim())
        }
        _ => (String::new(), entry),
    };

    match kind.as_str() {
        "domain" | "suffix" => Some(Matcher::DomainSuffix(normalize_domain(value)?)),
        "full" | "exact" => Some(Matcher::DomainFull(normalize_domain(value)?)),
        "keyword" => {
            let needle = value.trim().to_lowercase();
            if needle.is_empty() {
                None
            } else {
                Some(Matcher::DomainKeyword(needle))
            }
        }
        "regexp" | "regex" => Regex::new(value).ok().map(Matcher::DomainRegex),
        "ip" | "cidr" => parse_net(value).map(Matcher::Net),
        "port" => parse_ports(value).map(|(lo, hi)| Matcher::Ports(lo, hi)),
        "geoip" | "geosite" => {
            if value.eq_ignore_ascii_case("private") {
                Some(Matcher::Private)
            } else {
                None
            }
        }
        "" => {
            if value.eq_ignore_ascii_case("private") {
                return Some(Matcher::Private);
            }
            if let Some(net) = parse_net(value) {
                return Some(Matcher::Net(net));
            }
            normalize_domain(value).map(Matcher::DomainSuffix)
        }
        _ => None,
    }
}

fn normalize_domain(value: &str) -> Option<String> {
    let cleaned = value
        .trim()
        .trim_start_matches('*')
        .trim_start_matches('.')
        .trim_end_matches('.')
        .to_lowercase();
    if cleaned.is_empty() {
        None
    } else {
        Some(cleaned)
    }
}

fn parse_net(value: &str) -> Option<IpNet> {
    let value = value.trim();
    if let Ok(net) = value.parse::<IpNet>() {
        return Some(net);
    }
    value.parse::<IpAddr>().ok().map(IpNet::from)
}

fn parse_ports(value: &str) -> Option<(u16, u16)> {
    let value = value.trim();
    match value.split_once('-') {
        Some((lo, hi)) => {
            let lo = lo.trim().parse::<u16>().ok()?;
            let hi = hi.trim().parse::<u16>().ok()?;
            Some(if hi < lo { (hi, lo) } else { (lo, hi) })
        }
        None => {
            let single = value.parse::<u16>().ok()?;
            Some((single, single))
        }
    }
}

pub fn is_private(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            v4.is_private()
                || v4.is_loopback()
                || v4.is_link_local()
                || v4.is_broadcast()
                || v4.is_documentation()
                || v4.is_unspecified()
                || v4.octets()[0] == 100 && (64..128).contains(&v4.octets()[1])
        }
        IpAddr::V6(v6) => {
            v6.is_loopback()
                || v6.is_unspecified()
                || (v6.segments()[0] & 0xfe00) == 0xfc00
                || (v6.segments()[0] & 0xffc0) == 0xfe80
        }
    }
}

/// Whether a UDP payload is a WireGuard message, by the standard lengths of its four kinds:
/// handshake initiation (148 bytes), handshake response (92), cookie reply (64), and transport
/// data (a multiple of 16 bytes, at least 32, which is the header plus the authentication tag).
pub fn looks_like_wireguard(datagram: &[u8]) -> bool {
    if datagram.len() < 4 {
        return false;
    }
    match datagram[0] {
        1 => datagram.len() == 148,
        2 => datagram.len() == 92,
        3 => datagram.len() == 64,
        4 => datagram.len() >= 32 && datagram.len() % 16 == 0,
        _ => false,
    }
}

#[derive(Debug)]
struct Rule {
    action: Action,
    matcher: Matcher,
}

/// An ordered list of routing rules, matched the way sing-box matches its route rules: the first
/// rule that matches decides, and a connection no rule matches takes the default action.
#[derive(Debug)]
pub struct RuleSet {
    rules: Vec<Rule>,
    default: Action,
}

impl Default for RuleSet {
    fn default() -> Self {
        Self {
            rules: Vec::new(),
            default: Action::Tunnel,
        }
    }
}

impl RuleSet {
    /// Builds the rules from lists of (action, items). Each item is a rule, or `ruleset:TAG`,
    /// which stands for every rule of the set `TAG` in `sets`, all with the list's action. A set
    /// that is not loaded is skipped with a warning, and a set inside a set is not expanded.
    pub fn build(lists: &[(Action, String)], sets: &HashMap<String, String>, default: Action) -> Self {
        let mut rules = Vec::new();
        for (action, text) in lists {
            for raw in split_items(text) {
                match parse_entry(raw) {
                    Some(Entry::Rule(matcher)) => rules.push(Rule {
                        action: *action,
                        matcher,
                    }),
                    Some(Entry::Set(tag)) => match sets.get(&tag) {
                        Some(body) => {
                            for inner in split_items(body) {
                                match parse_entry(inner) {
                                    Some(Entry::Rule(matcher)) => rules.push(Rule {
                                        action: *action,
                                        matcher,
                                    }),
                                    Some(Entry::Set(nested)) => log::warn!(
                                        "[-] rule set {tag} refers to rule set {nested}; nested sets are not expanded"
                                    ),
                                    None => {}
                                }
                            }
                        }
                        None => log::warn!("[-] rule set {tag} is not loaded; its rules are skipped"),
                    },
                    None => {}
                }
            }
        }

        let set = Self { rules, default };
        if !set.is_empty() {
            log::info!(
                "[+] routing rules loaded: {} rules, default {}",
                set.rules.len(),
                set.default.label()
            );
        }
        set
    }

    /// Two plain lists, block first and then direct, with the default tunnel.
    pub fn parse(block: &str, direct: &str) -> Self {
        Self::build(
            &[
                (Action::Block, block.to_string()),
                (Action::Direct, direct.to_string()),
            ],
            &HashMap::new(),
            Action::Tunnel,
        )
    }

    pub fn is_empty(&self) -> bool {
        self.rules.is_empty() && self.default == Action::Tunnel
    }

    pub fn has_domain_rules(&self) -> bool {
        self.rules.iter().any(|rule| rule.matcher.is_domain())
    }

    /// The action of the first rule that matches the flow, or `None` when no rule does.
    pub fn matched(&self, flow: &Flow<'_>) -> Option<Action> {
        self.rules
            .iter()
            .find(|rule| rule.matcher.matches(flow))
            .map(|rule| rule.action)
    }

    /// The action of the first domain rule that matches `name`, ignoring ports and addresses.
    pub fn matched_name(&self, name: &str) -> Option<Action> {
        self.rules
            .iter()
            .find(|rule| rule.matcher.matches_name_of(Host::Domain(name)))
            .map(|rule| rule.action)
    }

    pub fn decide(&self, flow: &Flow<'_>) -> Action {
        self.matched(flow).unwrap_or(self.default)
    }

    /// The address ranges whose rules send a connection direct, for routes that keep them off
    /// the tunnel.
    pub fn direct_nets(&self) -> Vec<IpNet> {
        self.rules
            .iter()
            .filter(|rule| rule.action == Action::Direct)
            .filter_map(|rule| match &rule.matcher {
                Matcher::Net(net) => Some(*net),
                _ => None,
            })
            .collect()
    }
}

/// The rules from the environment: the settings lists, in the order block, direct, tunnel, dns.
pub fn env_lists() -> Vec<(Action, String)> {
    [
        (Action::Block, "AETHER_ROUTE_BLOCK"),
        (Action::Direct, "AETHER_ROUTE_DIRECT"),
        (Action::Tunnel, "AETHER_ROUTE_TUNNEL"),
        (Action::Resolve, "AETHER_ROUTE_DNS"),
    ]
    .into_iter()
    .map(|(action, var)| (action, std::env::var(var).unwrap_or_default()))
    .collect()
}

/// The sections of the routes file named by `AETHER_ROUTES_FILE`, in the order they are written.
pub fn routes_file_lists() -> Vec<(Action, String)> {
    let Ok(path) = std::env::var("AETHER_ROUTES_FILE") else {
        return Vec::new();
    };
    match std::fs::read_to_string(&path) {
        Ok(text) => split_sections(&text),
        Err(error) => {
            log::warn!("[-] could not read the routing file {path}: {error}");
            Vec::new()
        }
    }
}

fn default_from_env() -> Action {
    match std::env::var("AETHER_ROUTE_FINAL") {
        Ok(word) if !word.trim().is_empty() => match Action::parse(&word) {
            Some(action) => action,
            None => {
                log::warn!("[-] unknown AETHER_ROUTE_FINAL {word:?}; using tunnel");
                Action::Tunnel
            }
        },
        _ => Action::Tunnel,
    }
}

/// The rule lists in their order: the settings first, then the routes file from top to bottom.
fn all_lists() -> Vec<(Action, String)> {
    let mut lists = env_lists();
    lists.extend(routes_file_lists());
    lists
}

static CURRENT: OnceLock<RwLock<Arc<RuleSet>>> = OnceLock::new();

fn slot() -> &'static RwLock<Arc<RuleSet>> {
    CURRENT.get_or_init(|| {
        let set = RuleSet::build(&all_lists(), &HashMap::new(), default_from_env());
        RwLock::new(Arc::new(set))
    })
}

/// The rules in force now. A connection takes the rules that were current when it was decided.
pub fn current() -> Arc<RuleSet> {
    Arc::clone(&slot().read())
}

/// Rebuilds the rules from the settings, the routes file and the given rule sets, and makes them
/// the ones in force. Connections decided from now on follow the new rules.
pub fn reload(sets: &HashMap<String, String>) {
    let set = RuleSet::build(&all_lists(), sets, default_from_env());
    *slot().write() = Arc::new(set);
}

/// How many rules a rule set text holds, for telling an empty download from a real one.
pub fn count_entries(text: &str) -> usize {
    split_items(text)
        .into_iter()
        .filter(|raw| matches!(parse_entry(raw), Some(Entry::Rule(_))))
        .count()
}

/// Splits a list into its items: one per line, comma or semicolon.
fn split_items(text: &str) -> Vec<&str> {
    text.split(['\n', ',', ';']).collect()
}

/// Splits a routes file into its sections, in the order they are written. A section header is a
/// line such as `[block]`; the words are the action names of [`Action::parse`]. A section with
/// an unknown name is skipped, and so are the lines under it.
fn split_sections(text: &str) -> Vec<(Action, String)> {
    let mut sections: Vec<(Action, String)> = Vec::new();
    let mut open = false;

    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }

        if let Some(name) = trimmed
            .strip_prefix('[')
            .and_then(|rest| rest.strip_suffix(']'))
        {
            open = match Action::parse(name) {
                Some(action) => {
                    sections.push((action, String::new()));
                    true
                }
                None => false,
            };
            continue;
        }

        if open {
            if let Some((_, body)) = sections.last_mut() {
                body.push_str(trimmed);
                body.push('\n');
            }
        }
    }

    sections
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rules(block: &str, direct: &str) -> RuleSet {
        RuleSet::parse(block, direct)
    }

    fn with(lists: &[(Action, &str)], default: Action) -> RuleSet {
        let owned: Vec<(Action, String)> = lists
            .iter()
            .map(|(action, text)| (*action, text.to_string()))
            .collect();
        RuleSet::build(&owned, &HashMap::new(), default)
    }

    fn domain(name: &str) -> Flow<'_> {
        Flow::new(Host::Domain(name), 443)
    }

    fn ip(address: &str) -> Flow<'static> {
        Flow::new(Host::Ip(address.parse().unwrap()), 443)
    }

    #[test]
    fn an_empty_rule_set_sends_everything_through_the_tunnel() {
        let set = rules("", "");
        assert!(set.is_empty());
        assert_eq!(set.decide(&domain("example.com")), Action::Tunnel);
        assert_eq!(set.decide(&ip("1.1.1.1")), Action::Tunnel);
    }

    #[test]
    fn a_bare_domain_matches_itself_and_its_subdomains() {
        let set = rules("ads.example", "");
        assert_eq!(set.decide(&domain("ads.example")), Action::Block);
        assert_eq!(set.decide(&domain("tracker.ads.example")), Action::Block);
        assert_eq!(set.decide(&domain("notads.example")), Action::Tunnel);
        assert_eq!(set.decide(&domain("ads.example.org")), Action::Tunnel);
    }

    #[test]
    fn a_full_rule_matches_only_the_exact_name() {
        let set = rules("full:example.com", "");
        assert_eq!(set.decide(&domain("example.com")), Action::Block);
        assert_eq!(set.decide(&domain("www.example.com")), Action::Tunnel);
    }

    #[test]
    fn a_keyword_rule_matches_anywhere_in_the_name() {
        let set = rules("keyword:doubleclick", "");
        assert_eq!(set.decide(&domain("stats.doubleclick.net")), Action::Block);
        assert_eq!(set.decide(&domain("example.com")), Action::Tunnel);
    }

    #[test]
    fn a_regex_rule_is_honoured() {
        let set = rules(r"regexp:^ad[0-9]+\.", "");
        assert_eq!(set.decide(&domain("ad42.example.com")), Action::Block);
        assert_eq!(set.decide(&domain("ads.example.com")), Action::Tunnel);
    }

    #[test]
    fn a_cidr_rule_matches_addresses_inside_it() {
        let set = rules("", "10.0.0.0/8");
        assert_eq!(set.decide(&ip("10.1.2.3")), Action::Direct);
        assert_eq!(set.decide(&ip("11.1.2.3")), Action::Tunnel);
    }

    #[test]
    fn a_bare_address_is_treated_as_a_single_host_rule() {
        let set = rules("1.2.3.4", "");
        assert_eq!(set.decide(&ip("1.2.3.4")), Action::Block);
        assert_eq!(set.decide(&ip("1.2.3.5")), Action::Tunnel);
    }

    #[test]
    fn a_port_rule_can_carve_out_a_range() {
        let set = rules("port:25", "port:3000-3010");
        assert_eq!(
            set.decide(&Flow::new(Host::Domain("mail.example"), 25)),
            Action::Block
        );
        assert_eq!(
            set.decide(&Flow::new(Host::Domain("dev.example"), 3005)),
            Action::Direct
        );
        assert_eq!(
            set.decide(&Flow::new(Host::Domain("dev.example"), 3011)),
            Action::Tunnel
        );
    }

    #[test]
    fn the_private_keyword_covers_lan_and_loopback_and_cgnat() {
        let set = rules("", "private");
        for address in ["10.1.1.1", "192.168.1.5", "172.16.9.9", "127.0.0.1", "100.96.0.2"] {
            assert_eq!(set.decide(&ip(address)), Action::Direct, "{address}");
        }
        assert_eq!(set.decide(&ip("8.8.8.8")), Action::Tunnel);
        assert_eq!(set.decide(&domain("localhost")), Action::Direct);
    }

    #[test]
    fn ipv6_private_ranges_are_recognised() {
        assert!(is_private("::1".parse().unwrap()));
        assert!(is_private("fd00::1".parse().unwrap()));
        assert!(is_private("fe80::1".parse().unwrap()));
        assert!(!is_private("2606:4700::1111".parse().unwrap()));
    }

    #[test]
    fn domain_rules_are_reported_so_a_tunnel_can_recover_the_name() {
        assert!(!rules("", "").has_domain_rules());
        assert!(!rules("10.0.0.0/8, port:25", "private").has_domain_rules());
        assert!(rules("ads.example", "").has_domain_rules());
        assert!(rules("", "keyword:internal").has_domain_rules());
        assert!(rules("", r"regexp:^ad[0-9]+\.").has_domain_rules());
        assert!(rules("full:example.com", "").has_domain_rules());
    }

    #[test]
    fn block_wins_over_direct_when_both_match() {
        let set = rules("example.com", "example.com");
        assert_eq!(set.decide(&domain("example.com")), Action::Block);
    }

    #[test]
    fn the_first_matching_rule_wins_whatever_its_action() {
        let set = with(
            &[
                (Action::Resolve, "example.com"),
                (Action::Block, "example.com"),
            ],
            Action::Tunnel,
        );
        assert_eq!(set.decide(&domain("example.com")), Action::Resolve);
    }

    #[test]
    fn a_narrow_rule_placed_first_carves_an_exception_out_of_a_broad_one() {
        let set = with(
            &[
                (Action::Tunnel, "full:api.example.com"),
                (Action::Block, "example.com"),
            ],
            Action::Direct,
        );
        assert_eq!(set.decide(&domain("api.example.com")), Action::Tunnel);
        assert_eq!(set.decide(&domain("www.example.com")), Action::Block);
    }

    #[test]
    fn the_default_action_applies_when_no_rule_matches() {
        let set = with(&[(Action::Block, "ads.example")], Action::Direct);
        assert_eq!(set.decide(&domain("example.org")), Action::Direct);
        assert_eq!(set.decide(&domain("ads.example")), Action::Block);
        assert!(set.matched(&domain("example.org")).is_none());
    }

    #[test]
    fn matched_reports_nothing_when_no_rule_applies() {
        let set = with(&[(Action::Direct, "internal.example")], Action::Block);
        assert_eq!(set.matched(&domain("other.example")), None);
        assert_eq!(
            set.matched(&domain("internal.example")),
            Some(Action::Direct)
        );
    }

    #[test]
    fn matched_name_looks_only_at_domain_rules() {
        let set = with(
            &[(Action::Block, "ads.example"), (Action::Direct, "port:53")],
            Action::Tunnel,
        );
        assert_eq!(set.matched_name("x.ads.example"), Some(Action::Block));
        assert_eq!(set.matched_name("example.org"), None);
    }

    #[test]
    fn action_names_are_recognised_in_sections_and_settings() {
        assert_eq!(Action::parse("block"), Some(Action::Block));
        assert_eq!(Action::parse("Direct"), Some(Action::Direct));
        assert_eq!(Action::parse("tunnel"), Some(Action::Tunnel));
        assert_eq!(Action::parse("dns"), Some(Action::Resolve));
        assert_eq!(Action::parse("dns-tunnel"), Some(Action::Resolve));
        assert_eq!(Action::parse("proxy"), None);
        assert_eq!(Action::parse("wireguard"), None);
    }

    #[test]
    fn a_protocol_rule_matches_wireguard_flows_only() {
        let set = with(&[(Action::Tunnel, "protocol:wireguard")], Action::Direct);
        let wg = Flow {
            host: Host::Ip("203.0.113.5".parse().unwrap()),
            port: 51820,
            wireguard: true,
        };
        assert_eq!(set.decide(&wg), Action::Tunnel);
        assert_eq!(set.decide(&ip("203.0.113.5")), Action::Direct);
    }

    #[test]
    fn wireguard_messages_are_recognised_by_their_standard_lengths() {
        let mut init = vec![0u8; 148];
        init[0] = 1;
        assert!(looks_like_wireguard(&init));
        let mut response = vec![0u8; 92];
        response[0] = 2;
        assert!(looks_like_wireguard(&response));
        let mut cookie = vec![0u8; 64];
        cookie[0] = 3;
        assert!(looks_like_wireguard(&cookie));
        let mut keepalive = vec![0u8; 32];
        keepalive[0] = 4;
        assert!(looks_like_wireguard(&keepalive));
        let mut data = vec![0u8; 48];
        data[0] = 4;
        assert!(looks_like_wireguard(&data));

        let mut wrong_length = vec![0u8; 100];
        wrong_length[0] = 1;
        assert!(!looks_like_wireguard(&wrong_length));
        assert!(!looks_like_wireguard(b"GET / HTTP/1.1\r\n"));
        assert!(!looks_like_wireguard(&[]));
    }

    #[test]
    fn a_rule_set_reference_expands_to_its_rules_with_the_list_action() {
        let mut sets = HashMap::new();
        sets.insert(
            "ads".to_string(),
            "# advertising\nads.example\nkeyword:track\n".to_string(),
        );
        let lists = vec![(Action::Block, "ruleset:ads".to_string())];
        let set = RuleSet::build(&lists, &sets, Action::Tunnel);
        assert_eq!(set.decide(&domain("ads.example")), Action::Block);
        assert_eq!(set.decide(&domain("x.tracker.example")), Action::Block);
        assert_eq!(set.decide(&domain("example.org")), Action::Tunnel);
    }

    #[test]
    fn a_rule_set_that_is_not_loaded_is_skipped() {
        let lists = vec![(Action::Block, "ruleset:missing, ads.example".to_string())];
        let set = RuleSet::build(&lists, &HashMap::new(), Action::Tunnel);
        assert_eq!(set.decide(&domain("ads.example")), Action::Block);
        assert_eq!(set.decide(&domain("other.example")), Action::Tunnel);
    }

    #[test]
    fn a_rule_set_inside_a_rule_set_is_not_expanded() {
        let mut sets = HashMap::new();
        sets.insert("outer".to_string(), "ruleset:inner\nouter.example\n".to_string());
        sets.insert("inner".to_string(), "inner.example\n".to_string());
        let lists = vec![(Action::Block, "ruleset:outer".to_string())];
        let set = RuleSet::build(&lists, &sets, Action::Tunnel);
        assert_eq!(set.decide(&domain("outer.example")), Action::Block);
        assert_eq!(set.decide(&domain("inner.example")), Action::Tunnel);
    }

    #[test]
    fn direct_nets_lists_the_address_rules_that_send_direct() {
        let set = with(
            &[
                (Action::Block, "10.9.0.0/16"),
                (Action::Direct, "10.0.0.0/8, 192.0.2.1, example.com"),
            ],
            Action::Tunnel,
        );
        assert_eq!(
            set.direct_nets(),
            vec![
                "10.0.0.0/8".parse::<IpNet>().unwrap(),
                "192.0.2.1/32".parse::<IpNet>().unwrap()
            ]
        );
    }

    #[test]
    fn counting_entries_ignores_comments_and_blank_lines() {
        assert_eq!(count_entries("# x\n\nads.example\nkeyword:a, b.example\n"), 3);
        assert_eq!(count_entries("   \n# only comments\n"), 0);
    }

    #[test]
    fn a_rules_file_keeps_each_section_and_its_action() {
        let text = "# routing\n[block]\nads.example\nkeyword:tracker\n\n[direct]\nprivate\n10.0.0.0/8\n[dns]\nslow.example\n[tunnel]\nruleset:foo\n";
        let sections = split_sections(text);
        let actions: Vec<Action> = sections.iter().map(|(action, _)| *action).collect();
        assert_eq!(
            actions,
            vec![Action::Block, Action::Direct, Action::Resolve, Action::Tunnel]
        );
        assert!(sections[0].1.contains("ads.example"));
        assert!(sections[0].1.contains("keyword:tracker"));
        assert!(sections[1].1.contains("private"));
        assert!(sections[1].1.contains("10.0.0.0/8"));
        assert!(!sections[0].1.contains("private"));
        assert!(sections[3].1.contains("ruleset:foo"));
    }

    #[test]
    fn an_unknown_section_is_ignored_rather_than_misfiled() {
        let sections = split_sections("[proxy]\nexample.com\n[block]\nads.example\n");
        assert_eq!(sections.len(), 1);
        assert_eq!(sections[0].0, Action::Block);
        assert!(!sections[0].1.contains("example.com"));
        assert!(sections[0].1.contains("ads.example"));
    }

    #[test]
    fn malformed_entries_are_dropped_without_panicking() {
        let set = rules("regexp:[unclosed, port:abc, ip:not-an-ip, geoip:cn, :, ruleset:", "");
        assert_eq!(set.decide(&domain("example.com")), Action::Tunnel);
    }
}
