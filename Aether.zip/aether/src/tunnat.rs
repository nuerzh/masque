//! Address translation for TUN mode.
//!
//! The system sends its packets from its own address on the TUN device, while the tunnel only
//! carries packets from the address WARP assigned. This module rewrites the source of each outgoing
//! packet to the assigned address, giving the flow a port from [`NAT_PORTS`], and reverses that for
//! the replies. TCP and UDP flows are mapped by port, ICMP echo by identifier. Checksums are
//! updated incrementally (RFC 1624), so the payload is not read again.
//!
//! Nothing here touches the network, so the translation is testable on its own.

use std::collections::HashMap;
use std::net::Ipv4Addr;
use std::ops::RangeInclusive;
use std::time::{Duration, Instant};

pub const PROTO_ICMP: u8 = 1;
pub const PROTO_TCP: u8 = 6;
pub const PROTO_UDP: u8 = 17;

/// The ports this module hands out. The proxy stack takes its own ports from 49152 up, so an
/// inbound TCP or UDP packet on a port in this range is a reply to the system, and one outside it
/// belongs to the stack.
pub const NAT_PORTS: RangeInclusive<u16> = 20000..=49151;

const ICMP_ECHO_REPLY: u8 = 0;
const ICMP_ECHO_REQUEST: u8 = 8;

/// Flows that stay silent this long lose their mapping.
const UDP_IDLE: Duration = Duration::from_secs(180);
const ICMP_IDLE: Duration = Duration::from_secs(60);
const TCP_IDLE: Duration = Duration::from_secs(3600);
/// Upper bound on live mappings, so a flood of new flows cannot grow the table without limit.
const MAX_MAPPINGS: usize = 16_384;
const SWEEP_EVERY: Duration = Duration::from_secs(30);

fn idle_for(proto: u8) -> Duration {
    match proto {
        PROTO_TCP => TCP_IDLE,
        PROTO_UDP => UDP_IDLE,
        _ => ICMP_IDLE,
    }
}

/// One outgoing flow as the system sees it. For ICMP the ports are the echo identifier and zero.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct Flow {
    proto: u8,
    src: Ipv4Addr,
    sport: u16,
    dst: Ipv4Addr,
    dport: u16,
}

/// The parts of an IPv4 packet this module reads.
#[derive(Clone, Copy, Debug)]
struct Header {
    ihl: usize,
    proto: u8,
    src: Ipv4Addr,
    dst: Ipv4Addr,
}

/// Reads an IPv4 header. Fragments are refused: only the first carries the ports, and the others
/// cannot be matched to a flow.
fn parse(pkt: &[u8]) -> Option<Header> {
    if pkt.len() < 20 || pkt[0] >> 4 != 4 {
        return None;
    }
    let ihl = usize::from(pkt[0] & 0x0f) * 4;
    if ihl < 20 || pkt.len() < ihl {
        return None;
    }
    let total = usize::from(be16(pkt, 2));
    if total < ihl || total > pkt.len() {
        return None;
    }
    if be16(pkt, 6) & 0x3fff != 0 {
        return None;
    }
    Some(Header {
        ihl,
        proto: pkt[9],
        src: Ipv4Addr::new(pkt[12], pkt[13], pkt[14], pkt[15]),
        dst: Ipv4Addr::new(pkt[16], pkt[17], pkt[18], pkt[19]),
    })
}

/// Whether an inbound packet is the system's and so goes to the NAT rather than to the proxy stack:
/// every ICMP packet, and TCP or UDP to a port in [`NAT_PORTS`]. Fragments count as the system's,
/// so the NAT can drop them rather than hand them to the stack.
pub fn belongs_to_system(pkt: &[u8]) -> bool {
    if pkt.len() < 20 || pkt[0] >> 4 != 4 {
        return false;
    }
    let ihl = usize::from(pkt[0] & 0x0f) * 4;
    if ihl < 20 || pkt.len() < ihl + 4 {
        return false;
    }
    if be16(pkt, 6) & 0x3fff != 0 {
        return true;
    }
    match pkt[9] {
        PROTO_ICMP => true,
        PROTO_TCP | PROTO_UDP => NAT_PORTS.contains(&be16(pkt, ihl + 2)),
        _ => false,
    }
}

fn be16(pkt: &[u8], at: usize) -> u16 {
    u16::from_be_bytes([pkt[at], pkt[at + 1]])
}

fn words(addr: Ipv4Addr) -> [u16; 2] {
    let o = addr.octets();
    [
        u16::from_be_bytes([o[0], o[1]]),
        u16::from_be_bytes([o[2], o[3]]),
    ]
}

fn fold(mut sum: u32) -> u16 {
    while sum >> 16 != 0 {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    sum as u16
}

/// Updates a checksum after the 16-bit words `old` were replaced by `new` (RFC 1624, eqn. 3).
fn incremental(csum: u16, old: &[u16], new: &[u16]) -> u16 {
    let mut sum = u32::from(!csum);
    for &word in old {
        sum += u32::from(!word);
    }
    for &word in new {
        sum += u32::from(word);
    }
    !fold(sum)
}

/// Writes the words of a changed address or port into the checksum at `at`. A UDP checksum of zero
/// means none was computed, and stays zero.
fn update_checksum(pkt: &mut [u8], at: usize, old: &[u16], new: &[u16], udp: bool) {
    let stored = be16(pkt, at);
    if udp && stored == 0 {
        return;
    }
    let mut updated = incremental(stored, old, new);
    if udp && updated == 0 {
        updated = 0xffff;
    }
    pkt[at..at + 2].copy_from_slice(&updated.to_be_bytes());
}

/// Sets the IPv4 address at `at` (12 for source, 16 for destination), fixing the IP header checksum
/// and, when the transport carries the address in its pseudo-header, the transport checksum.
fn set_address(pkt: &mut [u8], h: &Header, at: usize, to: Ipv4Addr) {
    let old = words(if at == 12 { h.src } else { h.dst });
    let new = words(to);
    pkt[at..at + 4].copy_from_slice(&to.octets());
    update_checksum(pkt, 10, &old, &new, false);
    match h.proto {
        PROTO_TCP => update_checksum(pkt, h.ihl + 16, &old, &new, false),
        PROTO_UDP => update_checksum(pkt, h.ihl + 6, &old, &new, true),
        _ => {}
    }
}

/// Sets a 16-bit port or ICMP identifier at `at`, fixing the transport checksum.
fn set_port(pkt: &mut [u8], h: &Header, at: usize, to: u16) {
    let old = [be16(pkt, at)];
    let new = [to];
    pkt[at..at + 2].copy_from_slice(&to.to_be_bytes());
    match h.proto {
        PROTO_TCP => update_checksum(pkt, h.ihl + 16, &old, &new, false),
        PROTO_UDP => update_checksum(pkt, h.ihl + 6, &old, &new, true),
        PROTO_ICMP => update_checksum(pkt, h.ihl + 2, &old, &new, false),
        _ => {}
    }
}

/// The translation table, with the address the tunnel knows the system by.
pub struct Nat {
    wan: Ipv4Addr,
    out: HashMap<Flow, u16>,
    /// The flow behind each mapped port, and when it last carried a packet.
    back: HashMap<(u8, u16), (Flow, Instant)>,
    next: u16,
    last_sweep: Instant,
}

impl Nat {
    /// A table that presents the system as `wan`, the address of the tunnel.
    pub fn new(wan: Ipv4Addr) -> Self {
        Self {
            wan,
            out: HashMap::new(),
            back: HashMap::new(),
            next: *NAT_PORTS.start(),
            last_sweep: Instant::now(),
        }
    }

    /// Rewrites a packet leaving the system for the tunnel. Returns false to drop it.
    pub fn outbound(&mut self, pkt: &mut [u8], now: Instant) -> bool {
        self.maybe_sweep(now);
        let Some(h) = parse(pkt) else {
            return false;
        };
        match h.proto {
            PROTO_TCP | PROTO_UDP => {
                let flow = Flow {
                    proto: h.proto,
                    src: h.src,
                    sport: be16(pkt, h.ihl),
                    dst: h.dst,
                    dport: be16(pkt, h.ihl + 2),
                };
                let Some(mapped) = self.map(flow, now) else {
                    return false;
                };
                set_port(pkt, &h, h.ihl, mapped);
            }
            PROTO_ICMP => {
                if pkt[h.ihl] != ICMP_ECHO_REQUEST {
                    return false;
                }
                let flow = Flow {
                    proto: PROTO_ICMP,
                    src: h.src,
                    sport: be16(pkt, h.ihl + 4),
                    dst: h.dst,
                    dport: 0,
                };
                let Some(mapped) = self.map(flow, now) else {
                    return false;
                };
                set_port(pkt, &h, h.ihl + 4, mapped);
            }
            _ => return false,
        }
        set_address(pkt, &h, 12, self.wan);
        true
    }

    /// Rewrites a packet from the tunnel that belongs to the system. Returns false to drop it:
    /// it is no reply to a flow the system opened, or it came from another host than that flow's.
    pub fn inbound(&mut self, pkt: &mut [u8], now: Instant) -> bool {
        self.maybe_sweep(now);
        let Some(h) = parse(pkt) else {
            return false;
        };
        if h.dst != self.wan {
            return false;
        }
        let (key, remote_port, local_at) = match h.proto {
            PROTO_TCP | PROTO_UDP => {
                let dport = be16(pkt, h.ihl + 2);
                ((h.proto, dport), be16(pkt, h.ihl), h.ihl + 2)
            }
            PROTO_ICMP => {
                if pkt[h.ihl] != ICMP_ECHO_REPLY {
                    return false;
                }
                ((PROTO_ICMP, be16(pkt, h.ihl + 4)), 0, h.ihl + 4)
            }
            _ => return false,
        };
        let Some((flow, last)) = self.back.get_mut(&key) else {
            return false;
        };
        if flow.dst != h.src || flow.dport != remote_port {
            return false;
        }
        *last = now;
        let flow = *flow;

        set_port(pkt, &h, local_at, flow.sport);
        set_address(pkt, &h, 16, flow.src);
        true
    }

    /// The port a flow is mapped to, mapping it first if it is new.
    fn map(&mut self, flow: Flow, now: Instant) -> Option<u16> {
        if let Some(&mapped) = self.out.get(&flow) {
            if let Some((_, last)) = self.back.get_mut(&(flow.proto, mapped)) {
                *last = now;
            }
            return Some(mapped);
        }
        if self.out.len() >= MAX_MAPPINGS {
            self.sweep(now);
            if self.out.len() >= MAX_MAPPINGS {
                return None;
            }
        }
        let mapped = self.allocate(flow.proto)?;
        self.out.insert(flow, mapped);
        self.back.insert((flow.proto, mapped), (flow, now));
        Some(mapped)
    }

    /// The next port of [`NAT_PORTS`] not in use for this protocol.
    fn allocate(&mut self, proto: u8) -> Option<u16> {
        let (start, end) = (*NAT_PORTS.start(), *NAT_PORTS.end());
        let span = usize::from(end - start) + 1;
        for _ in 0..span {
            let port = self.next;
            self.next = if port >= end { start } else { port + 1 };
            if !self.back.contains_key(&(proto, port)) {
                return Some(port);
            }
        }
        None
    }

    fn maybe_sweep(&mut self, now: Instant) {
        if now.duration_since(self.last_sweep) >= SWEEP_EVERY {
            self.sweep(now);
        }
    }

    /// Drops the mappings that have been idle for longer than their protocol allows.
    fn sweep(&mut self, now: Instant) {
        self.last_sweep = now;
        let expired: Vec<(u8, u16)> = self
            .back
            .iter()
            .filter(|((proto, _), (_, last))| now.duration_since(*last) > idle_for(*proto))
            .map(|(key, _)| *key)
            .collect();
        for key in expired {
            if let Some((flow, _)) = self.back.remove(&key) {
                self.out.remove(&flow);
            }
        }
    }

    /// Number of live mappings.
    pub fn len(&self) -> usize {
        self.back.len()
    }

    pub fn is_empty(&self) -> bool {
        self.back.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SYSTEM: Ipv4Addr = Ipv4Addr::new(198, 18, 0, 1);
    const WAN: Ipv4Addr = Ipv4Addr::new(172, 16, 0, 2);
    const REMOTE: Ipv4Addr = Ipv4Addr::new(1, 1, 1, 1);

    fn fold_sum(bytes: &[u8], init: u32) -> u32 {
        let mut sum = init;
        let mut chunks = bytes.chunks_exact(2);
        for c in &mut chunks {
            sum += u32::from(u16::from_be_bytes([c[0], c[1]]));
        }
        if let [last] = chunks.remainder() {
            sum += u32::from(*last) << 8;
        }
        sum
    }

    /// Checks the IP header checksum and the transport checksum from scratch.
    fn assert_checksums(pkt: &[u8]) {
        let ihl = usize::from(pkt[0] & 0x0f) * 4;
        let header = fold(fold_sum(&pkt[..ihl], 0));
        assert_eq!(header, 0xffff, "ip header checksum");
        let proto = pkt[9];
        let seg = &pkt[ihl..];
        match proto {
            PROTO_TCP | PROTO_UDP => {
                let mut pseudo = 0u32;
                pseudo += fold_sum(&pkt[12..20], 0);
                pseudo += u32::from(proto);
                pseudo += seg.len() as u32;
                let total = fold(fold_sum(seg, pseudo));
                assert_eq!(total, 0xffff, "transport checksum");
            }
            PROTO_ICMP => assert_eq!(fold(fold_sum(seg, 0)), 0xffff, "icmp checksum"),
            _ => {}
        }
    }

    fn udp(src: Ipv4Addr, sport: u16, dst: Ipv4Addr, dport: u16, payload: &[u8]) -> Vec<u8> {
        let total = 20 + 8 + payload.len();
        let mut p = vec![0u8; total];
        p[0] = 0x45;
        p[2..4].copy_from_slice(&(total as u16).to_be_bytes());
        p[8] = 64;
        p[9] = PROTO_UDP;
        p[12..16].copy_from_slice(&src.octets());
        p[16..20].copy_from_slice(&dst.octets());
        p[20..22].copy_from_slice(&sport.to_be_bytes());
        p[22..24].copy_from_slice(&dport.to_be_bytes());
        p[24..26].copy_from_slice(&((8 + payload.len()) as u16).to_be_bytes());
        p[28..].copy_from_slice(payload);
        fix_all(&mut p);
        p
    }

    fn tcp(src: Ipv4Addr, sport: u16, dst: Ipv4Addr, dport: u16, payload: &[u8]) -> Vec<u8> {
        let total = 20 + 20 + payload.len();
        let mut p = vec![0u8; total];
        p[0] = 0x45;
        p[2..4].copy_from_slice(&(total as u16).to_be_bytes());
        p[8] = 64;
        p[9] = PROTO_TCP;
        p[12..16].copy_from_slice(&src.octets());
        p[16..20].copy_from_slice(&dst.octets());
        p[20..22].copy_from_slice(&sport.to_be_bytes());
        p[22..24].copy_from_slice(&dport.to_be_bytes());
        p[32] = 0x50; // data offset 5
        p[40..].copy_from_slice(payload);
        fix_all(&mut p);
        p
    }

    fn icmp_echo(src: Ipv4Addr, dst: Ipv4Addr, kind: u8, ident: u16) -> Vec<u8> {
        let len = 20 + 8 + 4;
        let mut p = vec![0u8; len];
        p[0] = 0x45;
        p[2..4].copy_from_slice(&(len as u16).to_be_bytes());
        p[8] = 64;
        p[9] = PROTO_ICMP;
        p[12..16].copy_from_slice(&src.octets());
        p[16..20].copy_from_slice(&dst.octets());
        p[20] = kind;
        p[24..26].copy_from_slice(&ident.to_be_bytes());
        p[26..28].copy_from_slice(&1u16.to_be_bytes());
        fix_all(&mut p);
        p
    }

    /// Computes every checksum of a packet from scratch, as a sender would.
    fn fix_all(pkt: &mut [u8]) {
        let ihl = usize::from(pkt[0] & 0x0f) * 4;
        pkt[10..12].copy_from_slice(&[0, 0]);
        let hc = !fold(fold_sum(&pkt[..ihl], 0));
        pkt[10..12].copy_from_slice(&hc.to_be_bytes());
        let proto = pkt[9];
        match proto {
            PROTO_TCP | PROTO_UDP => {
                let at = ihl + if proto == PROTO_TCP { 16 } else { 6 };
                pkt[at..at + 2].copy_from_slice(&[0, 0]);
                let mut pseudo = fold_sum(&pkt[12..20], 0);
                pseudo += u32::from(proto);
                pseudo += (pkt.len() - ihl) as u32;
                let mut c = !fold(fold_sum(&pkt[ihl..], pseudo));
                if proto == PROTO_UDP && c == 0 {
                    c = 0xffff;
                }
                pkt[at..at + 2].copy_from_slice(&c.to_be_bytes());
            }
            PROTO_ICMP => {
                pkt[ihl + 2..ihl + 4].copy_from_slice(&[0, 0]);
                let c = !fold(fold_sum(&pkt[ihl..], 0));
                pkt[ihl + 2..ihl + 4].copy_from_slice(&c.to_be_bytes());
            }
            _ => {}
        }
    }

    fn src_of(p: &[u8]) -> Ipv4Addr {
        Ipv4Addr::new(p[12], p[13], p[14], p[15])
    }
    fn dst_of(p: &[u8]) -> Ipv4Addr {
        Ipv4Addr::new(p[16], p[17], p[18], p[19])
    }

    #[test]
    fn udp_round_trip_keeps_checksums_valid() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut out = udp(SYSTEM, 5353, REMOTE, 53, b"hello dns");
        assert!(nat.outbound(&mut out, now));
        assert_eq!(src_of(&out), WAN);
        assert_checksums(&out);
        let mapped = be16(&out, 20);
        assert!(NAT_PORTS.contains(&mapped));

        // The reply comes back from the remote to the mapped port.
        let mut reply = udp(REMOTE, 53, WAN, mapped, b"reply bytes");
        assert!(belongs_to_system(&reply));
        assert!(nat.inbound(&mut reply, now));
        assert_eq!(dst_of(&reply), SYSTEM);
        assert_eq!(be16(&reply, 22), 5353);
        assert_checksums(&reply);
    }

    #[test]
    fn tcp_flow_is_translated_both_ways() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut syn = tcp(SYSTEM, 40000, REMOTE, 443, b"");
        assert!(nat.outbound(&mut syn, now));
        assert_checksums(&syn);
        let mapped = be16(&syn, 20);

        let mut synack = tcp(REMOTE, 443, WAN, mapped, b"");
        assert!(nat.inbound(&mut synack, now));
        assert_eq!(dst_of(&synack), SYSTEM);
        assert_checksums(&synack);
    }

    #[test]
    fn same_flow_reuses_its_mapping() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut a = udp(SYSTEM, 1000, REMOTE, 53, b"a");
        let mut b = udp(SYSTEM, 1000, REMOTE, 53, b"b");
        nat.outbound(&mut a, now);
        nat.outbound(&mut b, now);
        assert_eq!(be16(&a, 20), be16(&b, 20));
        assert_eq!(nat.len(), 1);
    }

    #[test]
    fn distinct_flows_get_distinct_ports() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut a = udp(SYSTEM, 1000, REMOTE, 53, b"a");
        let mut b = udp(SYSTEM, 1001, REMOTE, 53, b"b");
        nat.outbound(&mut a, now);
        nat.outbound(&mut b, now);
        assert_ne!(be16(&a, 20), be16(&b, 20));
    }

    #[test]
    fn unsolicited_inbound_is_dropped() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut stray = udp(REMOTE, 53, WAN, 30000, b"nobody asked");
        assert!(!nat.inbound(&mut stray, now));
    }

    #[test]
    fn reply_from_a_different_host_is_dropped() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut out = udp(SYSTEM, 5353, REMOTE, 53, b"q");
        nat.outbound(&mut out, now);
        let mapped = be16(&out, 20);
        let mut spoof = udp(Ipv4Addr::new(9, 9, 9, 9), 53, WAN, mapped, b"x");
        assert!(!nat.inbound(&mut spoof, now));
    }

    #[test]
    fn inbound_to_other_address_is_dropped() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut out = udp(SYSTEM, 5353, REMOTE, 53, b"q");
        nat.outbound(&mut out, now);
        let mapped = be16(&out, 20);
        let mut other = udp(REMOTE, 53, Ipv4Addr::new(172, 16, 0, 9), mapped, b"x");
        assert!(!nat.inbound(&mut other, now));
    }

    #[test]
    fn icmp_echo_round_trip() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut req = icmp_echo(SYSTEM, REMOTE, ICMP_ECHO_REQUEST, 777);
        assert!(nat.outbound(&mut req, now));
        assert_eq!(src_of(&req), WAN);
        assert_checksums(&req);
        let mapped = be16(&req, 24);

        let mut reply = icmp_echo(REMOTE, WAN, ICMP_ECHO_REPLY, mapped);
        assert!(belongs_to_system(&reply));
        assert!(nat.inbound(&mut reply, now));
        assert_eq!(dst_of(&reply), SYSTEM);
        assert_eq!(be16(&reply, 24), 777);
        assert_checksums(&reply);
    }

    #[test]
    fn icmp_other_than_echo_is_dropped() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut unreachable = icmp_echo(SYSTEM, REMOTE, 3, 1);
        assert!(!nat.outbound(&mut unreachable, now));
    }

    #[test]
    fn fragments_are_refused_and_claimed_by_the_system() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut frag = udp(SYSTEM, 5353, REMOTE, 53, b"part");
        frag[6] = 0x20; // more-fragments flag
        fix_all(&mut frag);
        assert!(!nat.outbound(&mut frag, now));
        assert!(belongs_to_system(&frag));
    }

    #[test]
    fn stack_traffic_stays_with_the_stack() {
        // A reply to a port the proxy stack uses is not the system's.
        let stack_reply = tcp(REMOTE, 443, WAN, 50000, b"");
        assert!(!belongs_to_system(&stack_reply));
        let system_reply = tcp(REMOTE, 443, WAN, 25000, b"");
        assert!(belongs_to_system(&system_reply));
    }

    #[test]
    fn idle_mappings_expire() {
        let mut nat = Nat::new(WAN);
        let start = Instant::now();
        let mut out = udp(SYSTEM, 5353, REMOTE, 53, b"q");
        nat.outbound(&mut out, start);
        assert_eq!(nat.len(), 1);
        let later = start + UDP_IDLE + Duration::from_secs(1);
        nat.sweep(later);
        assert!(nat.is_empty());
    }

    #[test]
    fn udp_zero_checksum_stays_zero() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        let mut out = udp(SYSTEM, 5353, REMOTE, 53, b"q");
        out[26] = 0;
        out[27] = 0;
        assert!(nat.outbound(&mut out, now));
        assert_eq!(be16(&out, 26), 0, "no checksum was computed, none is added");
    }

    #[test]
    fn incremental_matches_full_recompute() {
        let mut nat = Nat::new(WAN);
        let now = Instant::now();
        for payload_len in [0usize, 1, 2, 7, 64, 1200] {
            let payload = vec![0xa5u8; payload_len];
            let mut p = tcp(SYSTEM, 42000, REMOTE, 80, &payload);
            assert!(nat.outbound(&mut p, now));
            assert_checksums(&p);
        }
    }
}
