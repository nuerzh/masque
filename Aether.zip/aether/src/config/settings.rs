//! The run's settings: every AETHER_* value the core reads, built once when a run starts from
//! the options of the config file (`options::settings_from`). The AETHER_* names are only
//! internal keys now: the process environment is not read.
//!
//! Layers, highest first: the config file's options, what the config's inbounds imply (only
//! where no option gave the key, `decide_default`), the built-in default of whoever reads the
//! key. `install` publishes a run's `Settings`; what the
//! run decides on its way up (an answer on the terminal, a Zero Trust enrolment, the socket mark
//! TUN mode picks) goes in a separate layer above it (`decide`), which the next `install`
//! clears, as does the end of the run (`uninstall`).

use std::collections::HashMap;
use std::sync::{Arc, LazyLock};

use parking_lot::RwLock;

/// The settings as the config file's options give them.
#[derive(Debug, Clone, Default)]
pub struct Settings {
    values: HashMap<String, String>,
}

impl Settings {
    /// The AETHER_* entries of `vars`.
    #[cfg(test)]
    pub fn from_vars(vars: impl IntoIterator<Item = (String, String)>) -> Settings {
        Settings {
            values: vars.into_iter().filter(|(k, _)| k.starts_with("AETHER_")).collect(),
        }
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.values.get(key).map(String::as_str)
    }

    pub fn set(&mut self, key: &str, value: &str) {
        self.values.insert(key.to_string(), value.to_string());
    }

    /// Add `value` to a comma separated list (a flag given twice, or on top of its variable).
    #[cfg(test)]
    pub fn append_list(&mut self, key: &str, value: &str) {
        match self.values.get_mut(key) {
            Some(existing) if !existing.trim().is_empty() => {
                existing.push(',');
                existing.push_str(value);
            }
            _ => self.set(key, value),
        }
    }
}

/// A key that is not set, as `std::env::var` reports one, so that `var` reads the same.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct NotSet;

impl std::fmt::Display for NotSet {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("not set")
    }
}

struct State {
    /// The running core's settings; `None` between runs, when nothing is set (library calls
    /// that start no core run; the unit tests read the environment then).
    base: Option<Arc<Settings>>,
    /// `None` unsets a key the base has.
    decided: HashMap<String, Option<String>>,
}

static STATE: LazyLock<RwLock<State>> = LazyLock::new(|| {
    RwLock::new(State {
        base: None,
        decided: HashMap::new(),
    })
});

/// Publish a run's settings; the decisions of an earlier run go with it.
pub fn install(settings: Settings) {
    let mut state = STATE.write();
    state.base = Some(Arc::new(settings));
    state.decided.clear();
}

/// The run is over: back to the environment as it is, with nothing decided.
pub fn uninstall() {
    let mut state = STATE.write();
    state.base = None;
    state.decided.clear();
}

/// The value of `key`: what the run decided, else what the command line or the environment
/// gave.
pub fn var(key: &str) -> Result<String, NotSet> {
    let state = STATE.read();
    match state.decided.get(key) {
        Some(Some(value)) => Ok(value.clone()),
        Some(None) => Err(NotSet),
        None => match &state.base {
            Some(base) => base.get(key).map(str::to_string).ok_or(NotSet),
            #[cfg(test)]
            None => std::env::var(key).map_err(|_| NotSet),
            #[cfg(not(test))]
            None => Err(NotSet),
        },
    }
}

/// Whether `key` holds something other than blanks.
pub fn is_set(key: &str) -> bool {
    var(key).is_ok_and(|v| !v.trim().is_empty())
}

/// Record what the run decided for `key`, over the command line and the environment.
pub fn decide(key: &str, value: impl Into<String>) {
    STATE.write().decided.insert(key.to_string(), Some(value.into()));
}

/// `key` as if it had never been given.
pub fn forget(key: &str) {
    STATE.write().decided.insert(key.to_string(), None);
}

/// `decide`, but only where nothing gave `key` yet: the config file's layer, under the command
/// line and the environment.
pub fn decide_default(key: &str, value: impl Into<String>) {
    if !is_set(key) {
        decide(key, value);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_aether_variables_are_taken_and_lists_grow() {
        let mut s = Settings::from_vars([
            ("AETHER_TUN_INCLUDE".to_string(), "10.0.0.0/8".to_string()),
            ("HOME".to_string(), "/root".to_string()),
        ]);
        assert_eq!(s.get("HOME"), None);
        s.append_list("AETHER_TUN_INCLUDE", "192.168.0.0/16");
        s.append_list("AETHER_TUN_EXCLUDE", "1.1.1.1/32");
        assert_eq!(s.get("AETHER_TUN_INCLUDE"), Some("10.0.0.0/8,192.168.0.0/16"));
        assert_eq!(s.get("AETHER_TUN_EXCLUDE"), Some("1.1.1.1/32"));
    }

    #[test]
    fn decisions_sit_over_the_base_and_can_unset_it() {
        // a key no other test reads
        let key = "AETHER_SETTINGS_SELF_TEST";
        assert_eq!(var(key), Err(NotSet));
        decide_default(key, "file");
        assert_eq!(var(key).as_deref(), Ok("file"));
        decide_default(key, "ignored");
        assert_eq!(var(key).as_deref(), Ok("file"));
        decide(key, "answer");
        assert_eq!(var(key).as_deref(), Ok("answer"));
        forget(key);
        assert!(var(key).is_err());
        assert!(!is_set(key));
    }

    #[test]
    fn scan_switch_values_read_as_on_or_off() {
        use crate::transport::warp::prober::parse_scan_switch;
        assert_eq!(parse_scan_switch("off"), Some(false));
        assert_eq!(parse_scan_switch(" 0 "), Some(false));
        assert_eq!(parse_scan_switch("ON"), Some(true));
        assert_eq!(parse_scan_switch("sometimes"), None);
    }
}
