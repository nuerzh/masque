//! The config file: one YAML document, `-c` (default `aether.yaml`). It holds everything a run
//! is configured with:
//!
//! - the options (`config::options`: top-level keys and the sections `scan`, `masque`, `tls`,
//!   `zero-trust`, `tun`, `advanced`);
//! - the WARP MASQUE identity Aether registers and keeps up to date itself (`device_id`,
//!   `access_token`, `cert_pem`, `key_pem`, ...: see `config::identity`);
//! - `sunny`: the sunnyquic client of protocol sunny (direct, or inside WARP with
//!   `detour: warp`) and sunny-direct, the keys of sunny-config;
//! - `inbounds`, `outbounds`, `route` (with `rules`, `rule_set`, `final`,
//!   `default_domain_resolver`) and `dns`, with sing-box's field names, written in YAML.
//!
//! The option `route-config` names a second YAML document whose `inbounds`, `outbounds`,
//! `route` and `dns` are used instead of the config file's. JSON configs are not read.

use std::path::{Path, PathBuf};

use serde_json::Value;

/// The tables that make up the routed part of a config: what `routing` hands to the router
/// and the inbounds.
pub const ROUTING_KEYS: &[&str] = &["inbounds", "outbounds", "route", "dns"];

/// The identity Aether writes into the config file (`config::identity::PersistedIdentity`).
pub const IDENTITY_KEYS: &[&str] = &[
    "device_id",
    "access_token",
    "cert_pem",
    "key_pem",
    "cert_issued_at",
    "ipv4",
    "ipv6",
    "wg_private_key",
    "wg_peer_public_key",
    "client_id",
    "organization",
    "gateway_proxy",
    "assigned_endpoint",
];

/// Top-level keys of earlier builds that are options of the scan section now.
const MOVED_SCAN_KEYS: &[(&str, &str, &str)] = &[
    ("scan_max_rtt", "scan", "max-rtt"),
    ("scan-max-rtt", "scan", "max-rtt"),
    ("scan_rounds", "scan", "rounds"),
    ("scan-rounds", "scan", "rounds"),
    ("scan_switch", "scan", "switch"),
    ("scan-switch", "scan", "switch"),
];

/// Top-level sections of a sing-box config that mean nothing to Aether.
const SING_BOX_IGNORED: &[&str] = &["log", "experimental", "ntp", "endpoints", "services", "certificate", "providers"];

/// The config file of the run (`-c`, default aether.yaml).
pub fn main_path() -> String {
    crate::config::settings::var("AETHER_CONFIG")
        .ok()
        .filter(|p| !p.trim().is_empty())
        .unwrap_or_else(|| super::DEFAULT_CONFIG.to_string())
}

/// The directory relative paths in `path` are taken from.
pub fn base_dir(path: &Path) -> PathBuf {
    path.parent().map(Path::to_path_buf).unwrap_or_default()
}

/// The YAML document at `path`; `None` when there is no such file. A file that is not YAML is
/// an error naming where it stops being YAML.
pub fn read_table(path: &Path) -> Result<Option<toml::Table>, String> {
    let text = match std::fs::read_to_string(path) {
        Ok(t) => t,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(e) => return Err(format!("{}: {e}", path.display())),
    };
    parse_table(&text).map(Some).map_err(|e| format!("{}: {e}", path.display()))
}

/// A YAML document as the table of its top level (`config::yaml::parse_table`).
pub fn parse_table(text: &str) -> Result<toml::Table, String> {
    crate::config::yaml::parse_table(text)
}

/// A config value (as the table reads it) as the JSON value sing-box's field parsers take.
pub fn to_json(v: &toml::Value) -> Value {
    match v {
        toml::Value::String(s) => Value::String(s.clone()),
        toml::Value::Integer(i) => Value::from(*i),
        toml::Value::Float(f) => serde_json::Number::from_f64(*f).map(Value::Number).unwrap_or(Value::Null),
        toml::Value::Boolean(b) => Value::Bool(*b),
        toml::Value::Datetime(d) => Value::String(d.to_string()),
        toml::Value::Array(a) => Value::Array(a.iter().map(to_json).collect()),
        toml::Value::Table(t) => table_to_json(t),
    }
}

pub fn table_to_json(t: &toml::Table) -> Value {
    Value::Object(t.iter().map(|(k, v)| (k.clone(), to_json(v))).collect())
}

/// The routed part of a document: `route` (empty when only inbounds or outbounds are given),
/// `outbounds`, `inbounds`, `dns`. `None` when it has none of them.
pub fn routing_part(t: &toml::Table, what: &str) -> Result<Option<Value>, String> {
    if !ROUTING_KEYS.iter().any(|k| t.contains_key(*k)) {
        return Ok(None);
    }
    let mut out = serde_json::Map::new();
    for key in ROUTING_KEYS {
        if let Some(v) = t.get(*key) {
            let shape_ok = match *key {
                "inbounds" | "outbounds" => v.is_array(),
                _ => v.is_table(),
            };
            if !shape_ok {
                let shape = if matches!(*key, "inbounds" | "outbounds") {
                    format!("a list of mappings ({key}: [- type: ...])")
                } else {
                    format!("a mapping ({key}: ...)")
                };
                return Err(format!("{what}: {key} must be {shape}"));
            }
            out.insert(key.to_string(), to_json(v));
        }
    }
    out.entry("route").or_insert_with(|| Value::Object(Default::default()));
    Ok(Some(Value::Object(out)))
}

/// Keys of the config file that nothing reads, as warnings.
fn check_main_keys(t: &toml::Table, what: &str, warn: &mut dyn FnMut(String)) -> Result<(), String> {
    for key in t.keys() {
        let k = key.as_str();
        if ROUTING_KEYS.contains(&k)
            || IDENTITY_KEYS.contains(&k)
            || crate::config::options::is_top_level_option(k)
            || k == "sunny"
        {
            continue;
        }
        if let Some((_, section, key)) = MOVED_SCAN_KEYS.iter().find(|(old, _, _)| *old == k) {
            warn(format!("{what}: {k} is read as {section}.{key} now (scan:\n  {key}: ...); ignored here"));
            continue;
        }
        if SING_BOX_IGNORED.contains(&k) {
            warn(format!("{what}: {k} is a sing-box section Aether does not use; ignored"));
        } else {
            warn(format!("{what}: unknown key {k:?} ignored"));
        }
    }
    Ok(())
}

/// The routed config of this run, as JSON, with the directory its relative paths are taken
/// from: the `route-config` YAML file when one is given, else the config file's own.
/// `None` when neither has any.
pub fn routing() -> Result<(Option<Value>, PathBuf), String> {
    routing_with(&mut |w| warn_once(w))
}

pub fn routing_with(warn: &mut dyn FnMut(String)) -> Result<(Option<Value>, PathBuf), String> {
    if let Some(given) = crate::config::settings::var("AETHER_ROUTE_CONFIG").ok().filter(|p| !p.trim().is_empty()) {
        let path = PathBuf::from(given.trim());
        let what = format!("route-config {}", path.display());
        if !path.extension().is_some_and(|e| e.eq_ignore_ascii_case("yaml") || e.eq_ignore_ascii_case("yml")) {
            return Err(format!(
                "{what}: a YAML file (.yaml) is expected; JSON route configs are not read, write \
                 the same fields in YAML"
            ));
        }
        let table = read_table(&path)?.ok_or_else(|| format!("{what}: no such file"))?;
        for key in table.keys() {
            if !ROUTING_KEYS.contains(&key.as_str()) {
                warn(format!("{what}: {key:?} is not read from a route-config file (only {})", ROUTING_KEYS.join(", ")));
            }
        }
        let value = routing_part(&table, &what)?
            .ok_or_else(|| format!("{what}: none of {} is there", ROUTING_KEYS.join(", ")))?;
        return Ok((Some(value), base_dir(&path)));
    }
    let path = PathBuf::from(main_path());
    let what = path.display().to_string();
    let Some(table) = read_table(&path)? else { return Ok((None, PathBuf::new())) };
    check_main_keys(&table, &what, warn)?;
    Ok((routing_part(&table, &what)?, base_dir(&path)))
}

/// `sunny` of the config file: the sunnyquic client settings, keys as sunny-config takes them
/// (`server-name` or `server_name` alike).
pub fn sunny_table() -> Result<Option<(toml::Table, String)>, String> {
    let path = PathBuf::from(main_path());
    let Some(table) = read_table(&path)? else { return Ok(None) };
    match table.get("sunny") {
        None => Ok(None),
        Some(toml::Value::Table(t)) => Ok(Some((t.clone(), format!("{} sunny", path.display())))),
        Some(_) => Err(format!("{}: sunny must be a mapping (sunny:\n  server: ...)", path.display())),
    }
}

fn warn_once(msg: String) {
    static SEEN: parking_lot::Mutex<Vec<String>> = parking_lot::Mutex::new(Vec::new());
    let mut seen = SEEN.lock();
    if !seen.contains(&msg) {
        log::warn!("[config] {msg}");
        seen.push(msg);
    }
}

/// A config written in TOML (as the tests have them), converted to YAML and read as the config
/// file is, as the router and the inbounds read it.
#[cfg(test)]
pub(crate) fn test_routing(text: &str) -> Value {
    let yaml = crate::config::yaml::yaml_of_toml(text);
    let table = parse_table(&yaml).unwrap_or_else(|e| panic!("{e}\n{yaml}"));
    routing_part(&table, "test.yaml").unwrap().expect("a routed config")
}

#[cfg(test)]
mod tests {
    use super::{check_main_keys, routing_part};
    use serde_json::json;
    use serde_json::Value;

    /// The tests write configs in TOML; they are read as the YAML they convert to.
    fn parse_table(text: &str) -> Result<toml::Table, String> {
        super::parse_table(&crate::config::yaml::yaml_of_toml(text))
    }

    fn routed(text: &str) -> Result<Option<Value>, String> {
        routing_part(&parse_table(text).unwrap(), "test.yaml")
    }

    #[test]
    fn identity_only_has_no_routing() {
        assert_eq!(routed("device_id = \"d\"\naccess_token = \"t\"\n").unwrap(), None);
    }

    #[test]
    fn inbounds_outbounds_route_and_dns_are_read_in_sing_box_shape() {
        let v = routed(
            r#"
device_id = "kept-by-aether"

[[inbounds]]
type = "mixed"
tag = "mixed-in"
listen = "127.0.0.1"
listen_port = 2080

[[inbounds]]
type = "sunnyquic"
tag = "sq-in"
listen = "0.0.0.0"
listen_port = 8443
users = [{ name = "1114", password = "314" }]
tls = { server_name = "www.bing.com", certificate_path = "./cert.pem", key_path = "./key.pem", alpn = ["h3"] }

[[outbounds]]
type = "sunnyquic"
tag = "hk"
server = "1.2.3.4"
server_port = 8443
username = "u"
password = "p"
detour = "warp"

[route]
final = "hk"
default_domain_resolver = { strategy = "prefer_ipv4" }

[[route.rules]]
domain_suffix = ["cn"]
outbound = "direct"

[[route.rules]]
type = "logical"
mode = "and"
rules = [{ network = "udp" }, { port = 443 }]
action = "reject"

[[route.rule_set]]
type = "inline"
tag = "ads"
rules = [{ domain_keyword = ["doubleclick"] }]

[dns]
servers = [{ tag = "local", type = "local" }]
"#,
        )
        .unwrap()
        .unwrap();
        assert_eq!(v["inbounds"][0]["listen_port"], json!(2080));
        assert_eq!(v["inbounds"][1]["users"][0]["name"], json!("1114"));
        assert_eq!(v["inbounds"][1]["tls"]["alpn"], json!(["h3"]));
        assert_eq!(v["outbounds"][0]["detour"], json!("warp"));
        assert_eq!(v["route"]["final"], json!("hk"));
        assert_eq!(v["route"]["rules"][1]["rules"][1]["port"], json!(443));
        assert_eq!(v["route"]["rule_set"][0]["rules"][0]["domain_keyword"], json!(["doubleclick"]));
        assert_eq!(v["dns"]["servers"][0]["type"], json!("local"));
        assert!(v.get("device_id").is_none(), "the identity is not part of the routing");
    }

    #[test]
    fn inbounds_alone_route_by_the_default_final() {
        let v = routed("[[inbounds]]\ntype = \"socks\"\nlisten_port = 1080\n").unwrap().unwrap();
        assert_eq!(v["route"], json!({}));
    }

    #[test]
    fn a_wrong_shape_is_named() {
        let e = routed("inbounds = { type = \"socks\" }\n").unwrap_err();
        assert!(e.contains("a list of mappings"), "{e}");
        let e = routed("route = \"direct\"\n").unwrap_err();
        assert!(e.contains("a mapping (route"), "{e}");
    }

    #[test]
    fn sing_box_sections_and_unknown_keys_are_warned_about() {
        let mut warnings = Vec::new();
        check_main_keys(&parse_table("device_id = \"d\"\n[log]\nlevel = \"info\"\n[routes]\n").unwrap(), "aether.yaml", &mut |w| warnings.push(w))
            .unwrap();
        assert_eq!(warnings.len(), 2, "{warnings:?}");
        assert!(warnings[0].contains("log") && warnings[1].contains("routes"), "{warnings:?}");
    }

    #[test]
    fn a_route_config_path_is_taken_from_the_config_files_directory() {
        let dir = crate::test_util::scratch_dir("route-json");
        let config = dir.join("aether.yaml");
        std::fs::write(&config, "route_config: route.json\n").unwrap();
        let settings = crate::config::load_settings(Some(&config.to_string_lossy()), crate::config::cli::Action::Run).unwrap();
        assert_eq!(settings.get("AETHER_ROUTE_CONFIG"), Some(dir.join("route.json").to_string_lossy().as_ref()));
        assert_eq!(settings.get("AETHER_CONFIG"), Some(config.to_string_lossy().as_ref()));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn options_and_moved_scan_keys_at_the_top_level() {
        let mut warnings = Vec::new();
        check_main_keys(
            &parse_table("bind = \"127.0.0.1:1\"\nscan = { max-rtt = 300 }\ntun = true\n").unwrap(),
            "aether.yaml",
            &mut |w| warnings.push(w),
        )
        .unwrap();
        assert!(warnings.is_empty(), "{warnings:?}");
        check_main_keys(&parse_table("scan_max_rtt = 300\n").unwrap(), "aether.yaml", &mut |w| warnings.push(w)).unwrap();
        assert!(warnings.len() == 1 && warnings[0].contains("scan.max-rtt"), "{warnings:?}");
    }

    #[test]
    fn the_shipped_examples_read_and_their_options_check() {
        let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../Docs/examples");
        for name in ["client-full.yaml", "route.yaml", "server.yaml", "tun-route.yaml"] {
            let path = dir.join(name);
            let table = super::read_table(&path).unwrap().unwrap_or_else(|| panic!("{name} missing"));
            crate::config::options::settings_from(&table, name).unwrap_or_else(|e| panic!("{e}"));
            let routed = routing_part(&table, name).unwrap().unwrap_or_else(|| panic!("{name}: no route"));
            assert!(routed["route"].get("final").is_some(), "{name}");
            let mut warnings = Vec::new();
            check_main_keys(&table, name, &mut |w| warnings.push(w)).unwrap();
            assert!(warnings.is_empty(), "{name}: {warnings:?}");
        }
    }

    #[test]
    fn yaml_that_does_not_parse_says_where() {
        let e = super::parse_table("route:\n  final: [direct\n").unwrap_err();
        assert!(e.contains("not valid YAML") && e.contains("line"), "{e}");
    }
}
