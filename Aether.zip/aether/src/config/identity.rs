use std::path::{Path, PathBuf};

use base64::Engine;
use serde::{Deserialize, Serialize};

use crate::transport::warp::account::Identity;
use crate::error::{AetherError, Result};

use super::file;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PersistedIdentity {
    pub device_id: String,
    pub access_token: String,
    #[serde(default)]
    pub cert_pem: String,
    #[serde(default)]
    pub key_pem: String,
    #[serde(default)]
    pub cert_issued_at: u64,
    pub ipv4: String,
    pub ipv6: String,
    pub wg_private_key: String,
    pub wg_peer_public_key: String,
    #[serde(default)]
    pub client_id: String,
    #[serde(default)]
    pub organization: String,
    #[serde(default)]
    pub gateway_proxy: String,
    #[serde(default)]
    pub assigned_endpoint: String,
}

impl From<&Identity> for PersistedIdentity {
    fn from(id: &Identity) -> Self {
        Self {
            device_id: id.device_id.clone(),
            access_token: id.access_token.clone(),
            cert_pem: String::from_utf8_lossy(&id.cert_pem).to_string(),
            key_pem: String::from_utf8_lossy(&id.key_pem).to_string(),
            cert_issued_at: id.cert_issued_at,
            ipv4: id.ipv4.clone(),
            ipv6: id.ipv6.clone(),
            wg_private_key: base64::engine::general_purpose::STANDARD.encode(id.wg_private_key),
            wg_peer_public_key: base64::engine::general_purpose::STANDARD
                .encode(id.wg_peer_public_key),
            client_id: base64::engine::general_purpose::STANDARD.encode(id.client_id),
            organization: id.organization.clone(),
            gateway_proxy: id.gateway_proxy.clone(),
            assigned_endpoint: id.assigned_endpoint.clone(),
        }
    }
}

fn decode_fixed<const N: usize>(field: &str, value: &str) -> Result<[u8; N]> {
    let decoded = base64::engine::general_purpose::STANDARD
        .decode(value)
        .map_err(|e| {
            AetherError::Other(format!("config field {field} is not valid base64: {e}"))
        })?;

    if decoded.len() != N {
        return Err(AetherError::Other(format!(
            "config field {field} must decode to {N} bytes, found {}",
            decoded.len()
        )));
    }

    let mut out = [0u8; N];
    out.copy_from_slice(&decoded);
    Ok(out)
}

impl TryFrom<PersistedIdentity> for Identity {
    type Error = AetherError;

    fn try_from(p: PersistedIdentity) -> Result<Self> {
        let wg_private_key = decode_fixed::<32>("wg_private_key", &p.wg_private_key)?;
        let wg_peer_public_key = decode_fixed::<32>("wg_peer_public_key", &p.wg_peer_public_key)?;

        let client_id = if p.client_id.is_empty() {
            [0u8; 3]
        } else {
            decode_fixed::<3>("client_id", &p.client_id).unwrap_or([0u8; 3])
        };

        Ok(Identity {
            device_id: p.device_id,
            access_token: p.access_token,
            cert_pem: p.cert_pem.into_bytes(),
            key_pem: p.key_pem.into_bytes(),
            cert_issued_at: p.cert_issued_at,
            ipv4: p.ipv4,
            ipv6: p.ipv6,
            wg_private_key,
            wg_peer_public_key,
            client_id,
            organization: p.organization,
            gateway_proxy: p.gateway_proxy,
            assigned_endpoint: p.assigned_endpoint,
            refused: false,
        })
    }
}

fn quarantine_path(path: &str) -> PathBuf {
    let mut target = PathBuf::from(path);
    let name = target
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "aether.yaml".to_string());
    target.set_file_name(format!("{name}.corrupt"));
    target
}

fn quarantine(path: &str) -> Option<PathBuf> {
    let target = quarantine_path(path);
    match std::fs::rename(path, &target) {
        Ok(()) => Some(target),
        Err(_) => None,
    }
}

/// Keys earlier builds wrote into an identity file next to the identity itself.
const LEGACY_IDENTITY_KEYS: &[&str] = &["warp_enabled"];

fn is_identity_key(key: &str) -> bool {
    file::IDENTITY_KEYS.contains(&key) || LEGACY_IDENTITY_KEYS.contains(&key)
}

/// A file holding nothing but an identity can be moved aside and registered again; one holding
/// the user's own settings never is.
fn only_identity(table: &toml::Table) -> bool {
    table.keys().all(|k| is_identity_key(k))
}

fn set_aside_or_explain(path: &str, problem: String) -> AetherError {
    AetherError::Other(match quarantine(path) {
        Some(target) => format!(
            "{problem}; the damaged file was moved to {} so a fresh identity can be provisioned",
            target.display()
        ),
        None => format!("{problem}; delete {path} to provision a fresh identity"),
    })
}

/// The identity saved in `path`: `None` when there is no such file or it holds no identity
/// (`device_id` / `access_token`), as a config file written by hand does before the first run.
pub fn load(path: &str) -> Result<Option<Identity>> {
    let yaml = yaml_file(path)?;
    let path = yaml.as_str();
    if !Path::new(path).exists() {
        return Ok(None);
    }

    let text = std::fs::read_to_string(path)?;

    let table: toml::Table = match file::parse_table(&text) {
        Ok(table) => table,
        // Only a file that is known to hold nothing but an identity is ever moved aside.
        Err(e) => {
            return Err(AetherError::Other(format!(
                "config parse: {path}: {e}; fix the YAML (the file was left as it is)"
            )))
        }
    };

    if !table.contains_key("device_id") && !table.contains_key("access_token") {
        return Ok(None);
    }

    let decoded = PersistedIdentity::deserialize(toml::Value::Table(table.clone()))
        .map_err(|e| AetherError::Other(format!("config identity: {}", e.to_string().trim_end())))
        .and_then(Identity::try_from);
    match decoded {
        Ok(identity) => Ok(Some(identity)),
        Err(e) if only_identity(&table) => {
            Err(set_aside_or_explain(path, e.to_string()))
        }
        Err(e) => Err(AetherError::Other(format!(
            "{e} in {path}; fix or remove the identity keys ({}) there to provision a fresh \
             identity (the rest of the file is kept)",
            file::IDENTITY_KEYS[..2].join(", ")
        ))),
    }
}

/// The YAML file a path stands for: a `.toml` one (as a library caller of an earlier build may
/// still name) is converted to the `.yaml` beside it.
fn yaml_file(path: &str) -> Result<String> {
    if crate::config::migrate::is_toml(path) {
        crate::config::migrate::adopt(path).map_err(AetherError::Other)
    } else {
        Ok(path.to_string())
    }
}

fn write_private(path: &str, contents: &str) -> Result<()> {
    let target = Path::new(path);
    let directory = target.parent().filter(|p| !p.as_os_str().is_empty());
    if let Some(dir) = directory {
        std::fs::create_dir_all(dir)?;
    }

    let mut temporary = PathBuf::from(path);
    let name = temporary
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "aether.yaml".to_string());
    temporary.set_file_name(format!(".{name}.{}.tmp", std::process::id()));

    let outcome = (|| -> Result<()> {
        {
            use std::io::Write;

            let mut options = std::fs::OpenOptions::new();
            options.write(true).create(true).truncate(true);

            #[cfg(unix)]
            {
                use std::os::unix::fs::OpenOptionsExt;
                options.mode(0o600);
            }

            let mut file = options.open(&temporary)?;
            file.write_all(contents.as_bytes())?;
            file.flush()?;
            file.sync_all()?;
        }

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&temporary, std::fs::Permissions::from_mode(0o600))?;
        }

        std::fs::rename(&temporary, target)?;
        Ok(())
    })();

    if outcome.is_err() {
        let _ = std::fs::remove_file(&temporary);
    }

    outcome
}

/// The identity as the keys and values it is written with.
fn identity_values(p: &PersistedIdentity) -> Vec<(&'static str, toml::Value)> {
    let s = |v: &str| toml::Value::String(v.to_string());
    vec![
        ("device_id", s(&p.device_id)),
        ("access_token", s(&p.access_token)),
        ("cert_pem", s(&p.cert_pem)),
        ("key_pem", s(&p.key_pem)),
        ("cert_issued_at", toml::Value::Integer(i64::try_from(p.cert_issued_at).unwrap_or(i64::MAX))),
        ("ipv4", s(&p.ipv4)),
        ("ipv6", s(&p.ipv6)),
        ("wg_private_key", s(&p.wg_private_key)),
        ("wg_peer_public_key", s(&p.wg_peer_public_key)),
        ("client_id", s(&p.client_id)),
        ("organization", s(&p.organization)),
        ("gateway_proxy", s(&p.gateway_proxy)),
        ("assigned_endpoint", s(&p.assigned_endpoint)),
    ]
}

const IDENTITY_HEADER: &str = "# WARP identity: written and kept up to date by Aether";

/// `key: value` as the YAML lines it is written with.
fn entry_lines(key: &str, value: &toml::Value) -> Result<Vec<String>> {
    let mut one = toml::Table::new();
    one.insert(key.to_string(), value.clone());
    let text = crate::config::yaml::table_to_string(&one).map_err(AetherError::Other)?;
    Ok(text.lines().map(str::to_string).collect())
}

/// Whether `line` starts the top-level key `key` (`key:`, or the key quoted).
fn starts_key(line: &str, key: &str) -> bool {
    for written in [key.to_string(), format!("\"{key}\""), format!("'{key}'")] {
        if let Some(rest) = line.strip_prefix(&written) {
            if rest.trim_start().starts_with(':') {
                return true;
            }
        }
    }
    false
}

/// The lines of the top-level entry `key`: from its key to the next line at the left margin
/// (another key, a comment, a document marker), without the blank lines before that one.
fn entry_span(lines: &[String], key: &str) -> Option<(usize, usize)> {
    let start = lines.iter().position(|l| starts_key(l, key))?;
    let mut end = start + 1;
    while end < lines.len() {
        let l = &lines[end];
        if !l.trim().is_empty() && !l.starts_with([' ', '\t']) {
            break;
        }
        end += 1;
    }
    while end > start + 1 && lines[end - 1].trim().is_empty() {
        end -= 1;
    }
    Some((start, end))
}

/// `text` (the file as it is, empty for none) with the identity written into its top level.
/// Every other key and comment stays as the user left it, a value that did not change keeps
/// its own lines, and the keys not there yet are added at the end under a comment.
pub(crate) fn render(text: &str, persisted: &PersistedIdentity) -> Result<String> {
    let current = file::parse_table(text).map_err(|e| AetherError::Other(format!("config parse: {e}")))?;
    let values = identity_values(persisted);
    let mut lines: Vec<String> = text.lines().map(str::to_string).collect();
    let had_identity = values.iter().any(|(k, _)| current.contains_key(*k));
    let mut header_written = had_identity;
    for (key, value) in &values {
        if current.get(*key) == Some(value) {
            continue;
        }
        let new = entry_lines(key, value)?;
        match entry_span(&lines, key) {
            Some((start, end)) => {
                lines.splice(start..end, new);
            }
            None => {
                if !header_written {
                    while lines.last().is_some_and(|l| l.trim().is_empty()) {
                        lines.pop();
                    }
                    if !lines.is_empty() {
                        lines.push(String::new());
                    }
                    lines.push(IDENTITY_HEADER.to_string());
                    header_written = true;
                }
                lines.extend(new);
            }
        }
    }
    let mut out = lines.join("\n");
    out.push('\n');
    // what was spliced in must read back as the identity, with the rest as it was
    let back = file::parse_table(&out).ok();
    let faithful = back.as_ref().is_some_and(|b| {
        values.iter().all(|(k, v)| b.get(*k) == Some(v))
            && current.iter().all(|(k, v)| values.iter().any(|(ik, _)| ik == k) || b.get(k) == Some(v))
    });
    if faithful {
        return Ok(out);
    }
    // a layout the lines cannot be spliced into (a flow mapping, an indented document): the
    // whole document written again, its comments lost
    log::warn!("[config] the identity could not be written into the file as it is laid out; it is written again whole (comments are not kept)");
    let mut table = current;
    for (key, value) in values {
        table.insert(key.to_string(), value);
    }
    crate::config::yaml::table_to_string(&table).map_err(AetherError::Other)
}

fn write_identity(path: &str, persisted: &PersistedIdentity) -> Result<()> {
    let old = match std::fs::read_to_string(path) {
        Ok(text) => Some(text),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => None,
        Err(e) => return Err(e.into()),
    };
    let text = render(old.as_deref().unwrap_or(""), persisted)
        .map_err(|e| AetherError::Other(format!("{e} in {path}; the identity was not saved")))?;
    if old.as_deref() == Some(text.as_str()) {
        return Ok(());
    }
    write_private(path, &text)
}

pub fn save(path: &str, identity: &Identity) -> Result<()> {
    write_identity(&yaml_file(path)?, &PersistedIdentity::from(identity))
}

#[cfg(test)]
pub fn save_masque_creds(
    path: &str,
    cert_pem: &[u8],
    key_pem: &[u8],
    issued_at: u64,
) -> Result<()> {
    if !Path::new(path).exists() {
        return Ok(());
    }

    let text = std::fs::read_to_string(path)?;
    let mut persisted: PersistedIdentity =
        serde_yaml_ng::from_str(&text).map_err(|e| AetherError::Other(format!("config parse: {e}")))?;

    persisted.cert_pem = String::from_utf8_lossy(cert_pem).to_string();
    persisted.key_pem = String::from_utf8_lossy(key_pem).to_string();
    persisted.cert_issued_at = issued_at;

    write_identity(path, &persisted)
}

#[cfg(test)]
mod config_file_tests {
    use super::*;

    fn persisted() -> PersistedIdentity {
        PersistedIdentity {
            device_id: "d".into(),
            access_token: "t".into(),
            cert_pem: "-----BEGIN CERTIFICATE-----\nAAAA\n-----END CERTIFICATE-----\n".into(),
            key_pem: String::new(),
            cert_issued_at: 0,
            ipv4: "172.16.0.2".into(),
            ipv6: String::new(),
            wg_private_key: String::new(),
            wg_peer_public_key: String::new(),
            client_id: String::new(),
            organization: String::new(),
            gateway_proxy: String::new(),
            assigned_endpoint: String::new(),
        }
    }

    fn scratch(name: &str) -> PathBuf {
        let dir = crate::test_util::scratch(&format!("cfg-{name}"));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    const USER_CONFIG: &str = r#"# my aether config
log_note: kept   # a key Aether does not know

sunny:
  server: sq.example.com:443   # my server

inbounds:
  - type: mixed
    listen_port: 2080

route:
  # everything direct for now
  final: direct
"#;

    #[test]
    fn the_identity_goes_to_the_end_and_the_users_keys_and_comments_stay() {
        let text = render(USER_CONFIG, &persisted()).unwrap();
        assert!(text.starts_with(USER_CONFIG), "{text}");
        for kept in ["# my server", "# everything direct for now", "# a key Aether does not know", "  - type: mixed"] {
            assert!(text.contains(kept), "{kept} lost:\n{text}");
        }
        assert!(text.contains(IDENTITY_HEADER), "{text}");
        let back = file::parse_table(&text).unwrap();
        assert_eq!(back["device_id"].as_str(), Some("d"));
        assert_eq!(back["route"]["final"].as_str(), Some("direct"));
        assert_eq!(back["inbounds"][0]["listen_port"].as_integer(), Some(2080));
        assert_eq!(back["sunny"]["server"].as_str(), Some("sq.example.com:443"));
        assert_eq!(back["cert_pem"].as_str(), Some(persisted().cert_pem.as_str()));
        // the identity keys are top-level keys, not keys of the last mapping
        assert!(back["route"].get("device_id").is_none());
        assert!(text.find("device_id").unwrap() > text.find("final: direct").unwrap(), "{text}");
    }

    #[test]
    fn a_changed_value_keeps_its_comment_and_an_unchanged_file_renders_the_same() {
        let first = render(USER_CONFIG, &persisted()).unwrap();
        assert_eq!(render(&first, &persisted()).unwrap(), first);
        assert!(first.contains("access_token: t\n"), "{first}");
        let commented = first.replace("access_token: t\n", "# from the API\naccess_token: t\n");
        let mut p = persisted();
        p.access_token = "t2".into();
        let second = render(&commented, &p).unwrap();
        assert!(second.contains("# from the API\naccess_token: t2\n"), "{second}");
        // a multi-line value replaced in place, the keys after it kept
        p.cert_pem = "-----BEGIN CERTIFICATE-----\nBBBB\nCCCC\n-----END CERTIFICATE-----\n".into();
        let third = render(&second, &p).unwrap();
        let back = file::parse_table(&third).unwrap();
        assert_eq!(back["cert_pem"].as_str(), Some(p.cert_pem.as_str()));
        assert_eq!(back["ipv4"].as_str(), Some("172.16.0.2"));
        assert!(!third.contains("AAAA"), "{third}");
        assert_eq!(third.matches("cert_pem").count(), 1, "{third}");
    }

    #[cfg(unix)]
    #[test]
    fn saving_the_same_identity_does_not_rewrite_the_file() {
        use std::os::unix::fs::PermissionsExt;
        let dir = scratch("unchanged");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();
        std::fs::write(&path, USER_CONFIG).unwrap();
        write_identity(path_str, &persisted()).unwrap();
        assert_eq!(std::fs::metadata(&path).unwrap().permissions().mode() & 0o777, 0o600);
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
        write_identity(path_str, &persisted()).unwrap();
        assert_eq!(std::fs::metadata(&path).unwrap().permissions().mode() & 0o777, 0o644, "rewritten");
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn a_config_without_an_identity_has_none() {
        let dir = scratch("noidentity");
        let path = dir.join("aether.yaml");
        std::fs::write(&path, USER_CONFIG).unwrap();
        assert!(load(path.to_str().unwrap()).unwrap().is_none());
        assert_eq!(std::fs::read_to_string(&path).unwrap(), USER_CONFIG);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn a_bad_identity_next_to_the_users_settings_is_reported_and_the_file_kept() {
        let dir = scratch("badmixed");
        let path = dir.join("aether.yaml");
        let body = format!("device_id: d\naccess_token: t\nipv4: x\nipv6: y\nwg_private_key: AAAA\nwg_peer_public_key: AAAA\n{USER_CONFIG}");
        std::fs::write(&path, &body).unwrap();
        let e = load(path.to_str().unwrap()).unwrap_err().to_string();
        assert!(e.contains("wg_private_key") && e.contains("the rest of the file is kept"), "{e}");
        assert_eq!(std::fs::read_to_string(&path).unwrap(), body);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn a_config_that_is_not_yaml_is_never_moved() {
        let dir = scratch("syntax");
        let path = dir.join("aether.yaml");
        std::fs::write(&path, "route:\n  final: [direct\n").unwrap();
        let e = load(path.to_str().unwrap()).unwrap_err().to_string();
        assert!(e.contains("fix the YAML"), "{e}");
        assert!(path.exists());
        assert!(save(path.to_str().unwrap(), &Identity::try_from(persisted_full()).unwrap()).is_err());
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "route:\n  final: [direct\n");
        let _ = std::fs::remove_dir_all(dir);
    }

    fn persisted_full() -> PersistedIdentity {
        let zeros = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=".to_string();
        PersistedIdentity { wg_private_key: zeros.clone(), wg_peer_public_key: zeros, ..persisted() }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::transport::warp::account::Identity;

    fn scratch(name: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "aether-config-test-{}-{}",
            std::process::id(),
            name
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("scratch directory");
        dir
    }

    fn sample() -> Identity {
        Identity {
            device_id: "device-1".to_string(),
            access_token: "token-1".to_string(),
            cert_pem: b"-----BEGIN CERTIFICATE-----".to_vec(),
            key_pem: b"-----BEGIN PRIVATE KEY-----".to_vec(),
            cert_issued_at: 1_700_000_000,
            ipv4: "172.16.0.2".to_string(),
            ipv6: "2606:4700::2".to_string(),
            wg_private_key: [7u8; 32],
            wg_peer_public_key: [9u8; 32],
            client_id: [1, 2, 3],
            organization: "example-team".to_string(),
            gateway_proxy: "172.16.0.1:2480".to_string(),
            assigned_endpoint: "162.159.197.2".to_string(),
            refused: false,
        }
    }

    #[test]
    fn saves_and_loads_every_field_including_the_issue_time() {
        let dir = scratch("roundtrip");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        save(path_str, &sample()).expect("save should succeed");
        let loaded = load(path_str)
            .expect("load should succeed")
            .expect("identity");

        assert_eq!(loaded.device_id, "device-1");
        assert_eq!(loaded.access_token, "token-1");
        assert_eq!(loaded.cert_issued_at, 1_700_000_000);
        assert_eq!(loaded.wg_private_key, [7u8; 32]);
        assert_eq!(loaded.wg_peer_public_key, [9u8; 32]);
        assert_eq!(loaded.client_id, [1, 2, 3]);
    }

    #[test]
    fn a_file_that_records_warp_as_an_earlier_build_did_still_loads() {
        let dir = scratch("warprecord");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        let zeros = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=";
        let body = format!(
            "device_id: d\naccess_token: t\nipv4: 172.16.0.2\nipv6: \"::1\"\n\
             wg_private_key: \"{zeros}\"\nwg_peer_public_key: \"{zeros}\"\nwarp_enabled: true\n"
        );
        std::fs::write(&path, body).expect("write");

        let loaded = load(path_str).expect("load").expect("identity");
        assert_eq!(loaded.device_id, "d");
    }

    #[cfg(unix)]
    #[test]
    fn the_secret_file_is_only_readable_by_its_owner() {
        use std::os::unix::fs::PermissionsExt;

        let dir = scratch("perms");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        save(path_str, &sample()).expect("save should succeed");

        let mode = std::fs::metadata(&path)
            .expect("metadata")
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(mode, 0o600, "found mode {mode:o}, expected 600");
    }

    #[test]
    fn saving_leaves_no_temporary_file_behind() {
        let dir = scratch("atomic");
        let path = dir.join("aether.yaml");

        save(path.to_str().unwrap(), &sample()).expect("save should succeed");

        let leftovers: Vec<String> = std::fs::read_dir(&dir)
            .expect("read dir")
            .filter_map(|entry| entry.ok())
            .map(|entry| entry.file_name().to_string_lossy().to_string())
            .filter(|name| name.ends_with(".tmp"))
            .collect();

        assert!(leftovers.is_empty(), "temporary files left: {leftovers:?}");
    }

    #[test]
    fn overwriting_an_existing_config_keeps_it_readable() {
        let dir = scratch("overwrite");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        save(path_str, &sample()).expect("first save");
        let mut second = sample();
        second.device_id = "device-2".to_string();
        save(path_str, &second).expect("second save");

        let loaded = load(path_str).expect("load").expect("identity");
        assert_eq!(loaded.device_id, "device-2");
    }

    #[test]
    fn a_corrupt_config_is_reported_and_left_in_place() {
        let dir = scratch("corrupt");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        std::fs::write(&path, "this: is: not [valid yaml").expect("write");

        let outcome = load(path_str);
        assert!(outcome.is_err(), "a corrupt config must be an error");
        assert!(path.exists(), "a file that is not YAML is the user's to fix, never moved");
        assert!(!dir.join("aether.yaml.corrupt").exists());
    }

    #[test]
    fn a_damaged_identity_file_is_set_aside() {
        let dir = scratch("damaged");
        let path = dir.join("aether-masque.yaml");
        let body = "device_id: d\naccess_token: t\nipv4: a\nipv6: b\nwg_private_key: AAAA\nwg_peer_public_key: AAAA\nwarp_enabled: true\n";
        std::fs::write(&path, body).expect("write");
        assert!(load(path.to_str().unwrap()).is_err());
        assert!(!path.exists(), "an identity-only file is moved aside");
        assert!(dir.join("aether-masque.yaml.corrupt").exists());
    }

    #[test]
    fn a_truncated_key_is_an_error_not_a_panic() {
        let dir = scratch("shortkey");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        let body = "\
device_id: d
access_token: t
cert_pem: ''
key_pem: ''
cert_issued_at: 0
ipv4: 172.16.0.2
ipv6: '::1'
wg_private_key: AAAA
wg_peer_public_key: AAAA
client_id: ''
";
        std::fs::write(&path, body).expect("write");

        let outcome = load(path_str);
        assert!(outcome.is_err(), "a short key must be rejected");
        let message = format!("{}", outcome.err().unwrap());
        assert!(
            message.contains("wg_private_key"),
            "the error should name the bad field, got: {message}"
        );
    }

    #[test]
    fn a_key_that_is_not_base64_is_an_error_not_a_panic() {
        let dir = scratch("badbase64");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        let body = "\
device_id: d
access_token: t
ipv4: 172.16.0.2
ipv6: '::1'
wg_private_key: '!!!not base64!!!'
wg_peer_public_key: AAAA
";
        std::fs::write(&path, body).expect("write");

        assert!(load(path_str).is_err());
    }

    #[test]
    fn a_missing_config_is_simply_absent() {
        let dir = scratch("missing");
        let path = dir.join("aether.yaml");
        assert!(load(path.to_str().unwrap()).expect("load").is_none());
    }

    #[test]
    fn refreshing_the_masque_credentials_records_the_new_issue_time() {
        let dir = scratch("creds");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        save(path_str, &sample()).expect("save");
        save_masque_creds(path_str, b"new-cert", b"new-key", 1_800_000_000).expect("update");

        let loaded = load(path_str).expect("load").expect("identity");
        assert_eq!(loaded.cert_pem, b"new-cert".to_vec());
        assert_eq!(loaded.key_pem, b"new-key".to_vec());
        assert_eq!(loaded.cert_issued_at, 1_800_000_000);
    }

    #[cfg(unix)]
    #[test]
    fn refreshing_the_credentials_keeps_the_restrictive_permissions() {
        use std::os::unix::fs::PermissionsExt;

        let dir = scratch("credperms");
        let path = dir.join("aether.yaml");
        let path_str = path.to_str().unwrap();

        save(path_str, &sample()).expect("save");
        save_masque_creds(path_str, b"c", b"k", 42).expect("update");

        let mode = std::fs::metadata(&path)
            .expect("metadata")
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(mode, 0o600);
    }
}
