use crate::transport::warp::prelude::*;
use crate::transport::warp::*;

pub(crate) fn env_value(key: &str) -> Option<String> {
    crate::config::settings::var(key)
        .ok()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
}

pub(crate) async fn prompt_line(prompt: &str) -> Option<String> {
    use std::io::IsTerminal;
    use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};

    if !std::io::stdin().is_terminal() {
        return None;
    }

    let mut stdout = tokio::io::stdout();
    let _ = stdout.write_all(prompt.as_bytes()).await;
    let _ = stdout.flush().await;

    let mut line = String::new();
    let mut reader = BufReader::new(tokio::io::stdin());
    match reader.read_line(&mut line).await {
        Ok(0) | Err(_) => None,
        Ok(_) => Some(line.trim().to_string()),
    }
}

/// The scan mode when --scan / AETHER_SCAN names none: balanced, with no question at startup.
pub(crate) const DEFAULT_SCAN_MODE: &str = "balanced";

/// The scan mode: --scan / AETHER_SCAN, or balanced. No longer asked at startup.
pub(crate) async fn select_scan_mode_str(_tip: &str) -> String {
    crate::config::settings::var("AETHER_SCAN").unwrap_or_else(|_| DEFAULT_SCAN_MODE.to_string())
}

pub(crate) async fn select_protocol(base: &str) -> Protocol {
    loop {
        let zero_trust = match team_scope() {
            Some(team) => format!("  [3] Zero Trust: signed in to {team}, pick another team\n"),
            None => "  [3] Zero Trust: sign in to an organization (WARP for teams)\n".to_string(),
        };

        let answer = prompt_line(&format!(
            "\nProtocol:\n  [1] MASQUE (QUIC/H3 or HTTP/2, default)\n  \
             [2] sunnyquic over MASQUE (your own sunnyquic server, reached inside warp)\n\
             {zero_trust}Choose [1-3] (default 1): "
        ))
        .await;

        match answer.as_deref().unwrap_or_default() {
            "2" => return Protocol::Sunny,
            "3" => {
                enrol_zero_trust(base).await;
                continue;
            }
            _ => return Protocol::Masque,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Protocol {
    Masque,
    Sunny,
}

impl Protocol {
    pub(crate) fn parse(s: &str) -> Result<Protocol> {
        match s.trim().to_lowercase().as_str() {
            "" | "masque" => Ok(Protocol::Masque),
            "sunny" | "sunnyquic" | "sunny-over-masque" => Ok(Protocol::Sunny),
            other => Err(AetherError::Other(format!(
                "protocol {other:?}: use masque or sunny (wireguard, gool and masque-in-masque \
                 were removed)"
            ))),
        }
    }
}

/// HTTP/3 or HTTP/2 comes from the config alone: `masque.http2: true` is HTTP/2, anything else
/// (false or left out) HTTP/3. The lastconn files hold gateways only and never choose the carrier.
pub(crate) fn select_masque_transport() {
    if crate::config::settings::var("AETHER_MASQUE_HTTP2").is_ok() || crate::config::settings::var("AETHER_PEER").is_ok() {
        return;
    }
    log::info!("[masque] HTTP/3 (masque.http2: true for HTTP/2)");
}

pub(crate) fn scan_settings_from_env() -> (String, prober::IpScan) {
    let mode = crate::config::settings::var("AETHER_SCAN").unwrap_or_else(|_| DEFAULT_SCAN_MODE.to_string());
    let ip = crate::config::settings::var("AETHER_IP")
        .map(|value| prober::IpScan::parse(&value))
        .unwrap_or(prober::IpScan::V4);
    (mode, ip)
}

pub(crate) async fn select_ip_version() -> prober::IpScan {
    if let Ok(v) = crate::config::settings::var("AETHER_IP") {
        return prober::IpScan::parse(&v);
    }

    let answer = prompt_line(
        "\nIP version to scan:\n  [1] IPv4 (default)\n  [2] IPv6\n  [3] Both\nChoose [1-3] (default 1): ",
    )
    .await;

    match answer.as_deref() {
        Some("2") => prober::IpScan::V6,
        Some("3") => prober::IpScan::Both,
        _ => prober::IpScan::V4,
    }
}
