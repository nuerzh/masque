//! The command line: which config file to read and what to do. Every option of a run is a key
//! of that file (`config::options`).

const USAGE: &str = "\
Aether — a censorship circumvention client. It finds a way out of a filtered
network, opens an encrypted tunnel, and serves it as a local SOCKS5 proxy.

Usage:
  aether [-c <file>]                run, with the options of the config file
  aether [-c <file>] register       register the WARP MASQUE identity and exit
                                    (no scan, no tunnel; saved only once WARP is
                                    enabled on it, an identity already there is kept)
  aether [-c <file>] tun-cleanup    remove the routes, rules, firewall and device
                                    a killed TUN run left behind, then exit
  aether help                       show this text
  aether version                    show the version

  -c, --config <file>   the config file, YAML (default aether.yaml). It holds every
                        option of a run, the WARP identity Aether keeps up to date in
                        it, [sunny], inbounds, outbounds, route and dns. A missing file
                        means every option at its default. An aether.toml an earlier
                        build wrote (and the -masque, -team-*, -lastconn* files beside
                        it) is converted to YAML once and kept as .toml.bak.

The options, as keys of the config file (- and _ alike in a key; a list may also
be a comma separated string):

  log-level: info              error | warn | info | debug | trace (RUST_LOG overrides)
  perf: medium                 low | medium | high (default: detected)
  protocol: masque             masque | sunny
  bind: 127.0.0.1:1819         the SOCKS5 listener
  http-proxy: 127.0.0.1:1820   also an HTTP CONNECT proxy (off when left out)
  upstream: socks5://127.0.0.1:1080   dial out through a proxy already running here
  mark: 0xff                   SO_MARK on every socket to the internet (Linux, Android)
  ip: v4                       v4 | v6 | both
  tunnel-dns: [1.1.1.1, 1.0.0.1]   resolvers inside the WARP tunnel (dns: is
                               the sing-box dns section)
  stats: true                  log traffic and uptime, every stats-secs (60)
  exit-loc: \"!IR,AZ\"           refuse an exit in those countries (DE,SE: only those);
                               quote it, a leading ! is a YAML tag; exit-loc-secs: 60
  warp-tunnel: auto            auto | on | off: whether WARP comes up at all
  route-config: route.yaml     a second file whose inbounds, outbounds, route and dns
                               are used instead of this one's
  route-cache-dir: ...         where remote rule sets are kept
  masque-config: warp.yaml     keep the MASQUE identity in this file instead
  sunny-config: sunny.yaml     the sunny settings from this file instead of [sunny]
  api-address: 188.114.97.6:443   where the calls to the WARP API go
  (relative paths are taken from the config file's directory)

  scan:
    mode: balanced             turbo | balanced | thorough | verified | ironclad
    ports: [500, 1701, 4500, 4443, 8443, 8095, 443]
    max-rtt: 500               start on the first gateway whose full check took at
                               most this long, in ms (0: no limit)
    rounds: 3                  1 to 10
    switch: true               keep scanning after the start and move to a gateway
                               under half the RTT of the one in use
    prefilter: true            the quick pass before the full handshakes
  masque:
    http2: false               true: HTTP/2 (TCP), false or left out: HTTP/3.
                               Set here only; H3 and H2 keep their gateways in separate files
                               (<config>-lastconn-h3.yaml, -h2.yaml)
    peer: 162.159.198.1:443    force a gateway, no scan
    noize: firewall            off | light | firewall | balanced | gfw | aggressive
    sni: www.cloudflare.com    server name of the MASQUE handshakes
    quic-v2: true              the QUIC v2 version-negotiation opener
    data-check: true           the end-to-end data-plane check
    h2-peer, validate-secs (10), startup-secs (30), reconnect-secs (2), mtu,
    fragment (false), fragment-size (8-16), fragment-delay (2-10), fragment-sni,
    h2-keepalive-secs (15), h2-keepalive-timeout-secs (20), reprovision (true)
  tls:
    ciphers, groups, grease (true), ech (auto | base64), ech-dns, ech-domain
  zero-trust:
    team, access-id, access-secret, access-token, access-email, gateway (false)
  tun:                         (or tun: true)
    enabled: true              the whole system through a TUN device
    name, address, mtu, dns, auto-route (true), strict-route (false), include,
    exclude, dns-hijack (true), fakeip (true), fakeip-range, direct-dns (system |
    tunnel | dns servers), allow-lan (true), table (1819), rule-priority (9180)
  advanced:
    route-sniff (true), route-sniff-ms (400), route-wait (45), max-clients,
    half-close-secs (30), tcp-keepalive-secs (60), tcp-connect-secs (30),
    netstack-tcp-rx, netstack-tcp-tx
  sunny:                       the sunnyquic client (protocol: sunny, sunny-direct)
    server: sq.example.com:443   username, password, server-name, alpn, ca,
    congestion-control, zero-rtt, over-stream, initial-mtu, min-mtu, mtu-discovery,
    keep-alive-interval, gso, handshake-secs, data-check, detour: direct | warp

  inbounds, outbounds, route (rules, rule_set, final, default_domain_resolver) and
  dns use sing-box's field names, written in YAML.

Docs/USAGE.zh.md and Docs/examples/*.yaml describe every key. After startup check
the proxy with:

  curl -x socks5h://127.0.0.1:1819 https://www.cloudflare.com/cdn-cgi/trace
";

/// What the command line asks for.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Parsed {
    /// Run (or register, or clean up) with this config file (`None`: the default).
    Run { config: Option<String>, action: Action },
    /// Help or the version was printed.
    Done,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    Run,
    Register,
    TunCleanup,
}

fn other(msg: String) -> crate::error::AetherError {
    crate::error::AetherError::Other(msg)
}

/// Read the command line: `-c <file>` and a command. Every other option moved into the config
/// file; one given here is an error naming its key there.
pub fn parse_args(args: Vec<String>) -> crate::error::Result<Parsed> {
    let mut config = None;
    let mut action = Action::Run;
    let mut i = 0;
    while i < args.len() {
        let arg = args[i].as_str();
        match arg {
            "-v" | "--version" | "version" => {
                println!("aether {}", env!("CARGO_PKG_VERSION"));
                return Ok(Parsed::Done);
            }
            "-h" | "--help" | "help" => {
                print!("{USAGE}");
                return Ok(Parsed::Done);
            }
            "-c" | "--config" => {
                i += 1;
                let path = args.get(i).ok_or_else(|| other(format!("{arg} requires a file")))?;
                config = Some(path.clone());
            }
            "register" => action = Action::Register,
            "tun-cleanup" => action = Action::TunCleanup,
            "--quick-reconnect" | "--no-quick-reconnect" => {
                return Err(other(format!(
                    "{arg} was removed: the remembered gateways (the saved best first) are always measured and the fastest that passes starts at once; delete the -lastconn-h3.yaml / -lastconn-h2.yaml files beside the config file to start from a fresh scan"
                )));
            }
            "--route-block" | "--route-direct" | "--routes" => {
                return Err(other(crate::proxy::router::removed_lists_message(arg)));
            }
            flag => {
                let flag_name = flag.split('=').next().unwrap_or(flag);
                return Err(other(match super::options::moved_option(flag_name) {
                    Some(key) => format!(
                        "{flag_name} is no longer a command-line option: write it in the config file (-c, default aether.yaml) as\n    {key}\n(aether help lists every key)"
                    ),
                    None => format!("unknown option or command '{flag}'\n\n{USAGE}"),
                }));
            }
        }
        i += 1;
    }
    Ok(Parsed::Run { config, action })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse(args: &[&str]) -> crate::error::Result<Parsed> {
        parse_args(args.iter().map(|s| s.to_string()).collect())
    }

    #[test]
    fn only_the_config_file_and_a_command_are_taken() {
        assert_eq!(parse(&[]).unwrap(), Parsed::Run { config: None, action: Action::Run });
        assert_eq!(
            parse(&["-c", "x.yaml", "register"]).unwrap(),
            Parsed::Run { config: Some("x.yaml".into()), action: Action::Register }
        );
        assert_eq!(
            parse(&["tun-cleanup", "--config", "y.yaml"]).unwrap(),
            Parsed::Run { config: Some("y.yaml".into()), action: Action::TunCleanup }
        );
        assert!(parse(&["-c"]).unwrap_err().to_string().contains("requires a file"));
    }

    #[test]
    fn a_removed_option_names_its_key() {
        let e = parse(&["--max-rtt", "500"]).unwrap_err().to_string();
        assert!(e.contains("scan: { max-rtt: 500 }"), "{e}");
        let e = parse(&["--h2"]).unwrap_err().to_string();
        assert!(e.contains("masque: { http2: true }"), "{e}");
        let e = parse(&["--bind=127.0.0.1:1"]).unwrap_err().to_string();
        assert!(e.contains("bind:"), "{e}");
        let e = parse(&["--quick-reconnect"]).unwrap_err().to_string();
        assert!(e.contains("was removed"), "{e}");
        let e = parse(&["--nonsense"]).unwrap_err().to_string();
        assert!(e.contains("unknown option"), "{e}");
    }
}
