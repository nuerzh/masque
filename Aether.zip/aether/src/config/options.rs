//! The run's options, read from the config file (YAML). Every option the command line and the
//! AETHER_* environment variables used to carry is a key here, at the top level or in one of
//! the sections `scan`, `masque`, `tls`, `zero-trust`, `tun` and `advanced`; `-` and `_` are
//! the same in a key. What a key gives goes into the run's `Settings` under the AETHER_* name
//! the code reads, so nothing past this module knows where an option came from.

use super::settings::Settings;

/// How a key's value becomes the setting.
#[derive(Clone, Copy)]
enum Kind {
    /// a string, or a number written as one
    Str,
    /// a list, or a string with its items separated by commas
    List,
    /// `true` sets the value given, `false` leaves the setting unset
    Flag(&'static str),
    /// `false` sets the value given, `true` leaves the setting unset
    InvFlag(&'static str),
    /// `true` is 1, `false` is 0
    Switch,
}

struct Opt {
    /// `key` at the top level, `section.key` in a section
    key: &'static str,
    var: &'static str,
    kind: Kind,
    /// a value the code would refuse, named before the run starts
    check: Option<Check>,
}

/// A check of an option's value: the reason it is refused.
type Check = fn(&str) -> Result<(), String>;

const fn opt(key: &'static str, var: &'static str, kind: Kind) -> Opt {
    Opt { key, var, kind, check: None }
}

const fn checked(key: &'static str, var: &'static str, kind: Kind, check: Check) -> Opt {
    Opt { key, var, kind, check: Some(check) }
}

/// The sections options sit in; a section given as `true` / `false` sets its `enabled`.
pub const SECTIONS: &[&str] = &["scan", "masque", "tls", "zero-trust", "tun", "advanced"];

fn check_max_rtt(v: &str) -> Result<(), String> {
    crate::transport::warp::prober::parse_max_rtt(v)
        .map(|_| ())
        .ok_or_else(|| "give milliseconds, e.g. 500 (0 for no limit)".to_string())
}

fn check_pps(v: &str) -> Result<(), String> {
    match v.trim().parse::<u32>() {
        Ok(_) => Ok(()),
        Err(_) => Err("give packets per second as a whole number, e.g. 3000".to_string()),
    }
}

fn check_retries(v: &str) -> Result<(), String> {
    match v.trim().parse::<u32>() {
        Ok(n) if n <= 5 => Ok(()),
        _ => Err("give a whole number of retries from 0 to 5".to_string()),
    }
}

fn check_rounds(v: &str) -> Result<(), String> {
    crate::transport::warp::prober::parse_scan_rounds(v).map(|_| ()).ok_or_else(|| {
        format!(
            "give a whole number of rounds from 1 to {}",
            crate::transport::warp::prober::MAX_SCAN_ROUNDS
        )
    })
}

fn check_warp_tunnel(v: &str) -> Result<(), String> {
    crate::transport::warp::demand::WarpTunnel::parse(v)
        .map(|_| ())
        .ok_or_else(|| "use auto, on or off".to_string())
}

fn check_one_of(v: &str, allowed: &[&str]) -> Result<(), String> {
    if allowed.iter().any(|a| a.eq_ignore_ascii_case(v.trim())) {
        Ok(())
    } else {
        Err(format!("use one of {}", allowed.join(", ")))
    }
}

fn check_protocol(v: &str) -> Result<(), String> {
    check_one_of(v, &["masque", "sunny", "sunnyquic"])
}

fn check_ip(v: &str) -> Result<(), String> {
    check_one_of(v, &["v4", "v6", "both", "4", "6", "dual"])
}

fn check_scan_mode(v: &str) -> Result<(), String> {
    check_one_of(v, &["turbo", "balanced", "thorough", "verified", "stealth", "ironclad"])
}

use Kind::*;

const OPTIONS: &[Opt] = &[
    // the top level
    opt("log-level", "AETHER_LOG_LEVEL", Str),
    opt("perf", "AETHER_PERF_PROFILE", Str),
    checked("protocol", "AETHER_PROTOCOL", Str, check_protocol),
    opt("bind", "AETHER_SOCKS", Str),
    opt("http-proxy", "AETHER_HTTP_PROXY", Str),
    opt("upstream", "AETHER_UPSTREAM", Str),
    opt("mark", "AETHER_MARK", Str),
    checked("ip", "AETHER_IP", Str, check_ip),
    opt("tunnel-dns", "AETHER_DNS", List),
    opt("stats", "AETHER_STATS", Flag("1")),
    opt("stats-secs", "AETHER_STATS_SECS", Str),
    opt("exit-loc", "AETHER_EXIT_LOC", List),
    opt("exit-loc-secs", "AETHER_EXIT_LOC_SECS", Str),
    checked("warp-tunnel", "AETHER_WARP_TUNNEL", Str, check_warp_tunnel),
    opt("route-config", "AETHER_ROUTE_CONFIG", Str),
    opt("route-cache-dir", "AETHER_ROUTE_CACHE_DIR", Str),
    opt("masque-config", "AETHER_MASQUE_CONFIG", Str),
    opt("sunny-config", "AETHER_SUNNY_CONFIG", Str),
    opt("api-address", "AETHER_API_ADDRESS", Str),
    // scan
    checked("scan.mode", "AETHER_SCAN", Str, check_scan_mode),
    opt("scan.ports", "AETHER_SCAN_PORTS", List),
    checked("scan.max-rtt", "AETHER_SCAN_MAX_RTT", Str, check_max_rtt),
    checked("scan.rounds", "AETHER_SCAN_ROUNDS", Str, check_rounds),
    checked("scan.pps", "AETHER_SCAN_PPS", Str, check_pps),
    checked("scan.retries", "AETHER_SCAN_RETRIES", Str, check_retries),
    opt("scan.pipeline", "AETHER_SCAN_PIPELINE", Switch),
    opt("scan.memory", "AETHER_SCAN_MEMORY", Str),
    opt("scan.switch", "AETHER_SCAN_SWITCH", Switch),
    opt("scan.prefilter", "AETHER_SCAN_PREFILTER", Switch),
    opt("scan.ironclad-port", "AETHER_IRONCLAD_PORT", Str),
    // masque
    opt("masque.http2", "AETHER_MASQUE_HTTP2", Switch),
    opt("masque.peer", "AETHER_PEER", Str),
    opt("masque.h2-peer", "AETHER_MASQUE_H2_PEER", Str),
    opt("masque.sni", "AETHER_MASQUE_SNI", Str),
    opt("masque.noize", "AETHER_NOIZE", Str),
    opt("masque.quic-v2", "AETHER_QUIC_V2", Switch),
    opt("masque.data-check", "AETHER_MASQUE_NO_DATA_CHECK", InvFlag("1")),
    opt("masque.validate-secs", "AETHER_MASQUE_VALIDATE_SECS", Str),
    opt("masque.startup-secs", "AETHER_MASQUE_STARTUP_SECS", Str),
    opt("masque.reconnect-secs", "AETHER_MASQUE_RECONNECT_SECS", Str),
    opt("masque.mtu", "AETHER_MASQUE_MTU", Str),
    opt("masque.fragment", "AETHER_MASQUE_H2_FRAGMENT", Flag("1")),
    opt("masque.fragment-size", "AETHER_MASQUE_H2_FRAGMENT_SIZE", Str),
    opt("masque.fragment-delay", "AETHER_MASQUE_H2_FRAGMENT_DELAY", Str),
    opt("masque.fragment-sni", "AETHER_MASQUE_H2_FRAGMENT_SNI", Str),
    opt("masque.h2-keepalive-secs", "AETHER_MASQUE_H2_KEEPALIVE_SECS", Str),
    opt("masque.h2-keepalive-timeout-secs", "AETHER_MASQUE_H2_KEEPALIVE_TIMEOUT_SECS", Str),
    opt("masque.reprovision", "AETHER_REPROVISION", Switch),
    // tls
    opt("tls.ciphers", "AETHER_TLS_CIPHERS", Str),
    opt("tls.groups", "AETHER_TLS_GROUPS", Str),
    opt("tls.grease", "AETHER_DISABLE_GREASE", InvFlag("1")),
    opt("tls.ech", "AETHER_ECH", Str),
    opt("tls.ech-dns", "AETHER_ECH_DNS", Str),
    opt("tls.ech-domain", "AETHER_ECH_DOMAIN", Str),
    opt("tls.verify", "AETHER_TLS_VERIFY", Flag("1")),
    // zero-trust
    opt("zero-trust.team", "AETHER_TEAM", Str),
    opt("zero-trust.access-id", "AETHER_ACCESS_CLIENT_ID", Str),
    opt("zero-trust.access-secret", "AETHER_ACCESS_CLIENT_SECRET", Str),
    opt("zero-trust.access-token", "AETHER_ACCESS_TOKEN", Str),
    opt("zero-trust.access-email", "AETHER_ACCESS_EMAIL", Str),
    opt("zero-trust.gateway", "AETHER_GATEWAY", Flag("1")),
    // tun
    opt("tun.enabled", "AETHER_TUN", Switch),
    opt("tun.name", "AETHER_TUN_NAME", Str),
    opt("tun.address", "AETHER_TUN_ADDRESS", List),
    opt("tun.mtu", "AETHER_TUN_MTU", Str),
    opt("tun.dns", "AETHER_TUN_DNS", Str),
    opt("tun.auto-route", "AETHER_TUN_AUTO_ROUTE", Switch),
    opt("tun.strict-route", "AETHER_TUN_STRICT_ROUTE", Switch),
    opt("tun.include", "AETHER_TUN_INCLUDE", List),
    opt("tun.exclude", "AETHER_TUN_EXCLUDE", List),
    opt("tun.dns-hijack", "AETHER_TUN_DNS_HIJACK", Switch),
    opt("tun.fakeip", "AETHER_TUN_FAKEIP", Switch),
    opt("tun.fakeip-range", "AETHER_TUN_FAKEIP_RANGE", List),
    opt("tun.direct-dns", "AETHER_TUN_DIRECT_DNS", List),
    opt("tun.allow-lan", "AETHER_TUN_ALLOW_LAN", Switch),
    opt("tun.table", "AETHER_TUN_TABLE", Str),
    opt("tun.rule-priority", "AETHER_TUN_RULE_PRIORITY", Str),
    // advanced
    opt("advanced.route-sniff", "AETHER_ROUTE_SNIFF", Switch),
    opt("advanced.route-sniff-ms", "AETHER_ROUTE_SNIFF_MS", Str),
    opt("advanced.route-wait", "AETHER_ROUTE_WAIT", Str),
    opt("advanced.max-clients", "AETHER_MAX_CLIENTS", Str),
    opt("advanced.half-close-secs", "AETHER_HALF_CLOSE_SECS", Str),
    opt("advanced.tcp-keepalive-secs", "AETHER_TCP_KEEPALIVE_SECS", Str),
    opt("advanced.tcp-connect-secs", "AETHER_TCP_CONNECT_SECS", Str),
    opt("advanced.netstack-tcp-rx", "AETHER_NETSTACK_TCP_RX", Str),
    opt("advanced.netstack-tcp-tx", "AETHER_NETSTACK_TCP_TX", Str),
];

/// Option keys of the top level, as written in the table above.
pub fn is_top_level_option(key: &str) -> bool {
    let k = key.replace('_', "-");
    OPTIONS.iter().any(|o| !o.key.contains('.') && o.key == k) || SECTIONS.contains(&k.as_str())
}

fn scalar(v: &toml::Value) -> Option<String> {
    match v {
        toml::Value::String(s) => Some(s.clone()),
        toml::Value::Integer(i) => Some(i.to_string()),
        toml::Value::Float(f) => Some(f.to_string()),
        toml::Value::Boolean(b) => Some(b.to_string()),
        _ => None,
    }
}

fn boolean(v: &toml::Value) -> Option<bool> {
    match v {
        toml::Value::Boolean(b) => Some(*b),
        toml::Value::Integer(0) => Some(false),
        toml::Value::Integer(1) => Some(true),
        toml::Value::String(s) => crate::transport::warp::prober::parse_scan_switch(s),
        _ => None,
    }
}

/// The setting `o` takes from `v`; `None` leaves it unset.
fn value_of(o: &Opt, v: &toml::Value, what: &str) -> Result<Option<String>, String> {
    let shown = format!("{what}: {}", o.key);
    if matches!(o.kind, Flag(_) | InvFlag(_) | Switch) && boolean(v).is_none() {
        return Err(format!("{shown} must be true or false, not {v}"));
    }
    let value = match o.kind {
        Str => Some(scalar(v).ok_or_else(|| format!("{shown} must be a string or a number, not {v}"))?),
        List => Some(match v {
            toml::Value::Array(items) => items
                .iter()
                .map(|i| scalar(i).ok_or_else(|| format!("{shown}: every item must be a string or a number")))
                .collect::<Result<Vec<_>, _>>()?
                .join(","),
            other => scalar(other).ok_or_else(|| format!("{shown} must be a list or a string, not {other}"))?,
        }),
        Flag(on) => boolean(v).unwrap().then(|| on.to_string()),
        InvFlag(on) => (!boolean(v).unwrap()).then(|| on.to_string()),
        Switch => Some(if boolean(v).unwrap() { "1" } else { "0" }.to_string()),
    };
    if let (Some(value), Some(check)) = (&value, o.check) {
        check(value).map_err(|e| format!("{shown} = {value:?}: {e}"))?;
    }
    Ok(value)
}

fn normalized(t: &toml::Table) -> Vec<(String, &toml::Value)> {
    t.iter().map(|(k, v)| (k.replace('_', "-"), v)).collect()
}

/// The settings the options of `table` (a config file's top level) give. A key in an option
/// section that is not an option, or a value of the wrong kind, is an error naming it.
pub fn settings_from(table: &toml::Table, what: &str) -> Result<Settings, String> {
    let mut settings = Settings::default();
    let mut seen: Vec<String> = Vec::new();
    for (key, v) in normalized(table) {
        if SECTIONS.contains(&key.as_str()) {
            let entries: Vec<(String, &toml::Value)> = match v {
                toml::Value::Table(t) => normalized(t),
                toml::Value::Boolean(_) if OPTIONS.iter().any(|o| o.key == format!("{key}.enabled")) => {
                    vec![("enabled".to_string(), v)]
                }
                other => return Err(format!("{what}: {key} must be a mapping of options, not {other}")),
            };
            for (inner, v) in entries {
                let full = format!("{key}.{inner}");
                let o = OPTIONS.iter().find(|o| o.key == full).ok_or_else(|| {
                    let known: Vec<&str> = OPTIONS
                        .iter()
                        .filter_map(|o| o.key.strip_prefix(&format!("{key}.")))
                        .collect();
                    format!("{what}: {full} is not an option (the {key} options are {})", known.join(", "))
                })?;
                if seen.contains(&full) {
                    return Err(format!("{what}: {full} is given twice"));
                }
                seen.push(full);
                if let Some(value) = value_of(o, v, what)? {
                    settings.set(o.var, &value);
                }
            }
        } else if let Some(o) = OPTIONS.iter().find(|o| o.key == key) {
            if seen.contains(&key) {
                return Err(format!("{what}: {key} is given twice"));
            }
            seen.push(key.clone());
            if let Some(value) = value_of(o, v, what)? {
                settings.set(o.var, &value);
            }
        }
    }
    Ok(settings)
}

/// Where a removed command-line option went in the config file.
pub fn moved_option(flag: &str) -> Option<&'static str> {
    Some(match flag {
        "--bind" => "bind: 127.0.0.1:1819",
        "--http-proxy" => "http-proxy: 127.0.0.1:1820",
        "--upstream" => "upstream: socks5://127.0.0.1:1080",
        "--mark" => "mark: 0xff",
        "--exit-loc" => "exit-loc: \"!IR,AZ\"",
        "--exit-loc-secs" => "exit-loc-secs: 60",
        "--stats" => "stats: true",
        "--stats-secs" => "stats-secs: 60",
        "-4" => "ip: v4",
        "-6" => "ip: v6",
        "--dual" => "ip: both",
        "--ip" => "ip: v4 | v6 | both",
        "--peer" => "masque: { peer: \"ip:port\" }",
        "--masque" => "protocol: masque",
        "--sunny" | "--sunnyquic" => "protocol: sunny",
        "--protocol" => "protocol: masque | sunny",
        "--sunny-server" => "sunny: { server: \"host:port\" } (and protocol: sunny)",
        "--sunny-user" | "--sunny-username" => "sunny: { username: ... }",
        "--sunny-password" | "--sunny-pass" => "sunny: { password: ... }",
        "--sunny-sni" | "--sunny-server-name" => "sunny: { server-name: ... }",
        "--sunny-alpn" => "sunny: { alpn: [h3] }",
        "--sunny-ca" | "--sunny-cert" => "sunny: { ca: ca.pem }",
        "--sunny-cc" | "--sunny-congestion" => "sunny: { congestion-control: bbr }",
        "--sunny-zero-rtt" => "sunny: { zero-rtt: true }",
        "--sunny-no-zero-rtt" => "sunny: { zero-rtt: false }",
        "--sunny-udp-over-stream" => "sunny: { over-stream: true }",
        "--sunny-mtu" => "sunny: { initial-mtu: 1250 }",
        "--sunny-min-mtu" => "sunny: { min-mtu: 1200 }",
        "--sunny-mtu-discovery" => "sunny: { mtu-discovery: true }",
        "--sunny-keepalive" => "sunny: { keep-alive-interval: 10000 }",
        "--sunny-handshake-secs" => "sunny: { handshake-secs: 15 }",
        "--sunny-no-data-check" => "sunny: { data-check: false }",
        "--sunny-config" => "sunny-config: sunny.yaml",
        "--sunny-detour" => "sunny: { detour: direct | warp }",
        "--scan" => "scan: { mode: balanced }",
        "--turbo" => "scan: { mode: turbo }",
        "--balanced" => "scan: { mode: balanced }",
        "--thorough" => "scan: { mode: thorough }",
        "--verified" | "--stealth" => "scan: { mode: verified }",
        "--ironclad" => "scan: { mode: ironclad }",
        "--scan-ports" => "scan: { ports: [500, 1701, 4500] }",
        "--no-prefilter" => "scan: { prefilter: false }",
        "--max-rtt" | "--scan-max-rtt" => "scan: { max-rtt: 500 }",
        "--scan-rounds" => "scan: { rounds: 3 }",
        "--no-scan-switch" => "scan: { switch: false }",
        "--scan-switch" => "scan: { switch: true }",
        "--noize" => "masque: { noize: firewall }",
        "--h2" | "--http2" => "masque: { http2: true }",
        "--h3" | "--quic" => "masque: { http2: false }",
        "--no-quic-v2" => "masque: { quic-v2: false }",
        "--h2-peer" => "masque: { h2-peer: \"ip:port\" }",
        "--masque-sni" => "masque: { sni: www.cloudflare.com }",
        "--no-data-check" => "masque: { data-check: false }",
        "--validate-secs" => "masque: { validate-secs: 10 }",
        "--startup-secs" => "masque: { startup-secs: 30 }",
        "--reconnect-secs" => "masque: { reconnect-secs: 2 }",
        "--fragment" => "masque: { fragment: true }",
        "--fragment-size" => "masque: { fragment-size: 8-16 }",
        "--fragment-delay" => "masque: { fragment-delay: 2-10 }",
        "--dns" => "tunnel-dns: [1.1.1.1, 1.0.0.1]",
        "--ech" => "tls: { ech: auto }",
        "--ech-dns" => "tls: { ech-dns: udp://1.1.1.1 }",
        "--ech-domain" => "tls: { ech-domain: cloudflare-ech.com }",
        "--tls-ciphers" => "tls: { ciphers: ... }",
        "--tls-groups" => "tls: { groups: \"P-256:X25519:P-384\" }",
        "--disable-grease" => "tls: { grease: false }",
        "--tls-verify" => "tls: { verify: true }",
        "--team" | "--organization" => "zero-trust: { team: ... }",
        "--access-id" => "zero-trust: { access-id: ... }",
        "--access-secret" => "zero-trust: { access-secret: ... }",
        "--access-token" => "zero-trust: { access-token: ... }",
        "--access-email" => "zero-trust: { access-email: ... }",
        "--gateway" => "zero-trust: { gateway: true }",
        "--tun" => "tun: { enabled: true }",
        "--tun-name" => "tun: { name: aether-tun }",
        "--tun-address" => "tun: { address: [172.19.0.1/30] }",
        "--tun-mtu" => "tun: { mtu: 9000 }",
        "--tun-dns" => "tun: { dns: 172.19.0.2 }",
        "--tun-auto-route" => "tun: { auto-route: true }",
        "--no-tun-auto-route" => "tun: { auto-route: false }",
        "--tun-strict-route" => "tun: { strict-route: true }",
        "--tun-include" => "tun: { include: [10.0.0.0/8] }",
        "--tun-exclude" => "tun: { exclude: [192.168.0.0/16] }",
        "--tun-dns-hijack" => "tun: { dns-hijack: true }",
        "--no-tun-dns-hijack" => "tun: { dns-hijack: false }",
        "--tun-fakeip" => "tun: { fakeip: true }",
        "--no-tun-fakeip" => "tun: { fakeip: false }",
        "--tun-fakeip-range" => "tun: { fakeip-range: [198.18.0.0/15] }",
        "--tun-direct-dns" => "tun: { direct-dns: system }",
        "--tun-block-lan" => "tun: { allow-lan: false }",
        "--tun-cleanup" => "the command `aether tun-cleanup`",
        "--register" => "the command `aether register`",
        "--route-config" => "route-config: route.yaml",
        "--warp-tunnel" => "warp-tunnel: auto | on | off",
        "--no-warp" => "warp-tunnel: off",
        "--route-cache-dir" => "route-cache-dir: ...",
        "--masque-config" => "masque-config: warp.yaml",
        "--api-address" => "api-address: 188.114.97.6:443",
        "--perf" => "perf: low | medium | high",
        "--log-level" => "log-level: info",
        "--verbose" => "log-level: debug",
        _ => return None,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn read(text: &str) -> Result<Settings, String> {
        settings_from(&crate::config::yaml::parse_table(text).unwrap(), "aether.yaml")
    }

    #[test]
    fn top_level_keys_and_sections_become_settings() {
        let s = read(
            "bind: 127.0.0.1:1\nprotocol: sunny\ntunnel-dns: [1.1.1.1, 8.8.8.8]\nstats: true\n\
             scan:\n  mode: turbo\n  max_rtt: 250\n  rounds: 5\n  switch: false\n  ports: [443, 8443]\n\
             masque:\n  http2: true\n  data-check: false\n  peer: 1.2.3.4:443\n\
             tls:\n  grease: false\n\
             tun:\n  enabled: true\n  include: [10.0.0.0/8, 192.168.0.0/16]\n  allow-lan: false\n",
        )
        .unwrap();
        assert_eq!(s.get("AETHER_SOCKS"), Some("127.0.0.1:1"));
        assert_eq!(s.get("AETHER_PROTOCOL"), Some("sunny"));
        assert_eq!(s.get("AETHER_DNS"), Some("1.1.1.1,8.8.8.8"));
        assert_eq!(s.get("AETHER_STATS"), Some("1"));
        assert_eq!(s.get("AETHER_SCAN"), Some("turbo"));
        assert_eq!(s.get("AETHER_SCAN_MAX_RTT"), Some("250"));
        assert_eq!(s.get("AETHER_SCAN_ROUNDS"), Some("5"));
        assert_eq!(s.get("AETHER_SCAN_SWITCH"), Some("0"));
        assert_eq!(s.get("AETHER_SCAN_PORTS"), Some("443,8443"));
        assert_eq!(s.get("AETHER_MASQUE_HTTP2"), Some("1"));
        assert_eq!(s.get("AETHER_MASQUE_NO_DATA_CHECK"), Some("1"));
        assert_eq!(s.get("AETHER_PEER"), Some("1.2.3.4:443"));
        assert_eq!(s.get("AETHER_DISABLE_GREASE"), Some("1"));
        assert_eq!(s.get("AETHER_TUN"), Some("1"));
        assert_eq!(s.get("AETHER_TUN_INCLUDE"), Some("10.0.0.0/8,192.168.0.0/16"));
        assert_eq!(s.get("AETHER_TUN_ALLOW_LAN"), Some("0"));
    }

    #[test]
    fn what_is_left_out_stays_unset_and_flags_set_only_when_on() {
        let s = read("stats: false\nmasque:\n  data-check: true\n  http2: false\nzero-trust:\n  gateway: false\n").unwrap();
        assert_eq!(s.get("AETHER_STATS"), None);
        assert_eq!(s.get("AETHER_MASQUE_NO_DATA_CHECK"), None);
        assert_eq!(s.get("AETHER_GATEWAY"), None);
        assert_eq!(s.get("AETHER_MASQUE_HTTP2"), Some("0"), "http2: false still forces HTTP/3");
        let none = read("device_id: d\n").unwrap();
        assert_eq!(none.get("AETHER_MASQUE_HTTP2"), None, "no http2: HTTP/3");
        assert_eq!(none.get("AETHER_SCAN_MAX_RTT"), None);
        assert_eq!(read("tun: true\n").unwrap().get("AETHER_TUN"), Some("1"));
    }

    #[test]
    fn the_scan_knobs_are_options_with_their_own_checks() {
        let s = read("scan:\n  pps: 1500\n  retries: 0\n  pipeline: false\n  memory: mem.txt\n").unwrap();
        assert_eq!(s.get("AETHER_SCAN_PPS"), Some("1500"));
        assert_eq!(s.get("AETHER_SCAN_RETRIES"), Some("0"));
        assert_eq!(s.get("AETHER_SCAN_PIPELINE"), Some("0"));
        assert_eq!(s.get("AETHER_SCAN_MEMORY"), Some("mem.txt"));
        let e = read("scan:\n  pps: fast\n").unwrap_err();
        assert!(e.contains("scan.pps") && e.contains("packets"), "{e}");
        let e = read("scan:\n  retries: 9\n").unwrap_err();
        assert!(e.contains("scan.retries") && e.contains("0 to 5"), "{e}");
    }

    #[test]
    fn a_wrong_key_or_value_is_named() {
        let e = read("scan:\n  max-rtt: fast\n").unwrap_err();
        assert!(e.contains("scan.max-rtt") && e.contains("milliseconds"), "{e}");
        let e = read("scan:\n  rounds: 0\n").unwrap_err();
        assert!(e.contains("scan.rounds"), "{e}");
        let e = read("scan:\n  maxrtt: 5\n").unwrap_err();
        assert!(e.contains("scan.maxrtt is not an option") && e.contains("max-rtt"), "{e}");
        let e = read("warp-tunnel: maybe\n").unwrap_err();
        assert!(e.contains("auto, on or off"), "{e}");
        let e = read("tun:\n  enabled: perhaps\n").unwrap_err();
        assert!(e.contains("true or false"), "{e}");
        let e = read("scan:\n  max-rtt: 5\n  max_rtt: 6\n").unwrap_err();
        assert!(e.contains("twice"), "{e}");
        assert_eq!(read("warp-tunnel: off\n").unwrap().get("AETHER_WARP_TUNNEL"), Some("off"));
    }
}
