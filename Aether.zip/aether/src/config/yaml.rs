//! YAML, the format of every config and state file: reading a document into the table the rest
//! of the config code works on, writing one, and the TOML an earlier build wrote converted.

use serde_json::Value;

/// A YAML document as a table of its top level. An empty document (or one holding only
/// comments) is an empty table; a key whose value is left empty (`key:`, or `~`) is as if it
/// were not there. A document whose top level is not a mapping is an error, and so is one that
/// does not parse, with the line and column where it stops being YAML.
pub fn parse_table(text: &str) -> Result<toml::Table, String> {
    let value: Value = if text.trim().is_empty() {
        Value::Null
    } else {
        serde_yaml_ng::from_str(text).map_err(|e| format!("not valid YAML: {}", e.to_string().trim_end()))?
    };
    match strip_nulls(value) {
        Value::Null => Ok(toml::Table::new()),
        v @ Value::Object(_) => json_to_table(v),
        other => Err(format!("not a YAML mapping at the top level (found {})", kind(&other))),
    }
}

fn kind(v: &Value) -> &'static str {
    match v {
        Value::Null => "nothing",
        Value::Bool(_) => "a boolean",
        Value::Number(_) => "a number",
        Value::String(_) => "a string",
        Value::Array(_) => "a list",
        Value::Object(_) => "a mapping",
    }
}

/// `v` without the mapping entries and list items left empty.
fn strip_nulls(v: Value) -> Value {
    match v {
        Value::Object(map) => Value::Object(
            map.into_iter()
                .filter(|(_, v)| !v.is_null())
                .map(|(k, v)| (k, strip_nulls(v)))
                .collect(),
        ),
        Value::Array(items) => Value::Array(items.into_iter().filter(|v| !v.is_null()).map(strip_nulls).collect()),
        other => other,
    }
}

fn json_to_table(v: Value) -> Result<toml::Table, String> {
    serde_json::from_value::<toml::Table>(v).map_err(|e| format!("a value YAML holds cannot be used here: {e}"))
}

/// `t` as a YAML document.
pub fn table_to_string(t: &toml::Table) -> Result<String, String> {
    to_string(&crate::config::file::table_to_json(t))
}

/// `v` as a YAML document.
pub fn to_string<T: serde::Serialize + ?Sized>(v: &T) -> Result<String, String> {
    serde_yaml_ng::to_string(v).map_err(|e| format!("cannot be written as YAML: {e}"))
}

/// The TOML text of a file an earlier build wrote, as YAML: the same keys and values (comments
/// are not carried over).
#[cfg(test)]
pub fn toml_to_yaml(text: &str) -> Result<String, String> {
    let table: toml::Table =
        toml::from_str(text).map_err(|e| format!("not valid TOML: {}", e.to_string().trim_end()))?;
    table_to_string(&table)
}

/// A config written in TOML, as tests and the TOML an earlier build wrote have it, turned into
/// the YAML the config files are now.
#[cfg(test)]
pub(crate) fn yaml_of_toml(text: &str) -> String {
    toml_to_yaml(text).unwrap_or_else(|e| panic!("{e}\n{text}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_document_reads_as_its_top_level_table() {
        let t = parse_table(
            "# comment\nbind: 127.0.0.1:1819\nscan:\n  max-rtt: 500\n  switch: false\nlist: [a, b]\nempty:\n",
        )
        .unwrap();
        assert_eq!(t["bind"].as_str(), Some("127.0.0.1:1819"));
        assert_eq!(t["scan"]["max-rtt"].as_integer(), Some(500));
        assert_eq!(t["scan"]["switch"].as_bool(), Some(false));
        assert_eq!(t["list"].as_array().unwrap().len(), 2);
        assert!(!t.contains_key("empty"));
        assert!(parse_table("").unwrap().is_empty());
        assert!(parse_table("# only a comment\n").unwrap().is_empty());
    }

    #[test]
    fn what_does_not_parse_says_where() {
        let e = parse_table("route:\n  final: [\n").unwrap_err();
        assert!(e.contains("not valid YAML") && e.contains("line"), "{e}");
        let e = parse_table("- a\n- b\n").unwrap_err();
        assert!(e.contains("not a YAML mapping"), "{e}");
    }

    #[test]
    fn toml_converts_with_its_values() {
        let y = toml_to_yaml(
            "device_id = \"d\"\ncert_pem = \"-----BEGIN-----\\nabc\\n-----END-----\\n\"\n[route]\nfinal = \"direct\"\n[[route.rules]]\nport = 443\noutbound = \"block\"\n",
        )
        .unwrap();
        let t = parse_table(&y).unwrap();
        assert_eq!(t["device_id"].as_str(), Some("d"));
        assert_eq!(t["cert_pem"].as_str(), Some("-----BEGIN-----\nabc\n-----END-----\n"));
        assert_eq!(t["route"]["rules"][0]["port"].as_integer(), Some(443));
    }
}
