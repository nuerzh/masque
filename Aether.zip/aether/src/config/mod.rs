//! Configuration: the command line (`cli`: the config file and a command), the YAML config
//! file (`file`: inbounds, outbounds, route, dns, sunny, and the WARP identity kept by
//! `identity`), the options it holds (`options`), TOML files of earlier builds converted
//! (`migrate`), the mode and scan choices (`mode`), and the typed settings of one run (`Config`).

pub mod cli;
pub mod file;
pub mod identity;
pub mod migrate;
pub mod mode;
pub mod options;
pub mod settings;
pub mod yaml;

use std::net::SocketAddr;

use crate::error::Result;

/// The aether config file when -c names none.
pub const DEFAULT_CONFIG: &str = "aether.yaml";

/// The listener --bind names when it is not given.
pub const DEFAULT_SOCKS: &str = "127.0.0.1:1819";

/// What one run is configured to do, read from the run's `settings` (the options of the
/// config file).
#[derive(Debug, Clone)]
pub struct Config {
    /// The config file (YAML: options, identity, `sunny`, `inbounds`, `outbounds`, `route`, `dns`).
    pub base_config: String,
    /// --bind: the socks5 listener.
    pub listen: SocketAddr,
    /// --http-proxy: the http proxy listener.
    pub http_proxy: Option<SocketAddr>,
}

impl Config {
    pub fn from_env() -> Result<Config> {
        let base_config = file::main_path();
        let listen = crate::config::settings::var("AETHER_SOCKS")
            .ok()
            .and_then(|s| s.trim().parse().ok())
            .unwrap_or_else(|| DEFAULT_SOCKS.parse().expect("the default socks address"));
        Ok(Config { base_config, listen, http_proxy: http_proxy_listen() })
    }
}

/// --http-proxy, when it names an address.
pub fn http_proxy_listen() -> Option<SocketAddr> {
    let raw = crate::config::settings::var("AETHER_HTTP_PROXY").ok()?;
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return None;
    }
    match trimmed.parse::<SocketAddr>() {
        Ok(addr) => Some(addr),
        Err(_) => {
            log::warn!("[config] ignoring an unparsable http proxy address: {trimmed}");
            None
        }
    }
}

/// Options holding a path, taken from the config file's directory when relative, and read as
/// YAML (a TOML file named there is converted once).
const PATH_OPTIONS: &[(&str, bool)] = &[
    ("AETHER_ROUTE_CONFIG", true),
    ("AETHER_SUNNY_CONFIG", true),
    ("AETHER_MASQUE_CONFIG", true),
    ("AETHER_ROUTE_CACHE_DIR", false),
    ("AETHER_SCAN_MEMORY", false),
];

/// The settings of a run with the config file `given` (`None`: aether.yaml) doing `action`:
/// the file's options, the file itself (AETHER_CONFIG) and the command. TOML files an earlier
/// build wrote are converted first; a missing config file leaves every option at its default.
pub fn load_settings(given: Option<&str>, action: cli::Action) -> Result<settings::Settings> {
    let err = |e: String| crate::error::AetherError::Other(e);
    let base = migrate::adopt(given.unwrap_or(DEFAULT_CONFIG)).map_err(err)?;
    migrate::adopt_siblings(&base).map_err(err)?;
    let path = std::path::PathBuf::from(&base);
    let table = file::read_table(&path).map_err(err)?.unwrap_or_default();
    let mut settings = options::settings_from(&table, &base).map_err(err)?;
    let dir = file::base_dir(&path);
    for (var, yaml_file) in PATH_OPTIONS {
        let Some(raw) = settings.get(var).map(str::trim).filter(|p| !p.is_empty()).map(str::to_string) else {
            continue;
        };
        let mut resolved = if std::path::Path::new(&raw).is_absolute() {
            raw.clone()
        } else {
            dir.join(&raw).to_string_lossy().into_owned()
        };
        if *yaml_file {
            resolved = migrate::adopt(&resolved).map_err(err)?;
        }
        settings.set(var, &resolved);
    }
    settings.set("AETHER_CONFIG", &base);
    match action {
        cli::Action::Run => {}
        cli::Action::Register => settings.set("AETHER_REGISTER", "masque"),
        cli::Action::TunCleanup => settings.set("AETHER_TUN_CLEANUP", "1"),
    }
    Ok(settings)
}
