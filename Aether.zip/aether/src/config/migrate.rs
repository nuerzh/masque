//! TOML files an earlier build wrote (the config file, the WARP identity, the lastconn state, a
//! route config, a rule set of one's own) turned into the YAML files this build reads. A file
//! is converted once, the first time it is wanted: `x.toml` becomes `x.yaml` with the same keys
//! and values (its comments are not carried over), and the TOML file is kept as `x.toml.bak`.

use std::path::{Path, PathBuf};

fn has_ext(path: &Path, exts: &[&str]) -> bool {
    path.extension()
        .and_then(|e| e.to_str())
        .is_some_and(|e| exts.iter().any(|x| e.eq_ignore_ascii_case(x)))
}

/// Whether `path` names a TOML file.
pub fn is_toml(path: &str) -> bool {
    has_ext(Path::new(path), &["toml"])
}

/// The YAML file `path` stands for: the same name with `.yaml` for a `.toml` one, else itself.
pub fn yaml_path(path: &str) -> String {
    if is_toml(path) {
        Path::new(path).with_extension("yaml").to_string_lossy().into_owned()
    } else {
        path.to_string()
    }
}

/// The YAML file to read for `path`, converting the TOML file it stands for when only that one
/// is there: `path` itself when it names a `.toml` file, or the `.toml` file beside a `.yaml` /
/// `.yml` one. With neither there, the YAML file (which a run may then create).
pub fn adopt(path: &str) -> Result<String, String> {
    let target = yaml_path(path);
    let toml_file: Option<PathBuf> = if is_toml(path) {
        Some(PathBuf::from(path))
    } else if has_ext(Path::new(path), &["yaml", "yml"]) {
        Some(Path::new(path).with_extension("toml"))
    } else {
        None
    };
    if Path::new(&target).exists() {
        if is_toml(path) && Path::new(path).exists() {
            warn_once(format!("{path}: using {target}, which is already there; the TOML file is not read"));
        }
        return Ok(target);
    }
    match toml_file {
        Some(old) if old.exists() => {
            convert(&old, Path::new(&target))?;
            Ok(target)
        }
        _ => Ok(target),
    }
}

/// Every TOML file of the config file `base` (a `.yaml` path) and of what is kept beside it
/// (`<stem>-masque`, `<stem>-team-<team>`, `<stem>-lastconn*`), converted.
pub fn adopt_siblings(base: &str) -> Result<(), String> {
    let base_path = Path::new(base);
    let dir = match base_path.parent() {
        Some(d) if !d.as_os_str().is_empty() => d.to_path_buf(),
        _ => PathBuf::from("."),
    };
    let Some(stem) = base_path.file_stem().and_then(|s| s.to_str()) else { return Ok(()) };
    adopt(base)?;
    let Ok(entries) = std::fs::read_dir(&dir) else { return Ok(()) };
    let mut found: Vec<PathBuf> = entries
        .flatten()
        .map(|e| e.path())
        .filter(|p| {
            has_ext(p, &["toml"])
                && p.file_stem()
                    .and_then(|s| s.to_str())
                    .is_some_and(|s| s.starts_with(&format!("{stem}-")))
        })
        .collect();
    found.sort();
    for path in found {
        adopt(&path.to_string_lossy())?;
    }
    Ok(())
}

/// The keys a TOML config file kept at its top level that are options of a section now.
const MOVED_TOP_LEVEL: &[(&str, &str, &str)] = &[
    ("scan_max_rtt", "scan", "max-rtt"),
    ("scan-max-rtt", "scan", "max-rtt"),
    ("scan_rounds", "scan", "rounds"),
    ("scan-rounds", "scan", "rounds"),
    ("scan_switch", "scan", "switch"),
    ("scan-switch", "scan", "switch"),
];

/// `text` (TOML) as the YAML the file is now, with the keys that moved into a section moved.
pub fn convert_text(text: &str) -> Result<String, String> {
    let mut table: toml::Table =
        toml::from_str(text).map_err(|e| format!("not valid TOML: {}", e.to_string().trim_end()))?;
    for (old, section, key) in MOVED_TOP_LEVEL {
        if let Some(v) = table.remove(*old) {
            let entry = table
                .entry(section.to_string())
                .or_insert_with(|| toml::Value::Table(toml::Table::new()));
            if let toml::Value::Table(t) = entry {
                t.entry(key.to_string()).or_insert(v);
            }
        }
    }
    crate::config::yaml::table_to_string(&table)
}

fn convert(old: &Path, target: &Path) -> Result<(), String> {
    let text = std::fs::read_to_string(old).map_err(|e| format!("{}: {e}", old.display()))?;
    let yaml = convert_text(&text).map_err(|e| format!("{}: {e}; convert it to YAML by hand", old.display()))?;
    let header = format!(
        "# converted from {} by Aether {} (comments of the TOML file are not carried over)\n",
        old.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default(),
        env!("CARGO_PKG_VERSION")
    );
    std::fs::write(target, format!("{header}{yaml}")).map_err(|e| format!("{}: {e}", target.display()))?;
    if let Ok(meta) = std::fs::metadata(old) {
        let _ = std::fs::set_permissions(target, meta.permissions());
    }
    let mut backup = old.as_os_str().to_owned();
    backup.push(".bak");
    let backup = PathBuf::from(backup);
    match std::fs::rename(old, &backup) {
        Ok(()) => log::info!(
            "[config] converted {} to {}; the TOML file is kept as {}",
            old.display(),
            target.display(),
            backup.display()
        ),
        Err(e) => log::warn!(
            "[config] converted {} to {} but could not rename the TOML file: {e}",
            old.display(),
            target.display()
        ),
    }
    Ok(())
}

fn warn_once(msg: String) {
    static SEEN: parking_lot::Mutex<Vec<String>> = parking_lot::Mutex::new(Vec::new());
    let mut seen = SEEN.lock();
    if !seen.contains(&msg) {
        log::warn!("[config] {msg}");
        seen.push(msg);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_toml_config_and_its_siblings_become_yaml_once() {
        let dir = crate::test_util::scratch_dir("migrate");
        let base = dir.join("aether.yaml");
        std::fs::write(
            dir.join("aether.toml"),
            "device_id = \"d\"\naccess_token = \"t\"\nscan_max_rtt = 1500\nscan-rounds = 2\n[sunny]\nserver = \"a:1\"\n",
        )
        .unwrap();
        std::fs::write(dir.join("aether-lastconn-h3.toml"), "peer = \"1.1.1.1:443\"\nprofile = \"gfw\"\n").unwrap();
        std::fs::write(dir.join("other.toml"), "x = 1\n").unwrap();
        adopt_siblings(&base.to_string_lossy()).unwrap();
        let main = crate::config::yaml::parse_table(&std::fs::read_to_string(&base).unwrap()).unwrap();
        assert_eq!(main["device_id"].as_str(), Some("d"));
        assert_eq!(main["scan"]["max-rtt"].as_integer(), Some(1500));
        assert_eq!(main["scan"]["rounds"].as_integer(), Some(2));
        assert!(!main.contains_key("scan_max_rtt"));
        assert_eq!(main["sunny"]["server"].as_str(), Some("a:1"));
        assert!(dir.join("aether.toml.bak").exists() && !dir.join("aether.toml").exists());
        assert!(dir.join("aether-lastconn-h3.yaml").exists());
        assert!(dir.join("other.toml").exists(), "a file of another name is left alone");
        // a second run finds the YAML files and converts nothing
        adopt_siblings(&base.to_string_lossy()).unwrap();
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_toml_path_given_reads_the_yaml_beside_it() {
        let dir = crate::test_util::scratch_dir("migrate-given");
        let toml_file = dir.join("route.toml");
        std::fs::write(&toml_file, "[route]\nfinal = \"direct\"\n").unwrap();
        let got = adopt(&toml_file.to_string_lossy()).unwrap();
        assert!(got.ends_with("route.yaml"), "{got}");
        let t = crate::config::yaml::parse_table(&std::fs::read_to_string(&got).unwrap()).unwrap();
        assert_eq!(t["route"]["final"].as_str(), Some("direct"));
        assert_eq!(adopt(&toml_file.to_string_lossy()).unwrap(), got);
        std::fs::write(dir.join("bad.toml"), "[route\n").unwrap();
        let e = adopt(&dir.join("bad.toml").to_string_lossy()).unwrap_err();
        assert!(e.contains("not valid TOML") && e.contains("by hand"), "{e}");
        assert!(!dir.join("bad.yaml").exists());
        let _ = std::fs::remove_dir_all(&dir);
    }
}
