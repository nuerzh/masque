use std::net::{IpAddr, Ipv6Addr, SocketAddr};
use std::time::Duration;

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::time::timeout_at;

use crate::error::{AetherError, Result};

/// The resolver the ECHConfigList is asked for unless --ech-dns names another.
pub const DEFAULT_ECH_DNS: &str = "udp://1.1.1.1";

/// The domain whose ECHConfigList the handshakes offer unless --ech-domain names another.
pub const DEFAULT_ECH_DOMAIN: &str = "cloudflare-ech.com";

const RR_HTTPS: u16 = 65;
const SVCPARAM_ECH: u16 = 5;

/// How long the lookup of the ECHConfigList may take, over any transport.
const ECH_LOOKUP_TIMEOUT: Duration = Duration::from_secs(12);

/// Over UDP the question goes out again after this long without an answer, until the
/// lookup gives up.
const UDP_RESEND_AFTER: Duration = Duration::from_secs(2);

/// The resolver the ECHConfigList is asked for: a DNS server over UDP or TCP, or a
/// DNS-over-HTTPS endpoint (RFC 8484).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EchDns {
    Udp(SocketAddr),
    Tcp(SocketAddr),
    Https(DohEndpoint),
}

/// A DNS-over-HTTPS endpoint. The host of its URL is the HTTP host, of Host or :authority,
/// and also where the connection goes and the server name of the ClientHello, unless
/// `address` and `sni` name others.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DohEndpoint {
    pub url: String,
    /// Where the connection goes: an IP address or a domain name, on the URL's port.
    pub address: Option<String>,
    /// The server name of the ClientHello: a domain name.
    pub sni: Option<String>,
}

impl DohEndpoint {
    /// `value`: an `https://` URL, then `@address=` an IP address or a domain name and
    /// `@sni=` a domain name, each at most once and in either order.
    fn parse(value: &str) -> std::result::Result<Self, String> {
        let mut pieces = value.split('@');
        let url = pieces.next().unwrap_or("").trim();
        let host = strip_scheme(url, "https://")
            .and_then(|rest| rest.split(['/', '?', '#']).next())
            .unwrap_or("");
        if host.is_empty() {
            return Err(format!("{value} names no host"));
        }
        let mut endpoint = DohEndpoint {
            url: url.to_string(),
            address: None,
            sni: None,
        };
        for piece in pieces {
            let neither = || format!("@{piece} in {value} is neither @address= nor @sni=");
            let (name, setting) = piece.split_once('=').ok_or_else(neither)?;
            let setting = setting.trim();
            let bare = setting
                .strip_prefix('[')
                .and_then(|inside| inside.strip_suffix(']'))
                .unwrap_or(setting);
            let (slot, checked) = match name.trim().to_ascii_lowercase().as_str() {
                "address" => (
                    &mut endpoint.address,
                    host_address(setting).ok_or_else(|| {
                        format!(
                            "@address={setting} is no IP address or domain name; the port is the URL's"
                        )
                    }),
                ),
                "sni" => (
                    &mut endpoint.sni,
                    (bare.parse::<IpAddr>().is_err() && valid_domain(setting))
                        .then(|| setting.to_string())
                        .ok_or_else(|| format!("@sni={setting} is no domain name")),
                ),
                _ => return Err(neither()),
            };
            if slot.is_some() {
                return Err(format!("{value} names @{} twice", name.trim()));
            }
            *slot = Some(checked?);
        }
        Ok(endpoint)
    }
}

impl EchDns {
    /// The resolver `value` names: `udp://ip[:port]` or `tcp://ip[:port]`, on port 53
    /// unless one is given and with an IPv6 address in brackets, or an `https://` URL,
    /// on port 443 unless it names one, with `@address=` and `@sni=` after it if need be,
    /// see `DohEndpoint`.
    pub fn parse(value: &str) -> std::result::Result<Self, String> {
        let value = value.trim();
        if strip_scheme(value, "https://").is_some() {
            return DohEndpoint::parse(value).map(EchDns::Https);
        }
        let (rest, tcp) = if let Some(rest) = strip_scheme(value, "udp://") {
            (rest, false)
        } else if let Some(rest) = strip_scheme(value, "tcp://") {
            (rest, true)
        } else {
            return Err(format!("{value} is no udp://, tcp:// or https:// address"));
        };
        let address = socket_address(rest.trim_end_matches('/'), 53)
            .ok_or_else(|| format!("{value} names no IP address"))?;
        Ok(if tcp {
            EchDns::Tcp(address)
        } else {
            EchDns::Udp(address)
        })
    }
}

impl std::fmt::Display for EchDns {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EchDns::Udp(address) => write!(f, "udp://{address}"),
            EchDns::Tcp(address) => write!(f, "tcp://{address}"),
            EchDns::Https(endpoint) => {
                f.write_str(&endpoint.url)?;
                if let Some(address) = &endpoint.address {
                    write!(f, "@address={address}")?;
                }
                if let Some(sni) = &endpoint.sni {
                    write!(f, "@sni={sni}")?;
                }
                Ok(())
            }
        }
    }
}

/// `value` after `scheme`, which it starts with in any case; None when it does not.
fn strip_scheme<'a>(value: &'a str, scheme: &str) -> Option<&'a str> {
    let head = value.get(..scheme.len())?;
    if head.eq_ignore_ascii_case(scheme) {
        Some(&value[scheme.len()..])
    } else {
        None
    }
}

/// `text` as an address: `ip:port`, `[ipv6]:port`, or an IP address alone, on
/// `default_port`.
fn socket_address(text: &str, default_port: u16) -> Option<SocketAddr> {
    if let Ok(address) = text.parse::<SocketAddr>() {
        return Some(address);
    }
    if let Ok(ip) = text.parse::<IpAddr>() {
        return Some(SocketAddr::new(ip, default_port));
    }
    let inner = text.strip_prefix('[')?.strip_suffix(']')?;
    inner
        .parse::<Ipv6Addr>()
        .ok()
        .map(|ip| SocketAddr::new(IpAddr::V6(ip), default_port))
}

/// `value` as the address a connection goes to: an IP address, an IPv6 one with or without
/// brackets, or a domain name; None when it is neither.
pub fn host_address(value: &str) -> Option<String> {
    let bare = value
        .strip_prefix('[')
        .and_then(|inside| inside.strip_suffix(']'))
        .unwrap_or(value);
    match bare.parse::<IpAddr>() {
        Ok(ip) => Some(ip.to_string()),
        Err(_) => valid_domain(value).then(|| value.to_string()),
    }
}

/// `value` as the address and port a connection goes to: `host_address`, on `default_port`,
/// or followed by `:port`, an IPv6 address then in brackets; None when it is neither.
pub fn host_and_port(value: &str, default_port: u16) -> Option<(String, u16)> {
    if let Some(host) = host_address(value) {
        return Some((host, default_port));
    }
    let (host, port) = value.rsplit_once(':')?;
    // An IPv6 address takes brackets before a port.
    if host.contains(':') && !host.starts_with('[') {
        return None;
    }
    let port = port.parse::<u16>().ok().filter(|port| *port != 0)?;
    host_address(host).map(|host| (host, port))
}

/// Whether `name` is a domain whose HTTPS record can be asked for: labels of letters,
/// digits, '-' and '_', of 1 to 63 bytes each and 253 in all, a trailing dot allowed.
pub fn valid_domain(name: &str) -> bool {
    let name = name.strip_suffix('.').unwrap_or(name);
    !name.is_empty()
        && name.len() <= 253
        && name.split('.').all(|label| {
            !label.is_empty()
                && label.len() <= 63
                && label
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
        })
}

/// Where an ECHConfigList is looked up: the options that name the resolver and the
/// domain, and the variables they set.
#[derive(Debug, Clone, Copy)]
pub struct EchLookup {
    pub dns_flag: &'static str,
    pub dns_variable: &'static str,
    pub domain_flag: &'static str,
    pub domain_variable: &'static str,
}

/// The lookup of --ech auto, whose key the calls to the WARP API offer.
pub const API_ECH_LOOKUP: EchLookup = EchLookup {
    dns_flag: "tls.ech-dns",
    dns_variable: "AETHER_ECH_DNS",
    domain_flag: "tls.ech-domain",
    domain_variable: "AETHER_ECH_DOMAIN",
};

/// The resolver `lookup` names, or the default one.
fn configured_dns(lookup: &EchLookup) -> std::result::Result<EchDns, String> {
    let value = crate::config::settings::var(lookup.dns_variable).unwrap_or_default();
    let value = value.trim();
    EchDns::parse(if value.is_empty() {
        DEFAULT_ECH_DNS
    } else {
        value
    })
}

/// The domain `lookup` names, or the default one.
fn configured_domain(lookup: &EchLookup) -> std::result::Result<String, String> {
    let value = crate::config::settings::var(lookup.domain_variable).unwrap_or_default();
    let value = value.trim();
    let name = if value.is_empty() {
        DEFAULT_ECH_DOMAIN
    } else {
        value
    };
    if valid_domain(name) {
        Ok(name.trim_end_matches('.').to_string())
    } else {
        Err(format!("{name} is no domain name"))
    }
}

/// Fetches an ECHConfigList: the ech parameter of the HTTPS record of the domain
/// `lookup` names, asked of the resolver it names, through the upstream proxy when there
/// is one. Over DNS-over-HTTPS, the handshake has the core's TLS fingerprint.
pub async fn fetch_ech_config(lookup: &EchLookup) -> Result<Vec<u8>> {
    fetch_ech_config_with(lookup, &crate::transport::warp::net::tls::Fingerprint::configured()).await
}

/// `fetch_ech_config` with `fingerprint` for the handshake of DNS-over-HTTPS.
async fn fetch_ech_config_with(
    lookup: &EchLookup,
    fingerprint: &crate::transport::warp::net::tls::Fingerprint,
) -> Result<Vec<u8>> {
    let dns = configured_dns(lookup)
        .map_err(|e| AetherError::Ech(format!("{}: {e}", lookup.dns_flag)))?;
    let domain = configured_domain(lookup)
        .map_err(|e| AetherError::Ech(format!("{}: {e}", lookup.domain_flag)))?;
    let lookup = async {
        match &dns {
            EchDns::Udp(server) => query_udp(*server, &domain).await,
            EchDns::Tcp(server) => query_tcp(*server, &domain).await,
            EchDns::Https(endpoint) => query_https(endpoint, &domain, fingerprint).await,
        }
    };
    let ech = match tokio::time::timeout(ECH_LOOKUP_TIMEOUT, lookup).await {
        Ok(Ok(ech)) => ech,
        Ok(Err(e)) => {
            let reason = match e {
                AetherError::Ech(reason) => reason,
                other => other.to_string(),
            };
            return Err(AetherError::Ech(format!(
                "{domain} via {dns} failed: {reason}"
            )));
        }
        Err(_) => {
            return Err(AetherError::Ech(format!(
                "{dns} did not answer for {domain}"
            )));
        }
    };
    log::info!(
        "[dns] fetched ECHConfigList ({} bytes) for {domain} via {dns}",
        ech.len()
    );
    Ok(ech)
}

async fn query_udp(server: SocketAddr, domain: &str) -> Result<Vec<u8>> {
    let (sock, _, _detour) = crate::transport::warp::net::upstream::bind_via_upstream(server).await?;
    let (query, id) = build_query(domain, RR_HTTPS);
    let mut buf = [0u8; 4096];

    // Asked again and again until an answer comes or the lookup gives up, see
    // fetch_ech_config.
    loop {
        sock.send(&query).await?;
        let resend_at = tokio::time::Instant::now() + UDP_RESEND_AFTER;
        while let Ok(received) = timeout_at(resend_at, sock.recv(&mut buf)).await {
            let n = received?;
            if response_matches(&buf[..n], id, domain, RR_HTTPS) {
                return answer_ech(&buf[..n], domain);
            }
            log::debug!("[dns] discarding an ech dns reply that does not match the query");
        }
    }
}

async fn query_tcp(server: SocketAddr, domain: &str) -> Result<Vec<u8>> {
    let mut stream = match crate::transport::warp::net::upstream::configured() {
        Some(proxy) => proxy.connect(server).await?,
        None => crate::utils::egress::tcp_connect(server).await?,
    };
    let (query, id) = build_query(domain, RR_HTTPS);
    stream.write_all(&tcp_message(&query)).await?;

    let mut length = [0u8; 2];
    stream.read_exact(&mut length).await?;
    let mut msg = vec![0u8; u16::from_be_bytes(length) as usize];
    stream.read_exact(&mut msg).await?;

    if !response_matches(&msg, id, domain, RR_HTTPS) {
        return Err(AetherError::Ech(
            "the reply does not match the query".into(),
        ));
    }
    answer_ech(&msg, domain)
}

/// Asks `endpoint`, a DoH endpoint, for the HTTPS record of `domain`, over BoringSSL with
/// `fingerprint` (see `https`), and without ECH: the key it looks up is the one ECH would
/// need. The URL's host is the HTTP host; the connection goes to the endpoint's address and
/// the ClientHello names its sni when it has them, the URL's host otherwise.
async fn query_https(
    endpoint: &DohEndpoint,
    domain: &str,
    fingerprint: &crate::transport::warp::net::tls::Fingerprint,
) -> Result<Vec<u8>> {
    let url = &endpoint.url;
    let parsed = reqwest::Url::parse(url).map_err(|e| AetherError::Ech(format!("{url}: {e}")))?;
    let host = parsed
        .host_str()
        .ok_or_else(|| AetherError::Ech(format!("{url} names no host")))?
        .trim_start_matches('[')
        .trim_end_matches(']');
    let path = match parsed.query() {
        Some(query) => format!("{}?{query}", parsed.path()),
        None => parsed.path().to_string(),
    };

    // RFC 8484 asks for the ID 0, which keeps the answers cacheable.
    let (mut query, _) = build_query(domain, RR_HTTPS);
    query[0] = 0;
    query[1] = 0;
    let headers = [
        (
            "Content-Type".to_string(),
            "application/dns-message".to_string(),
        ),
        ("Accept".to_string(), "application/dns-message".to_string()),
    ];
    let port = parsed.port_or_known_default().unwrap_or(443);
    let request = crate::transport::warp::net::https::Request {
        method: "POST",
        host,
        port,
        address: endpoint.address.as_deref().map(|address| (address, port)),
        sni: endpoint.sni.as_deref(),
        path: &path,
        headers: &headers,
        body: Some(&query),
    };
    let response = crate::transport::warp::net::https::send(&request, fingerprint, None, ECH_LOOKUP_TIMEOUT)
        .await
        .map_err(|e| AetherError::Ech(e.to_string()))?;
    if !(200..300).contains(&response.status) {
        return Err(AetherError::Ech(format!("answered {}", response.status)));
    }
    let msg = response.body;

    if !response_matches(&msg, 0, domain, RR_HTTPS) {
        return Err(AetherError::Ech(
            "the reply does not match the query".into(),
        ));
    }
    answer_ech(&msg, domain)
}

/// `msg` as it goes over TCP: behind its length, in two bytes in network order (RFC
/// 1035, 4.2.2).
fn tcp_message(msg: &[u8]) -> Vec<u8> {
    let mut framed = Vec::with_capacity(msg.len() + 2);
    framed.extend_from_slice(&(msg.len() as u16).to_be_bytes());
    framed.extend_from_slice(msg);
    framed
}

/// The ech parameter of the HTTPS record in `msg`, a reply about `domain`.
fn answer_ech(msg: &[u8], domain: &str) -> Result<Vec<u8>> {
    match parse_https_ech(msg) {
        Some(ech) if !ech.is_empty() => Ok(ech),
        _ => Err(AetherError::Ech(format!(
            "{domain} has no HTTPS record with an ech parameter"
        ))),
    }
}

pub fn response_matches(
    msg: &[u8],
    expected_id: u16,
    expected_name: &str,
    expected_qtype: u16,
) -> bool {
    if msg.len() < 12 {
        return false;
    }
    if u16::from_be_bytes([msg[0], msg[1]]) != expected_id {
        return false;
    }
    if msg[2] & 0x80 == 0 {
        return false;
    }
    if u16::from_be_bytes([msg[4], msg[5]]) != 1 {
        return false;
    }

    let mut pos = 12;
    for label in expected_name.split('.') {
        if label.is_empty() {
            continue;
        }
        let len = match msg.get(pos) {
            Some(value) => *value as usize,
            None => return false,
        };
        if len != label.len() {
            return false;
        }
        pos += 1;
        let end = match pos.checked_add(len) {
            Some(value) if value <= msg.len() => value,
            _ => return false,
        };
        if !msg[pos..end].eq_ignore_ascii_case(label.as_bytes()) {
            return false;
        }
        pos = end;
    }

    if msg.get(pos) != Some(&0) {
        return false;
    }
    pos += 1;

    if pos + 4 > msg.len() {
        return false;
    }

    u16::from_be_bytes([msg[pos], msg[pos + 1]]) == expected_qtype
}

fn build_query(name: &str, qtype: u16) -> (Vec<u8>, u16) {
    let mut q = Vec::with_capacity(32 + name.len());
    let id: u16 = rand::random();
    q.extend_from_slice(&id.to_be_bytes());
    q.extend_from_slice(&[0x01, 0x00]);
    q.extend_from_slice(&[0x00, 0x01]);
    q.extend_from_slice(&[0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    for label in name.split('.') {
        if label.is_empty() {
            continue;
        }
        q.push(label.len() as u8);
        q.extend_from_slice(label.as_bytes());
    }
    q.push(0x00);
    q.extend_from_slice(&qtype.to_be_bytes());
    q.extend_from_slice(&[0x00, 0x01]);
    (q, id)
}

fn parse_https_ech(msg: &[u8]) -> Option<Vec<u8>> {
    if msg.len() < 12 {
        return None;
    }
    let qd = u16::from_be_bytes([msg[4], msg[5]]) as usize;
    let an = u16::from_be_bytes([msg[6], msg[7]]) as usize;
    let mut pos = 12;

    for _ in 0..qd {
        pos = skip_name(msg, pos)?;
        pos = pos.checked_add(4)?;
    }

    for _ in 0..an {
        pos = skip_name(msg, pos)?;
        if pos + 10 > msg.len() {
            return None;
        }
        let rtype = u16::from_be_bytes([msg[pos], msg[pos + 1]]);
        let rdlen = u16::from_be_bytes([msg[pos + 8], msg[pos + 9]]) as usize;
        pos += 10;
        if pos + rdlen > msg.len() {
            return None;
        }
        if rtype == RR_HTTPS {
            if let Some(ech) = parse_svcparams_ech(msg, pos, rdlen) {
                return Some(ech);
            }
        }
        pos += rdlen;
    }
    None
}

fn parse_svcparams_ech(msg: &[u8], rdata_start: usize, rdlen: usize) -> Option<Vec<u8>> {
    let end = rdata_start + rdlen;
    if rdata_start + 2 > end {
        return None;
    }
    let mut p = skip_name(msg, rdata_start + 2)?;

    while p + 4 <= end {
        let key = u16::from_be_bytes([msg[p], msg[p + 1]]);
        let len = u16::from_be_bytes([msg[p + 2], msg[p + 3]]) as usize;
        p += 4;
        if p + len > end {
            return None;
        }
        if key == SVCPARAM_ECH {
            return Some(msg[p..p + len].to_vec());
        }
        p += len;
    }
    None
}

fn skip_name(buf: &[u8], mut pos: usize) -> Option<usize> {
    loop {
        let len = *buf.get(pos)?;
        if len & 0xc0 == 0xc0 {
            return Some(pos + 2);
        }
        if len == 0 {
            return Some(pos + 1);
        }
        pos += 1 + len as usize;
    }
}

#[cfg(test)]
mod tests;
