use super::*;

#[test]
fn the_ech_dns_names_a_resolver_over_udp_tcp_or_https() {
    let at = |text: &str| text.parse::<SocketAddr>().unwrap();
    assert_eq!(
        EchDns::parse("udp://1.1.1.1"),
        Ok(EchDns::Udp(at("1.1.1.1:53")))
    );
    assert_eq!(
        EchDns::parse(" UDP://8.8.8.8:5353 "),
        Ok(EchDns::Udp(at("8.8.8.8:5353")))
    );
    assert_eq!(
        EchDns::parse("tcp://1.1.1.1"),
        Ok(EchDns::Tcp(at("1.1.1.1:53")))
    );
    assert_eq!(
        EchDns::parse("tcp://[2606:4700:4700::1111]"),
        Ok(EchDns::Tcp(at("[2606:4700:4700::1111]:53")))
    );
    assert_eq!(
        EchDns::parse("udp://[::1]:5353/"),
        Ok(EchDns::Udp(at("[::1]:5353")))
    );
    assert_eq!(
        EchDns::parse("https://doq.dns4all.eu/dns-query"),
        Ok(doh("https://doq.dns4all.eu/dns-query", None, None))
    );
    assert_eq!(
        EchDns::parse("https://1.1.1.1:8443/dns-query"),
        Ok(doh("https://1.1.1.1:8443/dns-query", None, None))
    );
    assert_eq!(
        EchDns::parse(DEFAULT_ECH_DNS),
        Ok(EchDns::Udp(at("1.1.1.1:53")))
    );
    assert_eq!(
        EchDns::parse("tcp://[::1]").unwrap().to_string(),
        "tcp://[::1]:53"
    );
}

fn doh(url: &str, address: Option<&str>, sni: Option<&str>) -> EchDns {
    EchDns::Https(DohEndpoint {
        url: url.to_string(),
        address: address.map(str::to_string),
        sni: sni.map(str::to_string),
    })
}

#[test]
fn a_doh_url_takes_an_address_and_a_server_name_of_their_own() {
    let url = "https://doq.dns4all.eu/dns-query";
    for (text, address, sni) in [
        (
            "https://doq.dns4all.eu/dns-query@address=2.2.2.2@sni=google.com",
            Some("2.2.2.2"),
            Some("google.com"),
        ),
        (
            " https://doq.dns4all.eu/dns-query@SNI=google.com@Address=2.2.2.2 ",
            Some("2.2.2.2"),
            Some("google.com"),
        ),
        (
            "https://doq.dns4all.eu/dns-query@address=[2606:4700::1111]",
            Some("2606:4700::1111"),
            None,
        ),
        (
            "https://doq.dns4all.eu/dns-query@address=2606:4700::1111",
            Some("2606:4700::1111"),
            None,
        ),
        (
            "https://doq.dns4all.eu/dns-query@address=front.example.net",
            Some("front.example.net"),
            None,
        ),
        (
            "https://doq.dns4all.eu/dns-query@sni=google.com",
            None,
            Some("google.com"),
        ),
    ] {
        assert_eq!(EchDns::parse(text), Ok(doh(url, address, sni)), "{text}");
    }
    assert_eq!(
        EchDns::parse("https://doq.dns4all.eu@address=2.2.2.2"),
        Ok(doh("https://doq.dns4all.eu", Some("2.2.2.2"), None))
    );
    // As it is read, and as the log shows it.
    let text = "https://doq.dns4all.eu/dns-query@address=2.2.2.2@sni=google.com";
    assert_eq!(EchDns::parse(text).unwrap().to_string(), text);
}

#[test]
fn an_address_may_name_a_port_an_ipv6_one_in_brackets() {
    let at = |host: &str, port: u16| Some((host.to_string(), port));
    assert_eq!(host_and_port("188.114.97.6", 443), at("188.114.97.6", 443));
    assert_eq!(
        host_and_port("188.114.97.6:2053", 443),
        at("188.114.97.6", 2053)
    );
    assert_eq!(
        host_and_port("edge.example.com", 8443),
        at("edge.example.com", 8443)
    );
    assert_eq!(
        host_and_port("edge.example.com:443", 8443),
        at("edge.example.com", 443)
    );
    assert_eq!(host_and_port("2606:4700::1", 443), at("2606:4700::1", 443));
    assert_eq!(
        host_and_port("[2606:4700::1]", 443),
        at("2606:4700::1", 443)
    );
    assert_eq!(
        host_and_port("[2606:4700::1]:8443", 443),
        at("2606:4700::1", 8443)
    );
    for refused in [
        "188.114.97.6:0",
        "188.114.97.6:65536",
        "188.114.97.6:",
        "edge.example.com:https",
        ":443",
        "1.2.3.4:443:5",
        "[2606:4700::1:443",
        // Eight groups and a port: without brackets it is no address at all.
        "2606:4700:4700:0:0:0:0:1111:443",
        "https://edge.example.com",
        "edge example.com",
    ] {
        assert_eq!(host_and_port(refused, 443), None, "{refused}");
    }
}

#[test]
fn a_doh_url_with_a_parameter_it_cannot_use_is_refused() {
    for text in [
        "https://doq.dns4all.eu/dns-query@address=",
        "https://doq.dns4all.eu/dns-query@address=2.2.2.2:443",
        "https://doq.dns4all.eu/dns-query@address=not a name",
        "https://doq.dns4all.eu/dns-query@sni=",
        "https://doq.dns4all.eu/dns-query@sni=2.2.2.2",
        "https://doq.dns4all.eu/dns-query@sni=[::1]",
        "https://doq.dns4all.eu/dns-query@sni=google.com@sni=bing.com",
        "https://doq.dns4all.eu/dns-query@address=1.1.1.1@address=2.2.2.2",
        "https://doq.dns4all.eu/dns-query@port=443",
        "https://doq.dns4all.eu/dns-query@google.com",
        "https://user@doq.dns4all.eu/dns-query",
        "https://@address=2.2.2.2",
    ] {
        assert!(EchDns::parse(text).is_err(), "{text}");
    }
}

#[test]
fn an_ech_dns_without_a_scheme_or_an_ip_address_is_refused() {
    for text in [
        "1.1.1.1",
        "dns.google",
        "tls://1.1.1.1",
        "udp://dns.google",
        "tcp://",
        "udp://1.1.1.1:99999",
        "https://",
        "https:///dns-query",
        "",
    ] {
        assert!(EchDns::parse(text).is_err(), "{text}");
    }
}

#[test]
fn the_ech_domain_is_a_dns_name() {
    for name in [
        DEFAULT_ECH_DOMAIN,
        "crypto.cloudflare.com",
        "ip.gs",
        "ip.gs.",
        "_ech.example",
    ] {
        assert!(valid_domain(name), "{name}");
    }
    let long = format!("{}.com", "a".repeat(64));
    for name in [
        "",
        ".",
        "a..b",
        "with space.com",
        "https://ip.gs",
        "ip.gs/",
        long.as_str(),
    ] {
        assert!(!valid_domain(name), "{name}");
    }
}

#[test]
fn a_message_over_tcp_goes_behind_its_length() {
    assert_eq!(tcp_message(&[7, 8, 9]), vec![0, 3, 7, 8, 9]);
    assert_eq!(tcp_message(&[0u8; 300])[..2], [1, 44]);
}

fn reply(id: u16, name: &str, qtype: u16, qr: bool, qdcount: u16) -> Vec<u8> {
    let mut msg = Vec::new();
    msg.extend_from_slice(&id.to_be_bytes());
    msg.push(if qr { 0x81 } else { 0x01 });
    msg.push(0x80);
    msg.extend_from_slice(&qdcount.to_be_bytes());
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg.extend_from_slice(&[0, 0, 0, 0]);
    for label in name.split('.') {
        msg.push(label.len() as u8);
        msg.extend_from_slice(label.as_bytes());
    }
    msg.push(0);
    msg.extend_from_slice(&qtype.to_be_bytes());
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg
}

#[test]
fn build_query_reports_the_id_it_wrote() {
    let (query, id) = build_query("cloudflare-ech.com", RR_HTTPS);
    assert_eq!(u16::from_be_bytes([query[0], query[1]]), id);
}

#[test]
fn accepts_a_reply_that_matches_the_query() {
    let msg = reply(0x1234, "cloudflare-ech.com", RR_HTTPS, true, 1);
    assert!(response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

#[test]
fn rejects_a_spoofed_reply_with_the_wrong_transaction_id() {
    let msg = reply(0x9999, "cloudflare-ech.com", RR_HTTPS, true, 1);
    assert!(!response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

#[test]
fn rejects_a_reply_for_a_different_name() {
    let msg = reply(0x1234, "attacker.example", RR_HTTPS, true, 1);
    assert!(!response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

#[test]
fn rejects_a_reply_for_a_different_record_type() {
    let msg = reply(0x1234, "cloudflare-ech.com", 1, true, 1);
    assert!(!response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

#[test]
fn rejects_a_message_that_is_not_a_response() {
    let msg = reply(0x1234, "cloudflare-ech.com", RR_HTTPS, false, 1);
    assert!(!response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

#[test]
fn rejects_a_reply_with_an_unexpected_question_count() {
    let msg = reply(0x1234, "cloudflare-ech.com", RR_HTTPS, true, 2);
    assert!(!response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

#[test]
fn rejects_truncated_input_without_panicking() {
    let msg = reply(0x1234, "cloudflare-ech.com", RR_HTTPS, true, 1);
    for cut in 0..msg.len() {
        assert!(!response_matches(
            &msg[..cut],
            0x1234,
            "cloudflare-ech.com",
            RR_HTTPS
        ));
    }
}

#[test]
fn name_comparison_is_case_insensitive() {
    let msg = reply(0x1234, "CloudFlare-ECH.com", RR_HTTPS, true, 1);
    assert!(response_matches(
        &msg,
        0x1234,
        "cloudflare-ech.com",
        RR_HTTPS
    ));
}

/// The ClientHello of `lookup` over DoH, as a server on this machine reads it before it
/// hangs up.
async fn doh_hello(lookup: &EchLookup) -> crate::transport::warp::net::tls::client_hello::ClientHello {
    let (server, hello) = crate::transport::warp::net::tls::client_hello::catch().await;
    crate::config::settings::decide(lookup.dns_variable, format!("https://{server}/dns-query"));
    assert!(fetch_ech_config(lookup).await.is_err());
    crate::config::settings::forget(lookup.dns_variable);
    hello.await.expect("the ClientHello")
}

#[tokio::test]
async fn a_doh_lookup_has_the_fingerprint_the_options_give_and_no_ech() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let _options = crate::transport::warp::net::tls::hold_options().await;
    // A lookup of the test's own, so that no other test sees its variables.
    const LOOKUP: EchLookup = EchLookup {
        dns_flag: "--doh-test-dns",
        dns_variable: "AETHER_DOH_TEST_DNS",
        domain_flag: "--doh-test-domain",
        domain_variable: "AETHER_DOH_TEST_DOMAIN",
    };
    let own = doh_hello(&LOOKUP).await;
    crate::config::settings::decide(
        "AETHER_TLS_CIPHERS",
        "ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:AES256-SHA",
    );
    crate::config::settings::decide("AETHER_TLS_GROUPS", "X25519:P-256");
    crate::config::settings::decide("AETHER_DISABLE_GREASE", "1");
    let changed = doh_hello(&LOOKUP).await;
    // The core's ClientHello, Chrome's, offering HTTP/2 first, never ECH: the key it looks
    // up is the one ECH would need.
    assert!(own.has_grease());
    assert_eq!(own.alpn(), [b"h2".to_vec(), b"http/1.1".to_vec()]);
    assert_eq!(
        own.tls12_suites(),
        crate::transport::warp::net::tls::client_hello::chrome_tls12_suites()
    );
    assert_eq!(own.groups(), [0x0017, 0x001d, 0x0018]);
    assert!(!own.offers_ech() && !changed.offers_ech());
    // Every suite of the list, in its order, AES256-SHA among them; the groups; no GREASE.
    assert_eq!(changed.tls12_suites(), [0xc02f, 0xcca9, 0x0035]);
    assert_ne!(own.tls12_suites(), changed.tls12_suites());
    assert_eq!(changed.groups(), [0x001d, 0x0017]);
    assert!(!changed.has_grease());
}

/// A reply to `query` that holds one HTTPS record for its name, with `ech` for its ech
/// parameter.
fn https_reply(query: &[u8], ech: &[u8]) -> Vec<u8> {
    let mut rdata = vec![0x00, 0x01, 0x00];
    rdata.extend_from_slice(&SVCPARAM_ECH.to_be_bytes());
    rdata.extend_from_slice(&(ech.len() as u16).to_be_bytes());
    rdata.extend_from_slice(ech);

    let mut msg = query.to_vec();
    msg[2] |= 0x80;
    msg[6..8].copy_from_slice(&1u16.to_be_bytes());
    msg.extend_from_slice(&[0xc0, 0x0c]);
    msg.extend_from_slice(&RR_HTTPS.to_be_bytes());
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg.extend_from_slice(&300u32.to_be_bytes());
    msg.extend_from_slice(&(rdata.len() as u16).to_be_bytes());
    msg.extend_from_slice(&rdata);
    msg
}

/// What a DoH server on this machine was asked.
struct Asked {
    method: String,
    path: String,
    kind: String,
    /// The server name of the ClientHello.
    server_name: Option<String>,
    /// The HTTP host: Host, or :authority.
    host: String,
}

/// A DoH server on this machine that speaks the protocol of `alpn` and answers one query
/// with `ech`; the task ends with what it was asked.
async fn doh_server(
    alpn: &'static [u8],
    ech: &'static [u8],
) -> (SocketAddr, tokio::task::JoinHandle<Asked>) {
    let (address, listener, acceptor) = crate::transport::warp::net::https::test_server(alpn).await;
    let served = tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.expect("a connection");
        let mut tls = tokio_boring::accept(&acceptor, tcp)
            .await
            .expect("a handshake");
        let server_name = tls
            .ssl()
            .servername(boring::ssl::NameType::HOST_NAME)
            .map(str::to_string);
        if alpn == b"\x02h2" {
            let mut connection = h2::server::handshake(tls).await.expect("h2");
            let (request, mut respond) = connection
                .accept()
                .await
                .expect("a request")
                .expect("a whole request");
            let (parts, mut body) = request.into_parts();
            let mut query = Vec::new();
            while let Some(chunk) = body.data().await {
                query.extend_from_slice(&chunk.expect("the query"));
            }
            let answer = http::Response::builder()
                .status(200)
                .header("content-type", "application/dns-message")
                .body(())
                .unwrap();
            let mut stream = respond.send_response(answer, false).expect("an answer");
            stream
                .send_data(bytes::Bytes::from(https_reply(&query, ech)), true)
                .expect("its body");
            while let Some(Ok(_)) = connection.accept().await {}
            let kind = parts.headers["content-type"].to_str().unwrap().to_string();
            let path = parts.uri.path_and_query().map(|path| path.to_string());
            Asked {
                method: parts.method.to_string(),
                path: path.unwrap_or_default(),
                kind,
                server_name,
                host: parts
                    .uri
                    .authority()
                    .map(|a| a.to_string())
                    .unwrap_or_default(),
            }
        } else {
            let mut raw = Vec::new();
            let mut chunk = [0u8; 4096];
            let (head_end, length) = loop {
                let read = tls.read(&mut chunk).await.expect("the request");
                raw.extend_from_slice(&chunk[..read]);
                if let Some(end) = raw.windows(4).position(|window| window == b"\r\n\r\n") {
                    let head = String::from_utf8_lossy(&raw[..end]).to_lowercase();
                    let length = head
                        .lines()
                        .find_map(|line| line.strip_prefix("content-length:"))
                        .and_then(|value| value.trim().parse::<usize>().ok())
                        .expect("a length");
                    break (end + 4, length);
                }
            };
            while raw.len() < head_end + length {
                let read = tls.read(&mut chunk).await.expect("the query");
                raw.extend_from_slice(&chunk[..read]);
            }
            let head = String::from_utf8_lossy(&raw[..head_end]).into_owned();
            let reply = https_reply(&raw[head_end..head_end + length], ech);
            let mut wire = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: application/dns-message\r\nContent-Length: {}\r\n\r\n",
                reply.len()
            )
            .into_bytes();
            wire.extend_from_slice(&reply);
            tls.write_all(&wire).await.expect("the answer");
            let mut words = head.split_whitespace();
            let method = words.next().unwrap_or("").to_string();
            let path = words.next().unwrap_or("").to_string();
            let field = |name: &str| {
                head.lines()
                    .find_map(|line| line.strip_prefix(name))
                    .unwrap_or("")
                    .trim()
                    .to_string()
            };
            Asked {
                method,
                path,
                kind: field("Content-Type: "),
                server_name,
                host: field("Host: "),
            }
        }
    });
    (address, served)
}

#[tokio::test]
async fn a_doh_lookup_reads_the_key_over_http2_or_http1() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    const LOOKUP: EchLookup = EchLookup {
        dns_flag: "--doh-server-test-dns",
        dns_variable: "AETHER_DOH_SERVER_TEST_DNS",
        domain_flag: "--doh-server-test-domain",
        domain_variable: "AETHER_DOH_SERVER_TEST_DOMAIN",
    };
    const KEY: &[u8] = b"\x00\x05a key";
    for alpn in [&b"\x02h2"[..], &b"\x08http/1.1"[..]] {
        let (server, served) = doh_server(alpn, KEY).await;
        crate::config::settings::decide(
            LOOKUP.dns_variable,
            format!("https://{server}/dns-query?ct"),
        );
        let key = fetch_ech_config_with(&LOOKUP, &crate::transport::warp::net::tls::Fingerprint::default()).await;
        crate::config::settings::forget(LOOKUP.dns_variable);
        assert_eq!(key.expect("the key").as_slice(), KEY, "{alpn:?}");
        let asked = served.await.expect("the server");
        assert_eq!(asked.method, "POST");
        assert_eq!(asked.path, "/dns-query?ct");
        assert_eq!(asked.kind, "application/dns-message");
        // An address for its host: neither a server name nor a host of its own.
        assert_eq!(asked.server_name, None);
        assert_eq!(asked.host, server.to_string());
    }
}

#[tokio::test]
async fn a_doh_lookup_goes_to_its_address_with_its_server_name() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    const LOOKUP: EchLookup = EchLookup {
        dns_flag: "--doh-front-test-dns",
        dns_variable: "AETHER_DOH_FRONT_TEST_DNS",
        domain_flag: "--doh-front-test-domain",
        domain_variable: "AETHER_DOH_FRONT_TEST_DOMAIN",
    };
    const KEY: &[u8] = b"\x00\x05a key";
    for alpn in [&b"\x02h2"[..], &b"\x08http/1.1"[..]] {
        let (server, served) = doh_server(alpn, KEY).await;
        // doh.example.test is never looked up: the connection goes to the address.
        crate::config::settings::decide(
            LOOKUP.dns_variable,
            format!(
                "https://doh.example.test:{}/dns-query@address=127.0.0.1@sni=front.example.test",
                server.port()
            ),
        );
        let key = fetch_ech_config_with(&LOOKUP, &crate::transport::warp::net::tls::Fingerprint::default()).await;
        crate::config::settings::forget(LOOKUP.dns_variable);
        assert_eq!(key.expect("the key").as_slice(), KEY, "{alpn:?}");
        let asked = served.await.expect("the server");
        assert_eq!(asked.server_name.as_deref(), Some("front.example.test"));
        assert_eq!(asked.host, format!("doh.example.test:{}", server.port()));
        assert_eq!(asked.path, "/dns-query");
    }
}
