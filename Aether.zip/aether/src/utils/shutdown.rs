//! The run's stop signal. Every background task that has no end of its own (rule-set updates,
//! the stats line, the exit-location report, the listeners of a run, the TUN) is started with
//! `spawn` and ends when the run that started it ends: `run_with` returning, or the library's
//! job being cancelled, which drops it. Without this a library that starts and stops the core
//! again and again would keep every earlier run's loops.

use std::future::Future;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;

use parking_lot::Mutex;
use tokio::sync::watch;

/// A copy of one run's stop signal.
#[derive(Clone)]
pub struct Token {
    stopped: watch::Receiver<bool>,
    generation: u64,
}

impl Token {
    pub fn is_stopped(&self) -> bool {
        *self.stopped.borrow()
    }

    /// Which run this is; a new run has a higher number.
    pub fn generation(&self) -> u64 {
        self.generation
    }

    pub async fn stopped(&self) {
        let mut rx = self.stopped.clone();
        // a sender that is gone (its run ended) counts as stopped
        let _ = rx.wait_for(|stopped| *stopped).await;
    }
}

struct Current {
    sender: Arc<watch::Sender<bool>>,
    generation: u64,
}

static CURRENT: Mutex<Option<Current>> = Mutex::new(None);
static GENERATION: AtomicU64 = AtomicU64::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);

/// A run in progress; dropping it stops every task the run started with `spawn`.
pub struct Run {
    sender: Arc<watch::Sender<bool>>,
    generation: u64,
}

impl Run {
    #[cfg(test)]
    pub fn token(&self) -> Token {
        Token {
            stopped: self.sender.subscribe(),
            generation: self.generation,
        }
    }
}

impl Drop for Run {
    fn drop(&mut self) {
        self.sender.send_replace(true);
        let mut current = CURRENT.lock();
        if current.as_ref().is_some_and(|c| c.generation == self.generation) {
            *current = None;
        }
    }
}

/// Start a run: what `spawn` starts from now on stops when the returned `Run` is dropped. An
/// earlier run still going is stopped first.
pub fn begin() -> Run {
    let generation = GENERATION.fetch_add(1, Ordering::SeqCst) + 1;
    let (sender, _) = watch::channel(false);
    let sender = Arc::new(sender);
    let previous = CURRENT.lock().replace(Current {
        sender: sender.clone(),
        generation,
    });
    if let Some(previous) = previous {
        previous.sender.send_replace(true);
    }
    Run { sender, generation }
}

/// The stop signal of the run in progress. Outside a run (a test, a library call that is not
/// a core run) a signal that never fires.
pub fn token() -> Token {
    match CURRENT.lock().as_ref() {
        Some(c) => Token {
            stopped: c.sender.subscribe(),
            generation: c.generation,
        },
        None => {
            let (sender, stopped) = watch::channel(false);
            // kept, so that the receiver never sees the sender gone
            std::mem::forget(sender);
            Token { stopped, generation: 0 }
        }
    }
}

/// Counts a task of `spawn` while it lives, whichever way it ends.
struct Live;

impl Live {
    fn new() -> Self {
        LIVE.fetch_add(1, Ordering::SeqCst);
        Live
    }
}

impl Drop for Live {
    fn drop(&mut self) {
        LIVE.fetch_sub(1, Ordering::SeqCst);
    }
}

/// Run `task` until it ends or the current run stops.
pub fn spawn<F>(task: F) -> tokio::task::JoinHandle<()>
where
    F: Future + Send + 'static,
{
    spawn_with(token(), task)
}

/// `spawn` tied to `token` rather than the current run's.
pub fn spawn_with<F>(token: Token, task: F) -> tokio::task::JoinHandle<()>
where
    F: Future + Send + 'static,
{
    let live = Live::new();
    tokio::spawn(async move {
        let _live = live;
        if token.is_stopped() {
            return;
        }
        tokio::select! {
            biased;
            _ = token.stopped() => {}
            _ = task => {}
        }
    })
}

/// How many tasks started with `spawn` are still running, in every run.
#[cfg(test)]
pub fn live() -> usize {
    LIVE.load(Ordering::SeqCst)
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;

    // `CURRENT` and `LIVE` are process-wide; the tests that start runs take turns.
    pub(crate) static RUNS: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

    async fn settle(until: impl Fn() -> bool) {
        for _ in 0..200 {
            if until() {
                return;
            }
            tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        }
    }

    #[tokio::test]
    async fn tasks_of_a_run_end_with_it_and_do_not_pile_up() {
        let _turn = RUNS.lock().await;
        let before = live();
        for round in 0..5 {
            let run = begin();
            for _ in 0..4 {
                spawn(std::future::pending::<()>());
            }
            assert_eq!(live(), before + 4, "round {round}");
            drop(run);
            settle(|| live() == before).await;
            assert_eq!(live(), before, "round {round}: the run's loops are still there");
        }
    }

    #[tokio::test]
    async fn a_new_run_stops_the_one_before_it() {
        let _turn = RUNS.lock().await;
        let first = begin();
        let old = first.token();
        let second = begin();
        assert!(old.is_stopped());
        assert!(!second.token().is_stopped());
        assert!(second.token().generation() > old.generation());
        drop(first);
        assert!(!token().is_stopped(), "dropping an older run leaves the current one alone");
        drop(second);
        assert_eq!(token().generation(), 0);
    }

    #[tokio::test]
    async fn outside_a_run_nothing_is_stopped() {
        let _turn = RUNS.lock().await;
        let t = token();
        assert!(!t.is_stopped());
        let done = spawn_with(t, async {});
        done.await.unwrap();
    }
}
