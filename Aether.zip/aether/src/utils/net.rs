use std::net::IpAddr;

/// LAN, loopback, link-local, CGNAT, documentation and unspecified space: addresses that are
/// reached on this network, never through a proxy or a tunnel.
pub fn is_private(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            v4.is_private()
                || v4.is_loopback()
                || v4.is_link_local()
                || v4.is_broadcast()
                || v4.is_documentation()
                || v4.is_unspecified()
                || v4.octets()[0] == 100 && (64..128).contains(&v4.octets()[1])
        }
        IpAddr::V6(v6) => {
            v6.is_loopback()
                || v6.is_unspecified()
                || (v6.segments()[0] & 0xfe00) == 0xfc00
                || (v6.segments()[0] & 0xffc0) == 0xfe80
        }
    }
}

#[cfg(test)]
mod tests {
    use super::is_private;

    #[test]
    fn lan_loopback_and_cgnat_are_private() {
        for ip in ["10.1.2.3", "192.168.0.1", "127.0.0.1", "100.96.0.2", "169.254.1.1", "::1", "fd00::1", "fe80::1"] {
            assert!(is_private(ip.parse().unwrap()), "{ip}");
        }
        for ip in ["1.1.1.1", "100.128.0.1", "2606:4700::1"] {
            assert!(!is_private(ip.parse().unwrap()), "{ip}");
        }
    }
}
