//! Reads sing-box rule-set files (`.srs`), the binary form that sing-box and sing-geosite publish,
//! and turns them into rule lines in the routes-file syntax.
//!
//! The layout follows sing-box 1.12 (`common/srs/binary.go`, `ip_set.go`) and the sing library's
//! varbin and domain matcher. A file is the magic `SRS`, a version byte (1 to 3), and a zlib
//! stream holding a uvarint rule count followed by the rules.
//!
//! Each rule is converted as far as the routes syntax can express it. Inside one rule, the
//! destination address items (domain, keyword, regex, IP range) match when any of them does, and
//! the destination port items likewise; a rule that combines an address with a port, or uses an
//! item the routes syntax has no form for, cannot be written as a plain list, so it is left out and
//! counted in [`Decoded::skipped`].

use std::io::Read;
use std::net::{Ipv4Addr, Ipv6Addr};

use crate::error::{AetherError, Result};

const MAGIC: &[u8; 3] = b"SRS";
const MAX_VERSION: u8 = 3;

/// The rule lines of a rule set, and the reasons for the rules that could not be converted.
#[derive(Debug, Default)]
pub struct Decoded {
    pub lines: Vec<String>,
    pub skipped: Vec<&'static str>,
}

/// Whether the bytes are a sing-box binary rule set.
pub fn is_srs(bytes: &[u8]) -> bool {
    bytes.len() >= 4 && &bytes[..3] == MAGIC
}

/// Decodes a binary rule set into routes-syntax lines.
pub fn decode(bytes: &[u8]) -> Result<Decoded> {
    if !is_srs(bytes) {
        return Err(AetherError::Other("not a sing-box rule set file".into()));
    }
    let version = bytes[3];
    if version == 0 || version > MAX_VERSION {
        return Err(AetherError::Other(format!("unsupported rule set version {version}")));
    }

    let mut body = Vec::new();
    flate2::read::ZlibDecoder::new(&bytes[4..])
        .read_to_end(&mut body)
        .map_err(|e| AetherError::Other(format!("rule set is not a valid zlib stream: {e}")))?;

    let mut r = Reader::new(&body);
    let count = r.uvarint()?;
    let mut out = Decoded::default();
    for _ in 0..count {
        match rule(&mut r)? {
            Converted::Lines(lines) => out.lines.extend(lines),
            Converted::Skipped(reason) => out.skipped.push(reason),
        }
    }
    Ok(out)
}

// ---------------------------------------------------------------------------------------------
// Reading primitives: the sing varbin encoding. Lengths are uvarints, integers are big-endian.

struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

fn short() -> AetherError {
    AetherError::Other("rule set is truncated or damaged".into())
}

impl<'a> Reader<'a> {
    fn new(data: &'a [u8]) -> Self {
        Self { data, pos: 0 }
    }

    fn byte(&mut self) -> Result<u8> {
        let b = *self.data.get(self.pos).ok_or_else(short)?;
        self.pos += 1;
        Ok(b)
    }

    fn take(&mut self, n: usize) -> Result<&'a [u8]> {
        let end = self.pos.checked_add(n).ok_or_else(short)?;
        let slice = self.data.get(self.pos..end).ok_or_else(short)?;
        self.pos = end;
        Ok(slice)
    }

    /// Go's `binary.ReadUvarint`: little-endian base-128, at most ten bytes.
    fn uvarint(&mut self) -> Result<u64> {
        let mut value: u64 = 0;
        for shift in (0..70).step_by(7) {
            let b = self.byte()?;
            if b < 0x80 {
                if shift == 63 && b > 1 {
                    return Err(AetherError::Other("rule set length overflows".into()));
                }
                return Ok(value | (u64::from(b) << shift));
            }
            value |= u64::from(b & 0x7f) << shift;
        }
        Err(AetherError::Other("rule set length overflows".into()))
    }

    /// A length-prefixed byte string.
    fn bytes(&mut self) -> Result<&'a [u8]> {
        let n = self.uvarint()?;
        let n = usize::try_from(n).map_err(|_| short())?;
        self.take(n)
    }

    /// A string list: a count, then each string.
    fn strings(&mut self) -> Result<Vec<String>> {
        let n = self.uvarint()?;
        let mut out = Vec::new();
        for _ in 0..n {
            out.push(String::from_utf8_lossy(self.bytes()?).into_owned());
        }
        Ok(out)
    }

    /// A count, then big-endian `u16` values.
    fn u16s(&mut self) -> Result<Vec<u16>> {
        let n = self.uvarint()?;
        let mut out = Vec::new();
        for _ in 0..n {
            let b = self.take(2)?;
            out.push(u16::from_be_bytes([b[0], b[1]]));
        }
        Ok(out)
    }

    /// A count, then big-endian `u64` values.
    fn u64s(&mut self) -> Result<Vec<u64>> {
        let n = self.uvarint()?;
        let mut out = Vec::new();
        for _ in 0..n {
            let b = self.take(8)?;
            let mut word = [0u8; 8];
            word.copy_from_slice(b);
            out.push(u64::from_be_bytes(word));
        }
        Ok(out)
    }
}

// ---------------------------------------------------------------------------------------------
// Rules

enum Converted {
    Lines(Vec<String>),
    Skipped(&'static str),
}

/// What a default rule's items amount to, before it is judged.
#[derive(Default)]
struct Items {
    /// Destination address lines: they match when any of them does.
    addresses: Vec<String>,
    /// Destination port lines: they match when any of them does.
    ports: Vec<String>,
    /// An item with no routes-syntax form, named for the warning.
    unsupported: Option<&'static str>,
}

fn rule(r: &mut Reader<'_>) -> Result<Converted> {
    match r.byte()? {
        0 => default_rule(r),
        1 => logical_rule(r),
        other => Err(AetherError::Other(format!("unknown rule type {other} in rule set"))),
    }
}

fn default_rule(r: &mut Reader<'_>) -> Result<Converted> {
    let mut items = Items::default();
    let mut invert = false;
    loop {
        let kind = r.byte()?;
        match kind {
            // Query type: a DNS record type; no meaning for routing.
            0 => {
                r.u16s()?;
                items.unsupported.get_or_insert("query_type");
            }
            1 => {
                r.strings()?;
                items.unsupported.get_or_insert("network");
            }
            2 => items.addresses.extend(domain_matcher(r)?),
            3 => items.addresses.extend(r.strings()?.into_iter().map(|k| format!("keyword:{k}"))),
            4 => items.addresses.extend(r.strings()?.into_iter().map(|p| format!("regexp:{p}"))),
            5 => {
                ip_set(r)?;
                items.unsupported.get_or_insert("source_ip_cidr");
            }
            6 => items.addresses.extend(ip_set(r)?),
            7 => {
                r.u16s()?;
                items.unsupported.get_or_insert("source_port");
            }
            8 => {
                r.strings()?;
                items.unsupported.get_or_insert("source_port_range");
            }
            9 => items.ports.extend(r.u16s()?.into_iter().map(|p| format!("port:{p}"))),
            10 => {
                for range in r.strings()? {
                    items.ports.push(port_range(&range)?);
                }
            }
            11 | 12 | 13 | 14 | 15 | 17 => {
                r.strings()?;
                items.unsupported.get_or_insert(item_name(kind));
            }
            16 => {
                // AdGuard matcher: not converted; a rule that uses it is left out.
                skip_adguard(r)?;
                items.unsupported.get_or_insert("adguard_domain");
            }
            18 => {
                r.bytes()?;
                items.unsupported.get_or_insert("network_type");
            }
            19 => {
                items.unsupported.get_or_insert("network_is_expensive");
            }
            20 => {
                items.unsupported.get_or_insert("network_is_constrained");
            }
            0xFF => {
                invert = r.byte()? != 0;
                break;
            }
            other => return Err(AetherError::Other(format!("unknown rule item {other} in rule set"))),
        }
    }

    if invert {
        return Ok(Converted::Skipped("inverted rule"));
    }
    if let Some(name) = items.unsupported {
        return Ok(Converted::Skipped(name));
    }
    match (items.addresses.is_empty(), items.ports.is_empty()) {
        (false, true) => Ok(Converted::Lines(items.addresses)),
        (true, false) => Ok(Converted::Lines(items.ports)),
        (false, false) => Ok(Converted::Skipped("address and port in one rule")),
        (true, true) => Ok(Converted::Skipped("rule with no conditions")),
    }
}

/// A logical rule, when it is an OR of rules that can each be written as a list, is their union.
/// An AND cannot be written as a list.
fn logical_rule(r: &mut Reader<'_>) -> Result<Converted> {
    let mode = r.byte()?;
    let count = r.uvarint()?;
    let mut children = Vec::new();
    for _ in 0..count {
        children.push(rule(r)?);
    }
    let invert = r.byte()? != 0;

    if invert {
        return Ok(Converted::Skipped("inverted logical rule"));
    }
    if mode != 1 {
        return Ok(Converted::Skipped("logical AND rule"));
    }
    let mut lines = Vec::new();
    for child in children {
        match child {
            Converted::Lines(more) => lines.extend(more),
            Converted::Skipped(reason) => return Ok(Converted::Skipped(reason)),
        }
    }
    Ok(Converted::Lines(lines))
}

fn item_name(kind: u8) -> &'static str {
    match kind {
        11 => "process_name",
        12 => "process_path",
        13 => "package_name",
        14 => "wifi_ssid",
        15 => "wifi_bssid",
        17 => "process_path_regex",
        _ => "unknown",
    }
}

fn skip_adguard(r: &mut Reader<'_>) -> Result<()> {
    // Layout not converted; reading it is needed only to keep the stream in step, and the rule
    // is dropped anyway. Stop here: the rest of this rule cannot be located reliably.
    Err(AetherError::Other(format!(
        "rule set uses an AdGuard rule item (kind 16) at byte {}; not supported",
        r.pos
    )))
}

// ---------------------------------------------------------------------------------------------
// Domain matcher: a succinct trie over the reversed names (sing `common/domain`).

/// Marks a key that matches the name and all its subdomains, with the leading dot (as `.x`).
const PREFIX_LABEL: u8 = b'\r';
/// Marks a key that matches a domain suffix, the name and its subdomains (as `x`).
const ROOT_LABEL: u8 = b'\n';

fn domain_matcher(r: &mut Reader<'_>) -> Result<Vec<String>> {
    let _reserved = r.byte()?;
    let leaves = r.u64s()?;
    let label_bitmap = r.u64s()?;
    let labels = r.bytes()?.to_vec();

    let trie = Trie::new(leaves, label_bitmap, labels);
    let keys = trie.keys();

    // Mirrors `Matcher.Dump`: exact names, suffixes, and subdomain-only suffixes.
    let mut exact: Vec<String> = Vec::new();
    let mut prefixed: Vec<String> = Vec::new();
    let mut suffixes: Vec<String> = Vec::new();
    for key in keys {
        let name = reverse_chars(&key);
        let mut chars = name.chars();
        match chars.next() {
            Some(c) if c == PREFIX_LABEL as char => prefixed.push(chars.as_str().to_string()),
            Some(c) if c == ROOT_LABEL as char => suffixes.push(chars.as_str().to_string()),
            _ => exact.push(name),
        }
    }

    let mut lines = Vec::new();
    let mut merged: Vec<String> = Vec::new();
    for prefix in prefixed {
        if let Some(root) = prefix.strip_prefix('.') {
            if let Some(pos) = exact.iter().position(|e| e == root) {
                exact.remove(pos);
                suffixes.push(root.to_string());
                continue;
            }
            merged.push(prefix);
        } else {
            merged.push(prefix);
        }
    }
    for name in exact {
        lines.push(format!("full:{name}"));
    }
    for name in suffixes {
        lines.push(name);
    }
    for name in merged {
        // A name with a leading dot matches subdomains only.
        match name.strip_prefix('.') {
            Some(root) => lines.push(format!("regexp:\\.{}$", regex_escape(root))),
            None => lines.push(name),
        }
    }
    Ok(lines)
}

fn reverse_chars(s: &[u8]) -> String {
    String::from_utf8_lossy(s).chars().rev().collect()
}

fn regex_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        if "\\.+*?()|[]{}^$".contains(c) {
            out.push('\\');
        }
        out.push(c);
    }
    out
}

/// The LOUDS trie of sing's `succinctSet`, read back into its keys.
struct Trie {
    leaves: Vec<u64>,
    bitmap: Vec<u64>,
    labels: Vec<u8>,
    /// `ones_before[w]` is the number of one bits in the words before `w`.
    ones_before: Vec<u64>,
}

impl Trie {
    fn new(leaves: Vec<u64>, bitmap: Vec<u64>, labels: Vec<u8>) -> Self {
        let mut ones_before = Vec::with_capacity(bitmap.len() + 1);
        let mut total = 0u64;
        ones_before.push(0);
        for word in &bitmap {
            total += u64::from(word.count_ones());
            ones_before.push(total);
        }
        Self {
            leaves,
            bitmap,
            labels,
            ones_before,
        }
    }

    fn bit(words: &[u64], i: usize) -> bool {
        words
            .get(i >> 6)
            .map(|w| (w >> (i & 63)) & 1 == 1)
            .unwrap_or(false)
    }

    fn total_bits(&self) -> usize {
        self.bitmap.len() * 64
    }

    /// Number of one bits at positions before `i`.
    fn ones_before_pos(&self, i: usize) -> u64 {
        let word = i >> 6;
        if word >= self.bitmap.len() {
            return self.ones_before[self.bitmap.len()];
        }
        let inside = self.bitmap[word] & ((1u64 << (i & 63)).wrapping_sub(1));
        self.ones_before[word] + u64::from(inside.count_ones())
    }

    /// Number of zero bits at positions before `i`.
    fn zeros_before(&self, i: usize) -> u64 {
        i as u64 - self.ones_before_pos(i)
    }

    /// The position of the `k`th one bit, counting from zero.
    fn select_one(&self, k: u64) -> Option<usize> {
        if k >= *self.ones_before.last()? {
            return None;
        }
        // The last word whose preceding ones are at most k holds the k-th one.
        let word = self.ones_before.partition_point(|&before| before <= k) - 1;
        let mut remaining = k - self.ones_before[word];
        let mut w = self.bitmap[word];
        let mut bit = 0usize;
        loop {
            if w & 1 == 1 {
                if remaining == 0 {
                    return Some(word * 64 + bit);
                }
                remaining -= 1;
            }
            w >>= 1;
            bit += 1;
        }
    }

    fn keys(&self) -> Vec<Vec<u8>> {
        let mut out = Vec::new();
        let mut current = Vec::new();
        self.walk(0, 0, &mut current, &mut out, 0);
        out
    }

    /// Visits the node `node` whose children start at bit `start`, as sing's `keys` does. The depth
    /// guard stops a damaged file from recursing without end.
    fn walk(&self, node: u64, start: usize, current: &mut Vec<u8>, out: &mut Vec<Vec<u8>>, depth: usize) {
        if depth > 4096 || out.len() > 4_000_000 {
            return;
        }
        if Self::bit(&self.leaves, node as usize) {
            out.push(current.clone());
        }
        let mut idx = start;
        while idx < self.total_bits() {
            if Self::bit(&self.bitmap, idx) {
                return;
            }
            let Some(&label) = (idx as u64)
                .checked_sub(node)
                .and_then(|i| self.labels.get(i as usize))
            else {
                return;
            };
            current.push(label);
            let child = self.zeros_before(idx + 1);
            let Some(child_start) = child
                .checked_sub(1)
                .and_then(|k| self.select_one(k))
                .map(|p| p + 1)
            else {
                current.pop();
                return;
            };
            self.walk(child, child_start, current, out, depth + 1);
            current.pop();
            idx += 1;
        }
    }
}

// ---------------------------------------------------------------------------------------------
// IP ranges: sing stores each set as ranges of raw address bytes; the routes syntax wants CIDRs.

fn ip_set(r: &mut Reader<'_>) -> Result<Vec<String>> {
    let version = r.byte()?;
    if version != 1 {
        return Err(AetherError::Other(format!("unsupported IP set version {version}")));
    }
    let count = {
        let b = r.take(8)?;
        let mut word = [0u8; 8];
        word.copy_from_slice(b);
        u64::from_be_bytes(word)
    };
    let mut prefixes = Vec::new();
    for _ in 0..count {
        let from = r.bytes()?;
        let to = r.bytes()?;
        prefixes.extend(range_to_cidrs(from, to)?);
    }
    Ok(prefixes)
}

/// Splits an inclusive address range into the fewest CIDRs that cover it.
fn range_to_cidrs(from: &[u8], to: &[u8]) -> Result<Vec<String>> {
    let (width, lo, hi, v6) = match (from.len(), to.len()) {
        (4, 4) => (32u32, be_value(from), be_value(to), false),
        (16, 16) => (128u32, be_value(from), be_value(to), true),
        _ => return Err(AetherError::Other("malformed address range in rule set".into())),
    };
    let mut out = Vec::new();
    let mut lo = lo;
    while lo <= hi {
        // The largest block that starts at `lo` and stays inside the range.
        let aligned = if lo == 0 { width } else { lo.trailing_zeros().min(width) };
        let mut k = aligned;
        while k > 0 && span(k) > hi - lo {
            k -= 1;
        }
        out.push(format!("{}/{}", render(lo, v6), width - k));
        let block_end = lo + span(k);
        if block_end >= hi {
            break;
        }
        lo = block_end + 1;
    }
    Ok(out)
}

fn be_value(bytes: &[u8]) -> u128 {
    bytes.iter().fold(0u128, |acc, b| (acc << 8) | u128::from(*b))
}

/// The number of addresses in a block of `2^k`, minus one.
fn span(k: u32) -> u128 {
    if k >= 128 {
        u128::MAX
    } else {
        (1u128 << k) - 1
    }
}

fn render(value: u128, v6: bool) -> String {
    if v6 {
        Ipv6Addr::from(value).to_string()
    } else {
        Ipv4Addr::from(value as u32).to_string()
    }
}

fn port_range(raw: &str) -> Result<String> {
    let Some((start, end)) = raw.split_once(':') else {
        return Err(AetherError::Other(format!("bad port range {raw:?} in rule set")));
    };
    let start = if start.is_empty() { "0" } else { start };
    let end = if end.is_empty() { "65535" } else { end };
    Ok(format!("port:{start}-{end}"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_range_splits_into_the_cidrs_that_cover_it() {
        let cidrs = range_to_cidrs(&[10, 0, 0, 0], &[10, 0, 0, 255]).unwrap();
        assert_eq!(cidrs, vec!["10.0.0.0/24"]);

        let cidrs = range_to_cidrs(&[10, 0, 0, 1], &[10, 0, 0, 2]).unwrap();
        assert_eq!(cidrs, vec!["10.0.0.1/32", "10.0.0.2/32"]);

        let cidrs = range_to_cidrs(&[0, 0, 0, 0], &[255, 255, 255, 255]).unwrap();
        assert_eq!(cidrs, vec!["0.0.0.0/0"]);
    }

    #[test]
    fn a_v6_range_is_covered_too() {
        let cidrs = range_to_cidrs(&[0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], &[0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xff]).unwrap();
        assert_eq!(cidrs, vec!["2001:db8::/120"]);
    }

    #[test]
    fn port_ranges_follow_sing_syntax() {
        assert_eq!(port_range("100:200").unwrap(), "port:100-200");
        assert_eq!(port_range(":200").unwrap(), "port:0-200");
        assert_eq!(port_range("100:").unwrap(), "port:100-65535");
    }

    #[test]
    fn a_file_without_the_magic_is_refused() {
        assert!(decode(b"hello world").is_err());
        assert!(!is_srs(b"SR"));
    }

    #[test]
    fn a_damaged_stream_is_an_error_not_a_panic() {
        let mut bytes = b"SRS\x01".to_vec();
        bytes.extend_from_slice(&[0x78, 0xda, 0x01, 0x02]);
        assert!(decode(&bytes).is_err());
    }

    #[test]
    fn uvarints_read_like_go() {
        let mut r = Reader::new(&[0xac, 0x02]);
        assert_eq!(r.uvarint().unwrap(), 300);
    }
}
