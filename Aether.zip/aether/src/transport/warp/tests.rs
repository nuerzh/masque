#![allow(unused_imports)]

use super::prelude::*;
use super::*;
use crate::transport::warp::net::upstream;

const SOON: std::time::Duration = std::time::Duration::from_secs(10);

#[test]
fn a_masque_gateway_is_left_once_its_tunnel_ended_twice_in_a_row() {
    let gateway: SocketAddr = "162.159.198.1:443".parse().unwrap();
    let now = Instant::now();
    let rest = std::time::Duration::from_secs(300);
    let mut strikes = GatewayStrikes::default();

    strikes.using(gateway);
    strikes.ended(SOON);
    assert_eq!(strikes.give_up(now, rest), None);
    // The reconnect goes back to it, and it ends again.
    strikes.using(gateway);
    strikes.ended(SOON);
    assert_eq!(strikes.give_up(now, rest), Some(gateway));
    // Out of the scans on any port until it has rested; the count starts over.
    assert!(strikes.left_out(now).contains(&gateway.ip()));
    assert_eq!(strikes.give_up(now, rest), None);
    assert!(strikes.left_out(now + rest).is_empty());
}

#[test]
fn another_masque_gateway_starts_with_no_strikes() {
    let first: SocketAddr = "162.159.198.1:443".parse().unwrap();
    let second: SocketAddr = "162.159.198.2:443".parse().unwrap();
    let now = Instant::now();
    let rest = std::time::Duration::from_secs(300);
    let mut strikes = GatewayStrikes::default();

    strikes.using(first);
    strikes.ended(SOON);
    strikes.using(second);
    strikes.ended(SOON);
    assert_eq!(strikes.give_up(now, rest), None);
    assert!(strikes.left_out(now).is_empty());
    // A tunnel that has not ended yet counts for nothing either.
    strikes.using(second);
    assert_eq!(strikes.give_up(now, rest), None);
}

#[test]
fn a_tunnel_that_stayed_up_clears_the_ends_before_it() {
    let gateway: SocketAddr = "162.159.198.1:443".parse().unwrap();
    let now = Instant::now();
    let rest = std::time::Duration::from_secs(300);
    let mut strikes = GatewayStrikes::default();

    // Hours on the gateway, a network change, hours again, another one: it is not left.
    strikes.using(gateway);
    strikes.ended(TUNNEL_STAYED_UP * 36);
    strikes.using(gateway);
    strikes.ended(TUNNEL_STAYED_UP * 24);
    assert_eq!(strikes.give_up(now, rest), None);
    // One that ends soon, then one that stays up: still not.
    strikes.using(gateway);
    strikes.ended(SOON);
    strikes.using(gateway);
    strikes.ended(TUNNEL_STAYED_UP);
    assert_eq!(strikes.give_up(now, rest), None);
    // Two that end soon, one after the other, are what leaves it.
    strikes.using(gateway);
    strikes.ended(SOON);
    assert_eq!(strikes.give_up(now, rest), None);
    strikes.using(gateway);
    strikes.ended(SOON);
    assert_eq!(strikes.give_up(now, rest), Some(gateway));
}

#[test]
fn only_a_tunnel_that_ended_soon_counts_against_its_gateway_or_endpoint() {
    let almost = TUNNEL_STAYED_UP - std::time::Duration::from_secs(1);
    assert_eq!(count_tunnel_end(0, std::time::Duration::ZERO), 1);
    assert_eq!(count_tunnel_end(1, almost), 2);
    assert_eq!(count_tunnel_end(1, TUNNEL_STAYED_UP), 0);
    assert_eq!(count_tunnel_end(7, TUNNEL_STAYED_UP * 2), 0);
    assert_eq!(count_tunnel_end(u32::MAX, SOON), u32::MAX);
}

#[test]
fn sunnyquic_over_masque_is_selected_by_name() {
    for written in ["sunny", "sunnyquic", "SUNNY", "sunny-over-masque"] {
        assert_eq!(Protocol::parse(written).unwrap(), Protocol::Sunny, "{written}");
    }
    assert_eq!(Protocol::parse("masque").unwrap(), Protocol::Masque);
    for removed in ["wg", "wireguard", "gool", "mim", "warp-in-warp"] {
        assert!(Protocol::parse(removed).is_err(), "{removed}");
    }
}

/// What reached a MASQUE server on this machine first: the server name of the ClientHello,
/// and the :authority of the request.
type Reached = tokio::task::JoinHandle<(Option<String>, String)>;

/// A MASQUE server over HTTP/2 on this machine, see `Reached`.
async fn h2_masque_server() -> (SocketAddr, Reached) {
    let (address, listener, acceptor) = crate::transport::warp::net::https::test_server(b"\x02h2").await;
    let reached = tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.expect("a connection");
        let tls = tokio_boring::accept(&acceptor, tcp)
            .await
            .expect("a handshake");
        let name = tls
            .ssl()
            .servername(boring::ssl::NameType::HOST_NAME)
            .map(str::to_string);
        let mut connection = h2::server::handshake(tls).await.expect("h2");
        let (request, _answer) = connection
            .accept()
            .await
            .expect("a request")
            .expect("a whole request");
        let authority = request.uri().authority().expect("an authority").to_string();
        (name, authority)
    });
    (address, reached)
}

/// A MASQUE server over HTTP/3 on this machine, see `Reached`. It passes over what comes
/// before the first QUIC v1 Initial: the version bait and the junk of the obfuscation.
async fn h3_masque_server() -> (SocketAddr, Reached) {
    use quiche::h3::NameValue;

    let socket = tokio::net::UdpSocket::bind("127.0.0.1:0")
        .await
        .expect("a port");
    let address = socket.local_addr().expect("its address");
    let reached = tokio::spawn(async move {
        let pair = account::generate_masque_keypair().expect("a key and a certificate");
        let mut tls =
            boring::ssl::SslContextBuilder::new(boring::ssl::SslMethod::tls()).expect("tls");
        tls.set_certificate(
            &boring::x509::X509::from_pem(&pair.cert_pem).expect("a certificate"),
        )
        .expect("the certificate");
        tls.set_private_key(
            &boring::pkey::PKey::private_key_from_pem(&pair.key_pem).expect("a key"),
        )
        .expect("the key");
        let mut config =
            quiche::Config::with_boring_ssl_ctx_builder(quiche::PROTOCOL_VERSION, tls)
                .expect("a configuration");
        config
            .set_application_protos(&[consts::ALPN_H3])
            .expect("h3");
        config.set_initial_max_data(1 << 20);
        config.set_initial_max_stream_data_bidi_remote(1 << 20);
        config.set_initial_max_stream_data_uni(1 << 20);
        config.set_initial_max_streams_bidi(8);
        config.set_initial_max_streams_uni(8);
        config.enable_dgram(true, 64, 64);
        let mut h3_config = quiche::h3::Config::new().expect("h3");
        h3_config.enable_extended_connect(true);

        let mut conn: Option<quiche::Connection> = None;
        let mut h3: Option<quiche::h3::Connection> = None;
        let mut packet = vec![0u8; 65535];
        let mut out = vec![0u8; 1500];
        loop {
            let (read, from) = socket.recv_from(&mut packet).await.expect("a packet");
            if conn.is_none() {
                // A long header of the Initial type, and version 1.
                if read <= 5 || packet[0] & 0xf0 != 0xc0 || packet[1..5] != [0, 0, 0, 1] {
                    continue;
                }
                let scid = [7u8; 16];
                let scid = quiche::ConnectionId::from_ref(&scid);
                conn = Some(
                    quiche::accept(&scid, None, address, from, &mut config)
                        .expect("a connection"),
                );
            }
            let conn = conn.as_mut().expect("the connection");
            let _ = conn.recv(&mut packet[..read], quiche::RecvInfo { from, to: address });
            if conn.is_established() && h3.is_none() {
                h3 =
                    Some(quiche::h3::Connection::with_transport(conn, &h3_config).expect("h3"));
            }
            if let Some(h3) = h3.as_mut() {
                while let Ok((_, event)) = h3.poll(conn) {
                    if let quiche::h3::Event::Headers { list, .. } = event {
                        let authority = list
                            .iter()
                            .find(|header| header.name() == b":authority")
                            .map(|header| String::from_utf8_lossy(header.value()).into_owned())
                            .expect("an authority");
                        return (conn.server_name().map(str::to_string), authority);
                    }
                }
            }
            while let Ok((written, sent)) = conn.send(&mut out) {
                socket
                    .send_to(&out[..written], sent.to)
                    .await
                    .expect("a packet sent");
            }
        }
    });
    (address, reached)
}

#[tokio::test]
async fn the_masque_handshakes_send_the_masque_sni_and_keep_the_authority() {
    let _setting = upstream::hold_setting().await;
    // The handshakes take --masque-sni, the carrier and the fingerprint from the options.
    let _options = tls::hold_options().await;
    let identity = account::handshake_identity();
    let startup = std::time::Duration::from_secs(10);

    // Without --masque-sni, www.cloudflare.com; with it, the name it gives.
    for (option, sni) in [
        (None, "www.cloudflare.com"),
        (Some(consts::CONNECT_SNI), consts::CONNECT_SNI),
    ] {
        match option {
            Some(name) => crate::config::settings::decide("AETHER_MASQUE_SNI", name),
            None => crate::config::settings::forget("AETHER_MASQUE_SNI"),
        }
        for h2 in [false, true] {
            if h2 {
                crate::config::settings::decide("AETHER_MASQUE_HTTP2", "1");
            } else {
                crate::config::settings::forget("AETHER_MASQUE_HTTP2");
            }
            // The check of a gateway, and the tunnel.
            for tunnel in [false, true] {
                let case = format!("masque.sni {option:?}, h2 {h2}, tunnel {tunnel}");
                let (address, reached) = if h2 {
                    h2_masque_server().await
                } else {
                    h3_masque_server().await
                };
                let client = async {
                    if tunnel {
                        let mtu = if h2 { H2_TUNNEL_MTU } else { TUNNEL_MTU };
                        let datagram = quic::MAX_DATAGRAM_SIZE;
                        let hop = establish_masque(
                            &identity, address, h2, mtu, datagram, false, startup, "test",
                        );
                        let _ = hop.await;
                    } else {
                        quick_verify_masque_peer(&identity, address).await;
                    }
                };
                let (name, authority) = tokio::select! {
                    biased;
                    reached = reached => reached.expect("the server"),
                    () = client => panic!("{case}: the request did not reach the server"),
                };
                assert_eq!(name.as_deref(), Some(sni), "{case}");
                let host = if h2 {
                    "cloudflareaccess.com:443"
                } else {
                    "cloudflareaccess.com"
                };
                assert_eq!(authority, host, "{case}");
            }
        }
    }
}

#[tokio::test]
async fn the_masque_handshakes_go_without_ech_even_with_ech_given() {
    let _setting = upstream::hold_setting().await;
    let _options = tls::hold_options().await;
    let identity = account::handshake_identity();
    // Cloudflare's key of cloudflare-ech.com on 2026-10-01: one BoringSSL would offer.
    crate::config::settings::decide(
        "AETHER_ECH",
        "AEX+DQBBrwAgACCbK1mYDYFz/BAn6S5t+Q/v+Oej3eFNxtPWgz50fNnFPAAEAAEAAQASY2xvdWRmbGFyZS1lY2guY29tAAA=",
    );
    crate::config::settings::decide("AETHER_MASQUE_HTTP2", "1");
    for tunnel in [false, true] {
        let (address, hello) = tls::client_hello::catch().await;
        let identity = identity.clone();
        let client = tokio::spawn(async move {
            if tunnel {
                let startup = std::time::Duration::from_secs(5);
                let datagram = quic::MAX_DATAGRAM_SIZE;
                let hop = establish_masque(
                    &identity, address, true, H2_TUNNEL_MTU, datagram, false, startup, "test",
                );
                let _ = hop.await;
            } else {
                quick_verify_masque_peer(&identity, address).await;
            }
        });
        let hello = hello.await.expect("a ClientHello");
        client.abort();
        assert!(!hello.offers_ech(), "tunnel {tunnel}");
        assert_eq!(hello.server_name().as_deref(), Some("www.cloudflare.com"), "tunnel {tunnel}");
    }
}

#[test]
fn the_core_says_ech_is_for_the_api_alone() {
    assert_eq!(
        ech_scope_note(true),
        "[tls] tls.ech applies to the WARP API calls only; the MASQUE handshakes go without ECH (the WARP gateways turn it down)"
    );
    let without = ech_scope_note(false);
    assert!(without.contains("the MASQUE handshakes go without ECH"), "{without}");
    assert!(!without.contains("tls.ech"), "{without}");
}
