//! The MASQUE tunnel of WARP: the run loop (scan, reconnect, gateway strikes) and one tunnel
//! over HTTP/3 (`quic`) or HTTP/2 (`http2`), with the CONNECT-IP capsules in `proto`.

pub mod http2;
pub mod proto;
pub mod quic;

use crate::transport::warp::prelude::*;
use crate::transport::warp::*;

pub(crate) fn masque_reconnect_delay() -> std::time::Duration {
    let secs = crate::config::settings::var("AETHER_MASQUE_RECONNECT_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(2);
    std::time::Duration::from_secs(secs)
}

pub(crate) fn masque_startup_timeout() -> std::time::Duration {
    let secs = crate::config::settings::var("AETHER_MASQUE_STARTUP_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(30);
    std::time::Duration::from_secs(secs)
}

pub(crate) fn masque_carrier() -> &'static str {
    if masque_h2::enabled() {
        lastconn::CARRIER_MASQUE_H2
    } else {
        lastconn::CARRIER_MASQUE_H3
    }
}

/// What the MASQUE tunnel of `run_masque` carries: the proxy itself, or the sunnyquic hop of
/// `--sunny`.
pub(crate) enum MasqueInner {
    Plain,
    Sunny(std::sync::Arc<sunnyquic::Client>),
}

pub(crate) async fn run_masque(
    identity: account::Identity,
    lastconn_path: String,
    inner: MasqueInner,
) -> Result<()> {
    let forced = crate::config::settings::var("AETHER_PEER").ok();

    let mut quick_peer: Option<SocketAddr> = None;

    if forced.is_none() {
        if let Some(assigned) = crate::config::settings::var("AETHER_TEAM_ENDPOINT")
            .ok()
            .and_then(|value| value.parse::<SocketAddr>().ok())
        {
            log::info!("[masque] verifying the endpoint the organization assigned: {assigned}");
            if quick_verify_masque_peer(&identity, assigned).await {
                log::info!("[masque] the assigned endpoint {assigned} works; skipping the scan");
                quick_peer = Some(assigned);
            } else {
                log::warn!(
                    "[masque] the assigned endpoint {assigned} did not answer; falling back to scanning"
                );
            }
        }
    }

    let mut last_good_peer: Option<SocketAddr> = None;
    let mut strikes = GatewayStrikes::default();
    // The scan that goes on after the tunnel started on its first pick, and the gateway the run
    // moved away from last (to go back to when the faster one does not hold).
    let mut background: Option<prober::BackgroundScan> = None;
    let mut switched_from: Option<SocketAddr> = None;
    // The RTT of the gateway about to be used, when this run measured it (saved beside it).
    let mut peer_rtt: Option<std::time::Duration> = None;

    // With a remembered gateway the run starts on it at once, no question asked: the best of the
    // RTT history first, then the other remembered gateways together, with the scan's full check
    // (`start_on_remembered`); under half of --max-rtt there is no scan, else it goes on in the
    // background.
    if forced.is_none() && quick_peer.is_none() {
        if let Some(cached) = lastconn::load(&lastconn_path) {
            let ports = prober::masque_ports();
            let ring: Vec<SocketAddr> = lastconn::usable_peers(&cached, masque_carrier())
                .into_iter()
                .filter(|peer| {
                    let kept = ports.contains(&peer.port());
                    if !kept {
                        log::info!("[masque] cached gateway {peer} is on a port this scan leaves out; not reusing it");
                    }
                    kept
                })
                .collect();
            let ranked: Vec<(SocketAddr, u64)> = lastconn::ranked_history(&cached, masque_carrier())
                .into_iter()
                .filter(|(peer, _)| ports.contains(&peer.port()))
                .collect();
            if !ranked.is_empty() || !ring.is_empty() {
                let (mode_str, ip) = scan_settings_from_env();
                match start_on_remembered(
                    &identity,
                    &mode_str,
                    ip,
                    &HashSet::new(),
                    &ranked,
                    &ring,
                    &lastconn_path,
                    masque_carrier(),
                )
                .await
                {
                    Some(hunted) => {
                        quick_peer = Some(hunted.peer);
                        peer_rtt = Some(hunted.rtt);
                        background = hunted.background;
                    }
                    None => log::warn!("[masque] no remembered gateway passed; scanning fresh"),
                }
            }
        }
    }

    let (mode_str, ip) = if forced.is_some() || quick_peer.is_some() {
        scan_settings_from_env()
    } else {
        let mode_str = select_scan_mode_str("").await;
        let ip = select_ip_version().await;
        (mode_str, ip)
    };

    loop {
        // A gateway named by hand stays, whatever happens to it: it was asked for on purpose.
        if forced.is_none() {
            if let Some(peer) = strikes.give_up(Instant::now(), MASQUE_GATEWAY_REST) {
                log::warn!(
                    "[masque] gateway {peer} failed {MASQUE_GATEWAY_STRIKES} times in a row; leaving it out of the scans for {:?}",
                    MASQUE_GATEWAY_REST
                );
                last_good_peer = None;
            }
        }

        let peer = if let Some(p) = quick_peer.take() {
            p
        } else {
            let retried = match last_good_peer {
                Some(p) => {
                    log::info!("[masque] retrying last known-good gateway {p} before rescanning");
                    if quick_verify_masque_peer(&identity, p).await {
                        Some(p)
                    } else {
                        log::warn!(
                            "[masque] last known-good gateway {p} no longer responds; rescanning"
                        );
                        None
                    }
                }
                None => None,
            };

            match retried {
                Some(p) => p,
                None => match &forced {
                    Some(p) => match p.parse::<SocketAddr>() {
                        Ok(peer) => {
                            log::info!("[masque] using forced peer {peer} (probe skipped)");
                            peer
                        }
                        Err(_) => return Err(AetherError::Other(format!("bad peer address {p}"))),
                    },
                    None => {
                        // a fresh scan replaces the one still going
                        background = None;
                        let avoid = strikes.left_out(Instant::now());
                        match hunt_masque_peer(&identity, &mode_str, ip, &avoid).await {
                            Ok(hunted) => {
                                background = hunted.background;
                                peer_rtt = Some(hunted.rtt);
                                hunted.peer
                            }
                            Err(e) => {
                                log::warn!(
                                    "[masque] no usable MASQUE gateway found: {e}; rescanning shortly"
                                );
                                tokio::time::sleep(masque_reconnect_delay()).await;
                                continue;
                            }
                        }
                    }
                },
            }
        };

        log::info!("[masque] using cloudflare edge {peer}");

        if forced.is_none() {
            let profile = crate::config::settings::var("AETHER_NOIZE").unwrap_or_else(|_| "firewall".to_string());
            lastconn::save(
                &lastconn_path,
                &peer.to_string(),
                &profile,
                masque_carrier(),
                peer_rtt.take(),
            );
        }
        peer_rtt = None;

        last_good_peer = Some(peer);
        strikes.using(peer);
        let came_from = switched_from.take();

        let started = Instant::now();
        let outcome = {
            let tunnel = async {
                match &inner {
                    MasqueInner::Sunny(client) => run_sunny_tunnel(&identity, peer, client).await,
                    MasqueInner::Plain => run_masque_tunnel(&identity, peer).await,
                }
            };
            tokio::pin!(tunnel);
            tokio::select! {
                ended = &mut tunnel => TunnelOutcome::Ended(ended),
                (from, to) = next_switch(&mut background) => TunnelOutcome::Switch(from, to),
            }
            // the tunnel (and its stack) is dropped here, before the next one is dialled
        };
        match outcome {
            TunnelOutcome::Switch(from, to) => {
                let to_peer = SocketAddr::new(to.ip, to.port);
                log::info!(
                    "[masque] switching gateway {peer}({:?}) -> {to_peer}({:?})",
                    from.rtt,
                    to.rtt
                );
                quick_peer = Some(to_peer);
                peer_rtt = Some(to.rtt);
                switched_from = Some(peer);
                continue;
            }
            TunnelOutcome::Ended(ended) => {
                let lasted = started.elapsed();
                strikes.ended(lasted);
                match &ended {
                    Ok(()) => log::warn!("[masque] MASQUE tunnel closed; reconnecting"),
                    Err(e) => log::warn!("[masque] MASQUE tunnel ended: {e}; reconnecting"),
                }
                if let Some(prev) = back_after_failed_switch(came_from, ended.is_err(), lasted) {
                    log::warn!(
                        "[masque] the faster gateway {peer} did not hold; going back to {prev}"
                    );
                    last_good_peer = Some(prev);
                }
            }
        }

        tokio::time::sleep(masque_reconnect_delay()).await;
    }
}

/// How one tunnel of `run_masque` ended: by itself, or for a move to a faster gateway.
enum TunnelOutcome {
    Ended(Result<()>),
    Switch(prober::ProbeResult, prober::ProbeResult),
}

/// How long a tunnel the run moved to must hold before the gateway it left is forgotten.
pub(crate) const SWITCH_SETTLE: std::time::Duration = std::time::Duration::from_secs(60);

/// The gateway to go back to when the tunnel on a gateway the run just moved to (`came_from`
/// is the one it left) failed within [`SWITCH_SETTLE`].
pub(crate) fn back_after_failed_switch(
    came_from: Option<SocketAddr>,
    failed: bool,
    lasted: std::time::Duration,
) -> Option<SocketAddr> {
    came_from.filter(|_| failed && lasted < SWITCH_SETTLE)
}

/// The next move the background scan asks for; never, once there is no scan (or it is over).
pub(crate) async fn next_switch(
    background: &mut Option<prober::BackgroundScan>,
) -> (prober::ProbeResult, prober::ProbeResult) {
    loop {
        let Some(scan) = background.as_mut() else {
            return std::future::pending().await;
        };
        match scan.next_switch().await {
            Some(switch) => return switch,
            None => *background = None,
        }
    }
}

/// How many times in a row the tunnel through a MASQUE gateway may end, each time sooner than
/// [`TUNNEL_STAYED_UP`], before the run leaves the gateway.
pub(crate) const MASQUE_GATEWAY_STRIKES: u32 = 2;

/// How long a MASQUE gateway the run left stays out of its scans.
pub(crate) const MASQUE_GATEWAY_REST: std::time::Duration = std::time::Duration::from_secs(300);

/// The gateways that failed a MASQUE run: the one in use, how many times in a row its tunnel
/// ended soon after it started, and those left out of the scans until a while has passed. The
/// check before a reconnect only proves that a gateway answers, so a tunnel that ends every time,
/// as it does on an exit the exit rule refuses, would otherwise hold the run on one gateway for
/// good.
#[derive(Debug, Default)]
pub(crate) struct GatewayStrikes {
    pub(crate) current: Option<SocketAddr>,
    pub(crate) in_a_row: u32,
    pub(crate) resting: HashMap<IpAddr, Instant>,
}

impl GatewayStrikes {
    /// The tunnel goes through `peer` now; another gateway than the last starts with none.
    pub(crate) fn using(&mut self, peer: SocketAddr) {
        if self.current != Some(peer) {
            self.current = Some(peer);
            self.in_a_row = 0;
        }
    }

    /// The tunnel through the gateway in use ended, for whatever reason, after it `lasted` this
    /// long, see [`count_tunnel_end`].
    pub(crate) fn ended(&mut self, lasted: std::time::Duration) {
        self.in_a_row = count_tunnel_end(self.in_a_row, lasted);
    }

    /// The gateway in use, once its tunnel ended `MASQUE_GATEWAY_STRIKES` times in a row: its
    /// address rests until `rest` after `now`, out of the scans, and the count starts over.
    pub(crate) fn give_up(&mut self, now: Instant, rest: std::time::Duration) -> Option<SocketAddr> {
        if self.in_a_row < MASQUE_GATEWAY_STRIKES {
            return None;
        }
        self.in_a_row = 0;
        let peer = self.current.take()?;
        self.resting.insert(peer.ip(), now + rest);
        Some(peer)
    }

    /// The addresses the scans leave out at `now`.
    pub(crate) fn left_out(&mut self, now: Instant) -> HashSet<IpAddr> {
        self.resting.retain(|_, until| *until > now);
        self.resting.keys().copied().collect()
    }
}

pub(crate) struct MasqueHop {
    pub(crate) stack: netstack::StackHandle,
    pub(crate) exit: TunnelExit,
    pub(crate) _ctrl: tokio::sync::mpsc::Sender<quic::Control>,
    pub(crate) _guard: TaskGuard,
}

#[allow(clippy::too_many_arguments)]
pub(crate) async fn establish_masque(
    identity: &account::Identity,
    peer: SocketAddr,
    h2: bool,
    mtu: usize,
    datagram: usize,
    version_bait: bool,
    startup: std::time::Duration,
    label: &str,
) -> Result<MasqueHop> {
    let sni = quic::masque_sni()?;
    let (chans, internals) = quic::channels();
    let quic::Channels {
        outbound_tx,
        inbound_rx,
        ctrl_tx,
    } = chans;

    let stack = netstack::spawn(&identity.ipv4, &identity.ipv6, mtu, inbound_rx, outbound_tx)?;

    let mut guard = TaskGuard::new();

    let (addr_tx, mut addr_rx) = tokio::sync::mpsc::channel::<quic::AssignedAddr>(8);
    let bridge_stack = stack.clone();
    let bridge_task = tokio::spawn(async move {
        while let Some(a) = addr_rx.recv().await {
            let res = match a.ip {
                IpAddr::V4(v4) => bridge_stack.set_addrs(Some((v4, a.prefix)), None).await,
                IpAddr::V6(v6) => bridge_stack.set_addrs(None, Some((v6, a.prefix))).await,
            };
            if let Err(e) = res {
                log::warn!("[masque] failed to sync edge address into netstack: {e}");
            }
        }
    });
    guard.push(bridge_task.abort_handle());

    let (ready_tx, ready_rx) = tokio::sync::oneshot::channel::<()>();

    let tunnel_task = if h2 {
        let h2cfg = masque_h2::H2TunnelConfig {
            peer,
            sni,
            authority: quic::default_authority().to_string(),
            cert_pem: identity.cert_pem.clone(),
            key_pem: identity.key_pem.clone(),
            local_ipv4: parse_local_v4(&identity.ipv4),
            quiet: false,
            pin_endpoint: true,
            expected_pins: consts::MASQUE_PINS.iter().map(|p| p.to_vec()).collect(),
        };
        log::info!("[masque] [{label}] MASQUE transport: HTTP/2 (TCP) to {peer} (inner mtu {mtu})");
        tokio::spawn(masque_h2::run(
            h2cfg,
            internals,
            Some(addr_tx),
            Some(ready_tx),
        ))
    } else {
        let cfg = quic::TunnelConfig {
            peer,
            sni,
            authority: quic::default_authority().to_string(),
            path: quic::default_path().to_string(),
            cert_pem: identity.cert_pem.clone(),
            key_pem: identity.key_pem.clone(),
            noize: noize_config(),
            local_ipv4: parse_local_v4(&identity.ipv4),
            quiet: false,
            max_datagram: datagram,
            version_bait,
        };
        log::info!(
            "[masque] [{label}] MASQUE transport: HTTP/3 (QUIC) to {peer} (inner mtu {mtu}, datagram {})",
            cfg.datagram_budget()
        );
        tokio::spawn(quic::run(cfg, internals, Some(addr_tx), Some(ready_tx)))
    };
    guard.push(tunnel_task.abort_handle());

    let startup_timeout = startup;
    match tokio::time::timeout(startup_timeout, ready_rx).await {
        Ok(Ok(())) => {}
        Ok(Err(_)) => {
            let joined = tunnel_task.await;
            let msg = match joined {
                Ok(Ok(())) => format!("[{label}] tunnel exited before validation"),
                Ok(Err(e)) => format!("[{label}] tunnel failed before validation: {e}"),
                Err(e) => format!("[{label}] tunnel task join error: {e}"),
            };
            return Err(AetherError::Other(msg));
        }
        Err(_) => {
            tunnel_task.abort();
            let _ = tunnel_task.await;
            return Err(AetherError::Other(format!(
                "[{label}] tunnel startup timed out after {startup_timeout:?}"
            )));
        }
    }

    Ok(MasqueHop {
        stack,
        exit: tunnel_task,
        _ctrl: ctrl_tx,
        _guard: guard,
    })
}

pub(crate) async fn run_masque_tunnel(
    identity: &account::Identity,
    peer: SocketAddr,
) -> Result<()> {
    let h2 = masque_h2::enabled();
    let dial = if h2 { masque_h2::h2_peer(peer) } else { peer };

    let mut hop = establish_masque(
        identity,
        dial,
        h2,
        masque_tunnel_mtu(),
        quic::MAX_DATAGRAM_SIZE,
        true,
        masque_startup_timeout(),
        "masque",
    )
    .await?;

    let policy = exitloc::Policy::from_env();
    exitloc::settle(&hop.stack, &policy, "masque").await?;

    let _published = crate::proxy::router::exits::publish_stack(&hop.stack);

    let tunnel_result = tokio::select! {
        result = &mut hop.exit => result,
        reason = exit_policy_guard(&hop.stack, &policy) => return Err(reason),
    };

    match tunnel_result {
        Ok(Ok(())) => Ok(()),
        Ok(Err(e)) => Err(AetherError::Other(format!("tunnel exited: {e}"))),
        Err(e) => Err(AetherError::Other(format!("tunnel task join error: {e}"))),
    }
}

/// One outer MASQUE tunnel of `--sunny`: the sunnyquic client's socket rides inside it until it
/// drops, and is re-pointed at the next one. The stack is published too, so `warp` works
/// alongside `sunny`.
pub(crate) async fn run_sunny_tunnel(
    identity: &account::Identity,
    peer: SocketAddr,
    client: &std::sync::Arc<sunnyquic::Client>,
) -> Result<()> {
    let h2 = masque_h2::enabled();
    let dial = if h2 { masque_h2::h2_peer(peer) } else { peer };

    let mut outer = establish_masque(
        identity,
        dial,
        h2,
        masque_tunnel_mtu(),
        quic::MAX_DATAGRAM_SIZE,
        true,
        masque_startup_timeout(),
        "outer",
    )
    .await?;

    let _published = crate::proxy::router::exits::publish_stack(&outer.stack);
    client.attach(&outer.stack).await?;
    log::info!("[masque] sunny ready: masque {peer} carries sunnyquic");

    join_outcome("outer masque tunnel", (&mut outer.exit).await)
}

/// The exit checks of the WARP tunnel do not apply to `--sunny`, whose exit is the user's own
/// sunnyquic server. (Routing does: a [route] puts Aether's routed
/// listeners in front of the sunnyquic client.)
pub(crate) fn warn_ignored_on_sunny() {
    for (var, flag) in [
        ("AETHER_EXIT_LOC", "exit-loc"),
        ("AETHER_GATEWAY", "zero-trust.gateway"),
    ] {
        if env_value(var).is_some() {
            log::warn!(
                "[masque] {flag} is ignored with protocol sunny: the proxy there is the sunnyquic client's, \
                 and everything goes to your sunnyquic server"
            );
        }
    }
}
