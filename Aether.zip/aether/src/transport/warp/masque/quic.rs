use std::collections::HashMap;
use std::net::{IpAddr, Ipv4Addr, SocketAddr};
use std::sync::Arc;
use std::time::{Duration, Instant};

use quiche::h3;
use quiche::h3::NameValue;
use rand::Rng;
use tokio::net::UdpSocket;
use tokio::sync::{mpsc, oneshot};

use crate::transport::warp::masque::proto::{self as masque, CapsuleParser};
use crate::utils::noize::{self, NoizeConfig};
use crate::transport::warp::net::tls::{self, TlsParams};
use crate::{transport::warp::consts, error::AetherError, error::Result};

mod verify;
pub use verify::{verify_masque, VerifyParams};

pub const MAX_DATAGRAM_SIZE: usize = 1350;
pub const MIN_DATAGRAM_SIZE: usize = 1200;

fn net_queue() -> usize {
    crate::utils::sysprofile::channel_capacity()
}

async fn bind_udp_fast(bind_addr: SocketAddr) -> Result<UdpSocket> {
    use socket2::{Domain, Socket, Type};
    let domain = if bind_addr.is_ipv4() {
        Domain::IPV4
    } else {
        Domain::IPV6
    };
    let sock = Socket::new(domain, Type::DGRAM, None).map_err(AetherError::Io)?;
    sock.set_nonblocking(true).map_err(AetherError::Io)?;

    let buf_size = crate::utils::sysprofile::udp_socket_buf_bytes();
    let _ = sock.set_recv_buffer_size(buf_size);
    let _ = sock.set_send_buffer_size(buf_size);
    crate::utils::egress::apply(socket2::SockRef::from(&sock)).map_err(AetherError::Io)?;

    sock.bind(&bind_addr.into()).map_err(AetherError::Io)?;
    UdpSocket::from_std(sock.into()).map_err(AetherError::Io)
}

#[derive(Debug, Clone)]
#[expect(dead_code, reason = "commands the tunnel loop handles; nothing sends them yet")]
pub enum Control {
    Migrate,
    Close,
}

#[derive(Debug, Clone)]
pub struct AssignedAddr {
    pub ip: IpAddr,
    pub prefix: u8,
}

#[derive(Debug, Clone)]
pub struct TunnelConfig {
    pub peer: SocketAddr,
    pub sni: String,
    pub authority: String,
    pub path: String,
    pub cert_pem: Vec<u8>,
    pub key_pem: Vec<u8>,
    pub noize: NoizeConfig,
    pub local_ipv4: Ipv4Addr,
    pub quiet: bool,
    pub max_datagram: usize,
    pub version_bait: bool,
}

impl TunnelConfig {
    pub fn datagram_budget(&self) -> usize {
        self.max_datagram
            .clamp(MIN_DATAGRAM_SIZE, MAX_DATAGRAM_SIZE)
    }
}

fn validation_timeout() -> Duration {
    let secs = crate::config::settings::var("AETHER_MASQUE_VALIDATE_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(10);
    Duration::from_secs(secs)
}

fn data_check_enabled() -> bool {
    crate::config::settings::var("AETHER_MASQUE_NO_DATA_CHECK").is_err()
}

const DATA_PROBE_REQUIRED_SUCCESSES: u32 = 2;

pub struct Channels {
    pub outbound_tx: mpsc::Sender<Vec<u8>>,
    pub inbound_rx: mpsc::Receiver<Vec<u8>>,
    pub ctrl_tx: mpsc::Sender<Control>,
}

pub fn channels() -> (Channels, Internals) {
    let (outbound_tx, outbound_rx) = mpsc::channel(net_queue());
    let (inbound_tx, inbound_rx) = mpsc::channel(net_queue());
    let (ctrl_tx, ctrl_rx) = mpsc::channel(16);

    (
        Channels {
            outbound_tx,
            inbound_rx,
            ctrl_tx,
        },
        Internals {
            outbound_rx,
            inbound_tx,
            ctrl_rx,
        },
    )
}

pub struct Internals {
    outbound_rx: mpsc::Receiver<Vec<u8>>,
    inbound_tx: mpsc::Sender<Vec<u8>>,
    ctrl_rx: mpsc::Receiver<Control>,
}

impl Internals {
    pub fn into_parts(
        self,
    ) -> (
        mpsc::Receiver<Vec<u8>>,
        mpsc::Sender<Vec<u8>>,
        mpsc::Receiver<Control>,
    ) {
        (self.outbound_rx, self.inbound_tx, self.ctrl_rx)
    }
}

type NetPacket = (SocketAddr, SocketAddr, Vec<u8>);

fn random_scid() -> [u8; 16] {
    let mut scid = [0u8; 16];
    rand::rng().fill_bytes(&mut scid);
    scid
}

const QUIC_V2_VERSION: u32 = 0x6b33_43cf;
const QUIC_V2_BAIT_WAIT: Duration = Duration::from_millis(600);
const QUIC_V2_BAIT_LEN: usize = 1200;

pub(crate) fn quic_v2_bait_enabled() -> bool {
    !matches!(
        crate::config::settings::var("AETHER_QUIC_V2").as_deref(),
        Ok("0") | Ok("off") | Ok("false") | Ok("no")
    )
}

fn quic_varint2(value: u64) -> [u8; 2] {
    (((value & 0x3fff) as u16) | 0x4000).to_be_bytes()
}

fn build_version_bait() -> Vec<u8> {
    let mut rng = rand::rng();
    let mut dcid = [0u8; 8];
    let mut scid = [0u8; 8];
    rng.fill_bytes(&mut dcid);
    rng.fill_bytes(&mut scid);

    let mut pkt = Vec::with_capacity(QUIC_V2_BAIT_LEN);
    pkt.push(0xc3);
    pkt.extend_from_slice(&QUIC_V2_VERSION.to_be_bytes());
    pkt.push(dcid.len() as u8);
    pkt.extend_from_slice(&dcid);
    pkt.push(scid.len() as u8);
    pkt.extend_from_slice(&scid);
    pkt.push(0x00);

    let remaining = QUIC_V2_BAIT_LEN - pkt.len() - 2;
    pkt.extend_from_slice(&quic_varint2(remaining as u64));
    let mut pn = [0u8; 4];
    rng.fill_bytes(&mut pn);
    pkt.extend_from_slice(&pn);
    pkt.resize(QUIC_V2_BAIT_LEN, 0);
    pkt
}

async fn send_version_bait(sock: &UdpSocket, target: SocketAddr, wait: Duration, tries: usize) {
    let bait = build_version_bait();
    let connected = sock.peer_addr().is_ok();
    let mut buf = [0u8; 2048];

    for attempt in 0..tries.max(1) {
        let sent = if connected {
            sock.send(&bait).await
        } else {
            sock.send_to(&bait, target).await
        };
        if sent.is_err() {
            return;
        }

        let answered = tokio::time::timeout(wait, async {
            if connected {
                sock.recv(&mut buf).await
            } else {
                sock.recv_from(&mut buf).await.map(|(n, _)| n)
            }
        })
        .await;

        match answered {
            Ok(Ok(n)) => {
                log::debug!(
                    "[quic] version-negotiation bait answered with {n} bytes; the path is open for v1"
                );
                return;
            }
            Ok(Err(_)) => return,
            Err(_) => log::trace!(
                "[quic] version-negotiation bait attempt {} went unanswered",
                attempt + 1
            ),
        }
    }
}

#[derive(Default)]
struct ReaderGuard {
    handles: Vec<tokio::task::JoinHandle<()>>,
    detours: Vec<crate::transport::warp::net::upstream::DetourGuard>,
}

impl ReaderGuard {
    fn push(&mut self, h: tokio::task::JoinHandle<()>) {
        self.handles.push(h);
    }
}

impl Drop for ReaderGuard {
    fn drop(&mut self) {
        for h in self.handles.drain(..) {
            h.abort();
        }
    }
}

fn spawn_reader(
    sock: Arc<UdpSocket>,
    local: SocketAddr,
    tx: mpsc::Sender<NetPacket>,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        let mut buf = vec![0u8; 65535];
        loop {
            match sock.recv_from(&mut buf).await {
                Ok((n, observed)) => {
                    let from = crate::transport::warp::net::upstream::real_source(local, observed);
                    log::trace!("[quic] recv {n} bytes from {from}");
                    if tx.send((local, from, buf[..n].to_vec())).await.is_err() {
                        break;
                    }
                }
                Err(e) => {
                    log::debug!("[quic] recv error: {e}");
                    break;
                }
            }
        }
    })
}

struct Readiness {
    data_check: bool,
    tx: Option<oneshot::Sender<()>>,
    fired: bool,
    deadline: Option<Instant>,
    successes: u32,
}

impl Readiness {
    fn new(data_check: bool, tx: Option<oneshot::Sender<()>>) -> Self {
        Self {
            data_check,
            tx,
            fired: false,
            deadline: None,
            successes: 0,
        }
    }

    fn probing(&self) -> bool {
        self.data_check && !self.fired
    }

    fn timed_out(&self) -> bool {
        self.probing() && self.deadline.is_some_and(|dl| Instant::now() >= dl)
    }

    fn fire(&mut self) {
        self.fired = true;
        if let Some(tx) = self.tx.take() {
            let _ = tx.send(());
        }
    }

    fn on_established(&mut self, quiet: bool) {
        if self.data_check {
            self.deadline = Some(Instant::now() + validation_timeout());
            log_or_debug(
                quiet,
                "validating masque data-plane before exposing socks5".to_string(),
            );
        } else if !self.fired {
            self.fire();
        }
    }

    fn on_data(&mut self, got_data: bool, quiet: bool) {
        if !got_data || self.fired {
            return;
        }
        self.successes += 1;
        log::debug!(
            "[quic] masque data-plane round-trip {}/{} confirmed",
            self.successes,
            DATA_PROBE_REQUIRED_SUCCESSES
        );
        if self.successes >= DATA_PROBE_REQUIRED_SUCCESSES {
            self.fire();
            self.deadline = None;
            log_or_debug(
                quiet,
                "masque tunnel validated (end-to-end data confirmed); exposing socks5"
                    .to_string(),
            );
        }
    }
}

fn new_connection(
    sni: &str,
    local: SocketAddr,
    peer: SocketAddr,
    config: &mut quiche::Config,
) -> Result<quiche::Connection> {
    let scid_bytes = random_scid();
    let scid = quiche::ConnectionId::from_ref(&scid_bytes);
    Ok(quiche::connect(Some(sni), &scid, local, peer, config)?)
}

pub async fn run(
    cfg: TunnelConfig,
    mut internals: Internals,
    addr_tx: Option<mpsc::Sender<AssignedAddr>>,
    ready_tx: Option<oneshot::Sender<()>>,
) -> Result<()> {
    let peer = cfg.peer;
    let quiet = cfg.quiet;
    let probe_packet = masque::build_dns_probe_packet(cfg.local_ipv4);
    let mut ready = Readiness::new(data_check_enabled(), ready_tx);

    let init_sock = bind_udp_fast(crate::utils::egress::wildcard_for(peer)).await?;
    let _init_detour = crate::transport::warp::net::upstream::attach_detour(&init_sock, peer).await?;
    let local = init_sock.local_addr()?;
    let init_sock = Arc::new(init_sock);

    if cfg.version_bait && quic_v2_bait_enabled() {
        let target = crate::transport::warp::net::upstream::relay_target(local, peer);
        send_version_bait(&init_sock, target, QUIC_V2_BAIT_WAIT, 2).await;
    }

    let (net_tx, mut net_rx) = mpsc::channel::<NetPacket>(net_queue());

    let mut sockets: HashMap<SocketAddr, Arc<UdpSocket>> = HashMap::new();
    sockets.insert(local, init_sock.clone());
    let mut readers = ReaderGuard::default();
    readers.push(spawn_reader(init_sock, local, net_tx.clone()));

    let mut config = tls::build_config(&TlsParams {
        cert_pem: &cfg.cert_pem,
        key_pem: &cfg.key_pem,
        pin_endpoint: true,
        expected_pins: consts::MASQUE_PINS,
    })?;

    let datagram = cfg.datagram_budget();
    config.set_max_send_udp_payload_size(datagram);
    config.set_max_recv_udp_payload_size(datagram);

    // No ECH: the WARP gateways turn it down.
    let mut conn = new_connection(&cfg.sni, local, peer, &mut config)?;

    let h3_config = h3::Config::new()?;
    let mut h3_conn: Option<h3::Connection> = None;
    let mut req_stream: Option<u64> = None;
    let mut capsules = CapsuleParser::new();

    if let Some(sock) = sockets.get(&local) {
        noize::pre_handshake(sock.as_ref(), peer, &cfg.noize).await;
    }

    flush(&mut conn, &sockets, datagram).await?;

    let mut out_buf = vec![0u8; 65535];
    let mut keepalive_interval = tokio::time::interval(Duration::from_secs(20));
    keepalive_interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    let mut probe_interval = tokio::time::interval(Duration::from_millis(700));
    probe_interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    let mut ctrl_open = true;
    let mut outbound_open = true;

    loop {
        if ready.timed_out() {
            log::warn!(
                "[quic] masque data-plane validation timed out; edge {peer} accepts control but drops traffic"
            );
            let _ = conn.close(true, 0x00, b"validation-timeout");
            return Err(AetherError::Masque(
                "data-plane validation timeout (handshake ok, no traffic)".into(),
            ));
        }

        let timeout = conn.timeout();

        tokio::select! {
            biased;

            _ = keepalive_interval.tick() => keepalive(&mut conn),

            _ = probe_interval.tick(), if ready.probing() => {
                send_ip(&mut conn, req_stream, &probe_packet, Sent::Probe);
            }

            Some((to_local, from, data)) = net_rx.recv() => receive(&mut conn, to_local, from, data),

            ctrl = internals.ctrl_rx.recv(), if ctrl_open => {
                ctrl_open = on_control(ctrl, &mut conn, peer, &mut sockets, &net_tx, &mut readers).await;
            }

            pkt = internals.outbound_rx.recv(), if outbound_open => {
                match pkt {
                    Some(ip_packet) => send_ip(&mut conn, req_stream, &ip_packet, Sent::Outbound),
                    None => {
                        outbound_open = false;
                        let _ = conn.close(true, 0x00, b"eof");
                    }
                }
            }

            _ = sleep_opt(timeout) => {
                conn.on_timeout();
            }
        }

        if conn.is_established() && h3_conn.is_none() {
            let (h3c, sid) = open_connect_ip(&mut conn, &h3_config, &cfg)?;
            req_stream = Some(sid);
            h3_conn = Some(h3c);
            ready.on_established(quiet);
        }

        if let (Some(h3c), Some(sid)) = (h3_conn.as_mut(), req_stream) {
            poll_h3(&mut conn, h3c, sid, &mut capsules, &addr_tx, quiet)?;
        }

        let got_data = drain_datagrams(&mut conn, req_stream, &internals.inbound_tx, &mut out_buf);
        ready.on_data(got_data, quiet);

        flush(&mut conn, &sockets, datagram).await?;

        if conn.is_closed() {
            log_closed(&conn, quiet);
            return Ok(());
        }
    }
}

fn keepalive(conn: &mut quiche::Connection) {
    if conn.is_established() {
        if let Err(e) = conn.send_ack_eliciting() {
            log::debug!("[quic] keepalive ping failed: {e}");
        }
    }
}

#[derive(Clone, Copy)]
enum Sent {
    Probe,
    Outbound,
}

fn send_ip(conn: &mut quiche::Connection, req_stream: Option<u64>, ip_packet: &[u8], kind: Sent) {
    let Some(sid) = req_stream else {
        return;
    };
    match masque::encode_ip_datagram(sid, ip_packet) {
        Ok(framed) => {
            if let Err(e) = conn.dgram_send(&framed) {
                match kind {
                    Sent::Probe => log::trace!("[quic] data-plane probe send: {e}"),
                    Sent::Outbound => log::trace!("[quic] dgram_send: {e}"),
                }
            }
        }
        Err(e) => match kind {
            Sent::Probe => log::trace!("[quic] data-plane probe encode: {e}"),
            Sent::Outbound => log::trace!("[quic] encap: {e}"),
        },
    }
}

fn receive(conn: &mut quiche::Connection, to_local: SocketAddr, from: SocketAddr, mut data: Vec<u8>) {
    let mut hdr_buf = data.clone();
    if let Ok(hdr) = quiche::Header::from_slice(&mut hdr_buf, quiche::MAX_CONN_ID_LEN) {
        log::trace!("[quic] recv {} bytes type={:?} version=0x{:x} from {}", data.len(), hdr.ty, hdr.version, from);
    }
    let info = quiche::RecvInfo { from, to: to_local };
    if let Err(e) = conn.recv(&mut data, info) {
        log::trace!("[quic] recv error: {e}");
    }
}

async fn on_control(
    ctrl: Option<Control>,
    conn: &mut quiche::Connection,
    peer: SocketAddr,
    sockets: &mut HashMap<SocketAddr, Arc<UdpSocket>>,
    net_tx: &mpsc::Sender<NetPacket>,
    readers: &mut ReaderGuard,
) -> bool {
    match ctrl {
        Some(Control::Migrate) => {
            if let Err(e) = do_migrate(conn, peer, sockets, net_tx, readers).await {
                log::warn!("[quic] migration failed: {e}");
            }
            true
        }
        Some(Control::Close) | None => {
            let _ = conn.close(true, 0x00, b"bye");
            false
        }
    }
}

fn open_connect_ip(
    conn: &mut quiche::Connection,
    h3_config: &h3::Config,
    cfg: &TunnelConfig,
) -> Result<(h3::Connection, u64)> {
    log_or_debug(
        cfg.quiet,
        format!(
            "quic handshake established; alpn={}",
            String::from_utf8_lossy(conn.application_proto())
        ),
    );
    let mut h3c = h3::Connection::with_transport(conn, h3_config)?;
    let headers = masque::connect_ip_request(&cfg.authority, &cfg.path);
    let sid = h3c.send_request(conn, &headers, false)?;
    log_or_debug(cfg.quiet, format!("connect-ip request sent on stream {sid}"));
    Ok((h3c, sid))
}

fn log_closed(conn: &quiche::Connection, quiet: bool) {
    log_or_debug(quiet, format!("connection closed: {:?}", conn.stats()));
    if let Some(e) = conn.peer_error() {
        log_or_debug(
            quiet,
            format!(
                "peer closed: code=0x{:x} app={} reason={}",
                e.error_code,
                e.is_app,
                String::from_utf8_lossy(&e.reason)
            ),
        );
    }
    if let Some(e) = conn.local_error() {
        log_or_debug(
            quiet,
            format!(
                "local closed: code=0x{:x} app={} reason={}",
                e.error_code,
                e.is_app,
                String::from_utf8_lossy(&e.reason)
            ),
        );
    }
}

async fn sleep_opt(timeout: Option<Duration>) {
    match timeout {
        Some(d) => tokio::time::sleep(d).await,
        None => std::future::pending::<()>().await,
    }
}

fn log_or_debug(quiet: bool, msg: String) {
    if quiet {
        log::debug!("[quic] {msg}");
    } else {
        log::info!("[quic] {msg}");
    }
}

fn poll_h3(
    conn: &mut quiche::Connection,
    h3c: &mut h3::Connection,
    req_stream: u64,
    capsules: &mut CapsuleParser,
    addr_tx: &Option<mpsc::Sender<AssignedAddr>>,
    quiet: bool,
) -> Result<()> {
    let mut body = vec![0u8; 65535];

    loop {
        match h3c.poll(conn) {
            Ok((stream_id, h3::Event::Headers { list, .. })) => {
                for h in &list {
                    if h.name() == b":status" {
                        let status = String::from_utf8_lossy(h.value()).to_string();
                        log_or_debug(quiet, format!("connect-ip status: {status}"));
                        if stream_id == req_stream && !status.starts_with('2') {
                            return Err(AetherError::Masque(format!(
                                "the edge refused connect-ip with status {status}"
                            )));
                        }
                    }
                }
            }

            Ok((stream_id, h3::Event::Data)) => {
                if stream_id != req_stream {
                    continue;
                }
                while let Ok(n) = h3c.recv_body(conn, stream_id, &mut body) {
                    if n == 0 {
                        break;
                    }
                    capsules.push(&body[..n]);
                }
                drain_capsules(capsules, addr_tx);
            }

            Ok((stream_id, h3::Event::Finished)) if stream_id == req_stream => {
                return Err(AetherError::Masque(
                    "the edge closed the connect-ip stream".into(),
                ));
            }
            Ok((stream_id, h3::Event::Reset(code))) if stream_id == req_stream => {
                return Err(AetherError::Masque(format!(
                    "the edge reset the connect-ip stream (code 0x{code:x})"
                )));
            }
            Ok(_) => {}

            Err(h3::Error::Done) => break,
            Err(e) => return Err(AetherError::H3(e)),
        }
    }

    Ok(())
}

fn drain_capsules(capsules: &mut CapsuleParser, addr_tx: &Option<mpsc::Sender<AssignedAddr>>) {
    loop {
        match capsules.next_capsule() {
            Ok(Some(masque::Capsule::AddressAssign(addrs))) => {
                for a in addrs {
                    if let Some(ip) = bytes_to_ip(a.ip_version, &a.address) {
                        log::info!("[quic] edge assigned {}/{}", ip, a.prefix_len);
                        if let Some(tx) = addr_tx {
                            let _ = tx.try_send(AssignedAddr {
                                ip,
                                prefix: a.prefix_len,
                            });
                        }
                    }
                }
            }
            Ok(Some(masque::Capsule::RouteAdvertisement(routes))) => {
                log::info!("[quic] received {} route advertisements", routes.len());
            }
            Ok(Some(_)) => {}
            Ok(None) => break,
            Err(e) => {
                log::trace!("[quic] capsule parse: {e}");
                break;
            }
        }
    }
}

fn bytes_to_ip(version: u8, bytes: &[u8]) -> Option<IpAddr> {
    match version {
        4 if bytes.len() == 4 => Some(IpAddr::V4([bytes[0], bytes[1], bytes[2], bytes[3]].into())),
        6 if bytes.len() == 16 => {
            let mut b = [0u8; 16];
            b.copy_from_slice(bytes);
            Some(IpAddr::V6(b.into()))
        }
        _ => None,
    }
}

fn drain_datagrams(
    conn: &mut quiche::Connection,
    req_stream: Option<u64>,
    inbound_tx: &mpsc::Sender<Vec<u8>>,
    buf: &mut [u8],
) -> bool {
    let sid = match req_stream {
        Some(s) => s,
        None => return false,
    };

    let mut delivered = false;
    loop {
        match conn.dgram_recv(buf) {
            Ok(n) => match masque::decode_ip_datagram(&buf[..n], sid) {
                Ok(Some(ip_packet)) => {
                    delivered = true;
                    match inbound_tx.try_send(ip_packet) {
                        Ok(()) => {}
                        Err(mpsc::error::TrySendError::Full(_)) => {
                            log::trace!("[quic] inbound queue full, dropping datagram");
                        }
                        Err(mpsc::error::TrySendError::Closed(_)) => return delivered,
                    }
                }
                Ok(None) => {}
                Err(e) => log::trace!("[quic] decap: {e}"),
            },
            Err(quiche::Error::Done) => break,
            Err(e) => {
                log::trace!("[quic] dgram_recv: {e}");
                break;
            }
        }
    }
    delivered
}

async fn flush(
    conn: &mut quiche::Connection,
    sockets: &HashMap<SocketAddr, Arc<UdpSocket>>,
    datagram: usize,
) -> Result<()> {
    let mut out = vec![0u8; datagram];

    loop {
        match conn.send(&mut out) {
            Ok((write, send_info)) => {
                if let Some(sock) = sockets.get(&send_info.from) {
                    let to = crate::transport::warp::net::upstream::relay_target(send_info.from, send_info.to);
                    sock.send_to(&out[..write], to).await?;
                } else if let Some((local, sock)) = sockets.iter().next() {
                    let to = crate::transport::warp::net::upstream::relay_target(*local, send_info.to);
                    sock.send_to(&out[..write], to).await?;
                }
            }
            Err(quiche::Error::Done) => break,
            Err(e) => return Err(AetherError::Quic(e)),
        }
    }

    Ok(())
}

async fn do_migrate(
    conn: &mut quiche::Connection,
    peer: SocketAddr,
    sockets: &mut HashMap<SocketAddr, Arc<UdpSocket>>,
    net_tx: &mpsc::Sender<NetPacket>,
    readers: &mut ReaderGuard,
) -> Result<()> {
    if conn.available_dcids() == 0 {
        return Err(AetherError::Other("no spare dcids for migration".into()));
    }

    let new_sock = bind_udp_fast(crate::utils::egress::wildcard_for(peer)).await?;
    readers
        .detours
        .push(crate::transport::warp::net::upstream::attach_detour(&new_sock, peer).await?);
    let new_local = new_sock.local_addr()?;
    let new_sock = Arc::new(new_sock);

    sockets.insert(new_local, new_sock.clone());
    readers.push(spawn_reader(new_sock, new_local, net_tx.clone()));

    conn.probe_path(new_local, peer)?;
    let seq = conn.migrate_source(new_local)?;
    log::info!("[quic] migrated to local {new_local} (path seq {seq})");

    Ok(())
}

pub fn default_authority() -> &'static str {
    "cloudflareaccess.com"
}

pub fn default_path() -> &'static str {
    "/"
}

/// The server name the MASQUE handshakes send without --masque-sni.
pub fn default_sni() -> &'static str {
    consts::DEFAULT_MASQUE_SNI
}

/// The server name the MASQUE handshakes put in their ClientHello, over HTTP/3 and HTTP/2:
/// that of --masque-sni (AETHER_MASQUE_SNI), see `masque_sni_of`. Only the TLS name changes;
/// the HTTP host, the :authority of the CONNECT request, stays `default_authority`.
pub fn masque_sni() -> Result<String> {
    masque_sni_of(&crate::config::settings::var("AETHER_MASQUE_SNI").unwrap_or_default())
}

/// The server name `value`, given to --masque-sni, makes the MASQUE handshakes send: none
/// given, `default_sni`; else that domain name, without a trailing dot, as SNI has it
/// (RFC 6066). An address or anything else that is no domain name is refused, rather than
/// have the handshakes send the default name in its place.
pub fn masque_sni_of(value: &str) -> Result<String> {
    let value = value.trim();
    if value.is_empty() {
        return Ok(default_sni().to_string());
    }
    let name = value.strip_suffix('.').unwrap_or(value);
    if name.ends_with('.') || name.parse::<IpAddr>().is_ok() || !crate::dns::valid_domain(name) {
        return Err(AetherError::Tls(format!(
            "masque.sni: {value} is no domain name"
        )));
    }
    Ok(name.to_string())
}

/// Whether a QUIC v1 Initial, the packet that carries a ClientHello, reaches `peer` within
/// `wait`. The version bait (QUIC v2) and the junk of the obfuscation are no Initial.
#[cfg(test)]
pub(crate) async fn hears_a_client_hello(peer: &UdpSocket, wait: Duration) -> bool {
    let deadline = tokio::time::Instant::now() + wait;
    let mut packet = [0u8; 2048];
    while let Ok(Ok((read, _))) =
        tokio::time::timeout_at(deadline, peer.recv_from(&mut packet)).await
    {
        // A long header of the Initial type, and version 1.
        if read > 5 && packet[0] & 0xf0 == 0xc0 && packet[1..5] == [0, 0, 0, 1] {
            return true;
        }
    }
    false
}

#[cfg(test)]
mod v2_bait_tests;

#[cfg(test)]
mod masque_sni_tests;
