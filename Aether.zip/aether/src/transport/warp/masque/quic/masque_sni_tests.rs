use super::*;

#[test]
fn the_masque_sni_is_a_domain_name_or_the_default() {
    for (given, sent) in [
        // None given: www.cloudflare.com.
        ("", "www.cloudflare.com"),
        ("  ", "www.cloudflare.com"),
        // The name the WARP client sends.
        (consts::CONNECT_SNI, consts::CONNECT_SNI),
        (" front.example.test ", "front.example.test"),
        // SNI has no trailing dot (RFC 6066).
        ("front.example.test.", "front.example.test"),
        ("localhost", "localhost"),
    ] {
        assert_eq!(
            masque_sni_of(given).ok().as_deref(),
            Some(sent),
            "{given:?}"
        );
    }
    for refused in [
        "1.1.1.1",
        "1.1.1.1.",
        "2606:4700:4700::1111",
        "[2606:4700:4700::1111]",
        "www..cloudflare.com",
        "www.cloudflare.com..",
        ".",
        "www cloudflare com",
        "www.cloudflare.com:443",
        "https://www.cloudflare.com",
    ] {
        let error = masque_sni_of(refused).expect_err(refused);
        assert_eq!(
            error.to_string(),
            format!("tls: masque.sni: {refused} is no domain name")
        );
    }
}

#[tokio::test]
async fn the_masque_sni_is_that_of_its_variable() {
    let _options = tls::hold_options().await;
    assert_eq!(masque_sni().ok().as_deref(), Some("www.cloudflare.com"));
    crate::config::settings::decide("AETHER_MASQUE_SNI", consts::CONNECT_SNI);
    assert_eq!(masque_sni().ok().as_deref(), Some(consts::CONNECT_SNI));
    crate::config::settings::decide("AETHER_MASQUE_SNI", "1.1.1.1");
    assert!(masque_sni().is_err());
}
