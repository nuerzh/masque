use super::*;

#[test]
fn the_bait_is_a_v2_versioned_long_header_of_the_minimum_size() {
    let pkt = build_version_bait();
    assert_eq!(pkt.len(), QUIC_V2_BAIT_LEN);
    assert_eq!(pkt[0] & 0x80, 0x80, "long header form bit must be set");
    assert_eq!(pkt[0] & 0x40, 0x40, "fixed bit must be set");
    assert_eq!(
        u32::from_be_bytes([pkt[1], pkt[2], pkt[3], pkt[4]]),
        QUIC_V2_VERSION,
        "the version field must be QUIC v2 so the filter treats the flow as v2"
    );
    assert_eq!(pkt[5], 8, "destination connection id length");
    assert_eq!(pkt[14], 8, "source connection id length");
}

#[test]
fn two_baits_do_not_share_connection_ids() {
    let a = build_version_bait();
    let b = build_version_bait();
    assert_ne!(a[6..14], b[6..14], "each bait must use a fresh dcid");
}

#[test]
fn the_bait_is_on_unless_it_is_turned_off() {
    crate::config::settings::forget("AETHER_QUIC_V2");
    assert!(quic_v2_bait_enabled());
    crate::config::settings::decide("AETHER_QUIC_V2", "0");
    assert!(!quic_v2_bait_enabled());
    crate::config::settings::decide("AETHER_QUIC_V2", "off");
    assert!(!quic_v2_bait_enabled());
    crate::config::settings::decide("AETHER_QUIC_V2", "1");
    assert!(quic_v2_bait_enabled());
    crate::config::settings::forget("AETHER_QUIC_V2");
}

#[tokio::test]
async fn the_bait_triggers_a_version_negotiation_from_a_v1_only_server() {
    let server = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
    let server_addr = server.local_addr().unwrap();

    let responder = tokio::spawn(async move {
        let mut buf = [0u8; 2048];
        let (n, from) = server.recv_from(&mut buf).await.unwrap();
        assert_eq!(n, QUIC_V2_BAIT_LEN);
        let dcid = buf[6..14].to_vec();
        let scid = buf[15..23].to_vec();
        let mut vn = vec![0xc0, 0x00, 0x00, 0x00, 0x00];
        vn.push(scid.len() as u8);
        vn.extend_from_slice(&scid);
        vn.push(dcid.len() as u8);
        vn.extend_from_slice(&dcid);
        vn.extend_from_slice(&1u32.to_be_bytes());
        server.send_to(&vn, from).await.unwrap();
    });

    let client = UdpSocket::bind("127.0.0.1:0").await.unwrap();
    client.connect(server_addr).await.unwrap();
    send_version_bait(&client, server_addr, Duration::from_secs(2), 1).await;
    responder.await.unwrap();
}
