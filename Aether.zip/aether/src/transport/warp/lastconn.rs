use std::collections::HashSet;
use std::net::SocketAddr;

use serde::{Deserialize, Serialize};

pub const RECENT_CAP: usize = 8;

pub const CARRIER_MASQUE_H3: &str = "masque-h3";
pub const CARRIER_MASQUE_H2: &str = "masque-h2";

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct LastConnection {
    pub peer: String,
    #[serde(default)]
    pub profile: String,
    /// Read only, from files before the carrier came from the config alone: each carrier has its
    /// own file, so the file never names one.
    #[serde(default, skip_serializing)]
    pub carrier: String,
    #[serde(default)]
    pub recent: Vec<String>,
    /// Read only, from the one shared file of 7f463d7 (the other carrier's remembered gateways),
    /// which `split_shared` turns into the two files of their own.
    #[serde(default, skip_serializing)]
    pub other_carriers: std::collections::BTreeMap<String, Vec<String>>,
    /// The RTT of `peer` (the scan's full check) when it was last measured, for comparing runs.
    /// The run never switches on it: the comparison base is what this run measures.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rtt_ms: Option<u64>,
    /// When `rtt_ms` was measured, unix seconds.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub measured_at: Option<u64>,
    /// Every RTT measurement this run and earlier runs made (the scan's full check of a gateway
    /// started on, switched to, or measured at startup), newest first, the latest `HISTORY_CAP`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub history: Vec<RttRecord>,
}

/// How many RTT measurements `history` keeps.
pub const HISTORY_CAP: usize = 20;

/// One RTT measurement of a gateway.
#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
pub struct RttRecord {
    pub peer: String,
    pub rtt_ms: u64,
    /// Read only (older files); the file a record is in is its carrier's.
    #[serde(default, skip_serializing)]
    pub carrier: String,
    #[serde(default)]
    pub at: u64,
}

fn now_secs() -> Option<u64> {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .ok()
        .map(|t| t.as_secs())
}

/// The gateways in `history` on `carrier`, each with its newest measurement, fastest first: the
/// first is the best remembered gateway.
pub fn ranked_history(conn: &LastConnection, carrier: &str) -> Vec<(SocketAddr, u64)> {
    let mut seen = HashSet::new();
    let mut ranked: Vec<(SocketAddr, u64)> = conn
        .history
        .iter()
        .filter(|r| r.carrier.is_empty() || r.carrier == carrier)
        .filter(|r| seen.insert(r.peer.clone()))
        .filter_map(|r| Some((r.peer.parse().ok()?, r.rtt_ms)))
        .collect();
    ranked.sort_by_key(|(_, ms)| *ms);
    ranked
}

/// Add measurements to `history` (newest first, the latest `HISTORY_CAP` kept).
pub fn record(path: &str, carrier: &str, measured: &[(SocketAddr, std::time::Duration)]) {
    let Some(mut conn) = load(path) else { return };
    let at = now_secs().unwrap_or_default();
    let mut fresh: Vec<RttRecord> = measured
        .iter()
        .map(|(peer, rtt)| RttRecord {
            peer: peer.to_string(),
            rtt_ms: rtt.as_millis() as u64,
            carrier: carrier.to_string(),
            at,
        })
        .collect();
    fresh.append(&mut conn.history);
    fresh.truncate(HISTORY_CAP);
    conn.history = fresh;
    write(path, &conn);
}

/// Drop every measurement of `peers` from `history` (they failed their check).
pub fn forget(path: &str, peers: &[SocketAddr]) {
    let Some(mut conn) = load(path) else { return };
    let gone: HashSet<String> = peers.iter().map(|p| p.to_string()).collect();
    let before = conn.history.len();
    conn.history.retain(|r| !gone.contains(&r.peer));
    if conn.history.len() != before {
        write(path, &conn);
    }
}

/// The file of `carrier` beside the identity: `base` (`aether-lastconn.yaml`) with `-h3` or `-h2`
/// (`aether-lastconn-h3.yaml`). Each carrier keeps its own file, never shared.
pub fn carrier_path(base: &str, carrier: &str) -> String {
    let tag = if carrier == CARRIER_MASQUE_H2 { "h2" } else { "h3" };
    crate::transport::warp::derive_sibling_path(base, tag)
}

/// Turn the one file both carriers shared before (`base`) into the file of each carrier, leaving
/// a file a carrier already has alone, and rename `base` to `<base>.old`. Its last carrier is
/// written last, so it stays the newest.
pub fn split_shared(base: &str) {
    let Some(shared) = load(base) else { return };
    let last = if shared.carrier == CARRIER_MASQUE_H2 { CARRIER_MASQUE_H2 } else { CARRIER_MASQUE_H3 };
    let other = if last == CARRIER_MASQUE_H2 { CARRIER_MASQUE_H3 } else { CARRIER_MASQUE_H2 };
    let history_of = |carrier: &str| -> Vec<RttRecord> {
        shared
            .history
            .iter()
            .filter(|r| r.carrier == carrier || (r.carrier.is_empty() && carrier == last))
            .cloned()
            .collect()
    };
    let other_ring = shared.other_carriers.get(other).cloned().unwrap_or_default();
    let other_history = history_of(other);
    if !other_ring.is_empty() || !other_history.is_empty() {
        let path = carrier_path(base, other);
        if load(&path).is_none() {
            let peer = other_ring
                .first()
                .cloned()
                .or_else(|| other_history.first().map(|r| r.peer.clone()))
                .unwrap_or_default();
            write(
                &path,
                &LastConnection {
                    peer,
                    profile: shared.profile.clone(),
                    carrier: other.to_string(),
                    recent: other_ring,
                    history: other_history,
                    ..Default::default()
                },
            );
        }
    }
    let path = carrier_path(base, last);
    if load(&path).is_none() {
        write(
            &path,
            &LastConnection {
                carrier: last.to_string(),
                history: history_of(last),
                other_carriers: Default::default(),
                ..shared.clone()
            },
        );
    }
    let old = format!("{base}.old");
    match std::fs::rename(base, &old) {
        Ok(()) => log::info!("[lastconn] split {base} into {} and {}; the old file is {old}", carrier_path(base, CARRIER_MASQUE_H3), carrier_path(base, CARRIER_MASQUE_H2)),
        Err(e) => log::debug!("[lastconn] could not rename {base}: {e}"),
    }
}

fn write(path: &str, conn: &LastConnection) {
    match crate::config::yaml::to_string(conn) {
        Ok(text) => {
            if let Err(e) = std::fs::write(path, text) {
                log::debug!("[lastconn] failed to save {path}: {e}");
            }
        }
        Err(e) => log::debug!("[lastconn] failed to encode: {e}"),
    }
}

pub fn load(path: &str) -> Option<LastConnection> {
    let text = std::fs::read_to_string(path).ok()?;
    serde_yaml_ng::from_str(&text).ok()
}

/// Save `peer` as the last working gateway, with its RTT when this run measured one. Without
/// one, the RTT saved for the same gateway on the same carrier is kept.
pub fn save(path: &str, peer: &str, profile: &str, carrier: &str, rtt: Option<std::time::Duration>) {
    let previous = load(path);
    let (rtt_ms, measured_at) = match rtt {
        Some(d) => (Some(d.as_millis() as u64), now_secs()),
        None => previous
            .as_ref()
            .filter(|c| c.peer == peer && (c.carrier.is_empty() || c.carrier == carrier))
            .map_or((None, None), |c| (c.rtt_ms, c.measured_at)),
    };
    let carried_over = previous
        .as_ref()
        .filter(|c| c.carrier.is_empty() || c.carrier == carrier)
        .map(|c| c.recent.clone())
        .unwrap_or_default();

    let mut recent: Vec<String> = vec![peer.to_string()];
    for entry in carried_over {
        if entry != peer && recent.len() < RECENT_CAP {
            recent.push(entry);
        }
    }

    let mut history = previous.as_ref().map(|c| c.history.clone()).unwrap_or_default();
    if let (Some(ms), Some(_)) = (rtt_ms, rtt) {
        history.insert(
            0,
            RttRecord {
                peer: peer.to_string(),
                rtt_ms: ms,
                carrier: carrier.to_string(),
                at: measured_at.unwrap_or_default(),
            },
        );
        history.truncate(HISTORY_CAP);
    }

    let conn = LastConnection {
        peer: peer.to_string(),
        profile: profile.to_string(),
        carrier: carrier.to_string(),
        recent,
        other_carriers: Default::default(),
        rtt_ms,
        measured_at,
        history,
    };
    write(path, &conn);
}

pub fn usable_peers(cached: &LastConnection, carrier: &str) -> Vec<SocketAddr> {
    if !cached.carrier.is_empty() && cached.carrier != carrier {
        log::debug!(
            "[lastconn] ignoring gateways saved for {} while running {carrier}",
            cached.carrier
        );
        return Vec::new();
    }

    let mut out = Vec::new();
    let mut seen = HashSet::new();
    for raw in std::iter::once(&cached.peer).chain(cached.recent.iter()) {
        if let Ok(addr) = raw.parse::<SocketAddr>() {
            if seen.insert(addr) {
                out.push(addr);
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scratch(tag: &str) -> String {
        let mut path = std::env::temp_dir();
        path.push(format!("aether-lastconn-{tag}-{}.yaml", std::process::id()));
        let _ = std::fs::remove_file(&path);
        path.to_string_lossy().to_string()
    }

    #[test]
    fn the_newest_gateway_leads_the_ring() {
        let path = scratch("ring");
        save(&path, "1.1.1.1:443", "gfw", CARRIER_MASQUE_H3, None);
        save(&path, "1.0.0.1:443", "gfw", CARRIER_MASQUE_H3, None);
        save(&path, "1.1.1.1:443", "gfw", CARRIER_MASQUE_H3, None);
        let loaded = load(&path).expect("it was just written");
        assert_eq!(loaded.peer, "1.1.1.1:443");
        assert_eq!(loaded.recent, vec!["1.1.1.1:443", "1.0.0.1:443"]);
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn the_rtt_is_recorded_and_kept_for_the_same_gateway() {
        let path = scratch("rtt");
        save(&path, "1.1.1.1:443", "gfw", CARRIER_MASQUE_H3, Some(std::time::Duration::from_millis(812)));
        let first = load(&path).expect("it was just written");
        assert_eq!(first.rtt_ms, Some(812));
        assert!(first.measured_at.is_some());
        // a reconnect to the same gateway without a measurement keeps the RTT
        save(&path, "1.1.1.1:443", "gfw", CARRIER_MASQUE_H3, None);
        assert_eq!(load(&path).expect("written").rtt_ms, Some(812));
        // another gateway without a measurement has none
        save(&path, "1.0.0.1:443", "gfw", CARRIER_MASQUE_H3, None);
        assert_eq!(load(&path).expect("written").rtt_ms, None);
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn the_history_keeps_the_latest_twenty_measurements_and_ranks_by_each_gateways_newest() {
        let path = scratch("history");
        let ms = std::time::Duration::from_millis;
        let a: SocketAddr = "1.1.1.1:443".parse().unwrap();
        let b: SocketAddr = "1.0.0.1:443".parse().unwrap();
        save(&path, "1.1.1.1:443", "gfw", CARRIER_MASQUE_H3, Some(ms(300)));
        save(&path, "1.0.0.1:443", "gfw", CARRIER_MASQUE_H3, Some(ms(500)));
        save(&path, "1.0.0.2:443", "gfw", CARRIER_MASQUE_H3, None);
        let c = load(&path).expect("written");
        assert_eq!(c.history.len(), 2, "unmeasured saves add nothing");
        assert_eq!(ranked_history(&c, CARRIER_MASQUE_H3), vec![(a, 300), (b, 500)]);
        // a gateway that got slower ranks by its newest measurement, not its old best
        record(&path, CARRIER_MASQUE_H3, &[(a, ms(900))]);
        let c = load(&path).unwrap();
        assert_eq!(ranked_history(&c, CARRIER_MASQUE_H3), vec![(b, 500), (a, 900)]);
        assert_eq!(c.history.len(), 3, "every measurement is a record");
        // only the latest twenty
        for n in 0..25u8 {
            record(&path, CARRIER_MASQUE_H3, &[(format!("10.0.0.{n}:443").parse().unwrap(), ms(100 + n as u64))]);
        }
        let c = load(&path).unwrap();
        assert_eq!(c.history.len(), HISTORY_CAP);
        assert_eq!(c.history[0].peer, "10.0.0.24:443");
        assert_eq!(ranked_history(&c, CARRIER_MASQUE_H3)[0].0, "10.0.0.5:443".parse::<SocketAddr>().unwrap());
        forget(&path, &["10.0.0.5:443".parse().unwrap()]);
        let c = load(&path).unwrap();
        assert_eq!(c.history.len(), HISTORY_CAP - 1);
        assert_eq!(c.peer, "1.0.0.2:443", "the rest stays");
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn the_ring_never_grows_past_its_cap() {
        let path = scratch("cap");
        for n in 0..20u8 {
            save(
                &path,
                &format!("10.0.0.{n}:443"),
                "balanced",
                CARRIER_MASQUE_H3,
                None,
            );
        }
        let loaded = load(&path).expect("it was just written");
        assert_eq!(loaded.recent.len(), RECENT_CAP);
        assert_eq!(loaded.recent[0], "10.0.0.19:443");
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn a_file_written_by_an_older_build_still_loads() {
        let path = scratch("legacy");
        std::fs::write(&path, "peer: 1.1.1.1:443\nprofile: gfw\n").expect("write");
        let loaded = load(&path).expect("it was just written");
        assert_eq!(loaded.peer, "1.1.1.1:443");
        assert!(loaded.recent.is_empty());
        assert!(loaded.carrier.is_empty());
        assert_eq!(
            usable_peers(&loaded, CARRIER_MASQUE_H2),
            vec!["1.1.1.1:443".parse::<SocketAddr>().expect("an address")]
        );
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn gateways_proved_on_one_carrier_are_not_reused_on_another() {
        let cached = LastConnection {
            peer: "1.1.1.1:1701".to_string(),
            profile: String::new(),
            carrier: CARRIER_MASQUE_H3.to_string(),
            recent: vec!["1.1.1.1:1701".to_string()],
            ..Default::default()
        };
        assert!(usable_peers(&cached, CARRIER_MASQUE_H2).is_empty());
        assert_eq!(usable_peers(&cached, CARRIER_MASQUE_H3).len(), 1);
    }

    #[test]
    fn each_carrier_has_its_own_file_and_no_file_names_a_carrier() {
        let base = scratch("carriers");
        let h3 = carrier_path(&base, CARRIER_MASQUE_H3);
        let h2 = carrier_path(&base, CARRIER_MASQUE_H2);
        assert!(h3.ends_with("-h3.yaml") && h2.ends_with("-h2.yaml"), "{h3} {h2}");
        let ms = std::time::Duration::from_millis;
        save(&h3, "1.1.1.1:443", "gfw", CARRIER_MASQUE_H3, Some(ms(300)));
        save(&h2, "1.0.0.2:443", "gfw", CARRIER_MASQUE_H2, Some(ms(700)));
        for f in [&h3, &h2] {
            let text = std::fs::read_to_string(f).unwrap();
            assert!(!text.contains("carrier"), "{text}");
        }
        // the H3 file is untouched by the H2 run
        let c3 = load(&h3).unwrap();
        assert_eq!(c3.peer, "1.1.1.1:443");
        assert_eq!(c3.history.len(), 1);
        assert_eq!(load(&h2).unwrap().history.len(), 1);
        for p in [&h3, &h2] {
            let _ = std::fs::remove_file(p);
        }
    }

    #[test]
    fn the_shared_file_splits_into_one_per_carrier() {
        let base = scratch("shared");
        std::fs::write(
            &base,
            r#"peer: 1.0.0.2:443
profile: gfw
carrier: masque-h2
recent: [1.0.0.2:443]
rtt_ms: 700
other_carriers:
  masque-h3: [1.0.0.1:443, 1.1.1.1:443]
history:
  - { peer: 1.0.0.2:443, rtt_ms: 700, carrier: masque-h2, at: 3 }
  - { peer: 1.1.1.1:443, rtt_ms: 300, carrier: masque-h3, at: 1 }
"#,
        )
        .unwrap();
        split_shared(&base);
        let a: SocketAddr = "1.1.1.1:443".parse().unwrap();
        let b: SocketAddr = "1.0.0.1:443".parse().unwrap();
        let c: SocketAddr = "1.0.0.2:443".parse().unwrap();
        let c3 = load(&carrier_path(&base, CARRIER_MASQUE_H3)).expect("h3 file");
        let c2 = load(&carrier_path(&base, CARRIER_MASQUE_H2)).expect("h2 file");
        assert_eq!(usable_peers(&c3, CARRIER_MASQUE_H3), vec![b, a]);
        assert_eq!(ranked_history(&c3, CARRIER_MASQUE_H3), vec![(a, 300)]);
        assert_eq!(usable_peers(&c2, CARRIER_MASQUE_H2), vec![c]);
        assert_eq!(c2.rtt_ms, Some(700));
        assert_eq!(c2.history.len(), 1);
        assert!(!std::path::Path::new(&base).exists());
        assert!(!std::fs::read_to_string(carrier_path(&base, CARRIER_MASQUE_H2)).unwrap().contains("other_carriers"));
        for p in [carrier_path(&base, CARRIER_MASQUE_H3), carrier_path(&base, CARRIER_MASQUE_H2), format!("{base}.old")] {
            let _ = std::fs::remove_file(p);
        }
    }

    #[test]
    fn unparsable_and_repeated_entries_are_dropped() {
        let cached = LastConnection {
            peer: "not-an-address".to_string(),
            profile: String::new(),
            carrier: String::new(),
            recent: vec!["1.1.1.1:443".to_string(), "1.1.1.1:443".to_string()],
            ..Default::default()
        };
        assert_eq!(
            usable_peers(&cached, CARRIER_MASQUE_H3),
            vec!["1.1.1.1:443".parse::<SocketAddr>().expect("an address")]
        );
    }
}
