use super::*;
use std::time::Duration as StdDuration;

fn udp_ip_packet(payload_len: usize) -> Vec<u8> {
    let total = 20 + 8 + payload_len;
    let mut pkt = vec![0u8; total];
    pkt[0] = 0x45;
    pkt[2] = (total >> 8) as u8;
    pkt[3] = (total & 0xff) as u8;
    pkt[8] = 64;
    pkt[9] = 17;
    pkt[12..16].copy_from_slice(&[10, 0, 0, 9]);
    pkt[16..20].copy_from_slice(&[198, 18, 0, 1]);
    pkt[20..22].copy_from_slice(&5555u16.to_be_bytes());
    pkt[22..24].copy_from_slice(&9999u16.to_be_bytes());
    let udp_len = (8 + payload_len) as u16;
    pkt[24..26].copy_from_slice(&udp_len.to_be_bytes());
    pkt
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn netstack_keeps_draining_inbound_when_outbound_is_never_read() {
    let (inbound_tx, inbound_rx) = mpsc::channel::<Vec<u8>>(4);
    let (outbound_tx, _outbound_rx_never_read) = mpsc::channel::<Vec<u8>>(1);

    let stack = spawn("198.18.0.1", "fc00::1", 1400, inbound_rx, outbound_tx)
        .expect("netstack should start");

    let udp = stack.open_udp().await.expect("udp socket should open");
    let dst: SocketAddr = "1.1.1.1:53".parse().unwrap();

    for _ in 0..64 {
        let _ = udp.send_to(dst, vec![0u8; 64]).await;
    }

    tokio::time::sleep(StdDuration::from_millis(120)).await;

    for index in 0..64 {
        let send = inbound_tx.send(udp_ip_packet(32));
        tokio::time::timeout(StdDuration::from_secs(3), send)
            .await
            .unwrap_or_else(|_| {
                panic!("netstack stopped draining inbound at packet {index}: deadlock")
            })
            .expect("inbound channel should stay open");
    }
}

fn checksum16(data: &[u8], initial: u32) -> u16 {
    let mut sum = initial;
    let (pairs, rest) = data.as_chunks::<2>();
    for pair in pairs {
        sum += u16::from_be_bytes(*pair) as u32;
    }
    if let Some(&last) = rest.first() {
        sum += (last as u32) << 8;
    }
    while sum >> 16 != 0 {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    !(sum as u16)
}

struct Segment {
    src_port: u16,
    dst_port: u16,
    seq: u32,
    flags: u8,
}

fn parse_tcp(pkt: &[u8]) -> Option<Segment> {
    if pkt.len() < 20 || pkt[0] >> 4 != 4 {
        return None;
    }
    let ihl = ((pkt[0] & 0x0f) as usize) * 4;
    if pkt[9] != 6 || pkt.len() < ihl + 20 {
        return None;
    }
    let tcp = &pkt[ihl..];
    Some(Segment {
        src_port: u16::from_be_bytes([tcp[0], tcp[1]]),
        dst_port: u16::from_be_bytes([tcp[2], tcp[3]]),
        seq: u32::from_be_bytes([tcp[4], tcp[5], tcp[6], tcp[7]]),
        flags: tcp[13],
    })
}

fn build_tcp(
    src: (Ipv4Addr, u16),
    dst: (Ipv4Addr, u16),
    seq: u32,
    ack: u32,
    flags: u8,
) -> Vec<u8> {
    let mut tcp = vec![0u8; 20];
    tcp[0..2].copy_from_slice(&src.1.to_be_bytes());
    tcp[2..4].copy_from_slice(&dst.1.to_be_bytes());
    tcp[4..8].copy_from_slice(&seq.to_be_bytes());
    tcp[8..12].copy_from_slice(&ack.to_be_bytes());
    tcp[12] = 5 << 4;
    tcp[13] = flags;
    tcp[14..16].copy_from_slice(&64240u16.to_be_bytes());

    let mut pseudo = Vec::new();
    pseudo.extend_from_slice(&src.0.octets());
    pseudo.extend_from_slice(&dst.0.octets());
    pseudo.push(0);
    pseudo.push(6);
    pseudo.extend_from_slice(&(tcp.len() as u16).to_be_bytes());
    pseudo.extend_from_slice(&tcp);
    let tcp_sum = checksum16(&pseudo, 0);
    tcp[16..18].copy_from_slice(&tcp_sum.to_be_bytes());

    let total = 20 + tcp.len();
    let mut ip = vec![0u8; 20];
    ip[0] = 0x45;
    ip[2..4].copy_from_slice(&(total as u16).to_be_bytes());
    ip[8] = 64;
    ip[9] = 6;
    ip[12..16].copy_from_slice(&src.0.octets());
    ip[16..20].copy_from_slice(&dst.0.octets());
    let ip_sum = checksum16(&ip, 0);
    ip[10..12].copy_from_slice(&ip_sum.to_be_bytes());

    ip.extend_from_slice(&tcp);
    ip
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_vanished_app_makes_the_netstack_tear_the_connection_down() {
    let local = Ipv4Addr::new(198, 18, 0, 1);
    let remote = Ipv4Addr::new(93, 184, 216, 34);
    let remote_port = 80u16;

    let (inbound_tx, inbound_rx) = mpsc::channel::<Vec<u8>>(64);
    let (outbound_tx, mut outbound_rx) = mpsc::channel::<Vec<u8>>(256);

    let stack = spawn("198.18.0.1", "fc00::1", 1400, inbound_rx, outbound_tx)
        .expect("netstack should start");

    let dst = SocketAddr::new(IpAddr::V4(remote), remote_port);
    let connect = {
        let stack = stack.clone();
        tokio::spawn(async move { stack.open_tcp(dst).await })
    };

    let deadline = tokio::time::Instant::now() + StdDuration::from_secs(5);

    let (client_port, client_seq) = loop {
        let pkt = tokio::time::timeout_at(deadline, outbound_rx.recv())
            .await
            .expect("the netstack should emit a syn")
            .expect("outbound channel stays open");

        if let Some(seg) = parse_tcp(&pkt) {
            if seg.dst_port == remote_port && seg.flags & 0x02 != 0 && seg.flags & 0x10 == 0 {
                break (seg.src_port, seg.seq);
            }
        }
    };

    let syn_ack = build_tcp(
        (remote, remote_port),
        (local, client_port),
        5000,
        client_seq.wrapping_add(1),
        0x12,
    );
    inbound_tx
        .send(syn_ack)
        .await
        .expect("inbound accepts the syn-ack");

    let conn = tokio::time::timeout(StdDuration::from_secs(5), connect)
        .await
        .expect("the connect call should finish")
        .expect("the connect task should not panic")
        .expect("the connection should be established");

    drop(conn);

    let deadline = tokio::time::Instant::now() + StdDuration::from_secs(5);
    let mut saw_teardown = false;

    while let Ok(Some(pkt)) = tokio::time::timeout_at(deadline, outbound_rx.recv()).await {
        if let Some(seg) = parse_tcp(&pkt) {
            if seg.flags & 0x01 != 0 || seg.flags & 0x04 != 0 {
                saw_teardown = true;
                break;
            }
        }
    }

    assert!(
        saw_teardown,
        "the netstack never closed the socket after the app went away, so it leaks"
    );
}

fn quick_limits() -> TcpLimits {
    TcpLimits {
        connect: StdDuration::from_millis(300),
        keepalive: StdDuration::from_secs(60),
        orphan_linger: StdDuration::from_millis(300),
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_connect_nobody_answers_fails_instead_of_hanging() {
    let (_inbound_tx, inbound_rx) = mpsc::channel::<Vec<u8>>(64);
    let (outbound_tx, _outbound_rx) = mpsc::channel::<Vec<u8>>(256);
    let stack = spawn_with_limits(
        "198.18.0.1",
        "fc00::1",
        1400,
        inbound_rx,
        outbound_tx,
        quick_limits(),
    )
    .expect("netstack should start");

    let dst: SocketAddr = "93.184.216.34:80".parse().unwrap();
    let outcome = tokio::time::timeout(StdDuration::from_secs(5), stack.open_tcp(dst))
        .await
        .expect("a connect that is never answered must fail, not hang");

    match outcome {
        Ok(_) => panic!("nothing answered, so the connect cannot succeed"),
        Err(error) => assert!(error.to_string().contains("timed out"), "{error}"),
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn an_orphan_whose_far_end_never_closes_is_reset() {
    let local = Ipv4Addr::new(198, 18, 0, 1);
    let remote = Ipv4Addr::new(93, 184, 216, 34);
    let remote_port = 80u16;

    let (inbound_tx, inbound_rx) = mpsc::channel::<Vec<u8>>(64);
    let (outbound_tx, mut outbound_rx) = mpsc::channel::<Vec<u8>>(256);
    let stack = spawn_with_limits(
        "198.18.0.1",
        "fc00::1",
        1400,
        inbound_rx,
        outbound_tx,
        quick_limits(),
    )
    .expect("netstack should start");

    let dst = SocketAddr::new(IpAddr::V4(remote), remote_port);
    let connect = {
        let stack = stack.clone();
        tokio::spawn(async move { stack.open_tcp(dst).await })
    };

    let deadline = tokio::time::Instant::now() + StdDuration::from_secs(5);
    let (client_port, client_seq) = loop {
        let pkt = tokio::time::timeout_at(deadline, outbound_rx.recv())
            .await
            .expect("the netstack should emit a syn")
            .expect("outbound channel stays open");
        if let Some(seg) = parse_tcp(&pkt) {
            if seg.dst_port == remote_port && seg.flags & 0x02 != 0 && seg.flags & 0x10 == 0 {
                break (seg.src_port, seg.seq);
            }
        }
    };

    let syn_ack = build_tcp(
        (remote, remote_port),
        (local, client_port),
        5000,
        client_seq.wrapping_add(1),
        0x12,
    );
    inbound_tx
        .send(syn_ack)
        .await
        .expect("inbound accepts the syn-ack");

    let conn = tokio::time::timeout(StdDuration::from_secs(5), connect)
        .await
        .expect("the connect call should finish")
        .expect("the connect task should not panic")
        .expect("the connection should be established");
    drop(conn);

    let fin_seq = loop {
        let pkt = tokio::time::timeout_at(deadline, outbound_rx.recv())
            .await
            .expect("the netstack should send a fin")
            .expect("outbound channel stays open");
        if let Some(seg) = parse_tcp(&pkt) {
            if seg.flags & 0x01 != 0 {
                break seg.seq;
            }
        }
    };
    let ack = build_tcp(
        (remote, remote_port),
        (local, client_port),
        5001,
        fin_seq.wrapping_add(1),
        0x10,
    );
    inbound_tx.send(ack).await.expect("inbound accepts the ack");

    let mut saw_reset = false;
    while let Ok(Some(pkt)) = tokio::time::timeout_at(deadline, outbound_rx.recv()).await {
        if let Some(seg) = parse_tcp(&pkt) {
            if seg.flags & 0x04 != 0 {
                saw_reset = true;
                break;
            }
        }
    }
    assert!(
        saw_reset,
        "an orphaned connection whose far end never closes must be reset, not kept"
    );
}

#[tokio::test]
async fn an_address_assigned_for_one_family_keeps_the_other() {
    let mut device = StackDevice::new(1400);
    let mut iface = Interface::new(
        Config::new(HardwareAddress::Ip),
        &mut device,
        Instant::now(),
    );
    apply_addrs(
        &mut iface,
        Some(("172.16.0.2".parse().unwrap(), 32)),
        Some(("2606:4700:110:8a36::1".parse().unwrap(), 128)),
    );
    let mut stack = NetStack {
        iface,
        device,
        sockets: SocketSet::new(Vec::new()),
        tcp_conns: HashMap::new(),
        udp_conns: HashMap::new(),
        next_id: 0,
        next_port: 40000,
        data_in_tx: mpsc::channel(1).0,
        tcp_limits: TcpLimits::from_env(),
    };

    handle_cmd(
        &mut stack,
        Cmd::SetAddrs {
            v4: Some(("172.16.0.9".parse().unwrap(), 32)),
            v6: None,
        },
    );
    handle_cmd(
        &mut stack,
        Cmd::SetAddrs {
            v4: None,
            v6: Some(("2606:4700:110:8a36::9".parse().unwrap(), 128)),
        },
    );

    let (v4, v6) = current_addrs(&stack.iface);
    assert_eq!(v4.map(|(ip, _)| ip), Some("172.16.0.9".parse().unwrap()));
    assert_eq!(
        v6.map(|(ip, _)| ip),
        Some("2606:4700:110:8a36::9".parse().unwrap())
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn flush_tx_drops_instead_of_blocking_when_outbound_is_full() {
    let (outbound_tx, outbound_rx) = mpsc::channel::<Vec<u8>>(2);
    let mut stack = NetStack {
        iface: {
            let mut device = StackDevice::new(1400);
            let config = Config::new(HardwareAddress::Ip);
            Interface::new(config, &mut device, Instant::now())
        },
        device: StackDevice::new(1400),
        sockets: SocketSet::new(Vec::new()),
        tcp_conns: HashMap::new(),
        udp_conns: HashMap::new(),
        next_id: 0,
        next_port: 40000,
        data_in_tx: mpsc::channel(1).0,
        tcp_limits: TcpLimits::from_env(),
    };

    for _ in 0..10 {
        stack.device.tx.push_back(vec![1, 2, 3]);
    }

    let dropped = flush_tx(&mut stack, &outbound_tx);

    assert!(stack.device.tx.is_empty(), "the tx queue must be drained");
    assert_eq!(
        dropped, 8,
        "everything past the channel capacity is dropped"
    );
    assert_eq!(outbound_rx.len(), 2, "the channel keeps what fits");
}
