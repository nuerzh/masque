use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::Arc;
use std::time::{Duration, Instant};

use futures::stream::StreamExt;
use rand::RngExt;

use crate::error::{AetherError, Result};
use crate::utils::noize::NoizeConfig;
use crate::transport::warp::masque::quic;

mod carrier;
mod catalog;
mod cidr;
mod config;
mod memory;
mod plan;
use memory::RangeMemory;
mod settings;
pub use carrier::Carrier;
pub use catalog::*;
pub use config::ScanConfig;
pub use settings::*;
mod quick;
mod live;
mod rounds;
use cidr::*;
use live::*;
use quick::*;
use rounds::*;
pub use live::ScanEvent;
pub use rounds::{parse_scan_rounds, MAX_SCAN_ROUNDS};

/// The ports a MASQUE scan tries by default. 443 is one of them but comes last: on many
/// networks UDP 443 is the port QUIC gets throttled or dropped on first, so it no longer leads
/// the sweep. The port check ranks every port on what answers, and 443 only sweeps the ranges
/// when it answers more seed gateways than another port (it loses a tie). `--scan-ports`
/// (AETHER_SCAN_PORTS) names another set.
pub const MASQUE_PORTS: &[u16] = &[500, 1701, 4500, 4443, 8443, 8095, 443];

/// The port that loses a tie in the port check while the default ports are in use (see
/// `MASQUE_PORTS`); with --scan-ports every port is ranked alike.
const TIE_LOSER_PORT: u16 = 443;

fn tie_loser() -> Option<u16> {
    let raw = crate::config::settings::var("AETHER_SCAN_PORTS").unwrap_or_default();
    (masque_ports_of(&raw) == MASQUE_PORTS).then_some(TIE_LOSER_PORT)
}

/// The ports the MASQUE scan tries: those --scan-ports (AETHER_SCAN_PORTS) names, comma
/// separated, in its order, or `MASQUE_PORTS` when it names none (or `default`).
pub fn masque_ports() -> Vec<u16> {
    masque_ports_of(&crate::config::settings::var("AETHER_SCAN_PORTS").unwrap_or_default())
}

pub fn masque_ports_of(raw: &str) -> Vec<u16> {
    let mut out: Vec<u16> = Vec::new();
    for part in raw.split(|c: char| c == ',' || c.is_whitespace()) {
        if let Ok(port) = part.trim().parse::<u16>() {
            if port != 0 && !out.contains(&port) {
                out.push(port);
            }
        }
    }
    if out.is_empty() {
        MASQUE_PORTS.to_vec()
    } else {
        out
    }
}

/// What the scan keeps of the gateways that passed the full check: the fastest one within the
/// RTT ceiling, how many were within it (what counts toward the target), and the fastest one
/// over it, used only when nothing came in under the ceiling.
#[derive(Debug, Default)]
struct Picker {
    max_rtt: Option<Duration>,
    best: Option<ProbeResult>,
    counted: usize,
    fastest_over: Option<ProbeResult>,
    over: usize,
}

/// What `Picker::pick` chose.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Pick {
    /// The fastest gateway within the ceiling (or the fastest of all, with no ceiling).
    Within(ProbeResult),
    /// Nothing was within the ceiling: the fastest gateway found, over it.
    Fallback(ProbeResult),
}

impl Picker {
    fn new(max_rtt: Option<Duration>) -> Self {
        Picker { max_rtt, ..Default::default() }
    }

    /// Take a gateway that passed the full check; true when it counts toward the target.
    fn offer(&mut self, pr: ProbeResult) -> bool {
        let faster = |cur: Option<ProbeResult>| match cur {
            Some(cur) if cur.rtt <= pr.rtt => cur,
            _ => pr,
        };
        if self.max_rtt.is_some_and(|cap| pr.rtt > cap) {
            self.fastest_over = Some(faster(self.fastest_over));
            self.over += 1;
            return false;
        }
        self.best = Some(faster(self.best));
        self.counted += 1;
        true
    }

    fn any(&self) -> bool {
        self.best.is_some() || self.fastest_over.is_some()
    }

    fn pick(&self) -> Option<Pick> {
        match (self.best, self.fastest_over) {
            (Some(pr), _) => Some(Pick::Within(pr)),
            (None, Some(pr)) => Some(Pick::Fallback(pr)),
            (None, None) => None,
        }
    }
}




pub fn zero_trust_mode() -> bool {
    crate::config::settings::var("AETHER_TEAM")
        .map(|value| !value.trim().is_empty())
        .unwrap_or(false)
}

pub fn prioritize(all: &[&'static str], first: &[&'static str]) -> Vec<&'static str> {
    if !zero_trust_mode() {
        return all.to_vec();
    }

    let mut out: Vec<&'static str> = Vec::with_capacity(all.len());
    for entry in first {
        if all.contains(entry) {
            out.push(entry);
        }
    }
    for entry in all {
        if !out.contains(entry) {
            out.push(entry);
        }
    }
    out
}

pub fn masque_cidrs_v4() -> Vec<&'static str> {
    prioritize(catalog::current().cidrs_v4, MASQUE_ZT_CIDRS_V4)
}

pub fn masque_cidrs_v6() -> Vec<&'static str> {
    prioritize(catalog::current().cidrs_v6, MASQUE_ZT_CIDRS_V6)
}


#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ProbeResult {
    pub ip: IpAddr,
    pub port: u16,
    pub rtt: Duration,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IpScan {
    V4,
    V6,
    Both,
}

impl IpScan {
    pub fn parse(s: &str) -> IpScan {
        match s.trim().to_lowercase().as_str() {
            "6" | "v6" | "ipv6" => IpScan::V6,
            "both" | "all" | "dual" => IpScan::Both,
            _ => IpScan::V4,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            IpScan::V4 => "ipv4",
            IpScan::V6 => "ipv6",
            IpScan::Both => "dual-stack",
        }
    }

    pub fn want_v4(&self) -> bool {
        matches!(self, IpScan::V4 | IpScan::Both)
    }

    pub fn want_v6(&self) -> bool {
        matches!(self, IpScan::V6 | IpScan::Both)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScanMode {
    Turbo,
    Balanced,
    Thorough,
    Verified,
    Ironclad,
}

impl ScanMode {
    pub fn parse(s: &str) -> ScanMode {
        match s.trim().to_lowercase().as_str() {
            "turbo" | "fast" => ScanMode::Turbo,
            "thorough" | "deep" | "pro" => ScanMode::Thorough,
            "verified" | "proven" | "stealth" | "quiet" => ScanMode::Verified,
            "ironclad" | "real" | "verify" | "guaranteed" => ScanMode::Ironclad,
            _ => ScanMode::Balanced,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            ScanMode::Turbo => "turbo",
            ScanMode::Balanced => "balanced",
            ScanMode::Thorough => "thorough",
            ScanMode::Verified => "verified",
            ScanMode::Ironclad => "ironclad",
        }
    }

    fn strategy(&self) -> Strategy {
        match self {
            ScanMode::Turbo => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(45),
                quiet_after_first: Duration::from_secs(0),
                target_successes: 1,
                early_exit_first: true,
                full_subnet: false,
                sample_per_cidr: 64,
            },
            ScanMode::Balanced => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(120),
                quiet_after_first: Duration::from_secs(20),
                target_successes: 6,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
            ScanMode::Thorough => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(10000),
                overall_deadline: Duration::from_secs(300),
                quiet_after_first: Duration::from_secs(30),
                target_successes: 0,
                early_exit_first: false,
                full_subnet: true,
                sample_per_cidr: 0,
            },
            ScanMode::Verified => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(5000),
                overall_deadline: Duration::from_secs(60),
                quiet_after_first: Duration::from_secs(8),
                target_successes: 4,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 48,
            },
            ScanMode::Ironclad => Strategy {
                concurrency: 4,
                per_probe_timeout: Duration::from_millis(15000),
                overall_deadline: Duration::from_secs(180),
                quiet_after_first: Duration::from_secs(15),
                target_successes: 3,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
        }
    }
}

const IRONCLAD_TCPING_TIMEOUT: Duration = Duration::from_secs(10);

struct Strategy {
    concurrency: usize,
    per_probe_timeout: Duration,
    overall_deadline: Duration,
    quiet_after_first: Duration,
    target_successes: usize,
    early_exit_first: bool,
    full_subnet: bool,
    sample_per_cidr: usize,
}

#[derive(Clone)]
pub struct MasqueProbe {
    pub sni: String,
    pub authority: String,
    pub path: String,
    pub cert_pem: Arc<[u8]>,
    pub key_pem: Arc<[u8]>,
    pub noize: NoizeConfig,
    pub ports: Vec<u16>,
    pub ip: IpScan,
    pub local_ipv4: Ipv4Addr,
    /// The scan's settings, read once when the probe is made (see `ScanConfig`).
    pub cfg: ScanConfig,
}

pub async fn host_has_ipv6() -> bool {
    match crate::utils::egress::udp_bind(crate::utils::egress::WILDCARD_V6) {
        Ok(sock) => sock.connect("[2606:4700:d0::a29f:c001]:443").await.is_ok(),
        Err(_) => false,
    }
}

/// The port the ranges are swept on (one, see `SWEEP_PORTS`): the best that answered the port
/// check (`alive`, ranked with 443 losing a tie), or the first scan port when none did or there
/// was no port check.
fn primary_ports(alive: &[u16], ports: &[u16]) -> Vec<u16> {
    if alive.is_empty() {
        vec![ports.first().copied().unwrap_or(MASQUE_PORTS[0])]
    } else {
        alive.iter().copied().take(SWEEP_PORTS).collect()
    }
}

/// What a scan settles before it probes: the strategy of its mode, the IP family it can use,
/// the ports and what the port check found on them.
struct Prepared {
    st: Strategy,
    ip: IpScan,
    ports: Vec<u16>,
    alive: Vec<u16>,
    sweep: Vec<u16>,
    prefilter: bool,
    carrier: Carrier,
    max_rtt: Option<Duration>,
    rounds: u32,
}

async fn prepare(probe: &MasqueProbe, mode: ScanMode, avoid: &HashSet<IpAddr>, live: bool) -> Result<Prepared> {
    let mut st = mode.strategy();
    st.concurrency = crate::utils::sysprofile::cap_concurrency(st.concurrency);
    let has_v6 = !probe.ip.want_v6() || host_has_ipv6().await;
    let effective_ip = match plan::decide_ip(probe.ip, has_v6) {
        Some(ip) => {
            if ip != probe.ip {
                log::warn!("[scan] host has no IPv6 route; falling back to IPv4-only scan");
            }
            ip
        }
        None => {
            log::warn!("[scan] host has no IPv6 route; IPv6 scan needs native IPv6 connectivity");
            return Err(AetherError::NoCleanEndpoint);
        }
    };
    let ports: Vec<u16> = if probe.ports.is_empty() {
        MASQUE_PORTS.to_vec()
    } else {
        probe.ports.clone()
    };
    let carrier = Carrier::current();
    // The quick pass dials straight from this host; through an upstream proxy it would measure
    // the wrong path, so there the scan keeps to full handshakes.
    let prefilter = plan::decide_prefilter(
        &probe.cfg,
        crate::transport::warp::net::upstream::configured().is_some(),
    );
    // As upstream Aether: the ranges are swept on one port, the primary, and the seeds are tried
    // on every port. The primary is the best port of the port check (443 loses a tie there), or
    // the first scan port (500 by default, 443 comes last) when there is no port check.
    let alive = if prefilter {
        let alive = discover_ports(&ports, effective_ip, carrier, &probe.cfg, avoid).await;
        if alive.is_empty() {
            log::warn!(
                "[scan] no port answered the quick check on the seed gateways; sweeping {:?} with full handshakes",
                ports[0]
            );
        }
        alive
    } else {
        Vec::new()
    };
    let sweep_ports = primary_ports(&alive, &ports);
    if !avoid.is_empty() {
        log::info!(
            "[scan] leaving {} gateway(s) out of this scan for now",
            avoid.len()
        );
    }
    let max_rtt = max_rtt_for(mode, probe.cfg.max_rtt_ms);
    let rounds = rounds_for(mode, max_rtt, probe.cfg.scan_rounds, live);
    Ok(Prepared { st, ip: effective_ip, ports, alive, sweep: sweep_ports, prefilter, carrier, max_rtt, rounds })
}

/// The scan of a gateway, leaving out the addresses in `avoid` on every port: gateways a run gave
/// up on for a while. The whole scan runs before it picks (the --no-scan-switch behaviour).
pub async fn hunt_best_gateway_avoiding(
    probe: &MasqueProbe,
    mode: ScanMode,
    avoid: &HashSet<IpAddr>,
) -> Result<ProbeResult> {
    let p = prepare(probe, mode, avoid, false).await?;
    let st = &p.st;
    let timeout = st.per_probe_timeout;
    let carrier = p.carrier;
    let cfg = &probe.cfg;
    let max_rtt = p.max_rtt;
    let rounds = p.rounds;
    let ironclad = mode == ScanMode::Ironclad;
    let input = ScanInput {
        mode,
        st,
        ip: p.ip,
        ports: &p.ports,
        sweep: &p.sweep,
        alive: &p.alive,
        avoid,
        max_rtt,
        rounds,
        prefilter: p.prefilter,
    };
    // what the full checks learn is kept for the quick pass of the next round (and the next run)
    let memory = Arc::new(parking_lot::Mutex::new(RangeMemory::open(cfg)));
    let outcome = run_rounds(
        &input,
        |candidates| {
            let prior = memory.lock().prior();
            async move { quick_filter(&candidates, st, carrier, cfg, &prior, log::Level::Info).await }
        },
        |ip, port| {
            let memory = memory.clone();
            async move {
                let found = verify_one(probe, ip, port, timeout, ironclad).await;
                // written after every check, not only at the end: the background scan runs on
                // until it is stopped, and a stop must not lose what it has learned
                memory.lock().record(ip, port, found.is_some());
                memory.lock().save(cfg);
                found
            }
        },
    )
    .await;
    memory.lock().save(cfg);

    if let Some(pr) = outcome.first {
        return Ok(pr);
    }
    match outcome.pick {
        Some(Pick::Within(pr)) => {
            log::info!("[scan] best gateway {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
            Ok(pr)
        }
        Some(Pick::Fallback(pr)) => {
            log::warn!(
                "[scan] no gateway within max-rtt {:?} after {} of {} scan round(s) ({} answered, all slower); falling back to the fastest found {}:{} rtt={:?}",
                max_rtt.unwrap_or_default(),
                outcome.rounds_run,
                rounds,
                outcome.over,
                pr.ip,
                pr.port,
                pr.rtt
            );
            Ok(pr)
        }
        None => Err(AetherError::NoCleanEndpoint),
    }
}

/// A scan that goes on after the run started on a gateway (see `prober/live.rs`): what it
/// still has to say, and the task, which is stopped when this is dropped or the run stops.
pub struct BackgroundScan {
    events: tokio::sync::mpsc::UnboundedReceiver<ScanEvent>,
    task: tokio::task::JoinHandle<()>,
}

impl Drop for BackgroundScan {
    fn drop(&mut self) {
        self.task.abort();
    }
}

impl BackgroundScan {
    /// The next move to a faster gateway, `(from, to)`: when several are waiting, the latest
    /// (each is faster than the one before). `None` once the scan is over.
    pub async fn next_switch(&mut self) -> Option<(ProbeResult, ProbeResult)> {
        loop {
            let mut latest = match self.events.recv().await? {
                ScanEvent::Switch { from, to } => (from, to),
                ScanEvent::Start { .. } => continue,
            };
            while let Ok(ev) = self.events.try_recv() {
                if let ScanEvent::Switch { to, .. } = ev {
                    latest.1 = to;
                }
            }
            return Some(latest);
        }
    }

    /// Whether the scan task has ended.
    #[cfg(test)]
    pub fn finished(&self) -> bool {
        self.task.is_finished()
    }
}

/// Run `scan` as the background scan of the current run (`utils::shutdown`): the gateway to
/// start on, once `scan` announces one, and the scan that goes on. `Err` when the scan ended
/// with no gateway at all.
async fn start_background<F, Fut>(scan: F) -> Result<(ProbeResult, BackgroundScan)>
where
    F: FnOnce(tokio::sync::mpsc::UnboundedSender<ScanEvent>) -> Fut,
    Fut: std::future::Future<Output = ()> + Send + 'static,
{
    let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let task = crate::utils::shutdown::spawn(scan(tx));
    let mut bg = BackgroundScan { events: rx, task };
    loop {
        match bg.events.recv().await {
            Some(ScanEvent::Start { gateway, .. }) => return Ok((gateway, bg)),
            Some(ScanEvent::Switch { .. }) => continue,
            None => return Err(AetherError::NoCleanEndpoint),
        }
    }
}

/// The scan of a run: the gateway the tunnel starts on (the first whose full check is within
/// --max-rtt, or with no ceiling the first that passes; with none within it in the whole scan,
/// the fastest found once the scan is over), and the scan that goes on in the background over
/// every round, telling of each gateway under half the RTT of the one in use. With
/// `probe.scan_switch` off, the whole scan runs first and there is no background scan.
pub async fn hunt_gateway_live(
    probe: &MasqueProbe,
    mode: ScanMode,
    avoid: &HashSet<IpAddr>,
) -> Result<(ProbeResult, Option<BackgroundScan>)> {
    if !probe.cfg.scan_switch {
        return hunt_best_gateway_avoiding(probe, mode, avoid).await.map(|pr| (pr, None));
    }
    let probe = probe.clone();
    let avoid = avoid.clone();
    let (first, bg) = start_background(move |tx| async move {
        live_scan_task(probe, mode, avoid, None, tx).await;
    })
    .await?;
    Ok((first, Some(bg)))
}

/// The background scan of a run that already started on `in_use` (a remembered gateway and the
/// RTT measured for it just now): it announces only switches. `None` with --no-scan-switch.
pub fn scan_beside(
    probe: &MasqueProbe,
    mode: ScanMode,
    avoid: &HashSet<IpAddr>,
    in_use: ProbeResult,
) -> Option<BackgroundScan> {
    if !probe.cfg.scan_switch {
        return None;
    }
    let probe = probe.clone();
    let avoid = avoid.clone();
    let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
    let task = crate::utils::shutdown::spawn(async move {
        live_scan_task(probe, mode, avoid, Some(in_use), tx).await;
    });
    Some(BackgroundScan { events: rx, task })
}

/// The full check of the scan (the same check, timeout and RTT as `mode`'s scan) on each of
/// `peers` at once: those that passed, fastest first.
pub async fn measure_gateways(probe: &MasqueProbe, mode: ScanMode, peers: &[SocketAddr]) -> Vec<ProbeResult> {
    let timeout = mode.strategy().per_probe_timeout;
    let ironclad = mode == ScanMode::Ironclad;
    let mut passed: Vec<ProbeResult> = futures::future::join_all(
        peers.iter().map(|peer| verify_one(probe, peer.ip(), peer.port(), timeout, ironclad)),
    )
    .await
    .into_iter()
    .flatten()
    .collect();
    passed.sort_by_key(|pr| pr.rtt);
    passed
}

async fn live_scan_task(
    probe: MasqueProbe,
    mode: ScanMode,
    avoid: HashSet<IpAddr>,
    in_use: Option<ProbeResult>,
    tx: tokio::sync::mpsc::UnboundedSender<ScanEvent>,
) {
    let p = match prepare(&probe, mode, &avoid, true).await {
        Ok(p) => p,
        Err(e) => {
            log::warn!("[scan] {e}");
            return;
        }
    };
    let st = &p.st;
    let timeout = st.per_probe_timeout;
    let carrier = p.carrier;
    let cfg = &probe.cfg;
    let ironclad = mode == ScanMode::Ironclad;
    let input = ScanInput {
        mode,
        st,
        ip: p.ip,
        ports: &p.ports,
        sweep: &p.sweep,
        alive: &p.alive,
        avoid: &avoid,
        max_rtt: p.max_rtt,
        rounds: p.rounds,
        prefilter: p.prefilter,
    };
    let probe = &probe;
    let memory = Arc::new(parking_lot::Mutex::new(RangeMemory::open(cfg)));
    run_live(
        &input,
        in_use,
        |candidates| {
            let prior = memory.lock().prior();
            async move { quick_filter(&candidates, st, carrier, cfg, &prior, log::Level::Debug).await }
        },
        |ip, port| {
            let memory = memory.clone();
            async move {
                let found = verify_one(probe, ip, port, timeout, ironclad).await;
                // written after every check, not only at the end: the background scan runs on
                // until it is stopped, and a stop must not lose what it has learned
                memory.lock().record(ip, port, found.is_some());
                memory.lock().save(cfg);
                found
            }
        },
        |ev| {
            let _ = tx.send(ev);
        },
    )
    .await;
    memory.lock().save(cfg);
}

fn log_scan_end(picker: &Picker, quiet: bool) {
    if picker.any() {
        if quiet {
            log::info!("[scan] no new gateways recently, finalizing selection");
        } else {
            log::warn!("[scan] scan deadline reached");
        }
    } else {
        log::warn!("[scan] scan deadline reached with no gateway");
    }
}

/// `candidates` without the addresses in `avoid`, whatever their port.
fn leave_out(candidates: Vec<(IpAddr, u16)>, avoid: &HashSet<IpAddr>) -> Vec<(IpAddr, u16)> {
    candidates
        .into_iter()
        .filter(|(ip, _)| !avoid.contains(ip))
        .collect()
}

async fn verify_one(
    probe: &MasqueProbe,
    ip: IpAddr,
    port: u16,
    timeout: Duration,
    ironclad: bool,
) -> Option<ProbeResult> {
    if ironclad {
        let params = crate::transport::warp::tunnelping::MasquePingParams {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            noize: probe.noize.clone(),
            local_ipv4: probe.local_ipv4,
            local_ipv4_str: probe.local_ipv4.to_string(),
            local_ipv6_str: String::new(),
        };
        return match crate::transport::warp::tunnelping::masque_http_ping(&params, IRONCLAD_TCPING_TIMEOUT).await {
            Ok(rtt) => {
                log::info!(
                    "[scan] ironclad verified {ip}:{port} real http round trip rtt={:?}",
                    rtt
                );
                Some(ProbeResult { ip, port, rtt })
            }
            Err(e) => {
                log::trace!("[scan] ironclad {ip}:{port} failed real http check: {e}");
                None
            }
        };
    }

    if crate::transport::warp::masque::http2::enabled() {
        let cfg = crate::transport::warp::masque::http2::H2TunnelConfig {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            local_ipv4: probe.local_ipv4,
            quiet: true,
            pin_endpoint: true,
            expected_pins: crate::transport::warp::consts::MASQUE_PINS
                .iter()
                .map(|p| p.to_vec())
                .collect(),
        };
        return match crate::transport::warp::masque::http2::verify_h2(&cfg, timeout).await {
            Ok(rtt) => Some(ProbeResult { ip, port, rtt }),
            Err(e) => {
                log::trace!("[scan] h2 probe {ip}:{port} -> {e}");
                None
            }
        };
    }

    let vp = quic::VerifyParams {
        peer: SocketAddr::new(ip, port),
        sni: probe.sni.clone(),
        authority: probe.authority.clone(),
        path: probe.path.clone(),
        cert_pem: probe.cert_pem.to_vec(),
        key_pem: probe.key_pem.to_vec(),
        noize: probe.noize.clone(),
        timeout,
        local_ipv4: probe.local_ipv4,
    };

    match quic::verify_masque(&vp).await {
        Ok(rtt) => Some(ProbeResult { ip, port, rtt }),
        Err(e) => {
            log::trace!("[scan] probe {ip}:{port} -> {e}");
            None
        }
    }
}

/// The candidates of a single-round scan (the first round of any scan).
#[cfg(test)]
fn build_candidates(
    st: &Strategy,
    ports: &[u16],
    sweep: &[u16],
    ip: IpScan,
) -> Vec<(IpAddr, u16)> {
    build_round_candidates(&plan_round(st, 1, 1, sweep, &[], ports), ports, ip)
}

#[cfg(test)]
mod tests;
