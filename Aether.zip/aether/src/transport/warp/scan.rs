use super::prelude::*;
use super::*;
use prober::Carrier;

/// The gateway a scan found to start on, its RTT, and the scan that goes on in the background
/// (none with --no-scan-switch).
pub(crate) struct Hunted {
    pub(crate) peer: SocketAddr,
    pub(crate) rtt: std::time::Duration,
    pub(crate) background: Option<prober::BackgroundScan>,
}

/// What the scan of a MASQUE run checks gateways with.
fn masque_probe(identity: &account::Identity, ip: prober::IpScan) -> Result<prober::MasqueProbe> {
    let cfg = prober::ScanConfig::from_env();
    log::info!("[scan] settings: {}", cfg.describe());
    Ok(prober::MasqueProbe {
        sni: quic::masque_sni()?,
        authority: quic::default_authority().to_string(),
        path: quic::default_path().to_string(),
        cert_pem: std::sync::Arc::from(identity.cert_pem.clone()),
        key_pem: std::sync::Arc::from(identity.key_pem.clone()),
        noize: noize_config(),
        ports: prober::masque_ports(),
        ip,
        local_ipv4: parse_local_v4(&identity.ipv4),
        cfg,
    })
}

pub(crate) async fn hunt_masque_peer(
    identity: &account::Identity,
    mode_str: &str,
    ip: prober::IpScan,
    avoid: &HashSet<IpAddr>,
) -> Result<Hunted> {
    log::info!(
        "[scan] hunting for a working MASQUE gateway (deep connect-ip + data-plane verification)"
    );
    let mode = prober::ScanMode::parse(mode_str);
    let probe = masque_probe(identity, ip)?;

    let (best, background) = prober::hunt_gateway_live(&probe, mode, avoid).await?;
    log::info!(
        "[scan] selected MASQUE gateway {}:{} (rtt {:?})",
        best.ip,
        best.port,
        best.rtt
    );
    Ok(Hunted {
        peer: SocketAddr::new(best.ip, best.port),
        rtt: best.rtt,
        background,
    })
}

/// Whether a remembered gateway is good enough to skip the scan: under half of --max-rtt (never
/// with no ceiling).
fn good_enough(rtt: std::time::Duration, cap: Option<std::time::Duration>) -> bool {
    cap.is_some_and(|cap| rtt < cap / 2)
}

/// Start on a remembered gateway without a scan. The best of the RTT history (`ranked`, fastest
/// first by each gateway's newest measurement) is checked first, alone; under half of --max-rtt
/// it starts and nothing else runs. Otherwise the other gateways of the history and the recent
/// ones (`ring`) get the check at once and the fastest of all that passed starts; under half of
/// --max-rtt there is no scan either, else the scan goes on in the background from it (none with
/// --no-scan-switch). The check is the scan's own full check, with its timeout. Every measurement
/// but the one started on (saved with the connection) goes into the history of `lastconn_path`,
/// and gateways that failed leave it. `None` when nothing passes.
#[allow(clippy::too_many_arguments)]
pub(crate) async fn start_on_remembered(
    identity: &account::Identity,
    mode_str: &str,
    ip: prober::IpScan,
    avoid: &HashSet<IpAddr>,
    ranked: &[(SocketAddr, u64)],
    ring: &[SocketAddr],
    lastconn_path: &str,
    carrier: &str,
) -> Option<Hunted> {
    let mode = prober::ScanMode::parse(mode_str);
    let probe = match masque_probe(identity, ip) {
        Ok(p) => p,
        Err(e) => {
            log::warn!("[scan] {e}");
            return None;
        }
    };
    let cap = prober::max_rtt_for(mode, probe.cfg.max_rtt_ms);
    let half = cap.map_or_else(|| "no max-rtt".to_string(), |c| format!("{}ms", (c / 2).as_millis()));
    let start = |pr: prober::ProbeResult, background: Option<prober::BackgroundScan>| Hunted {
        peer: SocketAddr::new(pr.ip, pr.port),
        rtt: pr.rtt,
        background,
    };
    let addr = |pr: &prober::ProbeResult| SocketAddr::new(pr.ip, pr.port);
    // into the history: every measurement but the one started on, which is saved with the
    // connection
    let keep = |passed: &[prober::ProbeResult], failed: &[SocketAddr], chosen: Option<SocketAddr>| {
        let measured: Vec<(SocketAddr, std::time::Duration)> = passed
            .iter()
            .filter(|pr| Some(addr(pr)) != chosen)
            .map(|pr| (addr(pr), pr.rtt))
            .collect();
        if !measured.is_empty() {
            lastconn::record(lastconn_path, carrier, &measured);
        }
        if !failed.is_empty() {
            lastconn::forget(lastconn_path, failed);
        }
    };

    let best = ranked.first().copied();
    let mut passed = Vec::new();
    let mut failed = Vec::new();
    if let Some((peer, saved)) = best {
        log::info!(
            "[masque] checking the best remembered gateway {peer} first ({} mode, last measured {saved}ms)",
            mode.label()
        );
        match prober::measure_gateways(&probe, mode, &[peer]).await.first().copied() {
            Some(pr) if good_enough(pr.rtt, cap) => {
                log::info!(
                    "[masque] best remembered gateway {peer} rtt={:?}, under half of max-rtt ({half}); starting on it, no scan",
                    pr.rtt
                );
                return Some(start(pr, None));
            }
            Some(pr) => {
                log::info!(
                    "[masque] best remembered gateway {peer} rtt={:?}, not under half of max-rtt ({half}); checking the other remembered gateways",
                    pr.rtt
                );
                passed.push(pr);
            }
            None => {
                log::info!("[masque] best remembered gateway {peer} did not pass; dropping it from the history");
                failed.push(peer);
            }
        }
    }

    let mut rest: Vec<SocketAddr> = Vec::new();
    for peer in ranked.iter().skip(1).map(|(p, _)| *p).chain(ring.iter().copied()) {
        if Some(peer) != best.map(|(b, _)| b) && !rest.contains(&peer) {
            rest.push(peer);
        }
    }
    if !rest.is_empty() {
        log::info!(
            "[masque] measuring {} remembered gateway(s) with the scan's full check ({} mode): {}",
            rest.len(),
            mode.label(),
            rest.iter().map(|p| p.to_string()).collect::<Vec<_>>().join(", ")
        );
        let more = prober::measure_gateways(&probe, mode, &rest).await;
        for pr in &more {
            log::info!("[masque] remembered gateway {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
        }
        if more.len() < rest.len() {
            log::info!("[masque] {} remembered gateway(s) did not pass", rest.len() - more.len());
        }
        failed.extend(rest.iter().filter(|p| !more.iter().any(|pr| addr(pr) == **p)));
        passed.extend(more);
    }
    passed.sort_by_key(|pr| pr.rtt);
    let Some(best) = passed.first().copied() else {
        keep(&passed, &failed, None);
        return None;
    };
    let peer = addr(&best);
    keep(&passed, &failed, Some(peer));
    if good_enough(best.rtt, cap) {
        log::info!(
            "[masque] starting on remembered gateway {peer} rtt={:?}, under half of max-rtt ({half}); no scan",
            best.rtt
        );
        return Some(start(best, None));
    }
    log::info!(
        "[masque] starting on remembered gateway {peer} rtt={:?}; scanning in the background for one under half of it",
        best.rtt
    );
    if let Some(cap) = cap {
        if best.rtt > cap {
            log::warn!(
                "[masque] remembered gateway {peer} rtt={:?} is over max-rtt {cap:?}; moving to the first gateway within it the scan finds",
                best.rtt
            );
        }
    }
    let background = prober::scan_beside(&probe, mode, avoid, best);
    Some(start(best, background))
}

/// Whether `peer` serves MASQUE, by a quick check on the carrier the session uses.
pub(crate) async fn quick_verify_masque_peer(
    identity: &account::Identity,
    peer: SocketAddr,
) -> bool {
    // The core checks the name as it starts; a job of the library given no domain name fails
    // every check here.
    let sni = match quic::masque_sni() {
        Ok(sni) => sni,
        Err(e) => {
            log::warn!("[scan] {e}");
            return false;
        }
    };
    match Carrier::current() {
        Carrier::Http2 => verify_over_http2(identity, peer, sni).await,
        Carrier::Quic => verify_over_quic(identity, peer, sni).await,
    }
}

async fn verify_over_http2(identity: &account::Identity, peer: SocketAddr, sni: String) -> bool {
    let cfg = masque_h2::H2TunnelConfig {
        peer: masque_h2::h2_peer(peer),
        sni,
        authority: quic::default_authority().to_string(),
        cert_pem: identity.cert_pem.clone(),
        key_pem: identity.key_pem.clone(),
        local_ipv4: parse_local_v4(&identity.ipv4),
        quiet: true,
        pin_endpoint: true,
        expected_pins: consts::MASQUE_PINS.iter().map(|p| p.to_vec()).collect(),
    };
    masque_h2::verify_h2(&cfg, std::time::Duration::from_secs(5)).await.is_ok()
}

async fn verify_over_quic(identity: &account::Identity, peer: SocketAddr, sni: String) -> bool {
    let vp = quic::VerifyParams {
        peer,
        sni,
        authority: quic::default_authority().to_string(),
        path: quic::default_path().to_string(),
        cert_pem: identity.cert_pem.clone(),
        key_pem: identity.key_pem.clone(),
        noize: noize_config(),
        timeout: std::time::Duration::from_secs(5),
        local_ipv4: parse_local_v4(&identity.ipv4),
    };
    quic::verify_masque(&vp).await.is_ok()
}

#[cfg(test)]
mod tests {
    use super::good_enough;
    use std::time::Duration;

    #[test]
    fn a_remembered_gateway_skips_the_scan_only_under_half_of_max_rtt() {
        let cap = Some(Duration::from_millis(1000));
        assert!(good_enough(Duration::from_millis(499), cap));
        assert!(!good_enough(Duration::from_millis(500), cap), "exactly half is not under half");
        assert!(!good_enough(Duration::from_millis(10), None), "no ceiling: always scan on");
    }
}
