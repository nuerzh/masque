use super::*;

/// Cloudflare's key of cloudflare-ech.com on 2026-10-01.
const CLOUDFLARE_ECH: &str =
    "AEX+DQBBrwAgACCbK1mYDYFz/BAn6S5t+Q/v+Oej3eFNxtPWgz50fNnFPAAEAAEAAQASY2xvdWRmbGFyZS1lY2guY29tAAA=";

/// Why `option` found no key, from the error it ends with, which says NO_ECH_KEY first.
fn no_key_reason(option: &EchOption, outcome: Result<Option<Vec<u8>>>) -> String {
    match outcome {
        Err(AetherError::Ech(message)) => {
            let reason = message
                .strip_prefix(NO_ECH_KEY)
                .and_then(|rest| rest.strip_prefix(option.purpose))
                .expect("the core's word for going without an ECH key");
            assert!(reason.ends_with(option.refusal), "{message}");
            reason.to_string()
        }
        other => panic!("it went on: {other:?}"),
    }
}

#[tokio::test]
async fn a_key_asked_for_without_one_to_offer_goes_no_further() {
    let key = decode_ech_config_list(CLOUDFLARE_ECH).expect("base64");
    let unused = || async { panic!("looked up without auto") };
    let silent = || async {
        Err(AetherError::Ech(
            "udp://1.1.1.1:53 did not answer for cloudflare-ech.com".into(),
        ))
    };
    for option in [&API_ECH_OPTION] {
        assert_eq!(ech_key(option, None, unused).await.ok(), Some(None));
        assert_eq!(ech_key(option, Some(""), unused).await.ok(), Some(None));
        assert_eq!(
            ech_key(option, Some(CLOUDFLARE_ECH), unused).await.ok(),
            Some(Some(key.clone()))
        );
        let found = key.clone();
        assert_eq!(
            ech_key(option, Some("AUTO"), || async { Ok(found) })
                .await
                .ok(),
            Some(Some(key.clone()))
        );
        // Spaces around auto are no key in base64; spaces alone still ask for a key.
        let found = key.clone();
        assert_eq!(
            ech_key(option, Some(" auto "), || async { Ok(found) })
                .await
                .ok(),
            Some(Some(key.clone()))
        );
        no_key_reason(option, ech_key(option, Some("  "), unused).await);

        let unanswered = no_key_reason(option, ech_key(option, Some("auto"), silent).await);
        assert!(unanswered.contains("did not answer"), "{unanswered}");

        // BoringSSL would take this list and offer nothing from it: its only config is of
        // another version.
        let unusable = vec![0, 6, 0xfe, 0x0c, 0, 2, 0, 0];
        let passed_over = no_key_reason(
            option,
            ech_key(option, Some("auto"), || async { Ok(unusable) }).await,
        );
        assert!(passed_over.contains("cannot be offered"), "{passed_over}");

        let typo = no_key_reason(option, ech_key(option, Some("AEX+DQ="), unused).await);
        let named = format!("the {} value is not base64", option.flag);
        assert!(typo.contains(&named), "{typo}");
    }

    // Word for word, as an app that runs the core reads them.
    let said = |outcome: Result<Option<Vec<u8>>>| outcome.err().map(|e| e.to_string());
    assert_eq!(
        said(ech_key(&API_ECH_OPTION, Some("auto"), silent).await).as_deref(),
        Some(
            "ech: ECH is on but there is no ECH key to offer for the WARP API (udp://1.1.1.1:53 \
             did not answer for cloudflare-ech.com); not asking it rather than send its name in \
             the clear"
        )
    );
}

#[tokio::test]
async fn the_fingerprint_is_chromes_with_what_the_options_change() {
    let _options = hold_options().await;
    assert_eq!(Fingerprint::configured(), Fingerprint::default());
    assert_eq!(
        Fingerprint::default(),
        Fingerprint {
            ciphers: None,
            groups: "P-256:X25519:P-384".to_string(),
            grease: true,
        }
    );
    assert!(check_tls_options().is_ok());

    crate::config::settings::decide("AETHER_TLS_CIPHERS", " ECDHE-RSA-AES128-GCM-SHA256 ");
    crate::config::settings::decide("AETHER_TLS_GROUPS", "X25519:P-256");
    for (value, greased) in [("1", false), ("on", false), ("TRUE", false), ("0", true)] {
        crate::config::settings::decide("AETHER_DISABLE_GREASE", value);
        assert_eq!(
            Fingerprint::configured(),
            Fingerprint {
                ciphers: Some("ECDHE-RSA-AES128-GCM-SHA256".to_string()),
                groups: "X25519:P-256".to_string(),
                grease: greased,
            },
            "{value}"
        );
    }
    assert!(check_tls_options().is_ok());

    crate::config::settings::decide("AETHER_TLS_GROUPS", "X25519:P-999");
    let refused = check_tls_options().expect_err("a group BoringSSL does not know");
    assert!(
        refused.to_string().starts_with("tls: tls.groups: "),
        "{refused}"
    );
    crate::config::settings::decide("AETHER_TLS_GROUPS", "X25519");
    crate::config::settings::decide(
        "AETHER_TLS_CIPHERS",
        "ECDHE-RSA-AES128-GCM-SHA256:NO-SUCH-SUITE",
    );
    let refused = check_tls_options().expect_err("a suite BoringSSL does not know");
    assert!(
        refused.to_string().starts_with("tls: tls.ciphers: "),
        "{refused}"
    );
}

/// The ClientHello of `fingerprint`, offering HTTP/2, as a server on this machine reads it.
async fn hello_of(fingerprint: &Fingerprint) -> client_hello::ClientHello {
    let (server, hello) = client_hello::catch().await;
    let mut builder = boring::ssl::SslConnector::builder(SslMethod::tls()).expect("tls");
    fingerprint
        .apply(&mut builder, b"\x02h2")
        .expect("the fingerprint");
    let config = builder.build().configure().expect("a configuration");
    let tcp = tokio::net::TcpStream::connect(server)
        .await
        .expect("a connection");
    assert!(
        tokio_boring::connect(config, "fingerprint.example.test", tcp)
            .await
            .is_err()
    );
    hello.await.expect("the ClientHello")
}

#[tokio::test]
async fn the_client_hello_carries_the_fingerprint() {
    let chrome = hello_of(&Fingerprint::default()).await;
    assert!(chrome.has_grease());
    assert!(chrome.has_grease_extension());
    assert_eq!(chrome.versions(), [0x0304, 0x0303]);
    assert_eq!(chrome.groups(), [0x0017, 0x001d, 0x0018]);
    assert_eq!(chrome.key_shares(), [0x0017]);
    assert_eq!(chrome.alpn(), [b"h2".to_vec()]);
    assert_eq!(
        chrome.server_name().as_deref(),
        Some("fingerprint.example.test")
    );
    // Signed certificate timestamps and OCSP asked for, as Chrome asks.
    assert!(chrome.has_extension(18) && chrome.has_extension(5));
    // Chrome's TLS 1.2 suites, in the order Chrome's rule gets on this machine.
    assert_eq!(chrome.tls12_suites(), client_hello::chrome_tls12_suites());
    let mut suites = chrome.tls12_suites();
    suites.sort_unstable();
    assert_eq!(
        suites,
        [
            0x002f, 0x0035, 0x009c, 0x009d, 0xc013, 0xc014, 0xc02b, 0xc02c, 0xc02f, 0xc030,
            0xcca8, 0xcca9
        ]
    );

    let plain = Fingerprint {
        grease: false,
        ..Fingerprint::default()
    };
    let ungreased = hello_of(&plain).await;
    assert!(!ungreased.has_grease());
    assert!(!ungreased.has_grease_extension());
    assert_eq!(ungreased.groups(), chrome.groups());

    let changed = hello_of(&Fingerprint {
        ciphers: Some("ECDHE-ECDSA-CHACHA20-POLY1305:AES256-SHA".to_string()),
        groups: "X25519:P-384".to_string(),
        grease: false,
    })
    .await;
    assert_eq!(changed.tls12_suites(), [0xcca9, 0x0035]);
    assert_eq!(changed.groups(), [0x001d, 0x0018]);
    assert_eq!(changed.key_shares(), [0x001d]);

    // The extensions go in a new order on each handshake, as Chrome's do; without GREASE,
    // whose values change on each handshake too, only the order can differ.
    let mut orders = std::collections::HashSet::new();
    for _ in 0..4 {
        orders.insert(hello_of(&plain).await.extension_types());
    }
    assert!(orders.len() > 1, "{orders:?}");
}

/// An ECHConfig: `version`, config id 7, the KEM `kem` with a key of `key_len` bytes, the
/// cipher suites `suites` as (KDF, AEAD), the public name `name`, and `extensions` as they
/// go on the wire.
fn config(
    version: u16,
    kem: u16,
    key_len: usize,
    suites: &[(u16, u16)],
    name: &str,
    extensions: &[u8],
) -> Vec<u8> {
    let mut contents = vec![7];
    contents.extend_from_slice(&kem.to_be_bytes());
    contents.extend_from_slice(&(key_len as u16).to_be_bytes());
    contents.extend(std::iter::repeat_n(0x42, key_len));
    contents.extend_from_slice(&((suites.len() * 4) as u16).to_be_bytes());
    for (kdf, aead) in suites {
        contents.extend_from_slice(&kdf.to_be_bytes());
        contents.extend_from_slice(&aead.to_be_bytes());
    }
    contents.push(0);
    contents.push(name.len() as u8);
    contents.extend_from_slice(name.as_bytes());
    contents.extend_from_slice(&(extensions.len() as u16).to_be_bytes());
    contents.extend_from_slice(extensions);
    let mut config = version.to_be_bytes().to_vec();
    config.extend_from_slice(&(contents.len() as u16).to_be_bytes());
    config.extend(contents);
    config
}

fn list(configs: &[Vec<u8>]) -> Vec<u8> {
    let body = configs.concat();
    let mut list = (body.len() as u16).to_be_bytes().to_vec();
    list.extend(body);
    list
}

/// A config like Cloudflare's: X25519, HKDF-SHA256 with AES-128-GCM.
fn offered(name: &str) -> Vec<u8> {
    config(0xfe0d, 0x0020, 32, &[(1, 1)], name, &[])
}

#[test]
fn cloudflares_key_is_one_boringssl_offers() {
    // Cloudflare's key of cloudflare-ech.com on 2026-10-01.
    let key = decode_ech_config_list(
        "AEX+DQBBrwAgACCbK1mYDYFz/BAn6S5t+Q/v+Oej3eFNxtPWgz50fNnFPAAEAAEAAQASY2xvdWRmbGFyZS1lY2guY29tAAA=",
    )
    .expect("base64");
    assert_eq!(check_ech_config_list(&key), Ok(()));
    // The same fields as built here, the key aside.
    let mut built = list(&[offered("cloudflare-ech.com")]);
    built[2 + 2 + 2 + 1 + 2 + 2..][..32].copy_from_slice(&key[11..43]);
    built[6] = key[6];
    assert_eq!(built, key);
}

#[test]
fn a_key_boringssl_would_pass_over_is_turned_down() {
    // Each parses, so BoringSSL would take it, offer nothing, and send the name in the clear.
    let passed_over = [
        config(0xfe0c, 0x0020, 32, &[(1, 1)], "cloudflare-ech.com", &[]),
        // P-256, its key as long as an X25519 one so that only the KEM tells them apart.
        config(0xfe0d, 0x0010, 32, &[(1, 1)], "cloudflare-ech.com", &[]),
        config(0xfe0d, 0x0020, 32, &[(2, 1)], "cloudflare-ech.com", &[]),
        config(0xfe0d, 0x0020, 32, &[(1, 4)], "cloudflare-ech.com", &[]),
        config(
            0xfe0d,
            0x0020,
            32,
            &[(1, 1)],
            "cloudflare-ech.com",
            &[0x80, 1, 0, 0],
        ),
        offered("192.0.2.1"),
        offered("example.0x1F"),
        offered("-example.com"),
        offered("example-.com"),
        offered("example..com"),
        offered("example.com."),
        offered("exa_mple.com"),
        offered(&"a".repeat(64)),
    ];
    for config in passed_over {
        let list = list(&[config]);
        assert!(check_ech_config_list(&list).is_err(), "{list:02x?}");
        assert!(usable_retry(&list).is_none());
    }
}

#[test]
fn the_first_config_boringssl_can_offer_is_the_one_it_offers() {
    let older = config(0xfe0c, 0x0020, 32, &[(1, 1)], "x.example", &[]);
    assert_eq!(
        check_ech_config_list(&list(&[older, offered("a.example")])),
        Ok(())
    );
    // An extension that is not mandatory is passed over, and one good suite is enough.
    let optional = config(
        0xfe0d,
        0x0020,
        32,
        &[(2, 1), (1, 3)],
        "a.example",
        &[0, 1, 0, 1, 9],
    );
    assert_eq!(check_ech_config_list(&list(&[optional])), Ok(()));
    // Only a last label that is a number disqualifies a name.
    assert_eq!(
        check_ech_config_list(&list(&[offered("0x1f.example")])),
        Ok(())
    );
    assert_eq!(check_ech_config_list(&list(&[offered("a.0x1g")])), Ok(()));
    assert_eq!(check_ech_config_list(&list(&[offered("a.b1")])), Ok(()));
    // A config it picks with a key of the wrong length fails the handshake: no later one counts.
    let short = config(0xfe0d, 0x0020, 31, &[(1, 1)], "a.example", &[]);
    assert!(check_ech_config_list(&list(&[short, offered("a.example")])).is_err());
}

#[test]
fn a_list_boringssl_cannot_parse_is_turned_down() {
    let mut trailing = list(&[offered("a.example")]);
    trailing.push(0);
    let mut cut = list(&[offered("a.example")]);
    cut.pop();
    // A config it would pass over still has to parse: here its extensions are cut short.
    let broken = list(&[
        offered("a.example"),
        config(0xfe0d, 0x0020, 32, &[(1, 1)], "a.example", &[0]),
    ]);
    let no_key = list(&[config(0xfe0d, 0x0020, 0, &[(1, 1)], "a.example", &[])]);
    let no_name = list(&[offered("")]);
    // What BoringSSL hands out for retry configs when it has none.
    let placeholder = vec![0xfe, 0x0d, 0xff, 0xff, 0xff];
    for bad in [
        vec![],
        vec![0, 0],
        trailing,
        cut,
        broken,
        no_key,
        no_name,
        placeholder,
    ] {
        assert!(check_ech_config_list(&bad).is_err(), "{bad:02x?}");
        assert!(ensure_offerable(&bad).is_err());
    }
}

/// Whether BoringSSL offers ECH from `list` in the ClientHello it sends to a server on this
/// machine: None when it takes no such list, or sends no ClientHello at all.
async fn boringssl_offers(list: &[u8]) -> Option<bool> {
    let mut builder = boring::ssl::SslConnector::builder(SslMethod::tls()).expect("tls");
    Fingerprint::default()
        .apply(&mut builder, b"\x02h2")
        .expect("the fingerprint");
    let mut config = builder.build().configure().expect("a configuration");
    config.set_ech_config_list(list).ok()?;
    let (server, hello) = client_hello::catch().await;
    let tcp = tokio::net::TcpStream::connect(server)
        .await
        .expect("a connection");
    let _ = tokio_boring::connect(config, "a.example", tcp).await;
    hello.await.ok().map(|hello| hello.offers_ech())
}

#[tokio::test]
async fn the_key_check_says_what_boringssl_does() {
    // The fingerprint sends no GREASE ECH, so an ECH extension in the ClientHello means
    // BoringSSL took a config from the list.
    let older = config(0xfe0c, 0x0020, 32, &[(1, 1)], "x.example", &[]);
    let short = config(0xfe0d, 0x0020, 31, &[(1, 1)], "a.example", &[]);
    let lists = [
        decode_ech_config_list(CLOUDFLARE_ECH).expect("base64"),
        list(&[older.clone(), offered("a.example")]),
        list(&[config(
            0xfe0d,
            0x0020,
            32,
            &[(2, 1), (1, 3)],
            "a.example",
            &[0, 1, 0, 1, 9],
        )]),
        list(&[offered("0x1f.example")]),
        list(&[older]),
        list(&[config(0xfe0d, 0x0010, 32, &[(1, 1)], "a.example", &[])]),
        list(&[config(0xfe0d, 0x0020, 32, &[(2, 1)], "a.example", &[])]),
        list(&[config(0xfe0d, 0x0020, 32, &[(1, 4)], "a.example", &[])]),
        list(&[config(
            0xfe0d,
            0x0020,
            32,
            &[(1, 1)],
            "a.example",
            &[0x80, 1, 0, 0],
        )]),
        list(&[offered("192.0.2.1")]),
        list(&[offered("example.0x1F")]),
        list(&[offered("example.com.")]),
        list(&[offered("exa_mple.com")]),
        list(&[short, offered("a.example")]),
        list(&[config(0xfe0d, 0x0020, 0, &[(1, 1)], "a.example", &[])]),
        vec![0xfe, 0x0d, 0xff, 0xff, 0xff],
    ];
    for list in lists {
        let sent = boringssl_offers(&list).await;
        assert_eq!(
            check_ech_config_list(&list).is_ok(),
            sent == Some(true),
            "{list:02x?}: BoringSSL {sent:?}"
        );
    }
}
