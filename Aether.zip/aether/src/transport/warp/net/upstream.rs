use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::time::Duration;

use base64::Engine;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpStream, UdpSocket};

use crate::error::AetherError;
use crate::error::Result;

const VER: u8 = 0x05;
const AUTH_NONE: u8 = 0x00;
const AUTH_USERPASS: u8 = 0x02;
const AUTH_REJECTED: u8 = 0xff;
const CMD_CONNECT: u8 = 0x01;
const CMD_ASSOCIATE: u8 = 0x03;
const ATYP_V4: u8 = 0x01;
const ATYP_NAME: u8 = 0x03;
const ATYP_V6: u8 = 0x04;
const REP_OK: u8 = 0x00;

const HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(10);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Socks5,
    Http,
}

impl Kind {
    pub fn label(self) -> &'static str {
        match self {
            Kind::Socks5 => "socks5",
            Kind::Http => "http",
        }
    }
}

#[derive(Clone, PartialEq, Eq)]
pub struct Upstream {
    pub kind: Kind,
    pub host: String,
    pub port: u16,
    pub user: Option<String>,
    pub password: Option<String>,
}

impl std::fmt::Debug for Upstream {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Upstream")
            .field("kind", &self.kind)
            .field("host", &self.host)
            .field("port", &self.port)
            .field("user", &self.user)
            .field("password", &self.password.as_ref().map(|_| "<redacted>"))
            .finish()
    }
}

tokio::task_local! {
    /// The proxy one task goes through instead of AETHER_UPSTREAM, see [`through`].
    static TASK_UPSTREAM: Upstream;
}

/// Runs `future` with the connections it makes going through `proxy` instead of AETHER_UPSTREAM.
/// The setting stays as it is, and every other task of the process keeps going through it, so one
/// call can be sent elsewhere without the rest of the process following it. A task `future`
/// spawns goes through the setting as well.
#[cfg(test)]
pub async fn through<F: std::future::Future>(proxy: Upstream, future: F) -> F::Output {
    TASK_UPSTREAM.scope(proxy, future).await
}

/// The proxy AETHER_UPSTREAM names, as it names it now, or the one a task runs [`through`]. It is
/// looked up on every call rather than once, so a setting changed while the process runs is
/// followed. A setting is parsed, and announced, only when it changes.
pub fn configured() -> Option<Upstream> {
    if let Ok(proxy) = TASK_UPSTREAM.try_with(Upstream::clone) {
        return Some(proxy);
    }
    static SEEN: std::sync::Mutex<Option<(String, Option<Upstream>)>> = std::sync::Mutex::new(None);
    let raw = crate::config::settings::var("AETHER_UPSTREAM").unwrap_or_default();
    let mut seen = SEEN
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    remembered(&mut seen, raw)
}

/// The hold on AETHER_UPSTREAM of a test: the variable is the whole process's, and the tests run
/// side by side, so each test that sets it, or that dials through the setting, holds it first.
/// Let go, the hold clears the variable, which a test that failed half way may have left set.
#[cfg(test)]
pub(crate) struct SettingHeld(#[expect(dead_code, reason = "held for its Drop")] tokio::sync::MutexGuard<'static, ()>);

#[cfg(test)]
impl Drop for SettingHeld {
    fn drop(&mut self) {
        crate::config::settings::forget("AETHER_UPSTREAM");
    }
}

/// Waits for the hold on AETHER_UPSTREAM, see `SettingHeld`; the variable starts out clear.
#[cfg(test)]
pub(crate) async fn hold_setting() -> SettingHeld {
    static SETTING: std::sync::OnceLock<tokio::sync::Mutex<()>> = std::sync::OnceLock::new();
    let held = SETTING
        .get_or_init(|| tokio::sync::Mutex::new(()))
        .lock()
        .await;
    crate::config::settings::forget("AETHER_UPSTREAM");
    SettingHeld(held)
}

/// The proxy `raw` names, parsed once per setting: while the setting stays the same, the proxy
/// `seen` holds for it is used again.
fn remembered(seen: &mut Option<(String, Option<Upstream>)>, raw: String) -> Option<Upstream> {
    if let Some((last, upstream)) = seen.as_ref() {
        if *last == raw {
            return upstream.clone();
        }
    }
    let upstream = Upstream::from_value(&raw);
    *seen = Some((raw, upstream.clone()));
    upstream
}

impl Upstream {

    /// The proxy `raw` names, announced in the log; none when it is blank or cannot be read.
    fn from_value(raw: &str) -> Option<Self> {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            return None;
        }

        match Self::parse(trimmed) {
            Ok(upstream) => {
                log::info!(
                    "[upstream] dialling out through the {} proxy at {}:{}",
                    upstream.kind.label(),
                    upstream.host,
                    upstream.port
                );
                Some(upstream)
            }
            Err(error) => {
                log::error!("[upstream] the upstream proxy setting was ignored: {error}");
                None
            }
        }
    }

    pub fn parse(raw: &str) -> Result<Self> {
        let raw = raw.trim();
        let (scheme, rest) = match raw.split_once("://") {
            Some((scheme, rest)) => (scheme.to_lowercase(), rest),
            None => ("socks5".to_string(), raw),
        };

        let kind = match scheme.as_str() {
            "socks5" | "socks5h" | "socks" => Kind::Socks5,
            "http" | "https" => Kind::Http,
            other => {
                return Err(AetherError::Other(format!(
                    "{other} is not an upstream proxy kind aether understands"
                )))
            }
        };

        let (credentials, endpoint) = match rest.rsplit_once('@') {
            Some((credentials, endpoint)) => (Some(credentials), endpoint),
            None => (None, rest),
        };

        if scheme == "https" {
            if credentials.is_some() {
                return Err(AetherError::Other(
                    "an https:// upstream with a password is refused: aether talks to its upstream \
                     over plain http, which would send the password in the clear; use http:// \
                     only if that is acceptable, or socks5://"
                        .into(),
                ));
            }
            log::warn!(
                "[upstream] the upstream is written as https:// but aether talks to it over plain http; \
                 the tunnel inside stays encrypted"
            );
        }

        let endpoint = endpoint.trim_end_matches('/');
        let (host, port) = split_endpoint(endpoint)?;

        let (user, password) = match credentials {
            Some(pair) => match pair.split_once(':') {
                Some((user, password)) => {
                    (Some(percent_decode(user)), Some(percent_decode(password)))
                }
                None => (Some(percent_decode(pair)), None),
            },
            None => (None, None),
        };

        Ok(Self {
            kind,
            host,
            port,
            user,
            password,
        })
    }

    pub fn endpoint(&self) -> String {
        format!("{}:{}", self.host, self.port)
    }

    pub fn url(&self) -> String {
        let host = if self.host.contains(':') {
            format!("[{}]", self.host)
        } else {
            self.host.clone()
        };
        let scheme = match self.kind {
            Kind::Socks5 => "socks5h",
            Kind::Http => "http",
        };
        format!("{scheme}://{host}:{}", self.port)
    }

    pub fn as_reqwest_proxy(&self) -> Result<reqwest::Proxy> {
        let proxy = reqwest::Proxy::all(self.url())
            .map_err(|error| AetherError::Other(format!("{} is unusable: {error}", self.url())))?;

        match &self.user {
            Some(user) => Ok(proxy.basic_auth(user, self.password.as_deref().unwrap_or(""))),
            None => Ok(proxy),
        }
    }

    pub async fn connect(&self, target: SocketAddr) -> Result<TcpStream> {
        self.open(encode_request(CMD_CONNECT, target), &target.to_string())
            .await
    }

    /// A TCP connection to `host`:`port` through the proxy. A name goes to the proxy as it is,
    /// for the proxy to look up, so that no DNS query for it leaves this machine.
    pub async fn connect_host(&self, host: &str, port: u16) -> Result<TcpStream> {
        if let Ok(ip) = host.parse::<IpAddr>() {
            return self.connect(SocketAddr::new(ip, port)).await;
        }
        self.open(
            encode_name_request(CMD_CONNECT, host, port)?,
            &format!("{host}:{port}"),
        )
        .await
    }

    /// A TCP connection through the proxy: `socks_request` asked of a socks5 proxy, a CONNECT
    /// to `authority` of an http one.
    async fn open(&self, socks_request: Vec<u8>, authority: &str) -> Result<TcpStream> {
        let attempt = async {
            let mut stream = crate::utils::egress::tcp_connect_host(&self.host, self.port).await?;
            let _ = stream.set_nodelay(true);

            match self.kind {
                Kind::Socks5 => {
                    self.socks_greet(&mut stream).await?;
                    stream.write_all(&socks_request).await?;
                    read_reply(&mut stream).await?;
                }
                Kind::Http => self.http_connect(&mut stream, authority).await?,
            }

            Ok(stream)
        };

        match tokio::time::timeout(HANDSHAKE_TIMEOUT, attempt).await {
            Ok(result) => result,
            Err(_) => Err(AetherError::Other(format!(
                "the upstream proxy at {} did not answer in time",
                self.endpoint()
            ))),
        }
    }

    pub async fn associate(&self) -> Result<UdpRelay> {
        if self.kind != Kind::Socks5 {
            return Err(AetherError::Other(
                "only a socks5 proxy can carry udp, an http proxy cannot".into(),
            ));
        }

        let attempt = async {
            let mut control = crate::utils::egress::tcp_connect_host(&self.host, self.port).await?;
            let _ = control.set_nodelay(true);
            self.socks_greet(&mut control).await?;

            let unspecified = SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0);
            let request = encode_request(CMD_ASSOCIATE, unspecified);
            control.write_all(&request).await?;
            let bound = read_reply(&mut control).await?;

            let relay = relay_address(bound, &self.host, self.port).await?;
            let socket = crate::utils::egress::udp_bind(crate::utils::egress::wildcard_for(relay))?;
            socket.connect(relay).await?;

            Ok(UdpRelay {
                socket,
                relay,
                _control: control,
            })
        };

        match tokio::time::timeout(HANDSHAKE_TIMEOUT, attempt).await {
            Ok(result) => result,
            Err(_) => Err(AetherError::Other(format!(
                "the upstream proxy at {} never opened a udp relay",
                self.endpoint()
            ))),
        }
    }

    async fn socks_greet(&self, stream: &mut TcpStream) -> Result<()> {
        let wants_auth = self.user.is_some();
        let greeting: Vec<u8> = if wants_auth {
            vec![VER, 1, AUTH_USERPASS]
        } else {
            vec![VER, 1, AUTH_NONE]
        };
        stream.write_all(&greeting).await?;

        let mut answer = [0u8; 2];
        stream.read_exact(&mut answer).await?;
        if answer[0] != VER {
            return Err(AetherError::Other(
                "the upstream proxy did not speak socks5".into(),
            ));
        }

        match answer[1] {
            AUTH_NONE if wants_auth => Err(AetherError::Other(
                "the upstream proxy skipped authentication even though credentials are configured"
                    .into(),
            )),
            AUTH_NONE => Ok(()),
            AUTH_USERPASS => self.socks_authenticate(stream).await,
            AUTH_REJECTED => Err(AetherError::Other(
                "the upstream proxy rejected every authentication method offered".into(),
            )),
            other => Err(AetherError::Other(format!(
                "the upstream proxy asked for authentication method {other}, which aether cannot do"
            ))),
        }
    }

    async fn socks_authenticate(&self, stream: &mut TcpStream) -> Result<()> {
        let user = self.user.clone().unwrap_or_default();
        let password = self.password.clone().unwrap_or_default();

        if user.len() > 255 || password.len() > 255 {
            return Err(AetherError::Other(
                "the upstream proxy credentials are longer than socks5 allows".into(),
            ));
        }

        let mut message = Vec::with_capacity(3 + user.len() + password.len());
        message.push(0x01);
        message.push(user.len() as u8);
        message.extend_from_slice(user.as_bytes());
        message.push(password.len() as u8);
        message.extend_from_slice(password.as_bytes());
        stream.write_all(&message).await?;

        let mut answer = [0u8; 2];
        stream.read_exact(&mut answer).await?;
        if answer[0] != 0x01 {
            return Err(AetherError::Other(
                "the upstream proxy answered the password negotiation with the wrong version"
                    .into(),
            ));
        }
        if answer[1] != 0x00 {
            return Err(AetherError::Other(
                "the upstream proxy refused the credentials supplied".into(),
            ));
        }
        Ok(())
    }

    async fn http_connect(&self, stream: &mut TcpStream, authority: &str) -> Result<()> {
        let mut request = format!(
            "CONNECT {authority} HTTP/1.1\r\nHost: {authority}\r\nProxy-Connection: Keep-Alive\r\n"
        );

        if let Some(user) = &self.user {
            let password = self.password.clone().unwrap_or_default();
            let token =
                base64::engine::general_purpose::STANDARD.encode(format!("{user}:{password}"));
            request.push_str(&format!("Proxy-Authorization: Basic {token}\r\n"));
        }
        request.push_str("\r\n");

        stream.write_all(request.as_bytes()).await?;

        let mut head = Vec::with_capacity(256);
        let mut byte = [0u8; 1];
        loop {
            if head.len() > 8192 {
                return Err(AetherError::Other(
                    "the upstream proxy sent an oversized answer".into(),
                ));
            }
            if stream.read(&mut byte).await? == 0 {
                return Err(AetherError::Other(
                    "the upstream proxy closed before answering the connect".into(),
                ));
            }
            head.push(byte[0]);
            if head.ends_with(b"\r\n\r\n") {
                break;
            }
        }

        let status = http_status(&head)
            .ok_or_else(|| AetherError::Other("the upstream proxy answer was not http".into()))?;

        if !(200..300).contains(&status) {
            return Err(AetherError::Other(format!(
                "the upstream proxy answered {status} to the connect"
            )));
        }
        Ok(())
    }
}

pub struct UdpRelay {
    socket: UdpSocket,
    relay: SocketAddr,
    _control: TcpStream,
}

impl UdpRelay {
    pub fn relay(&self) -> SocketAddr {
        self.relay
    }

    pub async fn send_to(&self, payload: &[u8], target: SocketAddr) -> std::io::Result<usize> {
        let mut framed = encode_udp_header(target);
        framed.extend_from_slice(payload);
        self.socket.send(&framed).await?;
        Ok(payload.len())
    }

    pub async fn recv_from(&self, out: &mut [u8]) -> std::io::Result<(usize, SocketAddr)> {
        let mut framed = vec![0u8; out.len().max(2048) + 512];
        let read = self.socket.recv(&mut framed).await?;

        let (origin, offset) = decode_udp_header(&framed[..read]).ok_or_else(|| {
            std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "the udp relay sent a malformed header",
            )
        })?;

        let payload = &framed[offset..read];
        let copied = payload.len().min(out.len());
        out[..copied].copy_from_slice(&payload[..copied]);
        Ok((copied, origin))
    }
}

struct Detour {
    id: u64,
    shim: SocketAddr,
    peer: SocketAddr,
}

#[derive(Default)]
#[must_use = "the detour is closed as soon as its guard is dropped"]
pub struct DetourGuard(Option<(SocketAddr, u64, tokio::task::AbortHandle)>);

impl Drop for DetourGuard {
    fn drop(&mut self) {
        if let Some((client, id, pump)) = self.0.take() {
            pump.abort();
            forget_detour(client, id);
        }
    }
}

fn forget_detour(client: SocketAddr, id: u64) {
    if let Ok(mut map) = detours().lock() {
        if map.get(&client).is_some_and(|detour| detour.id == id) {
            map.remove(&client);
        }
    }
}

fn next_detour_id() -> u64 {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
    NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
}

fn detours() -> &'static std::sync::Mutex<std::collections::HashMap<SocketAddr, Detour>> {
    static DETOURS: std::sync::OnceLock<
        std::sync::Mutex<std::collections::HashMap<SocketAddr, Detour>>,
    > = std::sync::OnceLock::new();
    DETOURS.get_or_init(|| std::sync::Mutex::new(std::collections::HashMap::new()))
}

pub fn relay_target(local: SocketAddr, intended: SocketAddr) -> SocketAddr {
    match detours().lock() {
        Ok(map) => map.get(&local).map(|d| d.shim).unwrap_or(intended),
        Err(_) => intended,
    }
}

pub fn real_source(local: SocketAddr, observed: SocketAddr) -> SocketAddr {
    match detours().lock() {
        Ok(map) => match map.get(&local) {
            Some(detour) if detour.shim == observed => detour.peer,
            _ => observed,
        },
        Err(_) => observed,
    }
}

pub async fn attach_detour(socket: &UdpSocket, peer: SocketAddr) -> Result<DetourGuard> {
    match configured() {
        Some(proxy) => attach_detour_via(&proxy, socket, peer).await,
        None => Ok(DetourGuard::default()),
    }
}

async fn attach_detour_via(
    proxy: &Upstream,
    socket: &UdpSocket,
    peer: SocketAddr,
) -> Result<DetourGuard> {
    if crate::utils::net::is_private(peer.ip()) {
        log::debug!("[upstream] {peer} is local, reaching it without the upstream proxy");
        return Ok(DetourGuard::default());
    }

    let relay = proxy.associate().await?;
    let client = socket.local_addr()?;
    let loopback = if client.is_ipv4() {
        IpAddr::V4(Ipv4Addr::LOCALHOST)
    } else {
        IpAddr::V6(Ipv6Addr::LOCALHOST)
    };
    let shim = UdpSocket::bind(SocketAddr::new(loopback, 0)).await?;
    let shim_address = shim.local_addr()?;
    let id = next_detour_id();

    if let Ok(mut map) = detours().lock() {
        map.insert(
            client,
            Detour {
                id,
                shim: shim_address,
                peer,
            },
        );
    }

    log::info!(
        "[upstream] {peer} is reached through the upstream relay at {}",
        relay.relay()
    );

    let task = tokio::spawn(async move {
        if let Err(error) = pump(shim, client, peer, relay).await {
            log::warn!("[upstream] the upstream udp relay for {peer} stopped: {error}");
        }
        forget_detour(client, id);
    });

    Ok(DetourGuard(Some((client, id, task.abort_handle()))))
}

pub async fn bind_via_upstream(peer: SocketAddr) -> Result<(UdpSocket, SocketAddr, DetourGuard)> {
    let socket = crate::utils::egress::udp_bind(crate::utils::egress::wildcard_for(peer))?;
    let detour = attach_detour(&socket, peer).await?;

    let local = socket.local_addr()?;
    let target = relay_target(local, peer);
    socket.connect(target).await?;

    Ok((socket, target, detour))
}

fn from_detoured_socket(client: SocketAddr, origin: SocketAddr) -> bool {
    origin.port() == client.port()
        && (origin.ip() == client.ip()
            || (client.ip().is_unspecified() && origin.ip().is_loopback()))
}

async fn pump(
    shim: UdpSocket,
    client: SocketAddr,
    peer: SocketAddr,
    relay: UdpRelay,
) -> std::io::Result<()> {
    let mut from_client = vec![0u8; 65535];
    let mut from_relay = vec![0u8; 65535];
    let mut reply_to: Option<SocketAddr> = None;

    loop {
        tokio::select! {
            read = shim.recv_from(&mut from_client) => {
                let (len, origin) = read?;
                if !from_detoured_socket(client, origin) {
                    continue;
                }
                reply_to = Some(origin);
                relay.send_to(&from_client[..len], peer).await?;
            }
            read = relay.recv_from(&mut from_relay) => {
                let len = match read {
                    Ok((len, _origin)) => len,
                    Err(error) if error.kind() == std::io::ErrorKind::InvalidData => continue,
                    Err(error) => return Err(error),
                };
                if let Some(to) = reply_to {
                    shim.send_to(&from_relay[..len], to).await?;
                }
            }
        }
    }
}

fn split_endpoint(endpoint: &str) -> Result<(String, u16)> {
    let malformed = || {
        AetherError::Other(format!(
            "{endpoint} is not a host and port an upstream proxy can live at"
        ))
    };

    if let Some(rest) = endpoint.strip_prefix('[') {
        let (host, tail) = rest.split_once(']').ok_or_else(malformed)?;
        let port = tail.strip_prefix(':').ok_or_else(malformed)?;
        let port = port.parse::<u16>().map_err(|_| malformed())?;
        if host.is_empty() || port == 0 {
            return Err(malformed());
        }
        return Ok((host.to_string(), port));
    }

    let (host, port) = endpoint.rsplit_once(':').ok_or_else(malformed)?;
    let port = port.parse::<u16>().map_err(|_| malformed())?;
    if host.is_empty() || port == 0 {
        return Err(malformed());
    }
    Ok((host.to_string(), port))
}

fn percent_decode(value: &str) -> String {
    let bytes = value.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut at = 0;
    while at < bytes.len() {
        if bytes[at] == b'%' && at + 2 < bytes.len() {
            let hex = std::str::from_utf8(&bytes[at + 1..at + 3]).unwrap_or("");
            if let Ok(byte) = u8::from_str_radix(hex, 16) {
                out.push(byte);
                at += 3;
                continue;
            }
        }
        out.push(bytes[at]);
        at += 1;
    }
    String::from_utf8_lossy(&out).to_string()
}

fn http_status(head: &[u8]) -> Option<u16> {
    let text = String::from_utf8_lossy(head);
    let line = text.lines().next()?;
    let mut parts = line.split_whitespace();
    let version = parts.next()?;
    if !version.starts_with("HTTP/") {
        return None;
    }
    parts.next()?.parse::<u16>().ok()
}

pub fn encode_address(target: SocketAddr) -> Vec<u8> {
    let mut out = Vec::with_capacity(19);
    match target.ip() {
        IpAddr::V4(v4) => {
            out.push(ATYP_V4);
            out.extend_from_slice(&v4.octets());
        }
        IpAddr::V6(v6) => {
            out.push(ATYP_V6);
            out.extend_from_slice(&v6.octets());
        }
    }
    out.extend_from_slice(&target.port().to_be_bytes());
    out
}

pub fn encode_request(command: u8, target: SocketAddr) -> Vec<u8> {
    let mut out = Vec::with_capacity(22);
    out.push(VER);
    out.push(command);
    out.push(0x00);
    out.extend_from_slice(&encode_address(target));
    out
}

/// A socks5 request for `name`:`port`, the name for the proxy to look up (RFC 1928, 4-5).
pub fn encode_name_request(command: u8, name: &str, port: u16) -> Result<Vec<u8>> {
    let length = u8::try_from(name.len())
        .ok()
        .filter(|length| *length > 0)
        .ok_or_else(|| {
            AetherError::Other(format!(
                "{name:?} is no name a socks5 proxy can be asked for"
            ))
        })?;
    let mut out = Vec::with_capacity(7 + name.len());
    out.extend_from_slice(&[VER, command, 0x00, ATYP_NAME, length]);
    out.extend_from_slice(name.as_bytes());
    out.extend_from_slice(&port.to_be_bytes());
    Ok(out)
}

pub fn encode_udp_header(target: SocketAddr) -> Vec<u8> {
    let mut out = Vec::with_capacity(22);
    out.push(0x00);
    out.push(0x00);
    out.push(0x00);
    out.extend_from_slice(&encode_address(target));
    out
}

pub fn decode_udp_header(buf: &[u8]) -> Option<(SocketAddr, usize)> {
    if buf.len() < 4 || buf[2] != 0x00 {
        return None;
    }

    match buf[3] {
        ATYP_V4 => {
            if buf.len() < 10 {
                return None;
            }
            let ip = Ipv4Addr::new(buf[4], buf[5], buf[6], buf[7]);
            let port = u16::from_be_bytes([buf[8], buf[9]]);
            Some((SocketAddr::new(IpAddr::V4(ip), port), 10))
        }
        ATYP_V6 => {
            if buf.len() < 22 {
                return None;
            }
            let mut octets = [0u8; 16];
            octets.copy_from_slice(&buf[4..20]);
            let port = u16::from_be_bytes([buf[20], buf[21]]);
            Some((SocketAddr::new(IpAddr::V6(octets.into()), port), 22))
        }
        ATYP_NAME => {
            let length = *buf.get(4)? as usize;
            let end = 5 + length;
            if buf.len() < end + 2 {
                return None;
            }
            let port = u16::from_be_bytes([buf[end], buf[end + 1]]);
            let name = std::str::from_utf8(&buf[5..end]).ok()?;
            let ip = name.parse::<IpAddr>().ok()?;
            Some((SocketAddr::new(ip, port), end + 2))
        }
        _ => None,
    }
}

async fn read_reply(stream: &mut TcpStream) -> Result<SocketAddr> {
    let mut head = [0u8; 4];
    stream.read_exact(&mut head).await?;

    if head[0] != VER {
        return Err(AetherError::Other(
            "the upstream proxy answered with something other than socks5".into(),
        ));
    }
    if head[1] != REP_OK {
        return Err(AetherError::Other(format!(
            "the upstream proxy refused the request with code {}",
            head[1]
        )));
    }

    let ip = match head[3] {
        ATYP_V4 => {
            let mut octets = [0u8; 4];
            stream.read_exact(&mut octets).await?;
            IpAddr::V4(Ipv4Addr::from(octets))
        }
        ATYP_V6 => {
            let mut octets = [0u8; 16];
            stream.read_exact(&mut octets).await?;
            IpAddr::V6(octets.into())
        }
        ATYP_NAME => {
            let mut length = [0u8; 1];
            stream.read_exact(&mut length).await?;
            let mut name = vec![0u8; length[0] as usize];
            stream.read_exact(&mut name).await?;
            String::from_utf8_lossy(&name)
                .parse::<IpAddr>()
                .unwrap_or(IpAddr::V4(Ipv4Addr::UNSPECIFIED))
        }
        other => {
            return Err(AetherError::Other(format!(
                "the upstream proxy sent address type {other}, which aether cannot read"
            )))
        }
    };

    let mut port = [0u8; 2];
    stream.read_exact(&mut port).await?;
    Ok(SocketAddr::new(ip, u16::from_be_bytes(port)))
}

async fn relay_address(bound: SocketAddr, host: &str, port: u16) -> Result<SocketAddr> {
    if !bound.ip().is_unspecified() && bound.port() != 0 {
        return Ok(bound);
    }

    let relay_port = if bound.port() == 0 {
        port
    } else {
        bound.port()
    };

    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(SocketAddr::new(ip, relay_port));
    }

    crate::proxy::socks::lookup_egress(host, relay_port)
        .await?
        .into_iter()
        .next()
        .ok_or_else(|| {
            AetherError::Other(format!("{host} does not resolve to a usable relay address"))
        })
}

#[cfg(test)]
mod tests;
