use super::*;

#[tokio::test]
async fn a_task_through_a_proxy_of_its_own_leaves_the_rest_on_the_setting() {
    let _setting = hold_setting().await;
    crate::config::settings::decide("AETHER_UPSTREAM", "socks5://127.0.0.1:1080");
    let tunnel = Upstream::parse("socks5h://127.0.0.1:2080").expect("proxy");

    // Another task looks while the one inside is still there.
    let (look, looking) = tokio::sync::oneshot::channel::<()>();
    let (seen, saw) = tokio::sync::oneshot::channel::<Option<Upstream>>();
    tokio::spawn(async move {
        looking.await.ok();
        seen.send(configured()).ok();
    });
    let (inside, beside, spawned) = through(tunnel, async move {
        look.send(()).ok();
        let beside = saw.await.expect("the other task");
        let spawned = tokio::spawn(async { configured() })
            .await
            .expect("a task of its own");
        (configured(), beside, spawned)
    })
    .await;

    assert_eq!(inside.map(|proxy| proxy.port), Some(2080));
    assert_eq!(beside.map(|proxy| proxy.port), Some(1080));
    assert_eq!(spawned.map(|proxy| proxy.port), Some(1080));
    // The setting itself was never touched, and the task is back on it once out.
    assert_eq!(
        crate::config::settings::var("AETHER_UPSTREAM").as_deref(),
        Ok("socks5://127.0.0.1:1080")
    );
    assert_eq!(configured().map(|proxy| proxy.port), Some(1080));
}

#[tokio::test]
async fn a_call_to_the_api_through_a_proxy_of_its_own_goes_to_that_proxy_alone() {
    let _setting = hold_setting().await;
    // The setting names a proxy that only counts the connections it gets.
    let setting = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    crate::config::settings::decide(
        "AETHER_UPSTREAM",
        format!("socks5://{}", setting.local_addr().unwrap()),
    );
    let (tunnel, server) = fake_socks_http_server().await;
    let tunnel = Upstream::parse(&format!("socks5h://{tunnel}")).unwrap();

    let headers = Vec::new();
    let request = crate::transport::warp::net::https::Request {
        method: "POST",
        host: "api.cloudflareclient.com",
        port: 443,
        address: None,
        sni: None,
        path: "/v0a4005/reg",
        headers: &headers,
        body: None,
    };
    let fingerprint = crate::transport::warp::net::tls::Fingerprint::default();
    let call = crate::transport::warp::net::https::send(&request, &fingerprint, None, Duration::from_secs(5));
    // The fake answers in plain HTTP, so the handshake fails: where the call went is what
    // counts.
    let _ = through(tunnel, call).await;

    let target = tokio::time::timeout(Duration::from_secs(5), server)
        .await
        .expect("the call went to the proxy of its own")
        .unwrap();
    assert_eq!(target.as_deref(), Some("api.cloudflareclient.com"));
    let dialled = tokio::time::timeout(Duration::from_millis(100), setting.accept()).await;
    assert!(dialled.is_err(), "the call went to the setting's proxy too");
}

#[test]
fn a_proxy_named_after_the_first_look_is_still_used() {
    // a proxy named while the process already runs
    let mut seen = None;
    assert!(remembered(&mut seen, String::new()).is_none());
    let carrier =
        remembered(&mut seen, "socks5://127.0.0.1:1820".to_string()).expect("the carrier");
    assert_eq!(carrier.port, 1820);
    assert_eq!(
        remembered(&mut seen, "socks5://127.0.0.1:1820".to_string()),
        Some(carrier)
    );
    assert!(remembered(&mut seen, "  ".to_string()).is_none());
}

#[test]
fn a_bare_host_and_port_is_taken_as_socks5() {
    let upstream = Upstream::parse("127.0.0.1:1080").unwrap();
    assert_eq!(upstream.kind, Kind::Socks5);
    assert_eq!(upstream.host, "127.0.0.1");
    assert_eq!(upstream.port, 1080);
    assert!(upstream.user.is_none());
}

#[test]
fn every_socks_spelling_is_accepted() {
    for raw in [
        "socks5://127.0.0.1:1080",
        "socks5h://127.0.0.1:1080",
        "socks://127.0.0.1:1080",
    ] {
        assert_eq!(Upstream::parse(raw).unwrap().kind, Kind::Socks5, "{raw}");
    }
}

#[test]
fn an_http_proxy_is_recognised() {
    let upstream = Upstream::parse("http://proxy.example:8080").unwrap();
    assert_eq!(upstream.kind, Kind::Http);
    assert_eq!(upstream.host, "proxy.example");
    assert_eq!(upstream.port, 8080);
}

#[test]
fn credentials_are_pulled_out_of_the_url() {
    let upstream = Upstream::parse("socks5://alice:s3cret@10.0.0.2:1080").unwrap();
    assert_eq!(upstream.user.as_deref(), Some("alice"));
    assert_eq!(upstream.password.as_deref(), Some("s3cret"));
    assert_eq!(upstream.host, "10.0.0.2");
}

#[test]
fn a_password_holding_an_at_sign_survives() {
    let upstream = Upstream::parse("socks5://alice:p%40ss@10.0.0.2:1080").unwrap();
    assert_eq!(upstream.password.as_deref(), Some("p@ss"));
    assert_eq!(upstream.host, "10.0.0.2");
}

#[test]
fn an_ipv6_endpoint_is_read_in_brackets() {
    let upstream = Upstream::parse("socks5://[::1]:1080").unwrap();
    assert_eq!(upstream.host, "::1");
    assert_eq!(upstream.port, 1080);
}

#[test]
fn nonsense_is_refused_rather_than_guessed_at() {
    for raw in [
        "",
        "socks5://",
        "socks5://host",
        "socks5://host:0",
        "socks5://host:notaport",
        "ftp://host:21",
        "socks5://:1080",
    ] {
        assert!(Upstream::parse(raw).is_err(), "{raw} should be refused");
    }
}

#[test]
fn a_connect_request_matches_the_socks5_wire_format() {
    let request = encode_request(CMD_CONNECT, "93.184.216.34:443".parse().unwrap());
    assert_eq!(
        request,
        vec![0x05, 0x01, 0x00, 0x01, 93, 184, 216, 34, 0x01, 0xbb]
    );
}

#[test]
fn an_ipv6_request_carries_all_sixteen_octets() {
    let request = encode_request(CMD_CONNECT, "[::1]:80".parse().unwrap());
    assert_eq!(request[3], ATYP_V6);
    assert_eq!(request.len(), 4 + 16 + 2);
    assert_eq!(&request[request.len() - 2..], &[0x00, 0x50]);
}

#[test]
fn a_udp_header_round_trips() {
    for raw in ["1.2.3.4:53", "[2606:4700::1111]:443"] {
        let target: SocketAddr = raw.parse().unwrap();
        let mut framed = encode_udp_header(target);
        let offset = framed.len();
        framed.extend_from_slice(b"payload");

        let (decoded, at) = decode_udp_header(&framed).unwrap();
        assert_eq!(decoded, target, "{raw}");
        assert_eq!(at, offset, "{raw}");
        assert_eq!(&framed[at..], b"payload", "{raw}");
    }
}

#[test]
fn a_udp_header_that_is_fragmented_is_refused() {
    let mut framed = encode_udp_header("1.2.3.4:53".parse().unwrap());
    framed[2] = 0x01;
    assert!(decode_udp_header(&framed).is_none());
}

#[test]
fn a_truncated_udp_header_is_refused_without_panicking() {
    let framed = encode_udp_header("[2606:4700::1111]:443".parse().unwrap());
    for cut in 0..framed.len() {
        assert!(decode_udp_header(&framed[..cut]).is_none(), "cut {cut}");
    }
}

async fn fake_socks_udp_server() -> (SocketAddr, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();

    let handle = tokio::spawn(async move {
        let (mut control, _) = listener.accept().await.unwrap();

        let mut greeting = [0u8; 3];
        control.read_exact(&mut greeting).await.unwrap();
        control.write_all(&[VER, AUTH_NONE]).await.unwrap();

        let mut head = [0u8; 4];
        control.read_exact(&mut head).await.unwrap();
        assert_eq!(head[1], CMD_ASSOCIATE);
        let mut rest = [0u8; 6];
        control.read_exact(&mut rest).await.unwrap();

        let relay = UdpSocket::bind("127.0.0.1:0").await.unwrap();
        let relay_address = relay.local_addr().unwrap();

        let mut answer = vec![VER, REP_OK, 0x00];
        answer.extend_from_slice(&encode_address(relay_address));
        control.write_all(&answer).await.unwrap();

        let mut buf = vec![0u8; 4096];
        let (len, from) = relay.recv_from(&mut buf).await.unwrap();
        let (target, offset) = decode_udp_header(&buf[..len]).unwrap();

        let mut echo = encode_udp_header(target);
        echo.extend_from_slice(b"pong:");
        echo.extend_from_slice(&buf[offset..len]);
        relay.send_to(&echo, from).await.unwrap();

        tokio::time::sleep(Duration::from_millis(200)).await;
        drop(control);
    });

    (address, handle)
}

#[tokio::test]
async fn a_datagram_makes_the_round_trip_through_a_socks5_relay() {
    let _setting = hold_setting().await;
    let (proxy_address, server) = fake_socks_udp_server().await;
    crate::config::settings::decide("AETHER_UPSTREAM", format!("socks5://{proxy_address}"));

    let proxy = Upstream::parse(&format!("socks5://{proxy_address}")).unwrap();
    let relay = proxy.associate().await.unwrap();

    let peer: SocketAddr = "203.0.113.9:2408".parse().unwrap();
    relay.send_to(b"ping", peer).await.unwrap();

    let mut out = vec![0u8; 1024];
    let (len, origin) = tokio::time::timeout(Duration::from_secs(3), relay.recv_from(&mut out))
        .await
        .unwrap()
        .unwrap();

    assert_eq!(&out[..len], b"pong:ping");
    assert_eq!(origin, peer);

    crate::config::settings::forget("AETHER_UPSTREAM");
    server.abort();
}

async fn round_trip_through_a_detour(bind: &str, peer: SocketAddr) {
    let (proxy_address, server) = fake_socks_udp_server().await;
    let proxy = Upstream::parse(&format!("socks5://{proxy_address}")).unwrap();

    let socket = UdpSocket::bind(bind).await.unwrap();
    let detour = attach_detour_via(&proxy, &socket, peer).await.unwrap();

    let local = socket.local_addr().unwrap();
    let target = relay_target(local, peer);
    assert_ne!(
        target, peer,
        "the datagram has to go to the shim, not straight to the peer"
    );
    socket.send_to(b"ping", target).await.unwrap();

    let mut buf = [0u8; 64];
    let (len, observed) =
        tokio::time::timeout(Duration::from_secs(3), socket.recv_from(&mut buf))
            .await
            .expect("the answer must come back through the relay")
            .unwrap();
    assert_eq!(&buf[..len], b"pong:ping");
    assert_eq!(real_source(local, observed), peer);

    drop(detour);
    assert_eq!(
        relay_target(local, peer),
        peer,
        "dropping the guard retires the detour"
    );
    server.abort();
}

#[tokio::test]
async fn a_wildcard_bound_socket_reaches_its_peer_through_the_relay() {
    round_trip_through_a_detour("0.0.0.0:0", "162.159.192.1:2408".parse().unwrap()).await;
}

#[tokio::test]
async fn an_ipv6_socket_reaches_its_peer_through_the_relay() {
    if UdpSocket::bind("[::1]:0").await.is_err() {
        eprintln!("skipped: this machine has no IPv6 loopback");
        return;
    }
    round_trip_through_a_detour("[::]:0", "[2606:4700:d0::a29f:c001]:2408".parse().unwrap())
        .await;
}

#[test]
fn only_the_detoured_socket_is_served_by_its_shim() {
    let wildcard: SocketAddr = "0.0.0.0:5000".parse().unwrap();
    assert!(from_detoured_socket(
        wildcard,
        "127.0.0.1:5000".parse().unwrap()
    ));
    assert!(!from_detoured_socket(
        wildcard,
        "127.0.0.1:5001".parse().unwrap()
    ));
    assert!(!from_detoured_socket(
        wildcard,
        "192.168.1.2:5000".parse().unwrap()
    ));

    let wildcard_v6: SocketAddr = "[::]:5000".parse().unwrap();
    assert!(from_detoured_socket(
        wildcard_v6,
        "[::1]:5000".parse().unwrap()
    ));
    assert!(!from_detoured_socket(
        wildcard_v6,
        "[::1]:5001".parse().unwrap()
    ));

    let bound: SocketAddr = "127.0.0.1:5000".parse().unwrap();
    assert!(from_detoured_socket(
        bound,
        "127.0.0.1:5000".parse().unwrap()
    ));
}

async fn fake_socks_http_server() -> (SocketAddr, tokio::task::JoinHandle<Option<String>>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();

    let handle = tokio::spawn(async move {
        let (mut control, _) = listener.accept().await.ok()?;

        let mut greeting = [0u8; 2];
        control.read_exact(&mut greeting).await.ok()?;
        let mut methods = vec![0u8; greeting[1] as usize];
        control.read_exact(&mut methods).await.ok()?;
        control.write_all(&[VER, AUTH_NONE]).await.ok()?;

        let mut head = [0u8; 4];
        control.read_exact(&mut head).await.ok()?;
        if head[1] != CMD_CONNECT {
            return None;
        }
        let target = match head[3] {
            ATYP_NAME => {
                let mut len = [0u8; 1];
                control.read_exact(&mut len).await.ok()?;
                let mut name = vec![0u8; len[0] as usize];
                control.read_exact(&mut name).await.ok()?;
                String::from_utf8(name).ok()?
            }
            ATYP_V4 => {
                let mut octets = [0u8; 4];
                control.read_exact(&mut octets).await.ok()?;
                Ipv4Addr::from(octets).to_string()
            }
            _ => return None,
        };
        let mut port = [0u8; 2];
        control.read_exact(&mut port).await.ok()?;

        let mut answer = vec![VER, REP_OK, 0x00];
        answer.extend_from_slice(&encode_address("127.0.0.1:1".parse().unwrap()));
        control.write_all(&answer).await.ok()?;

        let mut request = vec![0u8; 2048];
        let _ = control.read(&mut request).await.ok()?;
        control
            .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
            .await
            .ok()?;
        Some(target)
    });

    (address, handle)
}

#[tokio::test]
async fn the_api_client_reaches_its_host_through_a_socks5_upstream() {
    let (proxy_address, server) = fake_socks_http_server().await;
    let upstream = Upstream::parse(&format!("socks5://{proxy_address}")).unwrap();
    let client = reqwest::Client::builder()
        .proxy(upstream.as_reqwest_proxy().unwrap())
        .build()
        .unwrap();

    let body = tokio::time::timeout(Duration::from_secs(5), async {
        client
            .get("http://api.example.test/ping")
            .send()
            .await?
            .text()
            .await
    })
    .await
    .expect("the request finishes")
    .expect("the request goes through the socks5 proxy");

    assert_eq!(body, "ok");
    assert_eq!(
        server.await.unwrap().as_deref(),
        Some("api.example.test"),
        "the name has to be resolved by the proxy, not looked up locally"
    );
}

#[test]
fn a_name_goes_to_a_socks5_proxy_as_it_is() {
    let request = encode_name_request(CMD_CONNECT, "api.cloudflareclient.com", 443).unwrap();
    assert_eq!(request[..5], [VER, CMD_CONNECT, 0x00, ATYP_NAME, 24]);
    assert_eq!(&request[5..29], b"api.cloudflareclient.com");
    assert_eq!(request[29..], 443u16.to_be_bytes());
    assert!(encode_name_request(CMD_CONNECT, "", 443).is_err());
    assert!(encode_name_request(CMD_CONNECT, &"a".repeat(256), 443).is_err());
}

/// What `host` reaches through a socks5 proxy by connect_host: the target the proxy is
/// asked for, after the answer the proxy relays comes back.
async fn target_of(host: &str) -> Option<String> {
    let (proxy_address, server) = fake_socks_http_server().await;
    let upstream = Upstream::parse(&format!("socks5://{proxy_address}")).unwrap();
    let mut stream = upstream
        .connect_host(host, 80)
        .await
        .expect("a connection through the proxy");
    stream
        .write_all(b"GET /ping HTTP/1.1\r\nHost: x\r\n\r\n")
        .await
        .unwrap();
    let mut answer = Vec::new();
    stream.read_to_end(&mut answer).await.unwrap();
    assert!(answer.ends_with(b"ok"));
    server.await.unwrap()
}

#[tokio::test]
async fn a_name_is_dialled_through_the_proxy_unresolved_and_an_address_as_it_is() {
    assert_eq!(
        target_of("api.example.test").await.as_deref(),
        Some("api.example.test")
    );
    assert_eq!(target_of("127.0.0.1").await.as_deref(), Some("127.0.0.1"));
}

#[test]
fn a_password_is_never_sent_in_the_clear_to_an_https_upstream() {
    assert!(Upstream::parse("https://alice:s3cret@proxy.example:8443").is_err());
    let plain = Upstream::parse("https://proxy.example:8443").unwrap();
    assert_eq!(plain.kind, Kind::Http);
}

#[test]
fn the_upstream_password_stays_out_of_debug_output() {
    let upstream = Upstream::parse("socks5://alice:s3cret@127.0.0.1:1080").unwrap();
    let shown = format!("{upstream:?}");
    assert!(!shown.contains("s3cret"), "{shown}");
    assert!(shown.contains("alice"));
}

#[tokio::test]
async fn an_http_proxy_cannot_be_asked_to_carry_udp() {
    let proxy = Upstream::parse("http://127.0.0.1:8080").unwrap();
    assert!(proxy.associate().await.is_err());
}

#[tokio::test]
async fn a_local_peer_is_reached_without_the_proxy() {
    let _setting = hold_setting().await;
    crate::config::settings::decide("AETHER_UPSTREAM", "socks5://127.0.0.1:9");
    let socket = UdpSocket::bind("127.0.0.1:0").await.unwrap();

    for local in ["127.0.0.1:53", "10.0.0.1:2408", "192.168.1.1:443"] {
        let peer: SocketAddr = local.parse().unwrap();
        assert!(
            attach_detour(&socket, peer).await.is_ok(),
            "{local} must not be sent through the proxy"
        );
        assert_eq!(
            relay_target(socket.local_addr().unwrap(), peer),
            peer,
            "{local} should still be dialled directly"
        );
    }

    crate::config::settings::forget("AETHER_UPSTREAM");
}

#[test]
fn the_proxy_url_handed_to_the_api_client_is_well_formed() {
    assert_eq!(
        Upstream::parse("socks5://127.0.0.1:1080").unwrap().url(),
        "socks5h://127.0.0.1:1080"
    );
    assert_eq!(
        Upstream::parse("http://proxy.example:8080").unwrap().url(),
        "http://proxy.example:8080"
    );
    assert_eq!(
        Upstream::parse("socks5://[::1]:1080").unwrap().url(),
        "socks5h://[::1]:1080",
        "an ipv6 proxy host has to stay bracketed"
    );
}

#[test]
fn every_shape_of_proxy_is_accepted_by_the_api_client() {
    for raw in [
        "socks5://127.0.0.1:1080",
        "socks5://alice:s3cret@127.0.0.1:1080",
        "http://proxy.example:8080",
        "http://alice:s3cret@proxy.example:8080",
        "socks5://[::1]:1080",
    ] {
        let upstream = Upstream::parse(raw).unwrap();
        assert!(
            upstream.as_reqwest_proxy().is_ok(),
            "{raw} should be usable for the api calls"
        );
    }
}

#[test]
fn an_http_status_line_is_read() {
    assert_eq!(
        http_status(b"HTTP/1.1 200 Connection established\r\n\r\n"),
        Some(200)
    );
    assert_eq!(
        http_status(b"HTTP/1.0 407 Proxy Authentication Required\r\n\r\n"),
        Some(407)
    );
    assert_eq!(http_status(b"NOTHTTP 200 OK\r\n\r\n"), None);
    assert_eq!(http_status(b""), None);
}
