use boring::pkey::PKey;
use boring::ssl::{SslContextBuilder, SslMethod, SslVerifyError, SslVerifyMode, SslVersion};
use boring::x509::X509;
use ring::digest;

use crate::transport::warp::consts;
use crate::error::{AetherError, Result};

/// The groups of the fingerprint, in order, unless --tls-groups names others.
const CHROME_GROUPS: &str = "P-256:X25519:P-384";

/// The TLS 1.2 cipher suites of the fingerprint unless --tls-ciphers names others: Chrome's
/// own rule, which BoringSSL orders as it does for Chrome, AES-GCM before ChaCha20 on
/// hardware with AES instructions and after it elsewhere.
pub const CHROME_CIPHERS: &str = "ALL:!aPSK:!ECDSA+SHA1:!3DES";

/// An option that sets TLS 1.2 cipher suites: a BoringSSL cipher string, names separated
/// by ':'. A ClientHello lists them after BoringSSL's own TLS 1.3 suites, which no cipher
/// string changes, and only where it offers TLS 1.2 as well.
#[derive(Debug)]
pub struct CipherOption {
    pub flag: &'static str,
    pub variable: &'static str,
}

/// --tls-ciphers: the TLS 1.2 cipher suites of the handshakes `Fingerprint` makes, in place
/// of Chrome's (`CHROME_CIPHERS`). HTTP/3 lists none: QUIC offers TLS 1.3 alone.
pub const TLS_CIPHERS: CipherOption = CipherOption {
    flag: "tls.ciphers",
    variable: "AETHER_TLS_CIPHERS",
};

impl CipherOption {
    /// The cipher string given to the option; None when it is not given.
    pub fn configured(&self) -> Option<String> {
        crate::config::settings::var(self.variable)
            .ok()
            .map(|value| value.trim().to_string())
            .filter(|value| !value.is_empty())
    }
}

/// Sets `list`, a BoringSSL cipher string, as the TLS 1.2 cipher suites of `builder`.
/// Strictly, through boring's set_strict_cipher_list (SSL_CTX_set_strict_cipher_list): a name
/// BoringSSL does not know is an error, which set_cipher_list would leave out without a word.
/// boring takes the error off the thread's error queue, where it would show in a later error.
pub fn set_tls12_ciphers(builder: &mut SslContextBuilder, list: &str) -> Result<()> {
    builder.set_strict_cipher_list(list).map_err(|_| {
        AetherError::Tls(format!(
            "{list:?} is no cipher list BoringSSL takes (cipher names separated by ':')"
        ))
    })
}

/// The TLS 1.2 cipher suites `list` names, in its order, as BoringSSL reads it: the number
/// and the name of each.
pub fn tls12_ciphers(list: &str) -> Result<Vec<(u16, &'static str)>> {
    let mut builder =
        SslContextBuilder::new(SslMethod::tls()).map_err(|e| AetherError::Tls(e.to_string()))?;
    set_tls12_ciphers(&mut builder, list)?;
    Ok(builder
        .ciphers()
        .map(|ciphers| {
            ciphers
                .iter()
                .map(|cipher| {
                    let name = cipher.standard_name().unwrap_or_else(|| cipher.name());
                    (cipher.protocol_id(), name)
                })
                .collect()
        })
        .unwrap_or_default())
}

/// Sets `groups`, a BoringSSL group list, names separated by ':', as the groups of `builder`,
/// in order.
fn set_groups(builder: &mut SslContextBuilder, groups: &str) -> Result<()> {
    builder.set_curves_list(groups).map_err(|_| {
        AetherError::Tls(format!(
            "{groups:?} is no group list BoringSSL takes (group names separated by ':')"
        ))
    })
}

/// The TLS fingerprint of the handshakes of the tunnel and its setup: MASQUE over HTTP/2 and
/// over HTTP/3, the calls to the WARP API and the DoH lookup of the ECH key, each with its
/// own ALPN.
/// It is Chrome's, as BoringSSL writes it, with what --tls-ciphers, --tls-groups and
/// --disable-grease change of it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Fingerprint {
    /// --tls-ciphers: the TLS 1.2 cipher suites in place of Chrome's, when given.
    pub ciphers: Option<String>,
    /// --tls-groups: the groups, in order; the first gets a key share.
    pub groups: String,
    /// GREASE values (RFC 8701) among the cipher suites, the extensions, the groups, the key
    /// shares and the versions, as Chrome sends them; --disable-grease leaves them out.
    pub grease: bool,
}

impl Default for Fingerprint {
    /// Chrome's, with none of the options given.
    fn default() -> Self {
        Fingerprint {
            ciphers: None,
            groups: CHROME_GROUPS.to_string(),
            grease: true,
        }
    }
}

impl Fingerprint {
    /// The fingerprint the options give: --tls-ciphers (AETHER_TLS_CIPHERS), --tls-groups
    /// (AETHER_TLS_GROUPS) and --disable-grease (AETHER_DISABLE_GREASE).
    pub fn configured() -> Self {
        let groups = crate::config::settings::var("AETHER_TLS_GROUPS")
            .ok()
            .map(|value| value.trim().to_string())
            .filter(|value| !value.is_empty());
        Fingerprint {
            ciphers: TLS_CIPHERS.configured(),
            groups: groups.unwrap_or_else(|| CHROME_GROUPS.to_string()),
            grease: !crate::config::settings::var("AETHER_DISABLE_GREASE")
                .is_ok_and(|value| crate::utils::fragment::is_truthy(&value)),
        }
    }

    /// Gives `builder` the fingerprint, offering `alpn`, in wire format: TLS 1.2 and 1.3, the
    /// groups, the extensions in a new order on each handshake, signed certificate timestamps
    /// and OCSP asked for, GREASE unless it is off, and the TLS 1.2 suites, Chrome's unless the
    /// cipher list names others. TLS server-certificate verification disabled (unconditional).
    pub fn apply(&self, builder: &mut SslContextBuilder, alpn: &[u8]) -> Result<()> {
        let tls = |error: boring::error::ErrorStack| AetherError::Tls(error.to_string());
        builder.set_verify(SslVerifyMode::NONE);
        builder
            .set_min_proto_version(Some(SslVersion::TLS1_2))
            .map_err(tls)?;
        builder
            .set_max_proto_version(Some(SslVersion::TLS1_3))
            .map_err(tls)?;
        builder.set_grease_enabled(self.grease);
        builder.set_permute_extensions(true);
        set_groups(builder, &self.groups)?;
        builder.set_alpn_protos(alpn).map_err(tls)?;
        builder.enable_signed_cert_timestamps();
        builder.enable_ocsp_stapling();
        set_tls12_ciphers(builder, self.ciphers.as_deref().unwrap_or(CHROME_CIPHERS))?;
        Ok(())
    }
}

/// Checks --tls-ciphers and --tls-groups as the core starts: a cipher string or a group list
/// BoringSSL does not take stops it, with the option named.
pub fn check_tls_options() -> Result<()> {
    let named = |flag: &str, e: AetherError| {
        let reason = match e {
            AetherError::Tls(reason) => reason,
            other => other.to_string(),
        };
        AetherError::Tls(format!("{flag}: {reason}"))
    };
    let fingerprint = Fingerprint::configured();
    if let Some(list) = &fingerprint.ciphers {
        tls12_ciphers(list).map_err(|e| named(TLS_CIPHERS.flag, e))?;
    }
    let mut builder =
        SslContextBuilder::new(SslMethod::tls()).map_err(|e| AetherError::Tls(e.to_string()))?;
    set_groups(&mut builder, &fingerprint.groups).map_err(|e| named("tls.groups", e))
}

/// The variables of the options the handshakes are made with: those of the fingerprint, and
/// --ech, and for MASQUE --masque-sni and the carrier.
#[cfg(test)]
const OPTION_VARIABLES: [&str; 6] = [
    "AETHER_ECH",
    "AETHER_TLS_CIPHERS",
    "AETHER_TLS_GROUPS",
    "AETHER_DISABLE_GREASE",
    "AETHER_MASQUE_SNI",
    "AETHER_MASQUE_HTTP2",
];

/// A hold on the options the handshakes are made with, which the whole process shares, for a
/// test that sets them, reads them through `Fingerprint::configured`, or makes a MASQUE
/// handshake: they start out clear, and are cleared again as it ends. A test that holds
/// AETHER_UPSTREAM as well takes that first.
#[cfg(test)]
pub(crate) struct OptionsHeld(#[expect(dead_code, reason = "held for its Drop")] tokio::sync::MutexGuard<'static, ()>);

#[cfg(test)]
impl Drop for OptionsHeld {
    fn drop(&mut self) {
        for variable in OPTION_VARIABLES {
            crate::config::settings::forget(variable);
        }
    }
}

/// Waits for the hold on the options of the handshakes, see `OptionsHeld`.
#[cfg(test)]
pub(crate) async fn hold_options() -> OptionsHeld {
    static OPTIONS: std::sync::OnceLock<tokio::sync::Mutex<()>> = std::sync::OnceLock::new();
    let held = OPTIONS
        .get_or_init(|| tokio::sync::Mutex::new(()))
        .lock()
        .await;
    for variable in OPTION_VARIABLES {
        crate::config::settings::forget(variable);
    }
    OptionsHeld(held)
}

pub struct TlsParams<'a> {
    pub cert_pem: &'a [u8],
    pub key_pem: &'a [u8],
    pub pin_endpoint: bool,
    /// SHA-256 SPKI hashes of expected server certificates for pin-based verification.
    /// When non-empty and `pin_endpoint` is true, the server cert's SPKI hash is checked
    /// against these pins instead of relying on standard CA chain validation.
    /// This allows the TLS handshake to succeed even when SNI is spoofed for DPI bypass,
    /// while still preventing MITM attacks.
    pub expected_pins: &'a [&'a [u8]],
}

/// Install TLS verification on an `SslContextBuilder`.
///
fn verify_enabled() -> bool {
    crate::config::settings::var("AETHER_TLS_VERIFY")
        .map(|v| matches!(v.trim().to_lowercase().as_str(), "1" | "true" | "yes" | "on"))
        .unwrap_or(false)
}

fn spki_sha256(cert: &boring::x509::X509Ref) -> Option<[u8; 32]> {
    let pubkey = cert.public_key().ok()?;
    let der = pubkey.public_key_to_der().ok()?;
    let hash = digest::digest(&digest::SHA256, &der);
    let mut out = [0u8; 32];
    out.copy_from_slice(hash.as_ref());
    Some(out)
}

pub fn install_verification(
    builder: &mut SslContextBuilder,
    pin_endpoint: bool,
    expected_pins: &[&[u8]],
) -> Result<()> {
    if !verify_enabled() {
        builder.set_verify(SslVerifyMode::NONE);
        announce_once(
            "tls verification: disabled (default; tls.verify enables pinning)".to_string(),
        );
        return Ok(());
    }

    if pin_endpoint && !expected_pins.is_empty() {
        let pins: Vec<Vec<u8>> = expected_pins.iter().map(|p| p.to_vec()).collect();
        builder.set_custom_verify_callback(SslVerifyMode::PEER, move |ssl| {
            let leaf_cert = ssl.peer_certificate().ok_or_else(|| {
                log::warn!("[tls] tls pin: no peer certificate presented");
                SslVerifyError::Invalid(boring::ssl::SslAlert::BAD_CERTIFICATE)
            })?;
            let hash = spki_sha256(&leaf_cert).ok_or_else(|| {
                log::warn!("[tls] tls pin: failed to compute SPKI hash");
                SslVerifyError::Invalid(boring::ssl::SslAlert::INTERNAL_ERROR)
            })?;
            if pins.iter().any(|pin| pin.as_slice() == hash.as_slice()) {
                Ok(())
            } else {
                Err(SslVerifyError::Invalid(
                    boring::ssl::SslAlert::CERTIFICATE_UNKNOWN,
                ))
            }
        });
        announce_once(format!(
            "tls verification: pin-based ({} pins loaded)",
            expected_pins.len()
        ));
    } else {
        builder.set_verify(SslVerifyMode::NONE);
        announce_once(
            "tls verification: none (tls.verify set but no pins configured)".to_string(),
        );
    }
    Ok(())
}

fn announce_once(message: String) {
    use std::sync::OnceLock;
    static ANNOUNCED: OnceLock<()> = OnceLock::new();
    if ANNOUNCED.set(()).is_ok() {
        log::info!("[tls] {message}");
    } else {
        log::debug!("[tls] {message}");
    }
}

pub fn build_config(params: &TlsParams) -> Result<quiche::Config> {
    let mut builder =
        SslContextBuilder::new(SslMethod::tls()).map_err(|e| AetherError::Tls(e.to_string()))?;

    let mut alpn = Vec::with_capacity(consts::ALPN_H3.len() + 1);
    alpn.push(consts::ALPN_H3.len() as u8);
    alpn.extend_from_slice(consts::ALPN_H3);
    Fingerprint::configured().apply(&mut builder, &alpn)?;
    // QUIC carries TLS 1.3 alone, so the TLS 1.2 suites of --tls-ciphers never show here.
    builder
        .set_min_proto_version(Some(SslVersion::TLS1_3))
        .map_err(|e| AetherError::Tls(e.to_string()))?;
    builder
        .set_max_proto_version(Some(SslVersion::TLS1_3))
        .map_err(|e| AetherError::Tls(e.to_string()))?;

    let cert = X509::from_pem(params.cert_pem).map_err(|e| AetherError::Tls(e.to_string()))?;
    let key =
        PKey::private_key_from_pem(params.key_pem).map_err(|e| AetherError::Tls(e.to_string()))?;
    builder
        .set_certificate(&cert)
        .map_err(|e| AetherError::Tls(e.to_string()))?;
    builder
        .set_private_key(&key)
        .map_err(|e| AetherError::Tls(e.to_string()))?;

    // Install TLS verification (pin-based or standard CA chain)
    install_verification(&mut builder, params.pin_endpoint, params.expected_pins)?;

    let mut config = quiche::Config::with_boring_ssl_ctx_builder(quiche::PROTOCOL_VERSION, builder)
        .map_err(AetherError::Quic)?;

    config
        .set_application_protos(&[consts::ALPN_H3])
        .map_err(AetherError::Quic)?;

    config.set_max_idle_timeout(120_000);
    config.set_max_recv_udp_payload_size(1350);
    config.set_max_send_udp_payload_size(1350);
    config.set_initial_max_data(10_000_000);
    config.set_initial_max_stream_data_bidi_local(2_000_000);
    config.set_initial_max_stream_data_bidi_remote(2_000_000);
    config.set_initial_max_stream_data_uni(2_000_000);
    config.set_initial_max_streams_bidi(100);
    config.set_initial_max_streams_uni(100);
    config.set_disable_active_migration(true);
    config.enable_dgram(true, 65536, 65536);

    Ok(config)
}

/// `retry`, the ECHConfigList a server handed back as it turned the offered one down, when
/// BoringSSL can offer it: a handshake given one it cannot would go without ECH.
pub fn usable_retry(retry: &[u8]) -> Option<Vec<u8>> {
    match check_ech_config_list(retry) {
        Ok(()) => Some(retry.to_vec()),
        Err(reason) => {
            log::warn!(
                "[tls] the server handed back an ECH key that cannot be offered ({reason}); not retrying with it"
            );
            None
        }
    }
}

pub fn decode_ech_config_list(b64: &str) -> Result<Vec<u8>> {
    use base64::Engine;
    base64::engine::general_purpose::STANDARD
        .decode(b64.trim())
        .map_err(|e| AetherError::Ech(format!("not base64: {e}")))
}

/// How the core says that it goes no further for want of an ECH key: with --ech given,
/// going on without a key it can offer would send a server name in the clear. An app that runs the core reads it to tell its user why it stopped.
pub const NO_ECH_KEY: &str = "ECH is on but there is no ECH key to offer";

/// An option that asks for an ECH key: its name and variable, what the key is for, and
/// what the core does rather than go without it.
pub struct EchOption {
    pub flag: &'static str,
    pub variable: &'static str,
    pub purpose: &'static str,
    pub refusal: &'static str,
}

/// --ech as the calls to the WARP API take it, which register and enroll the WARP keys.
pub const API_ECH_OPTION: EchOption = EchOption {
    flag: "tls.ech",
    variable: "AETHER_ECH",
    purpose: " for the WARP API",
    refusal: "not asking it rather than send its name in the clear",
};

/// The ECH key `option` asks for with the value `setting`: none without a value; with one,
/// the key it gives in base64, or with auto, the key `fetch` looks up. With a key asked for
/// and none BoringSSL can offer, an error that says NO_ECH_KEY and why.
pub async fn ech_key<F>(
    option: &EchOption,
    setting: Option<&str>,
    fetch: impl FnOnce() -> F,
) -> Result<Option<Vec<u8>>>
where
    F: std::future::Future<Output = Result<Vec<u8>>>,
{
    let (key, origin) = match setting {
        Some(v) if v.trim().eq_ignore_ascii_case("auto") => (
            fetch().await,
            "fetched ECHConfigList automatically".to_string(),
        ),
        Some(b64) if !b64.is_empty() => (
            decode_ech_config_list(b64).map_err(|e| match e {
                AetherError::Ech(reason) => {
                    AetherError::Ech(format!("the {} value is {reason}", option.flag))
                }
                other => other,
            }),
            format!("using ECHConfigList from {}", option.variable),
        ),
        _ => return Ok(None),
    };
    match key.and_then(|key| ensure_offerable(&key).map(|()| key)) {
        Ok(key) => {
            log::info!("[tls] {origin}{} ({} bytes)", option.purpose, key.len());
            Ok(Some(key))
        }
        Err(e) => {
            let reason = match e {
                AetherError::Ech(reason) => reason,
                other => other.to_string(),
            };
            Err(AetherError::Ech(format!(
                "{NO_ECH_KEY}{} ({reason}); {}",
                option.purpose, option.refusal
            )))
        }
    }
}

/// The ECHConfig version BoringSSL offers, which is the code point of the extension as well.
const ECH_CONFIG_VERSION: u16 = 0xfe0d;
/// The HPKE algorithms BoringSSL offers ECH with, as a client: one KEM, one KDF, and the
/// AEADs AES-128-GCM, AES-256-GCM and ChaCha20-Poly1305.
const HPKE_DHKEM_X25519_HKDF_SHA256: u16 = 0x0020;
const HPKE_HKDF_SHA256: u16 = 0x0001;
const HPKE_AEADS: [u16; 3] = [0x0001, 0x0002, 0x0003];
const X25519_PUBLIC_KEY_LEN: usize = 32;

/// `check_ech_config_list`, as the error of a handshake about to be given `list`.
pub fn ensure_offerable(list: &[u8]) -> Result<()> {
    check_ech_config_list(list)
        .map_err(|reason| AetherError::Ech(format!("the ECH key cannot be offered: {reason}")))
}

/// Whether BoringSSL offers ECH when it is given `list`, an ECHConfigList. BoringSSL takes
/// any list that parses, even one with no config it can use, and then sends the server
/// name in the clear (with a GREASE ECH extension), so a key is checked here before a
/// handshake is given it. The list has to parse as BoringSSL parses it, and the first
/// config BoringSSL picks from it has to hold an X25519 key. This follows
/// ssl/encrypted_client_hello.cc (parse_ech_config, ssl_is_valid_ech_public_name,
/// ssl_select_ech_config) of the BoringSSL that boring 4.22 builds.
pub fn check_ech_config_list(list: &[u8]) -> std::result::Result<(), String> {
    let malformed = || "it is no ECHConfigList".to_string();
    let mut whole = Fields(list);
    let mut configs = whole.u16_prefixed().ok_or_else(malformed)?;
    if configs.is_empty() || !whole.is_empty() {
        return Err(malformed());
    }
    // BoringSSL parses every config as it takes the list, and offers the first it can.
    let mut picked = None;
    while !configs.is_empty() {
        let config = ech_config(&mut configs).ok_or_else(malformed)?;
        picked = picked.or(config);
    }
    match picked {
        Some(key) if key.len() == X25519_PUBLIC_KEY_LEN => Ok(()),
        Some(_) => Err("the X25519 key of its config is not 32 bytes long".into()),
        None => Err(
            "it holds no config BoringSSL offers: ECH version 0xfe0d, X25519, and \
                     HKDF-SHA256 with AES-GCM or ChaCha20-Poly1305"
                .into(),
        ),
    }
}

/// Reads one ECHConfig off `configs` as BoringSSL's parse_ech_config does. None when it
/// does not parse, for which BoringSSL turns the whole list down; Some(None) for a config
/// BoringSSL passes over; its public key for one BoringSSL would offer.
fn ech_config<'a>(configs: &mut Fields<'a>) -> Option<Option<&'a [u8]>> {
    let version = configs.u16()?;
    let mut contents = configs.u16_prefixed()?;
    if version != ECH_CONFIG_VERSION {
        return Some(None);
    }
    let _config_id = contents.u8()?;
    let kem_id = contents.u16()?;
    let public_key = contents.u16_prefixed()?.0;
    let mut cipher_suites = contents.u16_prefixed()?;
    let _maximum_name_length = contents.u8()?;
    let public_name = contents.u8_prefixed()?.0;
    let mut extensions = contents.u16_prefixed()?;
    if public_key.is_empty()
        || cipher_suites.is_empty()
        || cipher_suites.0.len() % 4 != 0
        || public_name.is_empty()
        || !contents.is_empty()
    {
        return None;
    }
    // A config whose public name is invalid is passed over before its extensions are read.
    if !valid_public_name(public_name) {
        return Some(None);
    }
    let mut mandatory_extension = false;
    while !extensions.is_empty() {
        let kind = extensions.u16()?;
        extensions.u16_prefixed()?;
        mandatory_extension |= kind & 0x8000 != 0;
    }
    let mut cipher_suite = false;
    while !cipher_suites.is_empty() {
        let (kdf, aead) = (cipher_suites.u16()?, cipher_suites.u16()?);
        cipher_suite |= kdf == HPKE_HKDF_SHA256 && HPKE_AEADS.contains(&aead);
    }
    let offered = !mandatory_extension && kem_id == HPKE_DHKEM_X25519_HKDF_SHA256 && cipher_suite;
    Some(offered.then_some(public_key))
}

/// BoringSSL's ssl_is_valid_ech_public_name: dot-separated labels of 1 to 63 letters,
/// digits and hyphens, none starting or ending with a hyphen, the last of them no decimal
/// number and no 0x hex one.
fn valid_public_name(name: &[u8]) -> bool {
    let mut last: &[u8] = &[];
    for label in name.split(|&b| b == b'.') {
        let ldh = label
            .iter()
            .all(|&b| b.is_ascii_alphanumeric() || b == b'-');
        if label.is_empty()
            || label.len() > 63
            || label[0] == b'-'
            || label[label.len() - 1] == b'-'
            || !ldh
        {
            return false;
        }
        last = label;
    }
    let decimal = last.iter().all(u8::is_ascii_digit);
    let hex = last.len() >= 2
        && last[0] == b'0'
        && (last[1] == b'x' || last[1] == b'X')
        && last[2..].iter().all(u8::is_ascii_hexdigit);
    !decimal && !hex
}

/// The fields of an ECHConfigList, read in order as BoringSSL's CBS reads them.
struct Fields<'a>(&'a [u8]);

impl<'a> Fields<'a> {
    fn take(&mut self, len: usize) -> Option<&'a [u8]> {
        if self.0.len() < len {
            return None;
        }
        let (head, rest) = self.0.split_at(len);
        self.0 = rest;
        Some(head)
    }

    fn u8(&mut self) -> Option<u8> {
        self.take(1).map(|b| b[0])
    }

    fn u16(&mut self) -> Option<u16> {
        self.take(2).map(|b| u16::from_be_bytes([b[0], b[1]]))
    }

    fn u8_prefixed(&mut self) -> Option<Fields<'a>> {
        let len = self.u8()?;
        self.take(len.into()).map(Fields)
    }

    fn u16_prefixed(&mut self) -> Option<Fields<'a>> {
        let len = self.u16()?;
        self.take(len.into()).map(Fields)
    }

    fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

#[cfg(test)]
mod tests;

/// A ClientHello as a server reads it, and a server on this machine that reads one and hangs
/// up, for the tests of the handshakes that list cipher suites.
#[cfg(test)]
pub(crate) mod client_hello {
    use tokio::io::AsyncReadExt;

    pub struct ClientHello {
        /// The cipher suites, in order.
        pub suites: Vec<u16>,
        /// The extensions, in order: their type and what they carry.
        pub extensions: Vec<(u16, Vec<u8>)>,
    }

    /// Whether `value` is a GREASE value (RFC 8701).
    fn grease(value: u16) -> bool {
        value & 0x0f0f == 0x0a0a && value >> 8 == value & 0xff
    }

    fn be16(bytes: &[u8], at: usize) -> usize {
        u16::from_be_bytes([bytes[at], bytes[at + 1]]) as usize
    }

    impl ClientHello {
        fn extension(&self, kind: u16) -> Option<&[u8]> {
            self.extensions
                .iter()
                .find(|(k, _)| *k == kind)
                .map(|(_, data)| data.as_slice())
        }

        /// The TLS 1.2 cipher suites: GREASE and the TLS 1.3 ones left out.
        pub fn tls12_suites(&self) -> Vec<u16> {
            self.suites
                .iter()
                .copied()
                .filter(|suite| !grease(*suite) && !(0x1301..=0x1305).contains(suite))
                .collect()
        }

        /// The versions of supported_versions, GREASE left out.
        pub fn versions(&self) -> Vec<u16> {
            let data = self.extension(43).expect("supported_versions");
            data[1..1 + data[0] as usize]
                .chunks(2)
                .map(|pair| u16::from_be_bytes([pair[0], pair[1]]))
                .filter(|version| !grease(*version))
                .collect()
        }

        /// The name in server_name.
        pub fn server_name(&self) -> Option<String> {
            let data = self.extension(0)?;
            Some(String::from_utf8_lossy(&data[5..5 + be16(data, 3)]).into_owned())
        }

        /// Whether it offers ECH: encrypted_client_hello.
        pub fn offers_ech(&self) -> bool {
            self.extension(0xfe0d).is_some()
        }

        /// The protocols of application_layer_protocol_negotiation, in order.
        pub fn alpn(&self) -> Vec<Vec<u8>> {
            let data = self.extension(16).expect("ALPN");
            let mut protocols = Vec::new();
            let mut at = 2;
            while at < data.len() {
                let len = data[at] as usize;
                protocols.push(data[at + 1..at + 1 + len].to_vec());
                at += 1 + len;
            }
            protocols
        }

        /// Whether a GREASE value leads its cipher suites.
        pub fn has_grease(&self) -> bool {
            self.suites.first().is_some_and(|suite| grease(*suite))
        }

        /// Whether one of its extensions is a GREASE one.
        pub fn has_grease_extension(&self) -> bool {
            self.extensions.iter().any(|(kind, _)| grease(*kind))
        }

        /// Whether it carries the extension `kind`.
        pub fn has_extension(&self, kind: u16) -> bool {
            self.extension(kind).is_some()
        }

        /// The types of its extensions, in order.
        pub fn extension_types(&self) -> Vec<u16> {
            self.extensions.iter().map(|(kind, _)| *kind).collect()
        }

        /// The groups of supported_groups, in order, GREASE left out.
        pub fn groups(&self) -> Vec<u16> {
            let data = self.extension(10).expect("supported_groups");
            data[2..2 + be16(data, 0)]
                .chunks(2)
                .map(|pair| u16::from_be_bytes([pair[0], pair[1]]))
                .filter(|group| !grease(*group))
                .collect()
        }

        /// The groups of the shares of key_share, in order, GREASE left out.
        pub fn key_shares(&self) -> Vec<u16> {
            let data = self.extension(51).expect("key_share");
            let mut groups = Vec::new();
            let mut at = 2;
            while at + 4 <= data.len() {
                let group = be16(data, at) as u16;
                if !grease(group) {
                    groups.push(group);
                }
                at += 4 + be16(data, at + 2);
            }
            groups
        }
    }

    /// The ClientHello in `record`, a TLS record as it goes over the wire.
    pub fn parse(record: &[u8]) -> ClientHello {
        assert_eq!(record[0], 0x16, "a handshake record");
        let message = &record[5..5 + be16(record, 3)];
        assert_eq!(message[0], 1, "a ClientHello");
        let hello = &message[4..];
        let mut at = 2 + 32;
        at += 1 + hello[at] as usize;
        let suites = hello[at + 2..at + 2 + be16(hello, at)]
            .chunks(2)
            .map(|pair| u16::from_be_bytes([pair[0], pair[1]]))
            .collect();
        at += 2 + be16(hello, at);
        at += 1 + hello[at] as usize;
        let end = at + 2 + be16(hello, at);
        at += 2;
        let mut extensions = Vec::new();
        while at + 4 <= end {
            let len = be16(hello, at + 2);
            extensions.push((be16(hello, at) as u16, hello[at + 4..at + 4 + len].to_vec()));
            at += 4 + len;
        }
        ClientHello { suites, extensions }
    }

    /// Chrome's TLS 1.2 suites, in the order BoringSSL gives Chrome's rule on this machine,
    /// which depends on its AES hardware.
    pub fn chrome_tls12_suites() -> Vec<u16> {
        super::tls12_ciphers(super::CHROME_CIPHERS)
            .expect("Chrome's rule")
            .iter()
            .map(|(id, _)| *id)
            .collect()
    }

    /// Listens on this machine: the task ends with the first ClientHello sent there, read
    /// before the server hangs up, and fails when none comes within ten seconds.
    pub async fn catch() -> (std::net::SocketAddr, tokio::task::JoinHandle<ClientHello>) {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("a port");
        let address = listener.local_addr().expect("its address");
        let caught = tokio::spawn(async move {
            let (mut tcp, _) =
                tokio::time::timeout(std::time::Duration::from_secs(10), listener.accept())
                    .await
                    .expect("a connection within ten seconds")
                    .expect("a connection");
            let mut record = vec![0u8; 5];
            tcp.read_exact(&mut record).await.expect("a record header");
            let len = be16(&record, 3);
            record.resize(5 + len, 0);
            tcp.read_exact(&mut record[5..]).await.expect("the record");
            parse(&record)
        });
        (address, caught)
    }
}
