use super::*;

fn headers() -> Vec<(String, String)> {
    vec![
        ("Content-Type".to_string(), "application/json".to_string()),
        ("CF-Client-Version".to_string(), "a-test".to_string()),
    ]
}

/// The length of the TLS record that starts `seen`, its header included.
fn record_len(seen: &[u8]) -> usize {
    5 + u16::from_be_bytes([seen[3], seen[4]]) as usize
}

/// The TLS record a server gets first on a connection, and the size of each read it took.
async fn first_record(listener: tokio::net::TcpListener) -> (Vec<u8>, Vec<usize>) {
    let (mut tcp, _) = listener.accept().await.expect("a connection");
    let mut seen = Vec::new();
    let mut reads = Vec::new();
    let mut chunk = [0u8; 4096];
    while seen.len() < 5 || seen.len() < record_len(&seen) {
        let read = tcp.read(&mut chunk).await.expect("the hello");
        if read == 0 {
            break;
        }
        reads.push(read);
        seen.extend_from_slice(&chunk[..read]);
    }
    (seen, reads)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_fragmented_client_hello_reaches_the_server_in_pieces() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let headers = headers();
    let fragment = FragmentConfig {
        enabled: true,
        size_min: 64,
        size_max: 64,
        delay_min_ms: 50,
        delay_max_ms: 50,
        sni_split: false,
    };
    for pieces in [Some(fragment), None] {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .expect("a listener");
        let port = listener.local_addr().expect("its address").port();
        let served = tokio::spawn(first_record(listener));
        let request = Request {
            method: "GET",
            host: "127.0.0.1",
            port,
            address: None,
            sni: Some("api.cloudflareclient.com"),
            path: "/",
            headers: &headers,
            body: None,
        };
        // No server answers it: the ClientHello is all this is about.
        let timeout = Duration::from_secs(10);
        let _ = match pieces {
            Some(fragment) => {
                send_fragmented(&request, &Fingerprint::default(), None, timeout, fragment)
                    .await
            }
            None => send(&request, &Fingerprint::default(), None, timeout).await,
        };

        let (seen, reads) = served.await.expect("the server");
        assert_eq!(&seen[..2], &[0x16, 0x03], "a TLS handshake record");
        assert_eq!(seen.len(), record_len(&seen));
        if pieces.is_some() {
            assert!(reads.iter().all(|&read| read <= 64), "{reads:?}");
            assert!(reads.len() >= seen.len() / 64, "{reads:?}");
        } else {
            assert!(reads[0] > 64, "{reads:?}");
        }
    }
}

#[tokio::test]
async fn a_request_goes_over_http2_when_the_server_picks_it() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let (address, listener, acceptor) = test_server(b"\x02h2").await;
    let served = tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.expect("a connection");
        let tls = tokio_boring::accept(&acceptor, tcp)
            .await
            .expect("a handshake");
        let mut connection = h2::server::handshake(tls).await.expect("an h2 connection");
        let (request, mut respond) = connection
            .accept()
            .await
            .expect("a request")
            .expect("a whole request");
        let (parts, mut body) = request.into_parts();
        let mut sent = Vec::new();
        while let Some(chunk) = body.data().await {
            sent.extend_from_slice(&chunk.expect("the body"));
        }
        // The client turned server push off in its settings, as Chrome does.
        let push = http::Request::get("https://127.0.0.1/pushed")
            .body(())
            .unwrap();
        assert!(respond.push_request(push).is_err(), "a push went through");
        let answer = http::Response::builder()
            .status(429)
            .header("retry-after", "7")
            .body(())
            .unwrap();
        let mut stream = respond.send_response(answer, false).expect("an answer");
        stream
            .send_data(Bytes::from_static(b"{\"slow\":\"down\"}"), true)
            .expect("its body");
        // Drives the connection until the client goes away.
        while let Some(Ok(_)) = connection.accept().await {}
        (parts, sent)
    });

    let headers = headers();
    let request = Request {
        method: "POST",
        host: "127.0.0.1",
        port: address.port(),
        address: None,
        sni: None,
        path: "/v0a4471/reg",
        headers: &headers,
        body: Some(b"{\"key\":\"x\"}"),
    };
    let response = send(
        &request,
        &Fingerprint::default(),
        None,
        Duration::from_secs(10),
    )
    .await
    .expect("an answer");
    assert_eq!(response.protocol, "h2");
    assert_eq!(response.status, 429);
    assert_eq!(response.headers["retry-after"], "7");
    assert_eq!(response.body, b"{\"slow\":\"down\"}");

    let (parts, sent) = served.await.expect("the server");
    assert_eq!(parts.method, "POST");
    assert_eq!(
        parts.uri.to_string(),
        format!("https://127.0.0.1:{}/v0a4471/reg", address.port())
    );
    assert_eq!(parts.headers["cf-client-version"], "a-test");
    assert_eq!(parts.headers["content-length"], "11");
    assert_eq!(sent, b"{\"key\":\"x\"}");
}

#[tokio::test]
async fn a_request_goes_over_http1_otherwise_and_ends_with_its_answer() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let (address, listener, acceptor) = test_server(b"\x08http/1.1").await;
    let served = tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.expect("a connection");
        let mut tls = tokio_boring::accept(&acceptor, tcp)
            .await
            .expect("a handshake");
        let mut sent = Vec::new();
        let mut chunk = [0u8; 4096];
        while !sent.windows(4).any(|window| window == b"\r\n\r\n") {
            let read = tls.read(&mut chunk).await.expect("the request");
            sent.extend_from_slice(&chunk[..read]);
        }
        tls.write_all(
            b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nok\r\n3\r\n-h1\r\n0\r\n\r\n",
        )
        .await
        .expect("the answer");
        // The connection stays open: the client has to see that the answer is whole.
        let _ = tokio::time::timeout(Duration::from_secs(10), tls.read(&mut chunk)).await;
        String::from_utf8_lossy(&sent).into_owned()
    });

    let headers = headers();
    let request = Request {
        method: "GET",
        host: "127.0.0.1",
        port: address.port(),
        address: None,
        sni: None,
        path: "/v0a4471/reg/a-device?x=1",
        headers: &headers,
        body: None,
    };
    let response = send(
        &request,
        &Fingerprint::default(),
        None,
        Duration::from_secs(5),
    )
    .await
    .expect("an answer before the connection ends");
    assert_eq!(response.protocol, "http/1.1");
    assert_eq!(response.status, 200);
    assert_eq!(response.body, b"ok-h1");

    let sent = served.await.expect("the server");
    assert!(sent.starts_with(&format!(
        "GET /v0a4471/reg/a-device?x=1 HTTP/1.1\r\nHost: 127.0.0.1:{}\r\n",
        address.port()
    )));
    assert!(sent.contains("CF-Client-Version: a-test\r\n"));
    assert!(sent.ends_with("Connection: close\r\n\r\n"));
    assert!(!sent.contains("Content-Length"));
}

/// The ClientHello of a request to `host` on this machine with `fingerprint`, offering
/// `ech` when given, as the server reads it before it hangs up.
async fn hello(
    host: &str,
    fingerprint: &Fingerprint,
    ech: Option<&mut Vec<u8>>,
) -> crate::transport::warp::net::tls::client_hello::ClientHello {
    let (address, hello) = crate::transport::warp::net::tls::client_hello::catch().await;
    let headers = headers();
    let request = Request {
        method: "GET",
        host,
        port: address.port(),
        address: Some(("127.0.0.1", address.port())),
        sni: None,
        path: "/",
        headers: &headers,
        body: None,
    };
    assert!(send(&request, fingerprint, ech, Duration::from_secs(10))
        .await
        .is_err());
    hello.await.expect("the ClientHello")
}

#[tokio::test]
async fn the_client_hello_is_the_fingerprints_with_http2_first() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let own = hello("api.example.test", &Fingerprint::default(), None).await;
    assert_eq!(own.alpn(), [b"h2".to_vec(), b"http/1.1".to_vec()]);
    assert_eq!(own.versions(), [0x0304, 0x0303]);
    assert_eq!(own.server_name().as_deref(), Some("api.example.test"));
    assert!(own.has_grease());
    assert!(!own.offers_ech());
    assert_eq!(
        own.tls12_suites(),
        crate::transport::warp::net::tls::client_hello::chrome_tls12_suites()
    );

    // Every name BoringSSL knows, AES256-SHA among them, in the list's order.
    let changed = Fingerprint {
        ciphers: Some(
            "ECDHE-ECDSA-CHACHA20-POLY1305:AES256-SHA:ECDHE-RSA-AES128-GCM-SHA256".to_string(),
        ),
        groups: "X25519:P-256".to_string(),
        grease: false,
    };
    let listed = hello("api.example.test", &changed, None).await;
    assert_eq!(listed.tls12_suites(), [0xcca9, 0x0035, 0xc02f]);
    assert_eq!(listed.groups(), [0x001d, 0x0017]);
    assert!(!listed.has_grease());
    assert_eq!(listed.alpn(), own.alpn());
}

/// Cloudflare's key of cloudflare-ech.com on 2026-10-01.
const CLOUDFLARE_ECH: &str =
    "AEX+DQBBrwAgACCbK1mYDYFz/BAn6S5t+Q/v+Oej3eFNxtPWgz50fNnFPAAEAAEAAQASY2xvdWRmbGFyZS1lY2guY29tAAA=";

#[tokio::test]
async fn with_an_ech_key_the_name_goes_inside_the_encrypted_client_hello() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let mut ech = crate::transport::warp::net::tls::decode_ech_config_list(CLOUDFLARE_ECH).expect("base64");
    let outer = hello("api.example.test", &Fingerprint::default(), Some(&mut ech)).await;
    assert!(outer.offers_ech());
    // The key's public name in the clear, the host only inside.
    assert_eq!(outer.server_name().as_deref(), Some("cloudflare-ech.com"));
    // As Chrome's, the outer ClientHello offers TLS 1.2 as well, with the fingerprint's
    // suites; a server that answers with TLS 1.2 has turned the ECH down.
    assert_eq!(outer.versions(), [0x0304, 0x0303]);
    assert_eq!(
        outer.tls12_suites(),
        crate::transport::warp::net::tls::client_hello::chrome_tls12_suites()
    );
    assert_eq!(outer.alpn(), [b"h2".to_vec(), b"http/1.1".to_vec()]);
}

#[tokio::test]
async fn a_key_that_cannot_be_offered_goes_no_further() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
        .await
        .expect("a port");
    let headers = headers();
    let port = listener.local_addr().expect("its address").port();
    let request = Request {
        method: "GET",
        host: "api.example.test",
        port,
        address: Some(("127.0.0.1", port)),
        sni: None,
        path: "/",
        headers: &headers,
        body: None,
    };
    // BoringSSL would take this list and offer nothing from it: its only config is of
    // another version, so the name would go in the clear.
    let mut unusable = vec![0, 6, 0xfe, 0x0c, 0, 2, 0, 0];
    let refused = send(
        &request,
        &Fingerprint::default(),
        Some(&mut unusable),
        Duration::from_secs(5),
    )
    .await
    .expect_err("no request without ECH");
    assert!(
        refused.to_string().contains("cannot be offered"),
        "{refused}"
    );
    assert!(
        tokio::time::timeout(Duration::from_millis(300), listener.accept())
            .await
            .is_err(),
        "nothing was sent"
    );
}

/// The server name of the ClientHello and the :authority of a request to `host` on this
/// machine, sent to `address` with `sni` when given. The host is on the port the server
/// listens on, or on `port` when given, as the address is on the server's port.
async fn server_name_and_authority(
    host: &str,
    port: Option<u16>,
    address: Option<&str>,
    sni: Option<&str>,
) -> (Option<String>, String) {
    let (listening, listener, acceptor) = test_server(b"\x02h2").await;
    let served = tokio::spawn(async move {
        let (tcp, _) = listener.accept().await.expect("a connection");
        let tls = tokio_boring::accept(&acceptor, tcp)
            .await
            .expect("a handshake");
        let name = tls
            .ssl()
            .servername(boring::ssl::NameType::HOST_NAME)
            .map(str::to_string);
        let mut connection = h2::server::handshake(tls).await.expect("h2");
        let (request, mut respond) = connection
            .accept()
            .await
            .expect("a request")
            .expect("a whole request");
        let authority = request.uri().authority().expect("an authority").to_string();
        let answer = http::Response::builder().status(204).body(()).unwrap();
        respond.send_response(answer, true).expect("an answer");
        while let Some(Ok(_)) = connection.accept().await {}
        (name, authority)
    });
    let headers = headers();
    let request = Request {
        method: "GET",
        host,
        port: port.unwrap_or(listening.port()),
        address: address.map(|address| (address, listening.port())),
        sni,
        path: "/",
        headers: &headers,
        body: None,
    };
    let response = send(
        &request,
        &Fingerprint::default(),
        None,
        Duration::from_secs(10),
    )
    .await
    .expect("an answer");
    assert_eq!(response.status, 204);
    served.await.expect("the server")
}

#[tokio::test]
async fn a_request_goes_to_its_address_with_its_server_name_and_its_host() {
    let _setting = crate::transport::warp::net::upstream::hold_setting().await;
    let (name, authority) = server_name_and_authority(
        "doh.example.test",
        None,
        Some("127.0.0.1"),
        Some("front.example.test"),
    )
    .await;
    assert_eq!(name.as_deref(), Some("front.example.test"));
    assert!(authority.starts_with("doh.example.test:"), "{authority}");

    // Without them the host is all three: the address, the server name and the HTTP host.
    let (name, authority) = server_name_and_authority("localhost", None, None, None).await;
    assert_eq!(name.as_deref(), Some("localhost"));
    assert!(authority.starts_with("localhost:"), "{authority}");

    // An address on a port of its own: the connection goes there, while the host keeps
    // its port, 443, which the authority leaves out.
    let (name, authority) =
        server_name_and_authority("api.example.test", Some(443), Some("127.0.0.1"), None).await;
    assert_eq!(name.as_deref(), Some("api.example.test"));
    assert_eq!(authority, "api.example.test");
}

/// Whether `raw` is a whole HTTP/1.1 answer, read at once. Read a byte at a time, it has
/// to turn whole on its last byte and not before.
fn whole(raw: &[u8]) -> bool {
    let at_once = Http1Answer::default().push(raw).expect("an answer so far");
    let mut answer = Http1Answer::default();
    for (index, byte) in raw.iter().enumerate() {
        let now = answer
            .push(std::slice::from_ref(byte))
            .expect("an answer so far");
        assert_eq!(now, at_once && index + 1 == raw.len(), "byte {index}");
    }
    at_once
}

/// `raw` read as an HTTP/1.1 answer that the connection ends after.
fn read(raw: &[u8]) -> Result<Answer> {
    let mut answer = Http1Answer::default();
    answer.push(raw)?;
    answer.finish()
}

#[test]
fn an_answer_is_whole_by_its_length_or_its_last_chunk() {
    assert!(whole(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok"));
    assert!(!whole(b"HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nok"));
    assert!(!whole(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n"));
    assert!(!whole(b"HTTP/1.1 200 OK\r\nServer: x\r\n\r\nok"));
    // A 204 ends with its head.
    assert!(whole(b"HTTP/1.1 204 No Content\r\nServer: x\r\n\r\n"));

    assert!(whole(
        b"HTTP/1.1 200 OK\r\ntransfer-encoding: Chunked\r\n\r\n2\r\nok\r\n0\r\n\r\n"
    ));
    // The bytes of a last chunk at the end of a chunk's data end nothing.
    assert!(!whole(
        b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n9\r\nabcd0\r\n\r\n"
    ));
    // A trailer comes before the end.
    assert!(!whole(
        b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nX-Sum: 1\r\n"
    ));
    assert!(whole(
        b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nX-Sum: 1\r\n\r\n"
    ));
    // Chunk sizes with leading zeros, in upper case, with an extension.
    assert!(whole(
        b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n00A;x=y\r\n0123456789\r\n0\r\n\r\n"
    ));
}

#[test]
fn a_plain_answer_is_parsed() {
    let raw = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{\"id\":\"x\"}";
    let (status, fields, body) = read(raw).expect("parsed");
    assert_eq!(status, 200);
    assert_eq!(
        fields,
        [("Content-Type".to_string(), "application/json".to_string())]
    );
    assert_eq!(body, b"{\"id\":\"x\"}");
}

#[test]
fn a_chunked_answer_is_joined() {
    let raw = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n4\r\n{\"a\"\r\n4\r\n:1}\n\r\n0\r\n\r\n";
    let (status, _, body) = read(raw).expect("parsed");
    assert_eq!(status, 200);
    assert_eq!(body, b"{\"a\":1}\n");
}

#[test]
fn a_rejection_is_reported_rather_than_hidden() {
    let raw = b"HTTP/1.1 429 Too Many Requests\r\nRetry-After: 30\r\n\r\nslow down";
    let (status, fields, body) = read(raw).expect("parsed");
    assert_eq!(status, 429);
    assert!(fields.contains(&("Retry-After".to_string(), "30".to_string())));
    assert_eq!(body, b"slow down");
}

#[test]
fn a_headless_answer_is_an_error() {
    assert!(read(b"garbage").is_err());
    assert!(read(b"").is_err());
    assert!(read(b"\r\n\r\n").is_err());
}

#[test]
fn a_chunked_body_is_joined_on_bytes_without_panicking() {
    let text = "ééé".as_bytes();
    let mut raw = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n".to_vec();
    raw.extend_from_slice(format!("{:x}\r\n", 3).as_bytes());
    raw.extend_from_slice(&text[..3]);
    raw.extend_from_slice(format!("\r\n{:x}\r\n", text.len() - 3).as_bytes());
    raw.extend_from_slice(&text[3..]);
    raw.extend_from_slice(b"\r\n0\r\n\r\n");
    assert!(whole(&raw));
    let (status, _, body) = read(&raw).expect("parsed");
    assert_eq!(status, 200);
    assert_eq!(body, text);
}

#[test]
fn what_is_no_chunked_body_is_an_error() {
    let chunked = |body: &[u8]| {
        let mut raw = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n".to_vec();
        raw.extend_from_slice(body);
        Http1Answer::default().push(&raw)
    };
    // A chunk size past what memory holds overflows nothing.
    assert!(chunked(b"ffffffffffffffff\r\nabc").is_err());
    assert!(chunked(b"zz\r\nabc").is_err());
    assert!(chunked(b"\r\nabc").is_err());
    assert!(chunked(b"2\r\nokX\r\n0\r\n\r\n").is_err());
    assert!(chunked(&vec![b'1'; MAX_LINE + 1]).is_err());
}

#[test]
fn an_answer_the_connection_cuts_short_is_an_error_not_a_body() {
    let cut = read(b"HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\nabc").expect_err("cut");
    assert!(cut.to_string().contains("3 of its 10 bytes"), "{cut}");
    assert!(read(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nok\r\n").is_err());
    assert!(read(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n").is_err());
    assert!(read(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n").is_err());
    assert!(read(b"HTTP/1.1 200 OK\r\nContent-Length: two\r\n\r\nok").is_err());
}

#[test]
fn a_body_ends_where_its_head_says() {
    // Past Content-Length, nothing belongs to the answer.
    let (_, _, body) = read(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nokEXTRA").unwrap();
    assert_eq!(body, b"ok");
    // Chunked goes before a Content-Length (RFC 9112, 6.3).
    let both = b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\nTransfer-Encoding: chunked\r\n\r\n";
    let mut raw = both.to_vec();
    raw.extend_from_slice(b"5\r\nhe");
    assert!(!Http1Answer::default().push(&raw).unwrap());
    assert!(read(&raw).is_err());
    raw.extend_from_slice(b"llo\r\n0\r\n\r\n");
    assert!(whole(&raw));
    assert_eq!(read(&raw).unwrap().2, b"hello");
}

#[test]
fn an_interim_answer_is_passed_over() {
    let raw = b"HTTP/1.1 103 Early Hints\r\nLink: </a>\r\n\r\nHTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok";
    assert!(whole(raw));
    let (status, fields, body) = read(raw).expect("parsed");
    assert_eq!(status, 200);
    assert_eq!(fields, [("Content-Length".to_string(), "2".to_string())]);
    assert_eq!(body, b"ok");
}

#[test]
fn an_answer_that_comes_a_byte_at_a_time_is_read_in_linear_time() {
    // Chunks of one byte, the most lines an answer can have, then a head that never ends:
    // each read looks at its own bytes, not at all that came before.
    let mut chunked = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n".to_vec();
    while chunked.len() < 200 * 1024 {
        chunked.extend_from_slice(b"1\r\na\r\n");
    }
    chunked.extend_from_slice(b"0\r\n\r\n");
    let endless_head = [b'x'; 200 * 1024];
    let started = std::time::Instant::now();
    for raw in [&chunked[..], &endless_head[..]] {
        let mut answer = Http1Answer::default();
        let mut ended = false;
        for byte in raw {
            ended = answer
                .push(std::slice::from_ref(byte))
                .expect("an answer so far");
        }
        assert_eq!(ended, raw.len() == chunked.len());
    }
    assert!(
        started.elapsed() < Duration::from_secs(3),
        "{:?}",
        started.elapsed()
    );
}

#[test]
fn an_authority_brackets_ipv6_and_leaves_out_port_443() {
    assert_eq!(
        authority("api.cloudflareclient.com", 443),
        "api.cloudflareclient.com"
    );
    assert_eq!(authority("1.1.1.1", 8443), "1.1.1.1:8443");
    assert_eq!(authority("2606:4700::1111", 443), "[2606:4700::1111]");
    assert_eq!(authority("::1", 853), "[::1]:853");
}
