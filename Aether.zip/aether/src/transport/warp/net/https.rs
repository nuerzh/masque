//! HTTPS over BoringSSL for the calls that are not tunnels: the calls to the WARP API and the
//! DoH lookup of the ECH key. The ClientHello is the core's fingerprint (see
//! `tls::Fingerprint`), offering HTTP/2 then HTTP/1.1, and ECH when the caller gives a key; the
//! request goes over HTTP/2 when the server picks it, over HTTP/1.1 otherwise.

use std::time::Duration;

use boring::ssl::{ConnectConfiguration, SslConnector, SslMethod};
use bytes::Bytes;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::net::TcpStream;

use crate::error::{AetherError, Result};
use crate::utils::fragment::{FragmentConfig, FragmentingStream};
use crate::transport::warp::net::tls::Fingerprint;

/// An HTTP answer: its status, header fields and body.
type Answer = (u16, Vec<(String, String)>, Vec<u8>);

/// ALPN: HTTP/2, then HTTP/1.1, as Chrome offers them.
const ALPN_H2_HTTP1: &[u8] = b"\x02h2\x08http/1.1";

/// The most of an answer that is read.
const MAX_BODY: usize = 512 * 1024;

/// The largest header list an HTTP/2 answer may have: Chrome's.
const MAX_HEADER_LIST: u32 = 256 * 1024;

/// The longest line of a chunked body, a chunk size or a field of its trailer, that is read.
const MAX_LINE: usize = 8 * 1024;

/// A request: `host` is the HTTP host, of Host or :authority, a name or an IP address, an IPv6
/// one without brackets, on `port`, which Host and :authority leave out when it is 443, and
/// `path` the path with its query. The connection goes to `host` on `port`, and the ClientHello
/// names `host`, unless `address` and `sni` name others; offering ECH, the name goes inside the
/// encrypted ClientHello.
pub struct Request<'a> {
    pub method: &'a str,
    pub host: &'a str,
    pub port: u16,
    /// Where the connection goes instead of `host` on `port`: a name or an IP address, and its
    /// port.
    pub address: Option<(&'a str, u16)>,
    /// The server name of the ClientHello instead of `host`.
    pub sni: Option<&'a str>,
    pub path: &'a str,
    pub headers: &'a [(String, String)],
    pub body: Option<&'a [u8]>,
}

/// An answer, read to its end.
#[derive(Debug)]
pub struct Response {
    pub status: u16,
    pub headers: http::HeaderMap,
    pub body: Vec<u8>,
    /// The protocol the server picked: "h2" or "http/1.1".
    #[cfg_attr(not(test), expect(dead_code, reason = "checked by the tests of the ALPN choice"))]
    pub protocol: &'static str,
}

/// Sends `request` with the TLS fingerprint `fingerprint`, and gives up after `timeout`. With
/// `ech`, an ECHConfigList, the handshake offers it and goes no further without it: a server
/// that turns it down hands back the key it holds now, which takes its place in `ech`, and the
/// handshake is made once more with that one.
pub async fn send(
    request: &Request<'_>,
    fingerprint: &Fingerprint,
    ech: Option<&mut Vec<u8>>,
    timeout: Duration,
) -> Result<Response> {
    send_fragmented(
        request,
        fingerprint,
        ech,
        timeout,
        FragmentConfig::disabled(),
    )
    .await
}

/// `send`, with the ClientHello written to the connection in pieces, sized and spaced as
/// `fragment` has them, the way `--fragment` writes the one of MASQUE over HTTP/2. Nothing after
/// it is cut up.
pub async fn send_fragmented(
    request: &Request<'_>,
    fingerprint: &Fingerprint,
    ech: Option<&mut Vec<u8>>,
    timeout: Duration,
    fragment: FragmentConfig,
) -> Result<Response> {
    tokio::time::timeout(timeout, exchange(request, fingerprint, ech, fragment))
        .await
        .map_err(|_| {
            AetherError::Api(format!(
                "{} did not answer within {}s",
                authority(request.host, request.port),
                timeout.as_secs()
            ))
        })?
}

async fn exchange(
    request: &Request<'_>,
    fingerprint: &Fingerprint,
    mut ech: Option<&mut Vec<u8>>,
    fragment: FragmentConfig,
) -> Result<Response> {
    let (address, port) = request.address.unwrap_or((request.host, request.port));
    let mut retried = false;
    let tls = loop {
        let mut config = configuration(fingerprint)?;
        if let Some(list) = ech.as_deref() {
            // BoringSSL takes a key it offers nothing from, and the name would go in the clear.
            crate::transport::warp::net::tls::ensure_offerable(list)?;
            config
                .set_ech_config_list(list)
                .map_err(|e| AetherError::Tls(e.to_string()))?;
        }
        let tcp = dial(address, port).await?;
        let _ = tcp.set_nodelay(true);
        let stream = FragmentingStream::new(tcp, fragment);
        match tokio_boring::connect(config, request.sni.unwrap_or(request.host), stream).await {
            Ok(tls) => break tls,
            Err(e) => {
                let message = e.to_string();
                // BoringSSL reports a key the server turned down as ECH_REJECTED, and only then
                // hands out the key the server sent back.
                let retry = match ech.as_deref_mut() {
                    Some(list) if !retried && message.contains("ECH_REJECTED") => e
                        .ssl()
                        .and_then(|ssl| ssl.get_ech_retry_configs())
                        .filter(|configs| !configs.is_empty())
                        .and_then(crate::transport::warp::net::tls::usable_retry)
                        .map(|retry| (list, retry)),
                    _ => None,
                };
                let Some((list, retry)) = retry else {
                    return Err(AetherError::Tls(format!(
                        "handshake with {}: {message}",
                        authority(address, port)
                    )));
                };
                log::debug!(
                    "[https] {} turned the ECH key down; offering the one it handed back ({} bytes)",
                    authority(address, port),
                    retry.len()
                );
                *list = retry;
                retried = true;
            }
        }
    };
    // Nothing goes over a handshake that went without the key it was given.
    if ech.is_some() && !tls.ssl().ech_accepted() {
        return Err(AetherError::Ech("the handshake went without ECH".into()));
    }
    if tls.ssl().selected_alpn_protocol() == Some(b"h2") {
        over_http2(tls, request).await
    } else {
        over_http1(tls, request).await
    }
}

/// The TLS of a request: the fingerprint, offering HTTP/2 then HTTP/1.1.
fn configuration(fingerprint: &Fingerprint) -> Result<ConnectConfiguration> {
    let mut builder =
        SslConnector::builder(SslMethod::tls()).map_err(|e| AetherError::Tls(e.to_string()))?;
    // TLS server-certificate verification disabled (unconditional), as the fingerprint has it:
    // the server name may be neither the HTTP host nor the address.
    fingerprint.apply(&mut builder, ALPN_H2_HTTP1)?;
    builder
        .build()
        .configure()
        .map_err(|e| AetherError::Tls(e.to_string()))
}

/// A TCP connection to `host`:`port`: through the upstream proxy when there is one, which looks
/// a name up itself, or else straight, with the socket mark.
async fn dial(host: &str, port: u16) -> Result<TcpStream> {
    match crate::transport::warp::net::upstream::configured() {
        Some(proxy) => proxy.connect_host(host, port).await,
        None => crate::utils::egress::tcp_connect_host(host, port)
            .await
            .map_err(|e| AetherError::Api(format!("connect to {}: {e}", authority(host, port)))),
    }
}

/// `host`:`port` as a URL writes it: an IPv6 address in brackets, and the port left out when
/// it is 443.
fn authority(host: &str, port: u16) -> String {
    let host = if host.contains(':') {
        format!("[{host}]")
    } else {
        host.to_string()
    };
    if port == 443 {
        host
    } else {
        format!("{host}:{port}")
    }
}

async fn over_http2<S>(tls: S, request: &Request<'_>) -> Result<Response>
where
    S: AsyncRead + AsyncWrite + Unpin + Send + 'static,
{
    let failed = |what: &str, e: h2::Error| AetherError::Api(format!("h2 {what}: {e}"));
    // As Chrome: no server push, whose streams would cost memory MAX_BODY does not count.
    let mut builder = h2::client::Builder::new();
    builder
        .enable_push(false)
        .max_header_list_size(MAX_HEADER_LIST);
    let (client, connection) = builder
        .handshake(tls)
        .await
        .map_err(|e| failed("handshake", e))?;
    let driver = tokio::spawn(async move {
        let _ = connection.await;
    });

    let outcome = async {
        let mut client = client.ready().await.map_err(|e| failed("ready", e))?;
        let mut head = http::Request::builder().method(request.method).uri(format!(
            "https://{}{}",
            authority(request.host, request.port),
            request.path
        ));
        for (name, value) in request.headers {
            head = head.header(name.as_str(), value.as_str());
        }
        if let Some(body) = request.body {
            head = head.header(http::header::CONTENT_LENGTH, body.len());
        }
        let head = head
            .body(())
            .map_err(|e| AetherError::Api(format!("h2 request: {e}")))?;

        let (answer, mut stream) = client
            .send_request(head, request.body.is_none())
            .map_err(|e| failed("request", e))?;
        if let Some(body) = request.body {
            stream
                .send_data(Bytes::copy_from_slice(body), true)
                .map_err(|e| failed("request body", e))?;
        }

        let (parts, mut body) = answer.await.map_err(|e| failed("answer", e))?.into_parts();
        let mut data = Vec::new();
        while let Some(chunk) = body.data().await {
            let chunk = chunk.map_err(|e| failed("answer body", e))?;
            let _ = body.flow_control().release_capacity(chunk.len());
            data.extend_from_slice(&chunk);
            if data.len() > MAX_BODY {
                return Err(AetherError::Api("the answer is too large".into()));
            }
        }
        Ok(Response {
            status: parts.status.as_u16(),
            headers: parts.headers,
            body: data,
            protocol: "h2",
        })
    }
    .await;

    driver.abort();
    outcome
}

async fn over_http1<S>(mut tls: S, request: &Request<'_>) -> Result<Response>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let mut head = format!(
        "{} {} HTTP/1.1\r\nHost: {}\r\n",
        request.method,
        request.path,
        authority(request.host, request.port)
    );
    for (name, value) in request.headers {
        head.push_str(&format!("{name}: {value}\r\n"));
    }
    if let Some(body) = request.body {
        head.push_str(&format!("Content-Length: {}\r\n", body.len()));
    }
    head.push_str("Connection: close\r\n\r\n");
    let mut wire = head.into_bytes();
    if let Some(body) = request.body {
        wire.extend_from_slice(body);
    }

    let failed = |e: std::io::Error| AetherError::Api(format!("http/1.1: {e}"));
    tls.write_all(&wire).await.map_err(failed)?;
    tls.flush().await.map_err(failed)?;

    let mut answer = Http1Answer::default();
    let mut chunk = [0u8; 8192];
    loop {
        match tls.read(&mut chunk).await {
            // The connection ended, with a close_notify or without one, which BoringSSL tells
            // alike: whether the answer came whole is for `finish` to say.
            Ok(0) => break,
            Ok(read) => {
                if answer.push(&chunk[..read])? {
                    break;
                }
            }
            Err(e) => return Err(failed(e)),
        }
    }

    let (status, fields, body) = answer.finish()?;
    let mut headers = http::HeaderMap::new();
    for (name, value) in fields {
        if let (Ok(name), Ok(value)) = (
            http::HeaderName::from_bytes(name.as_bytes()),
            http::HeaderValue::from_str(&value),
        ) {
            headers.append(name, value);
        }
    }
    Ok(Response {
        status,
        headers,
        body,
        protocol: "http/1.1",
    })
}

/// An HTTP/1.1 answer as it comes in, each byte looked at about once: its head, past any
/// interim (1xx) answers before it, then its body, which ends as RFC 9112 (6.3) has it: at
/// the head for a 204 or a 304, at the last chunk, after Content-Length bytes, or with the
/// connection.
#[derive(Default)]
struct Http1Answer {
    raw: Vec<u8>,
    /// Where the head being read starts: past the interim answers.
    head_start: usize,
    /// How far the search for the end of that head has looked.
    searched: usize,
    head: Option<Http1Head>,
}

struct Http1Head {
    status: u16,
    fields: Vec<(String, String)>,
    /// Where the body starts in the answer.
    body_start: usize,
    framing: Framing,
}

/// Where the body of an answer ends.
enum Framing {
    /// After this many bytes.
    Length(usize),
    /// At its last chunk and the end of its trailer.
    Chunked(Dechunker),
    /// With the connection.
    Close,
}

impl Http1Answer {
    /// Takes `bytes`, the next of the answer, and says whether the answer is whole.
    fn push(&mut self, bytes: &[u8]) -> Result<bool> {
        self.raw.extend_from_slice(bytes);
        if self.raw.len() > MAX_BODY {
            return Err(AetherError::Api("the answer is too large".into()));
        }
        while self.head.is_none() {
            let from = self.searched.saturating_sub(3).max(self.head_start);
            let Some(offset) = self.raw[from..]
                .windows(4)
                .position(|window| window == b"\r\n\r\n")
            else {
                self.searched = self.raw.len();
                return Ok(false);
            };
            let end = from + offset;
            let (status, fields) = http1_head(&self.raw[self.head_start..end])?;
            if (100..200).contains(&status) && status != 101 {
                // An interim answer, before the answer itself.
                self.head_start = end + 4;
                self.searched = self.head_start;
                continue;
            }
            let framing = framing(status, &fields)?;
            self.head = Some(Http1Head {
                status,
                fields,
                body_start: end + 4,
                framing,
            });
        }
        let head = self.head.as_mut().expect("the head");
        let body = &self.raw[head.body_start..];
        Ok(match &mut head.framing {
            Framing::Length(length) => body.len() >= *length,
            Framing::Chunked(dechunker) => dechunker.advance(body)?,
            Framing::Close => false,
        })
    }

    /// The status, the header fields and the body of the answer once the connection has
    /// ended, the body joined when it was chunked; an error when the connection ended before
    /// the answer did.
    fn finish(self) -> Result<Answer> {
        let Some(head) = self.head else {
            return Err(AetherError::Api(if self.raw.is_empty() {
                "empty response".into()
            } else {
                "truncated response head".into()
            }));
        };
        let body = &self.raw[head.body_start..];
        let body = match head.framing {
            Framing::Length(length) if body.len() < length => {
                return Err(AetherError::Api(format!(
                    "the answer ended after {} of its {length} bytes",
                    body.len()
                )))
            }
            Framing::Length(length) => body[..length].to_vec(),
            Framing::Chunked(dechunker) => dechunker.finish()?,
            Framing::Close => body.to_vec(),
        };
        Ok((head.status, head.fields, body))
    }
}

/// The status and the header fields of `head`, the head of an answer without its last CRLF.
fn http1_head(head: &[u8]) -> Result<(u16, Vec<(String, String)>)> {
    let head = String::from_utf8_lossy(head);
    let mut lines = head.split("\r\n");
    let status_line = lines.next().unwrap_or("");
    let status = status_line
        .split_whitespace()
        .nth(1)
        .and_then(|token| token.parse::<u16>().ok())
        .ok_or_else(|| AetherError::Api(format!("bad status line: {status_line}")))?;
    let fields = lines
        .filter_map(|line| line.split_once(':'))
        .map(|(name, value)| (name.trim().to_string(), value.trim().to_string()))
        .collect();
    Ok((status, fields))
}

/// Where the body of an answer with `status` and header `fields` ends (RFC 9112, 6.3): chunked
/// goes before any Content-Length.
fn framing(status: u16, fields: &[(String, String)]) -> Result<Framing> {
    if status == 204 || status == 304 {
        return Ok(Framing::Length(0));
    }
    let field = |wanted: &str| {
        fields
            .iter()
            .find(|(name, _)| name.eq_ignore_ascii_case(wanted))
            .map(|(_, value)| value)
    };
    if field("transfer-encoding")
        .is_some_and(|value| value.to_ascii_lowercase().contains("chunked"))
    {
        return Ok(Framing::Chunked(Dechunker::default()));
    }
    match field("content-length") {
        Some(value) => value
            .parse::<usize>()
            .map(Framing::Length)
            .map_err(|_| AetherError::Api(format!("bad Content-Length: {value}"))),
        None => Ok(Framing::Close),
    }
}

/// A chunked body (RFC 9112, 7.1), joined as it comes in, each byte looked at about once.
#[derive(Default)]
struct Dechunker {
    /// Where the next piece of the body starts: a chunk size, a chunk's data, or a field of
    /// the trailer.
    at: usize,
    /// How far the search for the end of the line at `at` has looked.
    searched: usize,
    /// The size of the chunk whose data comes next, when it is data that comes next.
    data: Option<usize>,
    /// Whether the last chunk has come, so that the trailer comes next.
    trailer: bool,
    done: bool,
    joined: Vec<u8>,
}

impl Dechunker {
    /// Goes on with `body`, the whole body so far, and says whether its last chunk and its
    /// trailer have come; an error for what is no chunked body.
    fn advance(&mut self, body: &[u8]) -> Result<bool> {
        let malformed = |what: &str| AetherError::Api(format!("a chunked answer with {what}"));
        while !self.done {
            if let Some(size) = self.data {
                // The chunk's data, then CRLF.
                let end = self
                    .at
                    .checked_add(size)
                    .and_then(|end| end.checked_add(2))
                    .ok_or_else(|| malformed("a chunk too large"))?;
                if body.len() < end {
                    return Ok(false);
                }
                if &body[end - 2..end] != b"\r\n" {
                    return Err(malformed("no line end after a chunk"));
                }
                self.joined.extend_from_slice(&body[self.at..end - 2]);
                self.at = end;
                self.searched = end;
                self.data = None;
                continue;
            }
            // A line: a chunk size, or a field of the trailer.
            let from = self.searched.saturating_sub(1).max(self.at);
            let Some(offset) = body[from..].windows(2).position(|window| window == b"\r\n") else {
                if body.len() - self.at > MAX_LINE {
                    return Err(malformed("a line too long"));
                }
                self.searched = body.len();
                return Ok(false);
            };
            let end = from + offset;
            let line = &body[self.at..end];
            self.at = end + 2;
            self.searched = self.at;
            if self.trailer {
                self.done = line.is_empty();
                continue;
            }
            let size = std::str::from_utf8(line)
                .ok()
                .and_then(|line| {
                    let size = line.split(';').next().unwrap_or("").trim();
                    usize::from_str_radix(size, 16).ok()
                })
                .ok_or_else(|| malformed("a bad chunk size"))?;
            match size {
                0 => self.trailer = true,
                size => self.data = Some(size),
            }
        }
        Ok(true)
    }

    /// The body, joined; an error unless its last chunk and its trailer have come.
    fn finish(self) -> Result<Vec<u8>> {
        if self.done {
            Ok(self.joined)
        } else {
            Err(AetherError::Api(
                "the chunked answer ended before its last chunk".into(),
            ))
        }
    }
}

/// A TLS server on this machine for the tests, which picks `alpn` when the client offers it.
#[cfg(test)]
pub(crate) async fn test_server(
    alpn: &'static [u8],
) -> (
    std::net::SocketAddr,
    tokio::net::TcpListener,
    std::sync::Arc<boring::ssl::SslAcceptor>,
) {
    let pair = crate::transport::warp::account::generate_masque_keypair().expect("a key and a certificate");
    let mut builder =
        boring::ssl::SslAcceptor::mozilla_intermediate_v5(boring::ssl::SslMethod::tls())
            .expect("tls");
    builder
        .set_certificate(&boring::x509::X509::from_pem(&pair.cert_pem).expect("a certificate"))
        .expect("the certificate");
    builder
        .set_private_key(&boring::pkey::PKey::private_key_from_pem(&pair.key_pem).expect("a key"))
        .expect("the key");
    builder.set_alpn_select_callback(move |_, offered| {
        boring::ssl::select_next_proto(alpn, offered).ok_or(boring::ssl::AlpnError::NOACK)
    });
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
        .await
        .expect("a port");
    let address = listener.local_addr().expect("its address");
    (address, listener, std::sync::Arc::new(builder.build()))
}

#[cfg(test)]
mod tests;
