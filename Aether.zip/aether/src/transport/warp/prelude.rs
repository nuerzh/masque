//! What the WARP tunnel modules (and `config::mode`, which picks among them) work with.

pub(crate) use std::collections::{HashMap, HashSet};
pub(crate) use std::net::{IpAddr, Ipv4Addr, SocketAddr};
pub(crate) use std::time::Instant;

pub(crate) use crate::config::identity as config;
pub(crate) use crate::config::mode::*;
pub(crate) use crate::error::{AetherError, Result};
pub(crate) use crate::proxy::socks;
pub(crate) use crate::transport::warp::{account, exitloc, lastconn, prober, zerotrust};
pub(crate) use crate::proxy::outbound::sunnyquic;
pub(crate) use crate::transport::warp::masque::{http2 as masque_h2, quic};
pub(crate) use crate::transport::warp::net::tls;
pub(crate) use crate::transport::warp::{consts, netstack};
pub(crate) use crate::utils::noize;
