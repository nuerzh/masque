//! What earlier verifications say about address ranges. Per (range, port) it counts the addresses
//! that were tried with the full check and the ones that passed. A scan seeds its quick pass with
//! these counts (see `Prior`), so the ranges that have worked go first; with `AETHER_SCAN_MEMORY`
//! set to a file, the counts are kept across runs, halved on each load so an old result fades.

use super::*;
use std::collections::HashMap;

/// (tried, passed) per (range, port): what the quick pass's scheduler starts from.
pub type Prior = HashMap<(u128, u16), (u32, u32)>;

const HEADER: &str = "# aether scan memory v1";

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct RangeMemory {
    stats: Prior,
}

impl RangeMemory {
    /// Notes one full check of `ip:port`.
    pub fn record(&mut self, ip: IpAddr, port: u16, passed: bool) {
        let e = self.stats.entry((quick::range_key(ip), port)).or_insert((0, 0));
        e.0 = e.0.saturating_add(1);
        if passed {
            e.1 = e.1.saturating_add(1);
        }
    }

    /// The counts a quick pass starts from.
    pub fn prior(&self) -> Prior {
        self.stats.clone()
    }

    /// The memory as text: a header, then one `range-hex port tried passed` line per range.
    pub fn to_text(&self) -> String {
        let mut out = String::from(HEADER);
        out.push('\n');
        let mut rows: Vec<_> = self.stats.iter().collect();
        rows.sort();
        for ((range, port), (tried, passed)) in rows {
            out.push_str(&format!("{range:x} {port} {tried} {passed}\n"));
        }
        out
    }

    /// The memory a text gives: lines that do not parse are skipped, and every count is halved
    /// (rounding up), so that what was learned a while ago counts for less than what is new.
    pub fn from_text(text: &str) -> Self {
        let mut stats = Prior::new();
        for line in text.lines().filter(|l| !l.starts_with('#') && !l.trim().is_empty()) {
            let mut f = line.split_whitespace();
            let parsed = (|| {
                let range = u128::from_str_radix(f.next()?, 16).ok()?;
                let port: u16 = f.next()?.parse().ok()?;
                let tried: u32 = f.next()?.parse().ok()?;
                let passed: u32 = f.next()?.parse().ok()?;
                Some((range, port, tried, passed))
            })();
            if let Some((range, port, tried, passed)) = parsed {
                let tried = tried.div_ceil(2);
                if tried > 0 {
                    stats.insert((range, port), (tried, passed.div_ceil(2).min(tried)));
                }
            }
        }
        Self { stats }
    }

    /// The memory of the file `cfg` names, or an empty one when there is no file yet or it does not
    /// read: a memory that cannot be read is logged and starts empty.
    pub fn open(cfg: &ScanConfig) -> Self {
        let Some(path) = cfg.memory.as_deref() else {
            return Self::default();
        };
        match std::fs::read_to_string(path) {
            Ok(text) => Self::from_text(&text),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Self::default(),
            Err(e) => {
                log::warn!("[scan] could not read the scan memory {path}: {e}; starting without it");
                Self::default()
            }
        }
    }

    /// Writes the memory to the file `cfg` names, if it names one. A failure is logged: the scan
    /// has its result either way.
    pub fn save(&self, cfg: &ScanConfig) {
        let Some(path) = cfg.memory.as_deref() else {
            return;
        };
        if let Err(e) = std::fs::write(path, self.to_text()) {
            log::warn!("[scan] could not write the scan memory {path}: {e}");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_full_check_counts_for_its_range_and_port() {
        let mut m = RangeMemory::default();
        let a: IpAddr = "162.159.198.1".parse().unwrap();
        let b: IpAddr = "162.159.198.9".parse().unwrap();
        m.record(a, 443, true);
        m.record(b, 443, false);
        m.record(a, 500, false);
        let prior = m.prior();
        assert_eq!(prior[&(quick::range_key(a), 443)], (2, 1), "same /24, same port: one range");
        assert_eq!(prior[&(quick::range_key(a), 500)], (1, 0), "another port is another range");
    }

    #[test]
    fn the_text_round_trips_and_a_load_halves_the_counts() {
        let mut m = RangeMemory::default();
        let ip: IpAddr = "162.159.198.1".parse().unwrap();
        for i in 0..10 {
            m.record(ip, 443, i < 4);
        }
        let back = RangeMemory::from_text(&m.to_text());
        assert_eq!(back.prior()[&(quick::range_key(ip), 443)], (5, 2), "halved, rounding up");
    }

    #[test]
    fn lines_that_do_not_parse_are_skipped() {
        let m = RangeMemory::from_text("# header\nnot a line\n1f 443 4 2\n2a 443 x 1\n");
        assert_eq!(m.prior().len(), 1);
    }

    #[test]
    fn a_memory_is_kept_in_its_file_across_loads() {
        let path = std::env::temp_dir().join(format!("aether-memory-test-{}.txt", std::process::id()));
        let cfg = ScanConfig { memory: Some(path.to_string_lossy().into_owned()), ..ScanConfig::default() };
        let ip: IpAddr = "162.159.198.1".parse().unwrap();
        let mut m = RangeMemory::open(&cfg);
        assert!(m.prior().is_empty(), "no file yet: an empty memory");
        m.record(ip, 443, true);
        m.save(&cfg);
        let again = RangeMemory::open(&cfg);
        assert_eq!(again.prior()[&(quick::range_key(ip), 443)], (1, 1));
        let _ = std::fs::remove_file(&path);
    }
}
