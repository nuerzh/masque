//! The port check: which of the ports answer on the seed gateways.

use super::*;

/// How long the port check may run in all.
const PORT_CHECK_BUDGET: Duration = Duration::from_secs(10);

/// The ports that answer the quick check on the seed gateways, those with the most answers
/// first and, among equals, the fastest: which ports get through is what differs most between
/// networks, so the range sweep spends its budget only on those.
pub(in crate::transport::warp::prober) async fn discover_ports(
    ports: &[u16],
    ip: IpScan,
    h2: bool,
    avoid: &HashSet<IpAddr>,
) -> Vec<u16> {
    let mut seeds: Vec<IpAddr> = Vec::new();
    if ip.want_v4() {
        seeds.extend(
            catalog::current().seeds_v4
                .iter()
                .chain(catalog::current().verified_v4)
                .filter_map(|s| s.parse::<Ipv4Addr>().ok())
                .map(IpAddr::V4),
        );
    }
    if ip.want_v6() {
        seeds.extend(
            catalog::current().seeds_v6
                .iter()
                .filter_map(|s| s.parse::<Ipv6Addr>().ok())
                .map(IpAddr::V6),
        );
    }
    let mut once: HashSet<IpAddr> = HashSet::new();
    seeds.retain(|a| !avoid.contains(a) && once.insert(*a));
    let targets: Vec<(IpAddr, u16)> = seeds
        .iter()
        .flat_map(|a| ports.iter().map(move |p| (*a, *p)))
        .collect();

    let started = Instant::now();
    let pass = run_pass(&targets, PORT_CHECK_BUDGET, usize::MAX, h2).await;

    let mut tally: Vec<(u16, u32, Duration)> = ports.iter().map(|p| (*p, 0, Duration::MAX)).collect();
    for (_, port, rtt) in pass.live {
        if let Some(entry) = tally.iter_mut().find(|e| e.0 == port) {
            entry.1 += 1;
            entry.2 = entry.2.min(rtt);
        }
    }
    tally.retain(|e| e.1 > 0);
    rank_ports(&mut tally, tie_loser());
    log::info!(
        "[scan] port check on {} seed gateway(s) in {:?}: {}",
        seeds.len(),
        started.elapsed(),
        if tally.is_empty() {
            "no port answered".to_string()
        } else {
            tally
                .iter()
                .map(|(p, n, rtt)| format!("{p} ({n} ok, {}ms)", rtt.as_millis()))
                .collect::<Vec<_>>()
                .join(", ")
        }
    );
    tally.into_iter().map(|e| e.0).collect()
}

/// Most seed gateways answered first; on a tie `loser` (443 with the default ports) goes after
/// any other port, then the lowest RTT.
pub(in crate::transport::warp::prober) fn rank_ports(tally: &mut [(u16, u32, Duration)], loser: Option<u16>) {
    tally.sort_by(|a, b| {
        b.1.cmp(&a.1)
            .then((Some(a.0) == loser).cmp(&(Some(b.0) == loser)))
            .then(a.2.cmp(&b.2))
    });
}
