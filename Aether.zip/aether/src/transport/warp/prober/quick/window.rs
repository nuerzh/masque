use std::collections::VecDeque;
use std::time::Duration;

/// The answers the adaptive timeout looks at.
const WINDOW_LEN: usize = 256;
/// The fewest answers the timeout adapts on; before that it stays at its widest.
const WINDOW_MIN_SAMPLES: usize = 8;
/// Once adapting, the timeout is recomputed every this many answers.
const WINDOW_RECOMPUTE_EVERY: u64 = 16;

/// The recent RTTs of the quick pass and the timeout a silent address is given from them.
pub(in crate::transport::warp::prober) struct RttWindow {
    recent: VecDeque<Duration>,
    seen: u64,
    timeout: Duration,
    min: Duration,
    max: Duration,
}

impl RttWindow {
    pub(in crate::transport::warp::prober) fn new(min: Duration, max: Duration) -> Self {
        Self {
            recent: VecDeque::with_capacity(WINDOW_LEN),
            seen: 0,
            timeout: max,
            min,
            max,
        }
    }

    /// The timeout now: the widest until enough answers came, then three times the median RTT
    /// within bounds (past that an address is too far or too lossy to be the pick anyway).
    pub(in crate::transport::warp::prober) fn timeout(&self) -> Duration {
        self.timeout
    }

    pub(in crate::transport::warp::prober) fn push(&mut self, rtt: Duration) {
        if self.recent.len() == WINDOW_LEN {
            self.recent.pop_front();
        }
        self.recent.push_back(rtt);
        self.seen += 1;
        let n = self.recent.len();
        if n >= WINDOW_MIN_SAMPLES
            && (n == WINDOW_MIN_SAMPLES || self.seen.is_multiple_of(WINDOW_RECOMPUTE_EVERY))
        {
            let mut sorted: Vec<Duration> = self.recent.iter().copied().collect();
            sorted.sort_unstable();
            self.timeout = (sorted[n / 2] * 3).clamp(self.min, self.max);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_window_waits_for_samples_then_tracks_three_times_the_median() {
        let mut w = RttWindow::new(Duration::from_millis(1), Duration::from_secs(1));
        assert_eq!(w.timeout(), Duration::from_secs(1), "no samples: the widest timeout");
        for _ in 0..7 {
            w.push(Duration::from_millis(10));
        }
        assert_eq!(w.timeout(), Duration::from_secs(1), "fewer than 8 samples");
        w.push(Duration::from_millis(10));
        assert_eq!(w.timeout(), Duration::from_millis(30));
    }

    #[test]
    fn the_window_is_bounded_and_the_timeout_is_clamped() {
        let mut w = RttWindow::new(Duration::from_millis(500), Duration::from_millis(1500));
        for _ in 0..8 {
            w.push(Duration::from_millis(1));
        }
        assert_eq!(w.timeout(), Duration::from_millis(500), "clamped to the minimum");
        for _ in 0..1000 {
            w.push(Duration::from_millis(400));
        }
        assert_eq!(w.recent.len(), WINDOW_LEN, "old samples leave the window");
        assert_eq!(w.timeout(), Duration::from_millis(1200));
    }
}
