use std::collections::VecDeque;
use std::time::Duration;

/// The answers the adaptive timeout looks at.
const WINDOW_LEN: usize = 256;
/// The fewest answers the timeout adapts on; before that it stays at its widest.
const WINDOW_MIN_SAMPLES: usize = 8;
/// Once adapting, the timeout is recomputed every this many answers.
const WINDOW_RECOMPUTE_EVERY: u64 = 16;

/// The recent RTTs of the quick pass and the timeout a silent address is given from them.
pub(in crate::transport::warp::prober) struct RttWindow {
    recent: VecDeque<Duration>,
    seen: u64,
    timeout: Duration,
    min: Duration,
    max: Duration,
}

impl RttWindow {
    pub(in crate::transport::warp::prober) fn new(min: Duration, max: Duration) -> Self {
        Self {
            recent: VecDeque::with_capacity(WINDOW_LEN),
            seen: 0,
            timeout: max,
            min,
            max,
        }
    }

    /// The timeout now: the widest until enough answers came, then twice the 95th-percentile RTT
    /// within bounds. The percentile, not the median, so that a link with a long tail (satellite,
    /// a long route) keeps the answers that are slow but real; past the ceiling an address is too
    /// far or too lossy to be the pick anyway.
    pub(in crate::transport::warp::prober) fn timeout(&self) -> Duration {
        self.timeout
    }

    pub(in crate::transport::warp::prober) fn push(&mut self, rtt: Duration) {
        if self.recent.len() == WINDOW_LEN {
            self.recent.pop_front();
        }
        self.recent.push_back(rtt);
        self.seen += 1;
        let n = self.recent.len();
        if n >= WINDOW_MIN_SAMPLES
            && (n == WINDOW_MIN_SAMPLES || self.seen.is_multiple_of(WINDOW_RECOMPUTE_EVERY))
        {
            let mut sorted: Vec<Duration> = self.recent.iter().copied().collect();
            sorted.sort_unstable();
            // the nearest-rank 95th percentile
            let p95 = sorted[((n * 95).div_ceil(100)).saturating_sub(1)];
            self.timeout = (p95 * 2).clamp(self.min, self.max);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_window_waits_for_samples_then_tracks_twice_the_95th_percentile() {
        let mut w = RttWindow::new(Duration::from_millis(1), Duration::from_secs(1));
        assert_eq!(w.timeout(), Duration::from_secs(1), "no samples: the widest timeout");
        for _ in 0..7 {
            w.push(Duration::from_millis(10));
        }
        assert_eq!(w.timeout(), Duration::from_secs(1), "fewer than 8 samples");
        w.push(Duration::from_millis(10));
        assert_eq!(w.timeout(), Duration::from_millis(20));
    }

    #[test]
    fn a_long_tail_is_not_cut_off_by_the_median() {
        // 240 fast answers and a slow tail of 16 (6%) fill the window, so the timeout is recomputed
        // on the full window: the median is 10 ms, but the slow answers are real, and the timeout
        // must allow them (the 95th percentile is 300 ms)
        let mut w = RttWindow::new(Duration::from_millis(1), Duration::from_secs(5));
        for _ in 0..240 {
            w.push(Duration::from_millis(10));
        }
        for _ in 0..16 {
            w.push(Duration::from_millis(300));
        }
        assert!(w.timeout() >= Duration::from_millis(300), "{:?}", w.timeout());
    }

    #[test]
    fn the_window_is_bounded_and_the_timeout_is_clamped() {
        let mut w = RttWindow::new(Duration::from_millis(500), Duration::from_millis(1500));
        for _ in 0..8 {
            w.push(Duration::from_millis(1));
        }
        assert_eq!(w.timeout(), Duration::from_millis(500), "clamped to the minimum");
        for _ in 0..1000 {
            w.push(Duration::from_millis(400));
        }
        assert_eq!(w.recent.len(), WINDOW_LEN, "old samples leave the window");
        assert_eq!(w.timeout(), Duration::from_millis(800), "twice the 400 ms percentile");
    }
}
