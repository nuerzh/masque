//! The quick pass: a one-round-trip check before the full handshake.
//!
//! A full MASQUE verification costs a TLS handshake, the CONNECT-IP request and a data check, and
//! a silent address holds its slot for the whole timeout. Most sampled addresses on a filtered
//! network are silent, so the quick pass rejects them cheaply. Only the addresses that answer go
//! on to the full handshake, fastest first. A range (/24, or /48 on IPv6) whose first probes on a
//! port all stay silent is dropped for that port. Nothing that answers is trusted on the quick
//! pass alone: the full verification still decides, and when the quick pass finds nothing the
//! scan falls back to the old sweep.
//!
//! The QUIC probes are pipelined (see `pipeline`). HTTP/2 probes with a TCP connect, one at a
//! time at a bounded concurrency, with the same range pruning.

use super::*;
use std::collections::HashMap;

mod pipeline;
mod ports;
mod window;

use crate::transport::warp::prober::memory::Prior;
use pipeline::{pipeline_family, Exchange, PipeCfg};
pub(super) use ports::discover_ports;
#[cfg(test)]
pub(super) use ports::rank_ports;
use window::RttWindow;

pub(super) const QUICK_TIMEOUT_MAX: Duration = Duration::from_millis(1500);
pub(super) const QUICK_TIMEOUT_MIN: Duration = Duration::from_millis(500);
pub(super) const PRUNE_AFTER: u32 = 6;
pub(super) const SWEEP_PORTS: usize = 1;
/// Concurrent TCP probes of the HTTP/2 pass: a quick probe is one connect, far lighter than a
/// handshake, so several times the handshake cap, still bounded on small devices.
pub(super) fn quick_concurrency() -> usize {
    crate::utils::sysprofile::cap_concurrency(usize::MAX)
        .saturating_mul(6)
        .clamp(16, 128)
}

/// The range an address is pruned with: its /24, or /48 on IPv6.
pub(super) fn range_key(ip: IpAddr) -> u128 {
    match ip {
        IpAddr::V4(a) => (u32::from(a) >> 8) as u128,
        IpAddr::V6(a) => (u128::from(a) >> 80) | (1u128 << 100),
    }
}

/// How long one quick pass may run: a third of the scan's deadline, within 10 to 40 seconds.
fn pass_budget(st: &Strategy) -> Duration {
    (st.overall_deadline / 3).clamp(Duration::from_secs(10), Duration::from_secs(40))
}

/// How many answers a quick pass wants before it stops: enough to fill the full verification
/// several times over; unlimited for a thorough scan.
fn pass_wanted(st: &Strategy) -> usize {
    if st.target_successes == 0 {
        usize::MAX
    } else {
        (st.target_successes * 6).max(24)
    }
}

/// What one quick pass found.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub(super) struct QuickPass {
    /// The candidates that answered, fastest first.
    pub live: Vec<(IpAddr, u16)>,
    /// Those it probed that stayed silent.
    pub silent: Vec<(IpAddr, u16)>,
    /// Those it left out because their range stayed silent on their port (not those it never
    /// reached before it had enough answers or ran out of time).
    pub skipped: Vec<(IpAddr, u16)>,
}

/// A pass over candidates with the RTT of each answer kept, for the port check and the merge.
pub(super) struct Pass {
    pub live: Vec<(IpAddr, u16, Duration)>,
    pub silent: Vec<(IpAddr, u16)>,
    pub skipped: Vec<(IpAddr, u16)>,
}

/// Probes `candidates`: QUIC pipelined, or one probe at a time for HTTP/2 (TCP) and for the
/// `AETHER_SCAN_PIPELINE=0` fallback (QUIC). Stops at `want` answers or
/// when `budget` runs out, and returns the answers fastest first.
pub(super) async fn run_pass(
    candidates: &[(IpAddr, u16)],
    budget: Duration,
    want: usize,
    carrier: Carrier,
    cfg: &ScanConfig,
    prior: &Prior,
) -> Pass {
    if !carrier.can_pipeline() || !cfg.pipeline {
        return per_probe_pass(candidates, budget, want, carrier.probe_kind()).await;
    }
    let (v4, v6): (Vec<_>, Vec<_>) = candidates.iter().copied().partition(|(ip, _)| ip.is_ipv4());

    // both families run at once and share the budget. An IPv4 answer goes to the IPv6 pass as a
    // hint: the gateway's IPv6 address (see `v6_hints_of`) is likely to answer too, so it goes out
    // first, as soon as the IPv4 pass has it.
    let cfg = PipeCfg {
        pps: cfg.pps,
        budget,
        want,
        timeout_min: QUICK_TIMEOUT_MIN,
        timeout_max: QUICK_TIMEOUT_MAX,
        retries: cfg.retries,
        prior: prior.clone(),
    };
    let (answers_tx, answers_rx) = tokio::sync::mpsc::unbounded_channel();
    let v4_exchange = Exchange { tap: Some(answers_tx), hints: None };
    let v6_exchange = Exchange { tap: None, hints: Some((answers_rx, v6_hints_of)) };
    let (a, b) = futures::future::join(
        pipeline_family(&v4, &cfg, v4_exchange),
        pipeline_family(&v6, &cfg, v6_exchange),
    )
    .await;

    let mut live: Vec<(IpAddr, u16, Duration)> = a.live.into_iter().chain(b.live).collect();
    live.sort_by_key(|h| h.2);
    live.truncate(want);
    Pass {
        live,
        silent: a.silent.into_iter().chain(b.silent).collect(),
        skipped: a.skipped.into_iter().chain(b.skipped).collect(),
    }
}

/// The IPv6 addresses an IPv4 answer hints at: the gateway embedded under each prefix of the scan.
/// (The pass keeps those that are candidates of its own.)
fn v6_hints_of((ip, port): (IpAddr, u16)) -> Vec<(IpAddr, u16)> {
    let IpAddr::V4(v4) = ip else {
        return Vec::new();
    };
    v6_prefix_bases()
        .into_iter()
        .map(|base| (IpAddr::V6(embed_v4(base, v4)), port))
        .collect()
}

/// (tried, answered) per (range, port) of a per-probe pass.
type ProbeTally = HashMap<(u128, u16), (u32, u32)>;

/// How one probe of a per-probe pass goes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::transport::warp::prober) enum ProbeKind {
    /// A TCP connect: the HTTP/2 carrier.
    Tcp,
    /// A QUIC Initial from its own socket: the fallback for the pipelined pass.
    Quic,
}

/// The per-probe pass: one probe at a time, at a bounded concurrency, with range pruning.
async fn per_probe_pass(candidates: &[(IpAddr, u16)], budget: Duration, want: usize, kind: ProbeKind) -> Pass {
    enum Outcome {
        Live(IpAddr, u16, Duration),
        Silent(IpAddr, u16),
        Skipped(IpAddr, u16),
    }
    let window = Arc::new(parking_lot::Mutex::new(RttWindow::new(QUICK_TIMEOUT_MIN, QUICK_TIMEOUT_MAX)));
    let ranges: Arc<parking_lot::Mutex<ProbeTally>> = Arc::default();
    let probes: Vec<_> = candidates
        .iter()
        .copied()
        .map(|(ip, port)| {
            let window = window.clone();
            let ranges = ranges.clone();
            async move {
                let key = (range_key(ip), port);
                let dead = {
                    let r = ranges.lock();
                    r.get(&key).is_some_and(|&(tried, answered)| answered == 0 && tried >= PRUNE_AFTER)
                };
                if dead {
                    return Outcome::Skipped(ip, port);
                }
                let timeout = window.lock().timeout();
                let rtt = quick_answer(SocketAddr::new(ip, port), timeout, kind).await;
                {
                    let mut r = ranges.lock();
                    let e = r.entry(key).or_insert((0, 0));
                    e.0 += 1;
                    if rtt.is_some() {
                        e.1 += 1;
                    }
                }
                match rtt {
                    Some(rtt) => {
                        window.lock().push(rtt);
                        Outcome::Live(ip, port, rtt)
                    }
                    None => Outcome::Silent(ip, port),
                }
            }
        })
        .collect();
    let stream = futures::stream::iter(probes).buffer_unordered(quick_concurrency());
    tokio::pin!(stream);

    let deadline = tokio::time::Instant::now() + budget;
    let mut pass = Pass { live: Vec::new(), silent: Vec::new(), skipped: Vec::new() };
    loop {
        tokio::select! {
            item = stream.next() => match item {
                None => break,
                Some(Outcome::Live(ip, port, rtt)) => {
                    pass.live.push((ip, port, rtt));
                    if pass.live.len() >= want {
                        break;
                    }
                }
                Some(Outcome::Silent(ip, port)) => pass.silent.push((ip, port)),
                Some(Outcome::Skipped(ip, port)) => pass.skipped.push((ip, port)),
            },
            _ = tokio::time::sleep_until(deadline) => break,
        }
    }
    pass.live.sort_by_key(|h| h.2);
    pass
}

/// One probe of the per-probe pass: the RTT of its answer, or None if it stayed silent.
async fn quick_answer(peer: SocketAddr, timeout: Duration, kind: ProbeKind) -> Option<Duration> {
    match kind {
        ProbeKind::Tcp => quick_tcp(peer, timeout).await,
        ProbeKind::Quic => quick_quic(peer, timeout).await,
    }
}

/// One TCP connect to `peer`, or None if it did not complete within `timeout`.
async fn quick_tcp(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
    let started = Instant::now();
    match tokio::time::timeout(timeout, crate::utils::egress::tcp_connect(peer)).await {
        Ok(Ok(_)) => Some(started.elapsed()),
        _ => None,
    }
}

/// One QUIC Initial to `peer` from a socket of its own, sent again halfway through `timeout`:
/// how long until any answer came, or None. Each probe gets its own connection, so this path
/// shares nothing with the others.
async fn quick_quic(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
    let sock = crate::utils::egress::udp_bind(crate::utils::egress::wildcard_for(peer)).ok()?;
    sock.connect(peer).await.ok()?;
    let local = sock.local_addr().ok()?;

    let mut config = quiche::Config::new(quiche::PROTOCOL_VERSION).ok()?;
    config.set_application_protos(&[crate::transport::warp::consts::ALPN_H3]).ok()?;
    config.verify_peer(false);
    config.set_max_idle_timeout(timeout.as_millis() as u64);
    let mut scid = [0u8; 16];
    rand::rng().fill(&mut scid[..]);
    let scid = quiche::ConnectionId::from_ref(&scid);
    let sni = quic::masque_sni().unwrap_or_else(|_| quic::default_sni().to_string());
    let mut conn = quiche::connect(Some(&sni), &scid, local, peer, &mut config).ok()?;
    let mut out = [0u8; 1350];
    let (written, _) = conn.send(&mut out).ok()?;

    let started = Instant::now();
    let mut buf = [0u8; 1500];
    for half in [timeout / 2, timeout - timeout / 2] {
        sock.send(&out[..written]).await.ok()?;
        if let Ok(Ok(n)) = tokio::time::timeout(half, sock.recv(&mut buf)).await {
            if pipeline::looks_like_quic(&buf[..n]) {
                return Some(started.elapsed());
            }
        }
    }
    None
}

/// The quick check of `candidates`, see `QuickPass`. Its summary line is logged at `level`: the
/// background scan logs its own line per batch and keeps this one for debug.
pub(super) async fn quick_filter(
    candidates: &[(IpAddr, u16)],
    st: &Strategy,
    carrier: Carrier,
    cfg: &ScanConfig,
    prior: &Prior,
    level: log::Level,
) -> QuickPass {
    let started = Instant::now();
    let pass = run_pass(candidates, pass_budget(st), pass_wanted(st), carrier, cfg, prior).await;
    log::log!(
        level,
        "[scan] quick pass: {} of {} candidate(s) answered in {:?} ({} skipped in silent ranges, {} pps, {} retries), verifying fastest first",
        pass.live.len(),
        candidates.len(),
        started.elapsed(),
        pass.skipped.len(),
        cfg.pps,
        cfg.retries,
    );
    QuickPass {
        live: pass.live.into_iter().map(|(ip, port, _)| (ip, port)).collect(),
        silent: pass.silent,
        skipped: pass.skipped,
    }
}

/// A port nothing listens on: a silent address on loopback.
#[cfg(test)]
pub(super) fn closed_port() -> u16 {
    let s = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
    let port = s.local_addr().unwrap().port();
    drop(s);
    port
}

/// A reply shaped like a QUIC long-header packet, which `looks_like_quic` accepts: the fixed bit
/// and the header form set, version 1, a connection ID.
#[cfg(test)]
pub(super) const QUIC_REPLY: [u8; 32] = [
    0xc0, 0, 0, 0, 1, 8, 1, 2, 3, 4, 5, 6, 7, 8, 8, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 0, 0, 0, 0, 0, 0,
];

/// Responders that drop the first datagram they get and answer the rest: the lossy network in
/// miniature. Only a retry can find them.
#[cfg(test)]
pub(super) async fn lossy_responders(n: usize) -> Vec<u16> {
    let mut ports = Vec::new();
    for _ in 0..n {
        let s = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
        ports.push(s.local_addr().unwrap().port());
        tokio::spawn(async move {
            let mut buf = [0u8; 2048];
            let mut seen = false;
            while let Ok((_, from)) = s.recv_from(&mut buf).await {
                if seen {
                    let _ = s.send_to(&QUIC_REPLY, from).await;
                }
                seen = true;
            }
        });
    }
    ports
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn the_quick_pass_keeps_only_what_answers_fastest_first() {
        // a local udp socket that answers anything stands in for a live edge; a closed port
        // stands in for a silent one
        let live = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
        let live_port = live.local_addr().unwrap().port();
        tokio::spawn(async move {
            let mut buf = [0u8; 2048];
            while let Ok((n, from)) = live.recv_from(&mut buf).await {
                let _ = live.send_to(&buf[..n.min(64)], from).await;
            }
        });
        let dead_port = closed_port();
        let lo: IpAddr = "127.0.0.1".parse().unwrap();
        let st = ScanMode::Turbo.strategy();
        let pass = quick_filter(
            &[(lo, dead_port), (lo, live_port)],
            &st,
            Carrier::Quic,
            &ScanConfig::default(),
            &Default::default(),
            log::Level::Info,
        )
        .await;
        assert_eq!(pass.live, vec![(lo, live_port)]);
        assert_eq!(pass.silent, vec![(lo, dead_port)], "the silent one is reported, so a deeper round skips it");
        assert!(pass.skipped.is_empty());
    }

    #[tokio::test]
    async fn the_per_probe_fallback_finds_a_live_address_and_reports_the_silent_one() {
        // the fallback is a separate engine: one socket per probe, its own connection each
        let live = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
        let live_port = live.local_addr().unwrap().port();
        tokio::spawn(async move {
            let mut buf = [0u8; 2048];
            while let Ok((_, from)) = live.recv_from(&mut buf).await {
                let _ = live.send_to(&QUIC_REPLY, from).await;
            }
        });
        let dead_port = closed_port();
        let lo: IpAddr = "127.0.0.1".parse().unwrap();
        let pass = per_probe_pass(
            &[(lo, dead_port), (lo, live_port)],
            Duration::from_secs(10),
            usize::MAX,
            ProbeKind::Quic,
        )
        .await;
        assert_eq!(pass.live.iter().map(|h| (h.0, h.1)).collect::<Vec<_>>(), vec![(lo, live_port)]);
        assert_eq!(pass.silent, vec![(lo, dead_port)]);
    }

    #[test]
    fn a_v4_answer_hints_the_ipv6_address_it_is_embedded_in() {
        let gw: Ipv4Addr = "162.159.198.2".parse().unwrap();
        let embedded: IpAddr = "2606:4700:d0::a29f:c602".parse().unwrap();
        let other: IpAddr = "2606:4700:d0::1".parse().unwrap();
        let hints = v6_hints_of((IpAddr::V4(gw), 443));
        assert!(hints.contains(&(embedded, 443)), "the address that embeds the gateway is hinted");
        assert!(!hints.contains(&(other, 443)));
        assert!(v6_hints_of((other, 443)).is_empty(), "an IPv6 answer hints nothing");
    }

    /// Compares the pass on 200 addresses that stay silent: bound but never answering, so no ICMP
    /// error comes back and each probe really waits out its timeout.
    /// `cargo test --lib quick_pass_benchmark -- --ignored --nocapture`.
    #[tokio::test]
    #[ignore = "a benchmark: run by hand with --ignored --nocapture"]
    async fn quick_pass_benchmark_on_silent_addresses() {
        let lo: IpAddr = "127.0.0.1".parse().unwrap();
        let holders: Vec<std::net::UdpSocket> = (0..200)
            .map(|_| std::net::UdpSocket::bind("127.0.0.1:0").unwrap())
            .collect();
        let cands: Vec<(IpAddr, u16)> = holders
            .iter()
            .map(|s| (lo, s.local_addr().unwrap().port()))
            .collect();
        let st = ScanMode::Turbo.strategy();
        let started = Instant::now();
        let cfg = ScanConfig::default();
        let pass = quick_filter(&cands, &st, Carrier::Quic, &cfg, &Default::default(), log::Level::Info).await;
        println!(
            "quick pass over {} silent addresses: {:?} (retries={}), answered {}, silent {}",
            cands.len(),
            started.elapsed(),
            cfg.retries,
            pass.live.len(),
            pass.silent.len(),
        );
        drop(holders);
    }

}
