//! The pipelined quick pass.
//!
//! One UDP socket per address family sends the same QUIC Initial to every candidate, paced at a
//! packet rate. A receiver task matches each answer to the address it came from. A probe whose
//! timeout runs out unanswered is sent again, up to `retries` times, so a lost probe costs one
//! timeout. Fresh candidates are not taken in list order: a Thompson-sampling scheduler picks
//! the (range, port) arm whose hit rate looks best so far, and a range that answered is boosted,
//! since live gateways cluster. Candidates a caller already knows to be likely (`hints`) go out
//! first.

use super::*;
use std::collections::{HashMap, VecDeque};

/// Datagrams sent per pacing tick.
const TICK_BATCH: usize = 16;
/// The weight of an arm whose range has answered, against one that has not.
const NEIGHBOUR_BOOST: f64 = 1.5;
/// Beta shapes up to this sum are sampled exactly from order statistics; larger ones from the
/// normal approximation, which is close there and much cheaper.
const EXACT_BETA_MAX_SUM: usize = 12;

/// What the pipelined pass needs, besides its candidates.
pub(in crate::transport::warp::prober) struct PipeCfg {
    pub pps: u32,
    /// How long the whole pass may run, sending and waiting for the last answers.
    pub budget: Duration,
    /// Answers after which the pass stops.
    pub want: usize,
    pub timeout_min: Duration,
    pub timeout_max: Duration,
    /// Extra probes an address gets after its previous one stayed silent for its whole timeout.
    pub retries: u32,
}

/// The result over one address family; `live` keeps the RTT for the merge.
#[derive(Default)]
pub(in crate::transport::warp::prober) struct PipeResult {
    pub live: Vec<(IpAddr, u16, Duration)>,
    pub silent: Vec<(IpAddr, u16)>,
    pub skipped: Vec<(IpAddr, u16)>,
}

/// The answers of the other family, as they come.
pub(in crate::transport::warp::prober) type HintRx = tokio::sync::mpsc::UnboundedReceiver<(IpAddr, u16)>;
/// The candidates an answer of the other family points at.
pub(in crate::transport::warp::prober) type HintMap = fn((IpAddr, u16)) -> Vec<(IpAddr, u16)>;

/// How a pass exchanges answers with the other address family's pass, which run at once: `tap`
/// gets each of this pass's answers as it comes, and `hints` gets the other family's answers,
/// mapped (by the function) to the candidates here that they point at, which go out first.
#[derive(Default)]
pub(in crate::transport::warp::prober) struct Exchange {
    pub tap: Option<tokio::sync::mpsc::UnboundedSender<(IpAddr, u16)>>,
    pub hints: Option<(HintRx, HintMap)>,
}

/// The tally of one (range, port): probes sent (all attempts), answers, the fresh probes sent,
/// and when the fresh probe that ends the pruning threshold went out.
#[derive(Default)]
struct PipeRange {
    tried: u32,
    answered: u32,
    fresh: u32,
    threshold_sent: Option<Instant>,
}

/// Sent and not yet answered: address:port -> (send time, range key).
type Inflight = HashMap<SocketAddr, (Instant, (u128, u16))>;

struct PipeState {
    want: usize,
    /// Silent fresh probes on one range and port before the range is skipped. Each address gets
    /// `retries + 1` probes, so the threshold grows with them: under loss a range that is really
    /// alive is not dropped on the first few lost probes.
    prune_after: u32,
    inflight: parking_lot::Mutex<Inflight>,
    ranges: parking_lot::Mutex<HashMap<(u128, u16), PipeRange>>,
    live: parking_lot::Mutex<Vec<(IpAddr, u16, Duration)>>,
    window: parking_lot::Mutex<RttWindow>,
    /// Raised once `want` answers came in, so the sender stops at its next tick.
    reached: tokio::sync::Notify,
}

impl PipeState {
    fn new(cfg: &PipeCfg) -> Self {
        Self {
            want: cfg.want,
            prune_after: PRUNE_AFTER * (cfg.retries + 1),
            inflight: Default::default(),
            ranges: Default::default(),
            live: Default::default(),
            window: parking_lot::Mutex::new(RttWindow::new(cfg.timeout_min, cfg.timeout_max)),
            reached: tokio::sync::Notify::new(),
        }
    }

    fn done(&self) -> bool {
        self.live.lock().len() >= self.want
    }

    fn note_sent(&self, key: (u128, u16), now: Instant, fresh: bool) {
        let mut ranges = self.ranges.lock();
        let t = ranges.entry(key).or_default();
        t.tried += 1;
        if fresh {
            t.fresh += 1;
            if t.fresh == self.prune_after {
                t.threshold_sent = Some(now);
            }
        }
    }

    /// A range is skipped on a port when its first `prune_after` fresh probes stayed silent for
    /// as long as the timeout, and nothing in it has answered since.
    fn prunable(&self, key: (u128, u16), timeout: Duration) -> bool {
        self.ranges.lock().get(&key).is_some_and(|t| {
            t.answered == 0 && t.threshold_sent.is_some_and(|sent| sent.elapsed() >= timeout)
        })
    }

    /// Whether the probe sent to `addr` at `sent` is still waiting for its answer.
    fn unanswered(&self, addr: SocketAddr, sent: Instant) -> bool {
        self.inflight.lock().get(&addr).is_some_and(|(s, _)| *s == sent)
    }
}

/// An address to probe, with its range key and which attempt this is (1 for the first).
#[derive(Clone, Copy)]
struct Due {
    addr: SocketAddr,
    key: (u128, u16),
    attempt: u32,
}

/// A probe on the wire, in the order sent.
struct Sent {
    addr: SocketAddr,
    key: (u128, u16),
    at: Instant,
    attempt: u32,
}

/// The fresh candidates of one (range, port), in the order they were listed.
struct Arm {
    key: (u128, u16),
    items: VecDeque<Due>,
}

/// A draw from Beta(a, b) for a, b >= 1.
fn sample_beta(a: f64, b: f64) -> f64 {
    let mut rng = rand::rng();
    let (ia, ib) = (a as usize, b as usize);
    if a.fract() == 0.0 && b.fract() == 0.0 && ia + ib <= EXACT_BETA_MAX_SUM {
        // for integer shapes, Beta(a, b) is the a-th smallest of a + b - 1 uniforms
        let n = ia + ib - 1;
        let mut u = [0f64; EXACT_BETA_MAX_SUM];
        for x in u[..n].iter_mut() {
            *x = rng.random::<f64>();
        }
        u[..n].sort_by(f64::total_cmp);
        return u[ia - 1];
    }
    let n = a + b;
    let mean = a / n;
    let sd = (a * b / (n * n * (n + 1.0))).sqrt();
    let u1 = rng.random::<f64>().max(1e-12);
    let u2 = rng.random::<f64>();
    let z = (-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos();
    (mean + sd * z).clamp(1e-9, 1.0 - 1e-9)
}

/// The arm to send from next: the highest Thompson draw of hits against misses so far.
fn pick_arm(arms: &[Arm], st: &PipeState) -> usize {
    let ranges = st.ranges.lock();
    let mut best = 0;
    let mut best_v = f64::MIN;
    for (i, arm) in arms.iter().enumerate() {
        let (tried, hits) = ranges.get(&arm.key).map_or((0, 0), |t| (t.tried, t.answered));
        let misses = tried.saturating_sub(hits);
        let mut v = sample_beta(f64::from(hits) + 1.0, f64::from(misses) + 1.0);
        if hits > 0 {
            v *= NEIGHBOUR_BOOST;
        }
        if v > best_v {
            best_v = v;
            best = i;
        }
    }
    best
}

/// The next fresh candidate, from the arm the scheduler picks. An arm whose range has gone
/// silent is dropped whole, its candidates reported as skipped.
fn next_fresh(arms: &mut Vec<Arm>, st: &PipeState, timeout: Duration, skipped: &mut Vec<(IpAddr, u16)>) -> Option<Due> {
    while !arms.is_empty() {
        let i = pick_arm(arms, st);
        if st.prunable(arms[i].key, timeout) {
            let arm = arms.swap_remove(i);
            skipped.extend(arm.items.iter().map(|d| (d.addr.ip(), d.addr.port())));
            continue;
        }
        let due = arms[i].items.pop_front();
        if arms[i].items.is_empty() {
            arms.swap_remove(i);
        }
        if due.is_some() {
            return due;
        }
    }
    None
}

/// The QUIC Initial every candidate is sent. It is built once, for the family of `peer`: the
/// packet is the same whichever address it goes to.
pub(in crate::transport::warp::prober) fn initial_packet(peer: SocketAddr) -> Option<Vec<u8>> {
    let mut config = quiche::Config::new(quiche::PROTOCOL_VERSION).ok()?;
    config.set_application_protos(&[crate::transport::warp::consts::ALPN_H3]).ok()?;
    config.verify_peer(false);
    let mut scid = [0u8; 16];
    rand::rng().fill(&mut scid[..]);
    let scid = quiche::ConnectionId::from_ref(&scid);
    let sni = quic::masque_sni().unwrap_or_else(|_| quic::default_sni().to_string());
    let local = crate::utils::egress::wildcard_for(peer);
    let mut conn = quiche::connect(Some(&sni), &scid, local, peer, &mut config).ok()?;
    let mut out = [0u8; 1350];
    let (written, _) = conn.send(&mut out).ok()?;
    Some(out[..written].to_vec())
}

/// Reads the answers: each one is matched to the address it came from, which must be one that
/// was sent to and not yet answered. Anything else (a late or stray datagram) is ignored.
async fn receive_answers(
    sock: Arc<tokio::net::UdpSocket>,
    st: Arc<PipeState>,
    tap: Option<tokio::sync::mpsc::UnboundedSender<(IpAddr, u16)>>,
) {
    let mut buf = [0u8; 1500];
    loop {
        match sock.recv_from(&mut buf).await {
            Ok((_, from)) => {
                let hit = st.inflight.lock().remove(&from);
                let Some((sent, key)) = hit else { continue };
                let rtt = sent.elapsed();
                st.ranges.lock().entry(key).or_default().answered += 1;
                st.window.lock().push(rtt);
                let mut live = st.live.lock();
                live.push((from.ip(), from.port(), rtt));
                if let Some(tap) = &tap {
                    let _ = tap.send((from.ip(), from.port()));
                }
                if live.len() >= st.want {
                    st.reached.notify_one();
                }
            }
            // an ICMP error reported on a socket that sent to a closed port: that address is silent
            Err(e) if e.kind() == std::io::ErrorKind::ConnectionReset => continue,
            Err(_) => break,
        }
    }
}

/// Waits for the next pacing tick; false when the pass has what it wants and should stop.
async fn next_tick(ticker: &mut tokio::time::Interval, st: &PipeState) -> bool {
    if st.done() {
        return false;
    }
    tokio::select! {
        _ = ticker.tick() => !st.done(),
        _ = st.reached.notified() => false,
    }
}

/// The pipelined pass over one address family. `candidates` are the addresses to try; `exchange`
/// links it to the other family's pass (see `Exchange`). A probe whose timeout runs out unanswered
/// goes back into the queue for its next attempt; an address is silent when its last attempt ran
/// out unanswered.
pub(in crate::transport::warp::prober) async fn pipeline_family(
    candidates: &[(IpAddr, u16)],
    cfg: &PipeCfg,
    exchange: Exchange,
) -> PipeResult {
    let mut out = PipeResult::default();
    let Some(&(ip0, port0)) = candidates.first() else {
        return out;
    };
    let peer0 = SocketAddr::new(ip0, port0);
    let Some(packet) = initial_packet(peer0) else {
        log::warn!("[scan] quick pass: could not build the probe packet; the full checks decide alone");
        return out;
    };
    let sock = match crate::utils::egress::udp_bind(crate::utils::egress::wildcard_for(peer0)) {
        Ok(s) => Arc::new(s),
        Err(e) => {
            log::warn!("[scan] quick pass: no udp socket ({e}); the full checks decide alone");
            return out;
        }
    };
    let st = Arc::new(PipeState::new(cfg));
    let receiver = tokio::spawn(receive_answers(sock.clone(), st.clone(), exchange.tap));
    let (mut hint_rx, map_hint) = match exchange.hints {
        Some((rx, map)) => (Some(rx), Some(map)),
        None => (None, None),
    };

    let deadline = Instant::now() + cfg.budget;
    let tick = Duration::from_secs_f64(TICK_BATCH as f64 / f64::from(cfg.pps.max(1)));
    let mut ticker = tokio::time::interval(tick);
    ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    // the arms: every candidate, grouped by (range, port) in the order listed. `taken` holds the
    // addresses already queued as hints or sent, so an arm never sends one of them again.
    let cand_set: HashSet<SocketAddr> = candidates
        .iter()
        .map(|&(ip, port)| SocketAddr::new(ip, port))
        .collect();
    let mut taken: HashSet<SocketAddr> = HashSet::new();
    let mut arms: Vec<Arm> = Vec::new();
    let mut arm_of: HashMap<(u128, u16), usize> = HashMap::new();
    let mut listed: HashSet<SocketAddr> = HashSet::new();
    for &(ip, port) in candidates {
        let addr = SocketAddr::new(ip, port);
        if !listed.insert(addr) {
            continue;
        }
        let key = (range_key(ip), port);
        let i = *arm_of.entry(key).or_insert_with(|| {
            arms.push(Arm { key, items: VecDeque::new() });
            arms.len() - 1
        });
        arms[i].items.push_back(Due { addr, key, attempt: 1 });
    }

    let attempts = cfg.retries + 1;
    let mut hinted: VecDeque<Due> = VecDeque::new();
    let mut retry: VecDeque<Due> = VecDeque::new();
    let mut expiring: VecDeque<Sent> = VecDeque::new();

    loop {
        if !next_tick(&mut ticker, &st).await || Instant::now() >= deadline {
            break;
        }
        let timeout = st.window.lock().timeout();

        // the other family's answers that arrived since the last tick
        if let (Some(rx), Some(map)) = (hint_rx.as_mut(), map_hint) {
            loop {
                match rx.try_recv() {
                    Ok(answer) => {
                        for cand in map(answer) {
                            if cand_set.contains(&SocketAddr::new(cand.0, cand.1)) && !taken.contains(&SocketAddr::new(cand.0, cand.1)) {
                                let addr = SocketAddr::new(cand.0, cand.1);
                                taken.insert(addr);
                                hinted.push_back(Due { addr, key: (range_key(cand.0), cand.1), attempt: 1 });
                            }
                        }
                    }
                    Err(tokio::sync::mpsc::error::TryRecvError::Empty) => break,
                    Err(tokio::sync::mpsc::error::TryRecvError::Disconnected) => {
                        hint_rx = None;
                        break;
                    }
                }
            }
        }

        // the probes whose timeout has run out: retried while they have attempts left
        while let Some(front) = expiring.front() {
            if front.at + timeout > Instant::now() {
                break;
            }
            let Some(p) = expiring.pop_front() else { break };
            if !st.unanswered(p.addr, p.at) {
                continue;
            }
            if p.attempt < attempts {
                retry.push_back(Due { addr: p.addr, key: p.key, attempt: p.attempt + 1 });
            } else {
                out.silent.push((p.addr.ip(), p.addr.port()));
            }
        }

        // this tick's batch: due retries, then hints, then the scheduler's picks
        for _ in 0..TICK_BATCH {
            let due = if let Some(d) = retry.pop_front() {
                d
            } else if let Some(d) = hinted.pop_front() {
                d
            } else if let Some(d) = next_fresh(&mut arms, &st, timeout, &mut out.skipped) {
                // an arm's candidate may already have gone out as a hint
                if !taken.insert(d.addr) {
                    continue;
                }
                d
            } else {
                break;
            };
            if st.prunable(due.key, timeout) {
                out.skipped.push((due.addr.ip(), due.addr.port()));
                continue;
            }
            let now = Instant::now();
            st.inflight.lock().insert(due.addr, (now, due.key));
            st.note_sent(due.key, now, due.attempt == 1);
            expiring.push_back(Sent { addr: due.addr, key: due.key, at: now, attempt: due.attempt });
            // a send that fails (no route, an unreachable host) is one more silent address
            let _ = sock.send_to(&packet, due.addr).await;
        }

        if arms.is_empty() && hinted.is_empty() && retry.is_empty() && expiring.is_empty() {
            break;
        }
    }
    receiver.abort();

    let mut live = std::mem::take(&mut *st.live.lock());
    live.sort_by_key(|h| h.2);
    out.live = live;
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pipe_cfg(pps: u32, timeout_ms: u64) -> PipeCfg {
        PipeCfg {
            pps,
            budget: Duration::from_secs(10),
            want: usize::MAX,
            timeout_min: Duration::from_millis(timeout_ms),
            timeout_max: Duration::from_millis(timeout_ms),
            retries: 0,
        }
    }

    #[test]
    fn the_probe_packet_is_a_long_header_quic_initial() {
        let peer: SocketAddr = "127.0.0.1:443".parse().unwrap();
        let packet = initial_packet(peer).expect("a packet builds");
        assert!(!packet.is_empty());
        assert_eq!(packet[0] & 0x80, 0x80, "long header: an Initial");
    }

    #[test]
    fn beta_draws_have_the_right_means_in_both_regimes() {
        let n = 20_000;
        let exact = (0..n).map(|_| sample_beta(3.0, 5.0)).sum::<f64>() / f64::from(n);
        assert!((exact - 3.0 / 8.0).abs() < 0.01, "exact regime: {exact}");
        let approx = (0..n).map(|_| sample_beta(50.0, 10.0)).sum::<f64>() / f64::from(n);
        assert!((approx - 50.0 / 60.0).abs() < 0.01, "normal regime: {approx}");
        assert!((0..1000).all(|_| {
            let x = sample_beta(1.0, 1.0);
            x > 0.0 && x < 1.0
        }));
    }

    #[test]
    fn the_scheduler_prefers_the_arm_that_has_answered() {
        let cfg = pipe_cfg(1000, 100);
        let st = PipeState::new(&cfg);
        let hot: (u128, u16) = (1, 443);
        let cold: (u128, u16) = (2, 443);
        {
            let mut r = st.ranges.lock();
            r.insert(hot, PipeRange { tried: 20, answered: 10, fresh: 20, threshold_sent: None });
            r.insert(cold, PipeRange { tried: 20, answered: 0, fresh: 20, threshold_sent: None });
        }
        let arms = vec![
            Arm { key: cold, items: VecDeque::new() },
            Arm { key: hot, items: VecDeque::new() },
        ];
        let hot_picks = (0..200).filter(|_| arms[pick_arm(&arms, &st)].key == hot).count();
        assert!(hot_picks >= 180, "the answering arm gets most picks: {hot_picks}/200");
    }

    #[tokio::test]
    async fn a_retry_finds_what_a_lost_first_probe_hid() {
        let lo: IpAddr = "127.0.0.1".parse().unwrap();
        let ports = lossy_responders(10).await;
        let cands: Vec<(IpAddr, u16)> = ports.iter().map(|p| (lo, *p)).collect();

        let mut cfg = pipe_cfg(3000, 200);
        let none = pipeline_family(&cands, &cfg, Exchange::default()).await;
        assert!(none.live.is_empty(), "with no retry every first probe is lost");
        assert_eq!(none.silent.len(), 10);

        cfg.retries = 1;
        let one = pipeline_family(&cands, &cfg, Exchange::default()).await;
        assert_eq!(one.live.len(), 10, "one retry reaches every responder");
        assert!(one.silent.is_empty());
    }

    #[tokio::test]
    async fn hints_go_first_and_each_address_is_sent_once() {
        let lo: IpAddr = "127.0.0.1".parse().unwrap();
        let ports = lossy_responders(4).await;
        let cands: Vec<(IpAddr, u16)> = ports.iter().map(|p| (lo, *p)).collect();
        // a hint for the first candidate, mapped to itself, queued before the pass starts
        let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
        tx.send((lo, ports[0])).unwrap();
        drop(tx);
        let exchange = Exchange { tap: None, hints: Some((rx, |a| vec![a])) };
        let pass = pipeline_family(&cands, &pipe_cfg(3000, 150), exchange).await;
        assert!(pass.live.is_empty(), "no retry: every responder drops its first datagram");
        assert_eq!(pass.silent.len(), 4, "hinted or not, each candidate is probed once and found silent");
    }

    #[tokio::test]
    async fn an_answer_is_tapped_for_the_other_family() {
        let lo: IpAddr = "127.0.0.1".parse().unwrap();
        let ports = lossy_responders(2).await;
        let cands: Vec<(IpAddr, u16)> = ports.iter().map(|p| (lo, *p)).collect();
        let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel();
        let mut cfg = pipe_cfg(3000, 150);
        cfg.retries = 1;
        let pass = pipeline_family(&cands, &cfg, Exchange { tap: Some(tx), hints: None }).await;
        assert_eq!(pass.live.len(), 2);
        let mut tapped = Vec::new();
        while let Ok(a) = rx.try_recv() {
            tapped.push(a);
        }
        tapped.sort();
        assert_eq!(tapped.len(), 2, "every answer is passed on as it comes");
    }

    #[cfg(target_os = "linux")]
    #[tokio::test]
    async fn a_silent_range_is_skipped_once_its_first_probes_have_timed_out() {
        // 40 addresses of one /24 on a closed port. At 100 packets a second the sender takes one
        // 16-probe tick every 160 ms; the timeout is 100 ms, so from the second tick on the range
        // has been silent for its first six probes and the rest is skipped.
        let dead_port = closed_port();
        let candidates: Vec<(IpAddr, u16)> = (2..42u8)
            .map(|last| (IpAddr::V4(Ipv4Addr::new(127, 0, 0, last)), dead_port))
            .collect();
        let pass = pipeline_family(&candidates, &pipe_cfg(100, 100), Exchange::default()).await;
        assert!(pass.live.is_empty());
        assert!(!pass.skipped.is_empty(), "the silent range is pruned");
        assert_eq!(pass.silent.len() + pass.skipped.len(), candidates.len(), "every candidate is accounted for");
        assert!(pass.silent.len() <= 16 + 6, "at most the first tick was sent before the pruning");
    }
}
