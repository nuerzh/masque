//! The scan's settings. They are read once, when a scan is set up, and then carried through it:
//! no part of the scan reads `AETHER_SCAN_*` itself, so a scan cannot see two different values
//! for one setting, and a test can build any configuration without touching the environment.

use super::*;

/// The fewest and most packets per second the quick pass may send.
const MIN_PPS: u32 = 100;
const MAX_PPS: u32 = 100_000;
/// The send rate of the quick pass when `AETHER_SCAN_PPS` does not say otherwise.
pub const DEFAULT_PPS: u32 = 3000;
/// Extra probes per address after a silent one, when `AETHER_SCAN_RETRIES` does not say otherwise:
/// enough to ride out a lost probe or two, at up to three times the packets on a silent address.
pub const DEFAULT_RETRIES: u32 = 2;
/// The most retries a scan may ask for.
const MAX_RETRIES: u32 = 5;

/// Every setting of a scan, validated.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ScanConfig {
    /// The quick pass's send rate, packets per second.
    pub pps: u32,
    /// Extra probes per address after a silent one (pipelined quick pass).
    pub retries: u32,
    /// Whether the quick pass runs pipelined (`AETHER_SCAN_PIPELINE`); off means one probe at a
    /// time, each from its own socket.
    pub pipeline: bool,
    /// Whether the scan runs the quick pass before the full checks (`AETHER_SCAN_PREFILTER`).
    pub prefilter: bool,
    /// The RTT ceiling in milliseconds: None for the mode's own, 0 for none (`AETHER_SCAN_MAX_RTT`).
    pub max_rtt_ms: Option<u64>,
    /// The number of rounds, None for the mode's own (`AETHER_SCAN_ROUNDS`).
    pub scan_rounds: Option<u32>,
    /// Whether the scan keeps a background scan going (`AETHER_SCAN_SWITCH`).
    pub scan_switch: bool,
    /// The file the scan memory is kept in across runs (`AETHER_SCAN_MEMORY`); None keeps it in
    /// the process only.
    pub memory: Option<String>,
}

impl Default for ScanConfig {
    fn default() -> Self {
        Self {
            pps: DEFAULT_PPS,
            retries: DEFAULT_RETRIES,
            pipeline: true,
            prefilter: true,
            max_rtt_ms: None,
            scan_rounds: None,
            scan_switch: true,
            memory: None,
        }
    }
}

/// Reads one setting: unset or blank takes `default`; a value `parse` refuses is logged and takes
/// `default` too.
fn setting<T>(
    get: &dyn Fn(&str) -> Option<String>,
    key: &str,
    parse: impl Fn(&str) -> Option<T>,
    default: T,
) -> T {
    match get(key).filter(|v| !v.trim().is_empty()) {
        None => default,
        Some(raw) => parse(&raw).unwrap_or_else(|| {
            log::warn!("[scan] {key}={raw:?} is not a usable value; using the default");
            default
        }),
    }
}

/// A switch that is on unless set to one of 0, false, no or off.
fn switch_on(get: &dyn Fn(&str) -> Option<String>, key: &str) -> bool {
    !matches!(
        get(key).unwrap_or_default().trim().to_ascii_lowercase().as_str(),
        "0" | "false" | "no" | "off"
    )
}

impl ScanConfig {
    /// The settings a lookup gives. Any key the lookup does not know is a default.
    pub fn from_lookup(get: impl Fn(&str) -> Option<String>) -> Self {
        let get: &dyn Fn(&str) -> Option<String> = &get;
        let default = Self::default();
        let pps = setting(get, "AETHER_SCAN_PPS", |v| v.trim().parse::<u32>().ok(), default.pps)
            .clamp(MIN_PPS, MAX_PPS);
        let retries = setting(get, "AETHER_SCAN_RETRIES", |v| v.trim().parse::<u32>().ok(), default.retries)
            .min(MAX_RETRIES);
        Self {
            pps,
            retries,
            pipeline: switch_on(get, "AETHER_SCAN_PIPELINE"),
            prefilter: switch_on(get, "AETHER_SCAN_PREFILTER"),
            // None: the mode's own ceiling; Some(0): no ceiling (see `max_rtt_for`)
            max_rtt_ms: setting(get, "AETHER_SCAN_MAX_RTT", |v| parse_max_rtt(v).map(Some), None),
            scan_rounds: setting(get, "AETHER_SCAN_ROUNDS", |v| parse_scan_rounds(v).map(Some), None),
            scan_switch: setting(get, "AETHER_SCAN_SWITCH", parse_scan_switch, true),
            memory: get("AETHER_SCAN_MEMORY").map(|v| v.trim().to_string()).filter(|v| !v.is_empty()),
        }
    }

    /// The settings of the environment, read now.
    pub fn from_env() -> Self {
        Self::from_lookup(|k| crate::config::settings::var(k).ok())
    }

    /// The effective settings, for the log: read once per scan, so the log says what it used.
    pub fn describe(&self) -> String {
        format!(
            "pps={} retries={} pipeline={} prefilter={} max_rtt_ms={:?} rounds={:?} switch={} memory={:?}",
            self.pps,
            self.retries,
            self.pipeline,
            self.prefilter,
            self.max_rtt_ms,
            self.scan_rounds,
            self.scan_switch,
            self.memory,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    fn lookup(pairs: &[(&str, &str)]) -> impl Fn(&str) -> Option<String> {
        let map: HashMap<String, String> =
            pairs.iter().map(|(k, v)| (k.to_string(), v.to_string())).collect();
        move |k: &str| map.get(k).cloned()
    }

    #[test]
    fn nothing_set_gives_the_defaults() {
        assert_eq!(ScanConfig::from_lookup(lookup(&[])), ScanConfig::default());
    }

    #[test]
    fn values_are_read_and_bounded() {
        let c = ScanConfig::from_lookup(lookup(&[
            ("AETHER_SCAN_PPS", "5"),
            ("AETHER_SCAN_RETRIES", "99"),
            ("AETHER_SCAN_PIPELINE", "0"),
            ("AETHER_SCAN_MAX_RTT", "off"),
            ("AETHER_SCAN_ROUNDS", "4"),
            ("AETHER_SCAN_SWITCH", "no"),
        ]));
        assert_eq!(c.pps, MIN_PPS, "clamped up");
        assert_eq!(c.retries, MAX_RETRIES, "clamped down");
        assert!(!c.pipeline);
        assert_eq!(c.max_rtt_ms, Some(0), "off is a ceiling of zero: no ceiling");
        assert_eq!(c.scan_rounds, Some(4));
        assert!(!c.scan_switch);
    }

    #[test]
    fn a_value_that_does_not_parse_takes_its_default() {
        let c = ScanConfig::from_lookup(lookup(&[("AETHER_SCAN_PPS", "fast"), ("AETHER_SCAN_ROUNDS", "")]));
        assert_eq!(c.pps, DEFAULT_PPS);
        assert_eq!(c.scan_rounds, None, "a blank value is unset");
    }
}
