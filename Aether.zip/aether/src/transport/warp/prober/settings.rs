//! The scan's settings from the environment (`AETHER_SCAN_*`): the RTT ceiling, the scan switch,
//! and the quick pass's send rate, retries and prefilter. Each is read where it is used, so a
//! change takes effect at the next scan.

use super::*;


/// The ceiling a scan puts on a gateway's full-handshake RTT unless --max-rtt
/// (AETHER_SCAN_MAX_RTT, `scan_max_rtt` in the config file) says otherwise. Every scan mode
/// applies it.
pub const DEFAULT_MAX_RTT_MS: u64 = 500;

/// A --max-rtt value in milliseconds: digits, optionally followed by `ms`; `off`/`none` is 0
/// (no ceiling). `None` when it is neither.
pub fn parse_max_rtt(raw: &str) -> Option<u64> {
    let v = raw.trim().to_ascii_lowercase();
    if matches!(v.as_str(), "off" | "none" | "no") {
        return Some(0);
    }
    v.strip_suffix("ms").unwrap_or(&v).trim().parse::<u64>().ok()
}

/// The RTT ceiling a scan applies, given the setting the user gave (`None`: not given): 500 ms
/// by default, `setting` ms when given, none for 0. Every mode applies it (`_mode` is kept so
/// the call sites read as before).
pub fn max_rtt_for(_mode: ScanMode, setting: Option<u64>) -> Option<Duration> {
    match setting.unwrap_or(DEFAULT_MAX_RTT_MS) {
        0 => None,
        ms => Some(Duration::from_millis(ms)),
    }
}

/// A --scan-switch value: on (`1`, `true`, `yes`, `on`) or off (`0`, `false`, `no`, `off`);
/// `None` when it is neither.
pub fn parse_scan_switch(raw: &str) -> Option<bool> {
    match raw.trim().to_ascii_lowercase().as_str() {
        "1" | "true" | "yes" | "on" => Some(true),
        "0" | "false" | "no" | "off" => Some(false),
        _ => None,
    }
}

