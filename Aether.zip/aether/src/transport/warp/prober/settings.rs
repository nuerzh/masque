//! The scan's settings from the environment (`AETHER_SCAN_*`): the RTT ceiling, the scan switch,
//! and the quick pass's send rate, retries and prefilter. Each is read where it is used, so a
//! change takes effect at the next scan.

use super::*;

/// The widest a quick probe waits for an answer; also the timeout before enough answers came in
/// to adapt it.
/// The shortest the adaptive timeout gets.
/// Silent fresh probes on one range and port before the rest of that range is skipped on that
/// port (times `retries + 1` for the pipelined pass).
/// The sweep ports the ranges are swept on when the port check has nothing to say.
/// The send rate of the pipelined pass when `AETHER_SCAN_PPS` does not say otherwise.
pub(super) const DEFAULT_PPS: u32 = 3000;
const MIN_PPS: u32 = 100;
const MAX_PPS: u32 = 100_000;
/// Extra probes per address after a silent one, when `AETHER_SCAN_RETRIES` does not say
/// otherwise: enough to ride out a lost probe or two, at up to three times the packets on a
/// silent address.
pub(super) const DEFAULT_RETRIES: u32 = 2;
const MAX_RETRIES: u32 = 5;

/// The ceiling a scan puts on a gateway's full-handshake RTT unless --max-rtt
/// (AETHER_SCAN_MAX_RTT, `scan_max_rtt` in the config file) says otherwise. Every scan mode
/// applies it.
pub const DEFAULT_MAX_RTT_MS: u64 = 500;

/// A --max-rtt value in milliseconds: digits, optionally followed by `ms`; `off`/`none` is 0
/// (no ceiling). `None` when it is neither.
pub fn parse_max_rtt(raw: &str) -> Option<u64> {
    let v = raw.trim().to_ascii_lowercase();
    if matches!(v.as_str(), "off" | "none" | "no") {
        return Some(0);
    }
    v.strip_suffix("ms").unwrap_or(&v).trim().parse::<u64>().ok()
}

/// The scan.max-rtt of the config file, in milliseconds (AETHER_SCAN_MAX_RTT). `None` when it
/// gives none (or it does not parse, which is logged).
pub fn max_rtt_setting() -> Option<u64> {
    if let Ok(raw) = crate::config::settings::var("AETHER_SCAN_MAX_RTT") {
        if !raw.trim().is_empty() {
            return match parse_max_rtt(&raw) {
                Some(ms) => Some(ms),
                None => {
                    log::warn!("[scan] AETHER_SCAN_MAX_RTT={raw:?} is not a number of milliseconds; using the default");
                    None
                }
            };
        }
    }
    None
}

/// The RTT ceiling a scan applies, given the setting the user gave (`None`: not given): 500 ms
/// by default, `setting` ms when given, none for 0. Every mode applies it (`_mode` is kept so
/// the call sites read as before).
pub fn max_rtt_for(_mode: ScanMode, setting: Option<u64>) -> Option<Duration> {
    match setting.unwrap_or(DEFAULT_MAX_RTT_MS) {
        0 => None,
        ms => Some(Duration::from_millis(ms)),
    }
}

/// A --scan-switch value: on (`1`, `true`, `yes`, `on`) or off (`0`, `false`, `no`, `off`);
/// `None` when it is neither.
pub fn parse_scan_switch(raw: &str) -> Option<bool> {
    match raw.trim().to_ascii_lowercase().as_str() {
        "1" | "true" | "yes" | "on" => Some(true),
        "0" | "false" | "no" | "off" => Some(false),
        _ => None,
    }
}

/// Whether the scan goes on in the background once the tunnel started and moves the tunnel to a
/// much faster gateway (on by default): scan.switch of the config file (AETHER_SCAN_SWITCH).
pub fn scan_switch_setting() -> bool {
    if let Ok(raw) = crate::config::settings::var("AETHER_SCAN_SWITCH") {
        if !raw.trim().is_empty() {
            return match parse_scan_switch(&raw) {
                Some(on) => on,
                None => {
                    log::warn!("[scan] AETHER_SCAN_SWITCH={raw:?} is neither on nor off; keeping it on");
                    true
                }
            };
        }
    }
    true
}

/// Whether the environment variable `key` is on: unset, or set to anything but 0, false, no or
/// off.
pub(super) fn flag_on(key: &str) -> bool {
    !matches!(
        crate::config::settings::var(key)
            .unwrap_or_default()
            .trim()
            .to_lowercase()
            .as_str(),
        "0" | "false" | "no" | "off"
    )
}

pub(super) fn prefilter_enabled() -> bool {
    flag_on("AETHER_SCAN_PREFILTER")
}

/// The pipelined pass's send rate: `AETHER_SCAN_PPS`, else `DEFAULT_PPS`, within bounds.
pub(super) fn scan_pps() -> u32 {
    crate::config::settings::var("AETHER_SCAN_PPS")
        .ok()
        .and_then(|v| v.trim().parse::<u32>().ok())
        .unwrap_or(DEFAULT_PPS)
        .clamp(MIN_PPS, MAX_PPS)
}

/// The extra attempts per address: `AETHER_SCAN_RETRIES`, else `DEFAULT_RETRIES`, up to 5.
pub(super) fn scan_retries() -> u32 {
    crate::config::settings::var("AETHER_SCAN_RETRIES")
        .ok()
        .and_then(|v| v.trim().parse::<u32>().ok())
        .unwrap_or(DEFAULT_RETRIES)
        .min(MAX_RETRIES)
}

