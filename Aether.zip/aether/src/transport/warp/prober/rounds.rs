use super::*;

// ---- deep scan: the rounds of a scan ----------------------------------------------------------
//
// The first round is upstream Aether's scan (the seeds and a sample of every range on the primary
// port, then the seeds on every other port). With the background scan on (the default, see
// `live.rs`) every round runs: --scan-rounds is how far the scan goes after the tunnel started.
// With --no-scan-switch a scan with an RTT ceiling takes later rounds only while nothing came in
// under the ceiling: it scans again instead of falling back at once. Each later round leaves out every address:port an
// earlier round probed (and the seed and verified gateways, which only the first round probes),
// samples more of each range (twice as many per round, the last round every address of every
// /24) on more ports (the other ports that answered the port check, the last round every scan
// port). The picker carries across rounds, so the fastest gateway of every round is kept; the
// first round that finds one within the ceiling ends the scan, and only when none does is the
// fastest of all rounds used, with a warning.

/// How many rounds a scan takes at most, unless --scan-rounds (AETHER_SCAN_ROUNDS,
/// `scan_rounds` in the config file) says otherwise.
pub const DEFAULT_SCAN_ROUNDS: u32 = 3;
/// The most rounds --scan-rounds takes.
pub const MAX_SCAN_ROUNDS: u32 = 10;
/// Hosts a /24 has to sample from (.1 to .254).
const HOSTS_PER_SLASH_24: usize = 254;
/// How far the IPv6 sample per /48 grows over its first round.
const V6_GROWTH_CAP: usize = 8;

/// A --scan-rounds value: a whole number from 1 to `MAX_SCAN_ROUNDS`; `None` when it is not.
pub fn parse_scan_rounds(raw: &str) -> Option<u32> {
    raw.trim()
        .parse::<u32>()
        .ok()
        .filter(|n| (1..=MAX_SCAN_ROUNDS).contains(n))
}

/// The --scan-rounds the user gave: the command line or AETHER_SCAN_ROUNDS, else `scan_rounds`
/// of the config file. `None` when neither gives one (or it does not parse, which is logged).
pub fn scan_rounds_setting() -> Option<u32> {
    if let Ok(raw) = crate::config::settings::var("AETHER_SCAN_ROUNDS") {
        if !raw.trim().is_empty() {
            return match parse_scan_rounds(&raw) {
                Some(n) => Some(n),
                None => {
                    log::warn!(
                        "[scan] AETHER_SCAN_ROUNDS={raw:?} is not a number of rounds from 1 to {MAX_SCAN_ROUNDS}; using the default"
                    );
                    None
                }
            };
        }
    }
    None
}

/// How many rounds a scan with ceiling `max_rtt` may take, given the --scan-rounds the user gave
/// (`None`: not given), in any mode. A background scan (`live`) takes them all, ceiling or not.
/// A scan that picks once it is over (--no-scan-switch) scans deeper only toward a ceiling: with
/// --max-rtt 0 it takes one round.
pub fn rounds_for(_mode: ScanMode, max_rtt: Option<Duration>, setting: Option<u32>, live: bool) -> u32 {
    if !live && max_rtt.is_none() {
        return 1;
    }
    setting.unwrap_or(DEFAULT_SCAN_ROUNDS).clamp(1, MAX_SCAN_ROUNDS)
}

/// What one round scans.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct RoundPlan {
    pub round: u32,
    pub rounds: u32,
    /// Every address of every IPv4 range, rather than `sample_v4` of each.
    pub full_subnet: bool,
    pub sample_v4: usize,
    pub sample_v6: usize,
    /// The ports the ranges are swept on.
    pub ports: Vec<u16>,
    /// Whether the seed gateways are probed (on the sweep ports first, then on every port):
    /// the first round only.
    pub seeds: bool,
}

impl RoundPlan {
    pub(super) fn sample_label(&self) -> String {
        if self.full_subnet {
            "every address of each /24".to_string()
        } else {
            format!("{} per /24", self.sample_v4.min(HOSTS_PER_SLASH_24))
        }
    }
}

/// `list` followed by what `more` has that it does not, in order.
fn union(list: &[u16], more: &[u16]) -> Vec<u16> {
    let mut out = list.to_vec();
    for p in more {
        if !out.contains(p) {
            out.push(*p);
        }
    }
    out
}

/// The plan of round `round` of `rounds`. `sweep` is what the first round sweeps the ranges on
/// (the best ports of the port check, or the first port), `alive` every port that answered the
/// port check, best first, and `ports` every port the scan tries.
pub(super) fn plan_round(
    st: &Strategy,
    round: u32,
    rounds: u32,
    sweep: &[u16],
    alive: &[u16],
    ports: &[u16],
) -> RoundPlan {
    let sweep: Vec<u16> = if sweep.is_empty() {
        vec![ports.first().copied().unwrap_or(MASQUE_PORTS[0])]
    } else {
        sweep.to_vec()
    };
    let base_v6 = if st.sample_per_cidr == 0 { 96 } else { st.sample_per_cidr };
    if round <= 1 {
        return RoundPlan {
            round: 1,
            rounds,
            full_subnet: st.full_subnet,
            sample_v4: st.sample_per_cidr,
            sample_v6: base_v6,
            ports: sweep,
            seeds: true,
        };
    }
    let growth = 1usize << (round - 1).min(16);
    let last = round >= rounds;
    RoundPlan {
        round,
        rounds,
        full_subnet: last || st.full_subnet,
        sample_v4: if last {
            HOSTS_PER_SLASH_24
        } else {
            st.sample_per_cidr.max(1).saturating_mul(growth).min(HOSTS_PER_SLASH_24)
        },
        sample_v6: base_v6.saturating_mul(growth.min(V6_GROWTH_CAP)),
        ports: if last {
            union(&union(&sweep, alive), ports)
        } else {
            union(&sweep, alive)
        },
        seeds: false,
    }
}

/// The seed and verified gateways: only the first round probes them.
pub(super) fn first_round_addresses() -> HashSet<IpAddr> {
    catalog::current().seeds_v4
        .iter()
        .chain(catalog::current().verified_v4)
        .chain(catalog::current().seeds_v6)
        .filter_map(|s| s.parse::<IpAddr>().ok())
        .collect()
}

/// The candidates of a round: the seeds on the plan's ports (first round), the ranges on the
/// plan's ports, then the seeds on every port in `all_ports` (first round).
///
/// The IPv6 candidates are the IPv4 gateways of the ranges embedded under each IPv6 prefix of the
/// scan (see `embed_v4`): the MASQUE gateways are numbered that way, so the IPv4 host sample
/// picks the IPv6 addresses too. A round that samples takes `sample_v6` hosts of each IPv4 range
/// for the IPv6 prefixes, as many as the round sampled before the embedding; the last round, and
/// a full-subnet scan, take every host.
pub(super) fn build_round_candidates(
    plan: &RoundPlan,
    all_ports: &[u16],
    ip: IpScan,
) -> Vec<(IpAddr, u16)> {
    let sweep = &plan.ports;
    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();
    let mut push = |out: &mut Vec<(IpAddr, u16)>, a: IpAddr, port: u16| {
        if seen.insert((a, port)) {
            out.push((a, port));
        }
    };

    let seeds: Vec<Ipv4Addr> = if plan.seeds {
        catalog::current().seeds_v4.iter().filter_map(|s| s.parse().ok()).collect()
    } else {
        Vec::new()
    };
    let seeds6: Vec<Ipv6Addr> = if plan.seeds {
        catalog::current().seeds_v6.iter().filter_map(|s| s.parse().ok()).collect()
    } else {
        Vec::new()
    };

    // the IPv4 hosts of each range: the IPv4 candidates, and the source of the IPv6 ones
    let v4_hosts = |per: usize| -> Vec<Vec<Ipv4Addr>> {
        masque_cidrs_v4()
            .iter()
            .map(|c| if plan.full_subnet { enumerate_cidr_v4(c) } else { sample_cidr_v4(c, per) })
            .collect()
    };

    if ip.want_v4() {
        for a in &seeds {
            for &port in sweep {
                push(&mut out, IpAddr::V4(*a), port);
            }
        }
        let cidr_hosts = v4_hosts(plan.sample_v4);
        let max_len = cidr_hosts.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for hosts in &cidr_hosts {
                if let Some(a) = hosts.get(i) {
                    for &port in sweep {
                        push(&mut out, IpAddr::V4(*a), port);
                    }
                }
            }
        }
    }

    if ip.want_v6() {
        for a in &seeds6 {
            for &port in sweep {
                push(&mut out, IpAddr::V6(*a), port);
            }
        }
        // the same number of IPv6 hosts per prefix as before the embedding: `sample_v6` of the
        // IPv4 hosts, taken one from each range in turn (all of them for a full scan)
        let bases = v6_prefix_bases();
        let pool6 = v4_hosts(plan.sample_v6);
        let limit = if plan.full_subnet { usize::MAX } else { plan.sample_v6 };
        let max6 = pool6.iter().map(|v| v.len()).max().unwrap_or(0);
        let mut hosts6: Vec<Ipv4Addr> = Vec::new();
        'fill: for i in 0..max6 {
            for hosts in &pool6 {
                if let Some(h) = hosts.get(i) {
                    if hosts6.len() >= limit {
                        break 'fill;
                    }
                    hosts6.push(*h);
                }
            }
        }
        for h in &hosts6 {
            for &base in &bases {
                for &port in sweep {
                    push(&mut out, IpAddr::V6(embed_v4(base, *h)), port);
                }
            }
        }
    }

    if ip.want_v4() {
        for a in &seeds {
            for &port in all_ports {
                push(&mut out, IpAddr::V4(*a), port);
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            for &port in all_ports {
                push(&mut out, IpAddr::V6(*a), port);
            }
        }
    }

    out
}

/// `candidates` without what an earlier round probed and without the first-round addresses:
/// what is left, how many address:port pairs were already probed, and how many were seed or
/// verified gateways.
pub(super) fn leave_out_probed(
    candidates: Vec<(IpAddr, u16)>,
    probed: &HashSet<(IpAddr, u16)>,
    first_round: &HashSet<IpAddr>,
) -> (Vec<(IpAddr, u16)>, usize, usize) {
    let (mut dup, mut seeds) = (0, 0);
    let left = candidates
        .into_iter()
        .filter(|c| {
            if first_round.contains(&c.0) {
                seeds += 1;
                false
            } else if probed.contains(c) {
                dup += 1;
                false
            } else {
                true
            }
        })
        .collect();
    (left, dup, seeds)
}

/// What a whole scan needs to know besides how to probe.
pub(super) struct ScanInput<'a> {
    pub mode: ScanMode,
    pub st: &'a Strategy,
    pub ip: IpScan,
    pub ports: &'a [u16],
    pub sweep: &'a [u16],
    pub alive: &'a [u16],
    pub avoid: &'a HashSet<IpAddr>,
    pub max_rtt: Option<Duration>,
    pub rounds: u32,
    pub prefilter: bool,
}

/// How a scan ended.
#[derive(Debug)]
pub(super) struct ScanOutcome {
    /// A turbo scan's first answer.
    pub first: Option<ProbeResult>,
    pub pick: Option<Pick>,
    /// The rounds that ran.
    pub rounds_run: u32,
    /// Gateways that passed but were over the ceiling, over every round.
    pub over: usize,
    /// The plan of every round that ran (read by the tests).
    #[cfg_attr(not(test), allow(dead_code))]
    pub plans: Vec<RoundPlan>,
}

/// The scan that picks once it is over (--no-scan-switch), round by round. `quick(candidates)`
/// is the quick pass, `verify(ip, port)` the full check.
pub(super) async fn run_rounds<Q, QF, V, VF>(inp: &ScanInput<'_>, quick: Q, verify: V) -> ScanOutcome
where
    Q: Fn(Vec<(IpAddr, u16)>) -> QF,
    QF: std::future::Future<Output = QuickPass>,
    V: Fn(IpAddr, u16) -> VF,
    VF: std::future::Future<Output = Option<ProbeResult>>,
{
    let st = inp.st;
    let mut picker = Picker::new(inp.max_rtt);
    let mut probed: HashSet<(IpAddr, u16)> = HashSet::new();
    let first_round = first_round_addresses();
    let mut quick_ever_answered = false;
    let mut plans = Vec::new();
    let mut rounds_run = 0;
    let cap = inp.max_rtt.unwrap_or_default();

    for round in 1..=inp.rounds.max(1) {
        let plan = plan_round(st, round, inp.rounds, inp.sweep, inp.alive, inp.ports);
        let mut all = leave_out(build_round_candidates(&plan, inp.ports, inp.ip), inp.avoid);
        if round > 1 {
            let (left, dup, seeds) = leave_out_probed(all, &probed, &first_round);
            all = left;
            log::info!(
                "[scan] deep scan round {round}/{}: no gateway within max-rtt {cap:?} yet; sampling {}{} on ports {:?}: {} new candidate(s), {} address:port already probed and {} seed/verified left out",
                inp.rounds,
                plan.sample_label(),
                if inp.ip.want_v6() { format!(" ({} per /48)", plan.sample_v6) } else { String::new() },
                plan.ports,
                all.len(),
                dup,
                seeds,
            );
        }
        plans.push(plan);
        rounds_run = round;
        if all.is_empty() {
            log::info!("[scan] round {round}/{}: nothing left to probe", inp.rounds);
            continue;
        }

        let candidates = if inp.prefilter {
            let QuickPass { live, silent, .. } = quick(all.clone()).await;
            probed.extend(silent);
            if !live.is_empty() {
                quick_ever_answered = true;
                live
            } else if round == 1 || !quick_ever_answered {
                log::warn!("[scan] quick pass found nothing; falling back to full handshakes on every candidate");
                all
            } else {
                log::info!("[scan] round {round}/{}: no new candidate answered the quick pass", inp.rounds);
                continue;
            }
        } else {
            all
        };

        if round == 1 {
            log::info!(
                "[scan] scan mode={} ip={} candidates={} ports={:?} sweep={:?} concurrency={} per_probe={:?} budget={:?} max_rtt={} rounds={}",
                inp.mode.label(),
                inp.ip.label(),
                candidates.len(),
                inp.ports,
                inp.sweep,
                st.concurrency,
                st.per_probe_timeout,
                st.overall_deadline,
                inp.max_rtt.map_or_else(|| "none".to_string(), |d| format!("{d:?}")),
                inp.rounds,
            );
        } else {
            log::info!(
                "[scan] deep scan round {round}/{}: verifying {} candidate(s), budget {:?}",
                inp.rounds,
                candidates.len(),
                st.overall_deadline
            );
        }

        if let Some(pr) = verify_round(st, candidates, round > 1, &mut picker, &mut probed, &verify).await {
            return ScanOutcome { first: Some(pr), pick: None, rounds_run, over: picker.over, plans };
        }
        if picker.counted > 0 || inp.max_rtt.is_none() {
            break;
        }
        if round < inp.rounds {
            log::info!(
                "[scan] round {round}/{} ended with no gateway within max-rtt {cap:?} ({} answered so far, all slower); scanning deeper",
                inp.rounds,
                picker.over
            );
        }
    }

    ScanOutcome { first: None, pick: picker.pick(), rounds_run, over: picker.over, plans }
}

/// The full check of one round's candidates, into `picker`; every candidate whose check
/// finished goes into `probed`. Ends when the candidates run out, at the round's deadline, or a
/// quiet period after the target (in a deeper round, after the first gateway within the
/// ceiling). `Some` only for a turbo scan's first answer within the ceiling.
async fn verify_round<V, VF>(
    st: &Strategy,
    candidates: Vec<(IpAddr, u16)>,
    deeper: bool,
    picker: &mut Picker,
    probed: &mut HashSet<(IpAddr, u16)>,
    verify: &V,
) -> Option<ProbeResult>
where
    V: Fn(IpAddr, u16) -> VF,
    VF: std::future::Future<Output = Option<ProbeResult>>,
{
    let max_rtt = picker.max_rtt;
    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| async move { ((ip, port), verify(ip, port).await) }),
    )
    .buffer_unordered(st.concurrency.max(1));
    tokio::pin!(stream);

    let deadline = Instant::now() + st.overall_deadline;
    let mut quiet_until: Option<Instant> = None;

    loop {
        let effective = match quiet_until {
            Some(q) => q.min(deadline),
            None => deadline,
        };
        let remaining = effective.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            log_scan_end(picker, quiet_until.is_some());
            return None;
        }

        tokio::select! {
            item = stream.next() => {
                let (pair, result) = item?;
                probed.insert(pair);
                let Some(pr) = result else { continue };
                let counted = picker.offer(pr);
                if st.early_exit_first && counted {
                    log::info!("[scan] candidate ok {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
                    return Some(pr);
                }
                if !counted {
                    log::debug!(
                        "[scan] candidate {}:{} rtt={:?} is over max-rtt {:?}; recorded, not counted",
                        pr.ip, pr.port, pr.rtt, max_rtt.unwrap_or_default()
                    );
                    continue;
                }
                log::info!("[scan] candidate ok {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);

                if quiet_until.is_some() {
                    continue;
                }
                let reached = st.target_successes > 0 && picker.counted >= st.target_successes;
                if reached {
                    match max_rtt {
                        Some(cap) => log::info!(
                            "[scan] reached target of {} gateways within max-rtt {:?}, selecting best",
                            st.target_successes, cap
                        ),
                        None => log::info!("[scan] reached target of {} gateways, selecting best", st.target_successes),
                    }
                } else if deeper {
                    log::info!(
                        "[scan] deep scan found a gateway within max-rtt {:?}; finishing after {:?} quiet",
                        max_rtt.unwrap_or_default(),
                        st.quiet_after_first
                    );
                } else {
                    continue;
                }
                if st.quiet_after_first.is_zero() {
                    return None;
                }
                quiet_until = Some(Instant::now() + st.quiet_after_first);
            }
            _ = tokio::time::sleep(remaining) => {
                log_scan_end(picker, quiet_until.is_some());
                return None;
            }
        }
    }
}
