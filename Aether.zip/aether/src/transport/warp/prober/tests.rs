use super::*;

#[test]
fn a_gateway_left_out_is_probed_on_no_port() {
    let left: IpAddr = "162.159.198.1".parse().unwrap();
    let other: IpAddr = "162.159.198.2".parse().unwrap();
    let avoid: HashSet<IpAddr> = [left].into_iter().collect();
    assert_eq!(
        leave_out(vec![(left, 443), (other, 443), (left, 4500)], &avoid),
        vec![(other, 443)]
    );
    assert_eq!(
        leave_out(vec![(left, 443)], &HashSet::new()),
        vec![(left, 443)]
    );
}

#[test]
fn the_documented_zero_trust_masque_ingress_range_is_scanned() {
    assert!(MASQUE_CIDRS_V4.contains(&"162.159.197.0/24"));
    assert!(MASQUE_CIDRS_V6.contains(&"2606:4700:102::/48"));
}

#[test]
fn the_dns_over_https_ranges_are_swept_last_because_they_never_serve_masque() {
    let tail = &MASQUE_CIDRS_V4[MASQUE_CIDRS_V4.len() - MASQUE_DOH_CIDRS_V4.len()..];
    for entry in MASQUE_DOH_CIDRS_V4 {
        assert!(tail.contains(entry), "{entry} should be at the end");
    }
}

#[test]
fn port_443_is_scanned_by_default_but_never_first() {
    assert!(MASQUE_PORTS.contains(&443));
    assert_eq!(MASQUE_PORTS.last(), Some(&443));
}

#[test]
fn port_443_sweeps_only_when_it_answers_more_seeds() {
    let ms = Duration::from_millis;
    // a tie: 443 is faster but goes after 8443
    let mut t = vec![(443, 5, ms(20)), (8443, 5, ms(90)), (500, 3, ms(10))];
    rank_ports(&mut t, Some(443));
    assert_eq!(t.iter().map(|e| e.0).collect::<Vec<_>>(), vec![8443, 443, 500]);
    // more answers: 443 leads
    let mut t = vec![(8443, 4, ms(20)), (443, 6, ms(90))];
    rank_ports(&mut t, Some(443));
    assert_eq!(t[0].0, 443);
    // no 443 involved: count, then rtt
    let mut t = vec![(500, 4, ms(50)), (4500, 4, ms(30)), (8095, 7, ms(99))];
    rank_ports(&mut t, Some(443));
    assert_eq!(t.iter().map(|e| e.0).collect::<Vec<_>>(), vec![8095, 4500, 500]);
    // ports the user named: no tie loser, 443 wins the tie on rtt
    let mut t = vec![(8443, 5, ms(90)), (443, 5, ms(20))];
    rank_ports(&mut t, None);
    assert_eq!(t[0].0, 443);
}

#[test]
fn scan_ports_name_their_own_set_in_order() {
    assert_eq!(masque_ports_of(""), MASQUE_PORTS.to_vec());
    assert_eq!(masque_ports_of("default"), MASQUE_PORTS.to_vec());
    assert_eq!(masque_ports_of("443, 8443,443"), vec![443, 8443]);
    assert_eq!(masque_ports_of("4500 500"), vec![4500, 500]);
}

#[test]
fn the_sweep_covers_every_sweep_port_on_the_ranges_and_all_ports_on_the_seeds() {
    let st = ScanMode::Turbo.strategy();
    let out = build_candidates(&st, &[500, 1701, 4500], &[4500, 500], IpScan::V4);
    let ranged: Vec<_> = out
        .iter()
        .filter(|(ip, _)| !MASQUE_SEEDS.iter().any(|s| s.parse::<IpAddr>().ok() == Some(*ip)))
        .collect();
    assert!(ranged.iter().all(|(_, p)| *p == 4500 || *p == 500));
    assert!(ranged.iter().any(|(_, p)| *p == 500));
    assert_eq!(out.first().map(|c| c.1), Some(4500));
    let seed: IpAddr = MASQUE_SEEDS[0].parse().unwrap();
    assert!(out.contains(&(seed, 1701)));
    let unique: HashSet<_> = out.iter().collect();
    assert_eq!(unique.len(), out.len());
}

#[test]
fn ranges_prune_by_slash_24_and_slash_48() {
    let a: IpAddr = "162.159.198.1".parse().unwrap();
    let b: IpAddr = "162.159.198.200".parse().unwrap();
    let c: IpAddr = "162.159.197.1".parse().unwrap();
    assert_eq!(range_key(a), range_key(b));
    assert_ne!(range_key(a), range_key(c));
    let x: IpAddr = "2606:4700:d0::1".parse().unwrap();
    let y: IpAddr = "2606:4700:d0::a29f:c602".parse().unwrap();
    let z: IpAddr = "2606:4700:d1::1".parse().unwrap();
    assert_eq!(range_key(x), range_key(y));
    assert_ne!(range_key(x), range_key(z));
    assert_ne!(range_key(a), range_key(x));
}

#[tokio::test]
async fn the_quick_pass_keeps_only_what_answers_fastest_first() {
    // a local udp socket that answers anything stands in for a live edge; a closed port
    // stands in for a silent one
    let live = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
    let live_port = live.local_addr().unwrap().port();
    tokio::spawn(async move {
        let mut buf = [0u8; 2048];
        while let Ok((n, from)) = live.recv_from(&mut buf).await {
            let _ = live.send_to(&buf[..n.min(64)], from).await;
        }
    });
    let dead = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
    let dead_port = dead.local_addr().unwrap().port();
    drop(dead);
    let lo: IpAddr = "127.0.0.1".parse().unwrap();
    let st = ScanMode::Turbo.strategy();
    let pass = quick_filter(&[(lo, dead_port), (lo, live_port)], &st, false, log::Level::Info).await;
    assert_eq!(pass.live, vec![(lo, live_port)]);
    assert_eq!(pass.silent, vec![(lo, dead_port)], "the silent one is reported, so a deeper round skips it");
    assert!(pass.skipped.is_empty());
}

#[test]
fn the_documented_masque_fallback_ports_keep_their_documented_order() {
    assert_eq!(MASQUE_PORTS, &[500, 1701, 4500, 4443, 8443, 8095, 443]);
}

#[test]
fn without_a_team_the_range_order_is_left_alone() {
    crate::config::settings::forget("AETHER_TEAM");
    assert_eq!(
        prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4),
        MASQUE_CIDRS_V4.to_vec()
    );
}

#[test]
fn prioritize_moves_the_wanted_entries_to_the_front_without_losing_any() {
    let all = ["a", "b", "c", "d"];
    let out = {
        let mut out: Vec<&'static str> = vec!["c"];
        for entry in all {
            if !out.contains(&entry) {
                out.push(entry);
            }
        }
        out
    };
    assert_eq!(out, vec!["c", "a", "b", "d"]);
    assert_eq!(out.len(), all.len());
}

#[test]
fn the_documented_masque_fallback_ports_are_all_covered() {
    for port in [500u16, 1701, 4443, 4500, 8443, 8095] {
        assert!(
            MASQUE_PORTS.contains(&port),
            "documented fallback port {port} should be scanned"
        );
    }
}

async fn quic_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
    let bind = if peer.is_ipv4() {
        "0.0.0.0:0"
    } else {
        "[::]:0"
    };
    // through egress: marked (Linux) or pinned (Windows) like the tunnel itself, so a
    // probe never enters the --tun device
    let sock = crate::utils::egress::udp_bind(bind.parse().ok()?).ok()?;
    sock.connect(peer).await.ok()?;
    let local = sock.local_addr().ok()?;

    let mut config = quiche::Config::new(quiche::PROTOCOL_VERSION).ok()?;
    config.set_application_protos(&[b"h3"]).ok()?;
    config.verify_peer(false);
    config.set_max_idle_timeout(timeout.as_millis() as u64);
    config.set_initial_max_data(1_000_000);
    config.set_initial_max_stream_data_bidi_local(100_000);
    config.set_initial_max_streams_bidi(4);

    let mut scid = [0u8; 16];
    rand::rng().fill(&mut scid[..]);
    let scid = quiche::ConnectionId::from_ref(&scid);

    // The name the core's MASQUE handshakes send.
    let sni = quic::default_sni();
    let mut conn = quiche::connect(Some(sni), &scid, local, peer, &mut config).ok()?;

    let mut out = [0u8; 1350];
    let (written, _) = conn.send(&mut out).ok()?;

    let started = Instant::now();
    sock.send(&out[..written]).await.ok()?;

    let mut buf = [0u8; 1500];
    match tokio::time::timeout(timeout, sock.recv(&mut buf)).await {
        Ok(Ok(read)) if read > 0 => Some(started.elapsed()),
        _ => None,
    }
}

async fn tcp_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
    let started = Instant::now();
    match tokio::time::timeout(timeout, crate::utils::egress::tcp_connect(peer)).await {
        Ok(Ok(_)) => Some(started.elapsed()),
        _ => None,
    }
}

async fn first_answer(
    targets: &[SocketAddr],
    timeout: Duration,
    attempts: u32,
    udp: bool,
) -> Option<(SocketAddr, Duration)> {
    for _ in 0..attempts {
        let probes = targets.iter().copied().map(|peer| async move {
            let rtt = match udp {
                true => quic_answers(peer, timeout).await,
                false => tcp_answers(peer, timeout).await,
            };
            (peer, rtt)
        });

        let results: Vec<(SocketAddr, Option<Duration>)> = futures::stream::iter(probes)
            .buffer_unordered(targets.len().max(1))
            .collect()
            .await;

        if let Some((peer, Some(rtt))) = results.into_iter().find(|(_, rtt)| rtt.is_some()) {
            return Some((peer, rtt));
        }
    }
    None
}

fn hosts_of(cidr: &str, tails: &[u8]) -> Vec<Ipv4Addr> {
    let base: Ipv4Addr = cidr.split('/').next().unwrap().parse().expect("cidr base");
    let octets = base.octets();
    tails
        .iter()
        .map(|tail| Ipv4Addr::new(octets[0], octets[1], octets[2], *tail))
        .collect()
}

#[tokio::test(flavor = "multi_thread")]
#[ignore = "probes the live cloudflare edge from this network to see which masque ranges answer"]
async fn report_which_masque_ranges_answer_on_this_network() {
    const TAILS: &[u8] = &[1, 2, 3];

    let timeout = Duration::from_millis(
        crate::config::settings::var("AETHER_PROBE_TIMEOUT_MS")
            .ok()
            .and_then(|raw| raw.trim().parse::<u64>().ok())
            .filter(|ms| *ms > 0)
            .unwrap_or(10_000),
    );

    let attempts = crate::config::settings::var("AETHER_PROBE_ATTEMPTS")
        .ok()
        .and_then(|raw| raw.trim().parse::<u32>().ok())
        .filter(|n| *n > 0)
        .unwrap_or(2);

    let ports: Vec<u16> = match crate::config::settings::var("AETHER_PROBE_PORTS") {
        Ok(raw) => raw
            .split(',')
            .filter_map(|p| p.trim().parse::<u16>().ok())
            .collect(),
        Err(_) => vec![443],
    };
    let ports = if ports.is_empty() { vec![443] } else { ports };

    println!();
    println!("probing the masque ranges from this network");
    println!("  udp timeout {timeout:?}, {attempts} attempt(s), hosts {TAILS:?}");
    println!("  udp ports {ports:?}");
    println!("  override: AETHER_PROBE_TIMEOUT_MS, AETHER_PROBE_ATTEMPTS, AETHER_PROBE_PORTS");
    println!();

    let control: Vec<SocketAddr> = vec![
        "1.1.1.1:443".parse().unwrap(),
        "8.8.8.8:443".parse().unwrap(),
    ];

    let control_quic = first_answer(&control, timeout, attempts, true).await;
    let control_tcp = first_answer(&control, timeout, attempts, false).await;

    println!("control targets (public resolvers, not cloudflare warp edges)");
    match control_quic {
        Some((peer, rtt)) => println!("  quic/udp 443 works: {peer} in {}ms", rtt.as_millis()),
        None => println!("  quic/udp 443 got no answer at all"),
    }
    match control_tcp {
        Some((peer, rtt)) => println!("  tcp 443 works:      {peer} in {}ms", rtt.as_millis()),
        None => println!("  tcp 443 got no answer at all"),
    }
    println!();

    let mut udp_ok = Vec::new();
    let mut tcp_only = Vec::new();
    let mut silent = Vec::new();

    for cidr in MASQUE_CIDRS_V4 {
        let note = if MASQUE_DOCUMENTED_CIDRS_V4.contains(cidr) {
            " [documented]"
        } else if MASQUE_DOH_CIDRS_V4.contains(cidr) {
            " [dns-over-https]"
        } else {
            ""
        };

        let hosts = hosts_of(cidr, TAILS);

        let mut udp_hit: Option<(SocketAddr, Duration)> = None;
        for port in &ports {
            let targets: Vec<SocketAddr> = hosts
                .iter()
                .map(|ip| SocketAddr::new(IpAddr::V4(*ip), *port))
                .collect();
            udp_hit = first_answer(&targets, timeout, attempts, true).await;
            if udp_hit.is_some() {
                break;
            }
        }

        let tcp_targets: Vec<SocketAddr> = hosts
            .iter()
            .map(|ip| SocketAddr::new(IpAddr::V4(*ip), 443))
            .collect();
        let tcp_hit = first_answer(&tcp_targets, timeout, attempts, false).await;

        match (udp_hit, tcp_hit) {
            (Some((peer, rtt)), _) => {
                println!("  UDP OK    {cidr}{note}  {peer} in {}ms", rtt.as_millis());
                udp_ok.push(*cidr);
            }
            (None, Some((peer, rtt))) => {
                println!(
                    "  TCP ONLY  {cidr}{note}  {peer} in {}ms, udp stayed silent",
                    rtt.as_millis()
                );
                tcp_only.push(*cidr);
            }
            (None, None) => {
                println!("  SILENT    {cidr}{note}");
                silent.push(*cidr);
            }
        }
    }

    println!();
    println!("masque over quic works on ({}):", udp_ok.len());
    for cidr in &udp_ok {
        println!("  {cidr}");
    }
    println!();
    println!("reachable over tcp only ({}):", tcp_only.len());
    for cidr in &tcp_only {
        println!("  {cidr}");
    }
    println!();
    println!("no answer on either ({}):", silent.len());
    for cidr in &silent {
        println!("  {cidr}");
    }

    println!();
    println!("verdict");
    if !udp_ok.is_empty() {
        println!("  put these ranges first in MASQUE_CIDRS_V4: {udp_ok:?}");
    } else if control_quic.is_none() {
        println!("  this network answers no quic at all, not even a public resolver,");
        println!("  so udp 443 is blocked here rather than these ranges being blocked.");
        println!("  reordering MASQUE_CIDRS_V4 cannot help; masque needs its http/2");
        println!("  fallback over tcp 443 (--masque-http2) on this network.");
    } else {
        println!("  quic works to other hosts but every warp range stayed silent,");
        println!("  so these ranges really are filtered here.");
        if !tcp_only.is_empty() {
            println!("  the tcp-only ranges above can still carry masque over http/2.");
        }
    }
    println!();
}

#[test]
fn every_masque_prefix_and_seed_parses() {
    for entry in MASQUE_CIDRS_V4 {
        let (addr, bits) = entry.split_once('/').expect("cidr");
        assert!(addr.parse::<Ipv4Addr>().is_ok(), "{entry}");
        assert!(bits.parse::<u8>().is_ok(), "{entry}");
    }
    for entry in MASQUE_CIDRS_V6 {
        let (addr, bits) = entry.split_once('/').expect("cidr");
        assert!(addr.parse::<Ipv6Addr>().is_ok(), "{entry}");
        assert!(bits.parse::<u8>().is_ok(), "{entry}");
    }
    for seed in MASQUE_SEEDS {
        assert!(seed.parse::<Ipv4Addr>().is_ok(), "{seed}");
    }
    for seed in MASQUE_SEEDS_V6 {
        assert!(seed.parse::<Ipv6Addr>().is_ok(), "{seed}");
    }
}

fn gw(last: u8, rtt_ms: u64) -> ProbeResult {
    ProbeResult {
        ip: IpAddr::V4(Ipv4Addr::new(162, 159, 198, last)),
        port: 500,
        rtt: Duration::from_millis(rtt_ms),
    }
}

#[test]
fn max_rtt_parses_milliseconds_and_off() {
    assert_eq!(parse_max_rtt("500"), Some(500));
    assert_eq!(parse_max_rtt(" 250ms "), Some(250));
    assert_eq!(parse_max_rtt("0"), Some(0));
    assert_eq!(parse_max_rtt("off"), Some(0));
    assert_eq!(parse_max_rtt("fast"), None);
    assert_eq!(parse_max_rtt("-1"), None);
}

const ALL_MODES: [ScanMode; 5] =
    [ScanMode::Turbo, ScanMode::Balanced, ScanMode::Thorough, ScanMode::Verified, ScanMode::Ironclad];

#[test]
fn every_mode_has_a_ceiling_500ms_by_default() {
    let ms = Duration::from_millis;
    for mode in ALL_MODES {
        assert_eq!(max_rtt_for(mode, None), Some(ms(500)), "{}", mode.label());
        assert_eq!(max_rtt_for(mode, Some(300)), Some(ms(300)), "{}", mode.label());
        assert_eq!(max_rtt_for(mode, Some(0)), None, "{}: 0 means no limit", mode.label());
    }
    assert_eq!(DEFAULT_MAX_RTT_MS, 500);
}

#[test]
fn gateways_within_the_ceiling_count_and_the_fastest_of_them_wins() {
    let mut p = Picker::new(Some(Duration::from_millis(500)));
    assert!(p.offer(gw(1, 420)));
    assert!(p.offer(gw(2, 500)), "exactly at the ceiling counts");
    assert!(!p.offer(gw(3, 590)));
    assert!(p.offer(gw(4, 130)));
    assert_eq!(p.counted, 3);
    assert_eq!(p.over, 1);
    assert_eq!(p.pick(), Some(Pick::Within(gw(4, 130))));
}

#[test]
fn gateways_over_the_ceiling_are_recorded_but_not_counted() {
    let mut p = Picker::new(Some(Duration::from_millis(500)));
    for (i, rtt) in [800u64, 650, 1200, 501].into_iter().enumerate() {
        assert!(!p.offer(gw(i as u8 + 1, rtt)));
    }
    assert_eq!(p.counted, 0, "nothing toward the target");
    assert_eq!(p.over, 4);
    assert!(p.any());
    // one within the ceiling arriving after slower ones is chosen
    let mut q = Picker::new(Some(Duration::from_millis(500)));
    q.offer(gw(1, 600));
    q.offer(gw(2, 499));
    assert_eq!(q.pick(), Some(Pick::Within(gw(2, 499))));
}

#[test]
fn with_every_gateway_over_the_ceiling_the_fastest_found_is_the_fallback() {
    let mut p = Picker::new(Some(Duration::from_millis(500)));
    p.offer(gw(1, 800));
    p.offer(gw(2, 650));
    p.offer(gw(3, 1200));
    assert_eq!(p.pick(), Some(Pick::Fallback(gw(2, 650))));
    assert_eq!(Picker::new(Some(Duration::from_millis(500))).pick(), None);
}

#[test]
fn no_ceiling_counts_every_gateway() {
    let mut p = Picker::new(max_rtt_for(ScanMode::Balanced, Some(0)));
    assert!(p.offer(gw(1, 5000)));
    assert!(p.offer(gw(2, 900)));
    assert_eq!(p.counted, 2);
    assert_eq!(p.pick(), Some(Pick::Within(gw(2, 900))));
    // another mode with --max-rtt set: the ceiling applies there too
    let mut t = Picker::new(max_rtt_for(ScanMode::Verified, Some(100)));
    assert!(!t.offer(gw(1, 900)));
    assert!(t.offer(gw(2, 90)));
}

// ---- deep scan rounds ---------------------------------------------------------------------------

#[test]
fn scan_rounds_parse_from_one_to_ten() {
    assert_eq!(parse_scan_rounds("3"), Some(3));
    assert_eq!(parse_scan_rounds(" 1 "), Some(1));
    assert_eq!(parse_scan_rounds("10"), Some(10));
    for bad in ["0", "11", "-1", "two", ""] {
        assert_eq!(parse_scan_rounds(bad), None, "{bad:?}");
    }
}

#[test]
fn every_scan_takes_its_rounds_and_without_switching_only_toward_a_ceiling() {
    let cap = Some(Duration::from_millis(100));
    assert_eq!(DEFAULT_SCAN_ROUNDS, 3);
    for mode in ALL_MODES {
        // the background scan takes every round, ceiling or not
        assert_eq!(rounds_for(mode, cap, None, true), DEFAULT_SCAN_ROUNDS, "{}", mode.label());
        assert_eq!(rounds_for(mode, None, Some(5), true), 5, "{}", mode.label());
        assert_eq!(rounds_for(mode, cap, Some(1), true), 1, "{}", mode.label());
        // --no-scan-switch: deeper rounds only toward a ceiling
        assert_eq!(rounds_for(mode, cap, Some(5), false), 5, "{}", mode.label());
        assert_eq!(rounds_for(mode, None, Some(5), false), 1, "{}: --max-rtt 0", mode.label());
    }
}

#[test]
fn later_rounds_sample_more_on_more_ports_and_the_last_takes_whole_ranges() {
    let ports = [500, 1701, 4500, 4443, 8443, 8095, 443];
    let alive = [4500, 500, 8443];
    let sweep = [4500, 500];
    let st = ScanMode::Balanced.strategy();
    let r1 = plan_round(&st, 1, 3, &sweep, &alive, &ports);
    assert_eq!((r1.sample_v4, r1.full_subnet, r1.seeds), (140, false, true));
    assert_eq!(r1.ports, vec![4500, 500]);
    let r2 = plan_round(&st, 2, 3, &sweep, &alive, &ports);
    assert_eq!((r2.sample_v4, r2.full_subnet, r2.seeds), (254, false, false), "twice 140, within a /24");
    assert_eq!(r2.ports, vec![4500, 500, 8443], "the other port that answered joins");
    assert_eq!(r2.sample_v6, 280);
    let r3 = plan_round(&st, 3, 3, &sweep, &alive, &ports);
    assert!(r3.full_subnet && !r3.seeds);
    assert_eq!(r3.ports, vec![4500, 500, 8443, 1701, 4443, 8095, 443], "every scan port last");

    // a smaller sample grows round by round
    let st = ScanMode::Verified.strategy();
    let samples: Vec<usize> = (1..=5).map(|k| plan_round(&st, k, 5, &sweep, &alive, &ports).sample_v4).collect();
    assert_eq!(samples, vec![48, 96, 192, 254, 254]);
    assert!(!plan_round(&st, 4, 5, &sweep, &alive, &ports).full_subnet);
    assert!(plan_round(&st, 5, 5, &sweep, &alive, &ports).full_subnet);
    // a single round is the first round
    assert_eq!(plan_round(&st, 1, 1, &sweep, &alive, &ports).ports, vec![4500, 500]);
}

#[test]
fn the_last_round_covers_every_host_of_every_range_and_no_seed() {
    let st = ScanMode::Balanced.strategy();
    let plan = plan_round(&st, 3, 3, &[500], &[500], &[500, 443]);
    let out = build_round_candidates(&plan, &[500, 443], IpScan::V4);
    assert_eq!(out.len(), MASQUE_CIDRS_V4.len() * 254 * 2);
    let first = first_round_addresses();
    let (left, dup, seeds) = leave_out_probed(out, &HashSet::new(), &first);
    assert_eq!(dup, 0);
    assert!(seeds > 0, "the seeds sit inside the ranges and are left out");
    assert!(left.iter().all(|(a, _)| !first.contains(a)));
}

#[test]
fn what_an_earlier_round_probed_is_left_out() {
    let a: IpAddr = "162.159.192.10".parse().unwrap();
    let b: IpAddr = "162.159.192.11".parse().unwrap();
    let seed: IpAddr = "162.159.192.1".parse().unwrap();
    let probed: HashSet<(IpAddr, u16)> = [(a, 500)].into_iter().collect();
    let (left, dup, seeds) = leave_out_probed(
        vec![(a, 500), (a, 8443), (b, 500), (seed, 8443)],
        &probed,
        &first_round_addresses(),
    );
    assert_eq!(left, vec![(a, 8443), (b, 500)], "the same address on a new port is still new");
    assert_eq!((dup, seeds), (1, 1));
}

type Seen = Arc<parking_lot::Mutex<Vec<(IpAddr, u16)>>>;

/// A scan over fake gateways: `answers` gives the RTT of those that pass the full check.
async fn fake_scan(
    rounds: u32,
    max_rtt_ms: u64,
    prefilter: bool,
    answers: &[(&str, u16, u64)],
) -> (ScanOutcome, Seen, Seen) {
    let answers: Vec<(IpAddr, u16, Duration)> = answers
        .iter()
        .map(|(a, p, ms)| (a.parse().unwrap(), *p, Duration::from_millis(*ms)))
        .collect();
    let mut st = ScanMode::Balanced.strategy();
    st.quiet_after_first = Duration::ZERO;
    let ports = [500, 1701, 4500, 4443, 8443, 8095, 443];
    let verified: Seen = Arc::default();
    let quick_seen: Seen = Arc::default();
    let input = ScanInput {
        mode: ScanMode::Balanced,
        st: &st,
        ip: IpScan::V4,
        ports: &ports,
        sweep: &[500, 4500],
        alive: &[500, 4500, 8443],
        avoid: &HashSet::new(),
        max_rtt: max_rtt_for(ScanMode::Balanced, Some(max_rtt_ms)),
        rounds,
        prefilter,
    };
    let out = run_rounds(
        &input,
        |cands: Vec<(IpAddr, u16)>| {
            let quick_seen = quick_seen.clone();
            async move {
                quick_seen.lock().extend(cands.iter().copied());
                // even last octets answer, odd ones stay silent
                let is_even = |a: &IpAddr| matches!(a, IpAddr::V4(v) if v.octets()[3] % 2 == 0);
                let (live, silent): (Vec<_>, Vec<_>) = cands.into_iter().partition(|(a, _)| is_even(a));
                QuickPass { live, silent, skipped: Vec::new() }
            }
        },
        |ip, port| {
            let verified = verified.clone();
            let hit = answers.iter().find(|(a, p, _)| *a == ip && *p == port).map(|(_, _, rtt)| ProbeResult { ip, port, rtt: *rtt });
            async move {
                verified.lock().push((ip, port));
                hit
            }
        },
    )
    .await;
    (out, verified, quick_seen)
}

fn no_repeats(seen: &Seen) -> bool {
    let seen = seen.lock();
    let set: HashSet<_> = seen.iter().collect();
    set.len() == seen.len()
}

/// No address checked twice, but for the second check each switch's gateway gets first.
fn no_repeats_but_rechecks(seen: &Seen, events: &[ScanEvent]) -> bool {
    let mut seen = seen.lock().clone();
    for ev in events {
        if let ScanEvent::Switch { to, .. } = ev {
            match seen.iter().rposition(|c| *c == (to.ip, to.port)) {
                Some(at) => {
                    seen.remove(at);
                }
                None => return false,
            }
        }
    }
    let set: HashSet<_> = seen.iter().collect();
    set.len() == seen.len()
}

#[tokio::test]
async fn a_gateway_within_the_ceiling_in_the_first_round_ends_the_scan() {
    // seeds are always in the first round
    let (out, _, _) = fake_scan(3, 100, false, &[("162.159.198.2", 500, 80), ("162.159.197.1", 4500, 900)]).await;
    assert_eq!(out.rounds_run, 1);
    let gw = ProbeResult { ip: "162.159.198.2".parse().unwrap(), port: 500, rtt: Duration::from_millis(80) };
    assert_eq!(out.pick, Some(Pick::Within(gw)));
}

#[tokio::test]
async fn nothing_within_the_ceiling_triggers_a_deeper_round_that_ends_once_one_is() {
    // 192.10:8443 is no seed, and 8443 is only swept from the second round on
    let (out, verified, _) = fake_scan(
        3,
        100,
        false,
        &[("162.159.198.2", 8443, 1400), ("162.159.192.10", 8443, 70)],
    )
    .await;
    assert_eq!(out.rounds_run, 2, "the second round found one; no third round");
    let gw = ProbeResult { ip: "162.159.192.10".parse().unwrap(), port: 8443, rtt: Duration::from_millis(70) };
    assert_eq!(out.pick, Some(Pick::Within(gw)));
    assert!(no_repeats(&verified), "no address:port is checked twice");
    assert!(!out.plans[1].seeds && out.plans[1].ports.contains(&8443));
}

#[tokio::test]
async fn with_nothing_within_the_ceiling_in_any_round_the_fastest_of_all_is_the_fallback() {
    let (out, verified, _) = fake_scan(
        3,
        100,
        false,
        &[
            ("162.159.198.2", 8443, 1400), // a seed: first round
            ("162.159.192.10", 8443, 400), // second round
            ("162.159.193.20", 443, 300),  // 443 only on the last round off the seeds
        ],
    )
    .await;
    assert_eq!(out.rounds_run, 3);
    assert_eq!(out.over, 3, "every round's slow gateway is kept");
    let fastest = ProbeResult { ip: "162.159.193.20".parse().unwrap(), port: 443, rtt: Duration::from_millis(300) };
    assert_eq!(out.pick, Some(Pick::Fallback(fastest)));
    assert!(no_repeats(&verified));
    assert!(out.plans[2].full_subnet);
    let first = first_round_addresses();
    let seed_checks = verified.lock().iter().filter(|(a, _)| first.contains(a)).count();
    assert_eq!(seed_checks, MASQUE_SEEDS.len() * 7, "seeds only in the first round, on every port once");
}

#[tokio::test]
async fn one_round_is_the_old_behaviour() {
    let (out, _, _) = fake_scan(1, 100, false, &[("162.159.198.2", 500, 1400), ("162.159.192.10", 8443, 70)]).await;
    assert_eq!(out.rounds_run, 1);
    let slow = ProbeResult { ip: "162.159.198.2".parse().unwrap(), port: 500, rtt: Duration::from_millis(1400) };
    assert_eq!(out.pick, Some(Pick::Fallback(slow)), "falls back at once");
}

#[tokio::test]
async fn without_a_ceiling_one_round_picks_the_fastest() {
    // --max-rtt 0 gives one round (rounds_for); even if more were asked the first answer ends it
    let (out, _, _) = fake_scan(3, 0, false, &[("162.159.198.2", 500, 1400)]).await;
    assert_eq!(out.rounds_run, 1);
    assert!(matches!(out.pick, Some(Pick::Within(_))));
}

#[tokio::test]
async fn a_deeper_quick_pass_skips_what_stayed_silent_before() {
    let (out, verified, quick) = fake_scan(3, 100, true, &[("162.159.198.2", 500, 1400)]).await;
    assert_eq!(out.rounds_run, 3);
    assert!(matches!(out.pick, Some(Pick::Fallback(_))));
    // the silent (odd) ones are never quick-probed twice
    let quick = quick.lock();
    let odd: Vec<_> = quick.iter().filter(|(a, _)| matches!(a, IpAddr::V4(v) if v.octets()[3] % 2 == 1)).collect();
    let set: HashSet<_> = odd.iter().collect();
    assert_eq!(set.len(), odd.len());
    assert!(no_repeats(&verified));
    assert!(verified.lock().iter().all(|(a, _)| matches!(a, IpAddr::V4(v) if v.octets()[3] % 2 == 0)));
}

// ---- upstream candidates ------------------------------------------------------------------------

/// Upstream Aether's `build_candidates` (CluvexStudio/Aether 577a4c8, aether/src/prober.rs),
/// word for word but for the names: the seeds and the ranges on the primary port (the first
/// of `ports`), then the seeds on every other port.
fn upstream_build_candidates(st: &Strategy, ports: &[u16], ip: IpScan) -> Vec<(IpAddr, u16)> {
    let primary = ports.first().copied().unwrap_or(443);
    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();
    let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();
    let seeds6: Vec<Ipv6Addr> = MASQUE_SEEDS_V6.iter().filter_map(|s| s.parse().ok()).collect();
    if ip.want_v4() {
        for a in &seeds {
            if seen.insert((IpAddr::V4(*a), primary)) {
                out.push((IpAddr::V4(*a), primary));
            }
        }
        let cidr_hosts: Vec<Vec<Ipv4Addr>> = masque_cidrs_v4()
            .iter()
            .map(|c| if st.full_subnet { enumerate_cidr_v4(c) } else { sample_cidr_v4(c, st.sample_per_cidr) })
            .collect();
        let max_len = cidr_hosts.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for hosts in &cidr_hosts {
                if let Some(a) = hosts.get(i) {
                    if seen.insert((IpAddr::V4(*a), primary)) {
                        out.push((IpAddr::V4(*a), primary));
                    }
                }
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            if seen.insert((IpAddr::V6(*a), primary)) {
                out.push((IpAddr::V6(*a), primary));
            }
        }
        let per = if st.sample_per_cidr == 0 { 96 } else { st.sample_per_cidr };
        let pool6: Vec<Vec<Ipv4Addr>> =
            masque_cidrs_v4().iter().map(|c| sample_cidr_v4(c, per)).collect();
        // `per` hosts per prefix, one from each range in turn, each embedded under the prefix
        let bases = v6_prefix_bases();
        let max6 = pool6.iter().map(|v| v.len()).max().unwrap_or(0);
        let mut hosts6: Vec<Ipv4Addr> = Vec::new();
        'fill: for i in 0..max6 {
            for hosts in &pool6 {
                if let Some(h) = hosts.get(i) {
                    if hosts6.len() >= per {
                        break 'fill;
                    }
                    hosts6.push(*h);
                }
            }
        }
        for h in &hosts6 {
            for &base in &bases {
                if seen.insert((IpAddr::V6(embed_v4(base, *h)), primary)) {
                    out.push((IpAddr::V6(embed_v4(base, *h)), primary));
                }
            }
        }
    }
    if ip.want_v4() {
        for a in &seeds {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V4(*a), port)) {
                    out.push((IpAddr::V4(*a), port));
                }
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V6(*a), port)) {
                    out.push((IpAddr::V6(*a), port));
                }
            }
        }
    }
    out
}

/// The parts of a candidate list that do not depend on the random sample: where each seed:port
/// sits, how many range hosts each /24 gives, and which ports the ranges are on.
type Shape = (Vec<(usize, IpAddr, u16)>, Vec<(u128, usize)>, HashSet<u16>);

fn shape(out: &[(IpAddr, u16)]) -> Shape {
    let seeds: HashSet<IpAddr> = MASQUE_SEEDS
        .iter()
        .chain(MASQUE_SEEDS_V6)
        .filter_map(|s| s.parse().ok())
        .collect();
    let mut seed_slots = Vec::new();
    let mut per_range: Vec<(u128, usize)> = Vec::new();
    let mut range_ports = HashSet::new();
    for (i, (a, p)) in out.iter().enumerate() {
        if seeds.contains(a) {
            seed_slots.push((i, *a, *p));
        } else {
            range_ports.insert(*p);
            let k = range_key(*a);
            match per_range.iter_mut().find(|e| e.0 == k) {
                Some(e) => e.1 += 1,
                None => per_range.push((k, 1)),
            }
        }
    }
    (seed_slots, per_range, range_ports)
}

#[test]
fn the_first_round_is_upstream_aethers_candidate_list() {
    let ports = MASQUE_PORTS;
    // whole ranges (thorough, IPv4): nothing random, the very same list
    let st = ScanMode::Thorough.strategy();
    assert_eq!(
        build_candidates(&st, ports, &[ports[0]], IpScan::V4),
        upstream_build_candidates(&st, ports, IpScan::V4),
    );
    // sampled modes, IPv4, IPv6 and both: the same seeds in the same order, the ranges in the
    // same order with as many hosts each, ranges only on the primary port. (A sampled host that
    // is a seed is dropped as a repeat, in upstream too, so a range may come out one short per
    // seed in it.)
    let seeds_in = |k: u128| {
        MASQUE_SEEDS.iter().chain(MASQUE_SEEDS_V6).filter(|s| range_key(s.parse().unwrap()) == k).count()
    };
    for mode in [ScanMode::Turbo, ScanMode::Balanced, ScanMode::Verified, ScanMode::Ironclad] {
        let st = mode.strategy();
        for ip in [IpScan::V4, IpScan::V6, IpScan::Both] {
            let what = format!("{} {}", mode.label(), ip.label());
            let ours = build_candidates(&st, ports, &[ports[0]], ip);
            let theirs = upstream_build_candidates(&st, ports, ip);
            let (mut a, mut b) = (shape(&ours), shape(&theirs));
            a.1.sort();
            b.1.sort();
            let seq = |v: &[(usize, IpAddr, u16)]| v.iter().map(|e| (e.1, e.2)).collect::<Vec<_>>();
            assert_eq!(seq(&a.0), seq(&b.0), "{what}: the seeds");
            assert_eq!(a.1.iter().map(|e| e.0).collect::<Vec<_>>(), b.1.iter().map(|e| e.0).collect::<Vec<_>>(), "{what}: the same ranges");
            for ((k, n), (_, m)) in a.1.iter().zip(&b.1) {
                if *k >> 100 == 1 {
                    // IPv6 samples with repeats (in upstream too): a few fewer, never more
                    let per = st.sample_per_cidr;
                    assert!(*n <= per && n * 4 >= per * 3, "{what}: range {k:x} has {n} of {per}");
                    assert!(*m <= per && m * 4 >= per * 3);
                } else {
                    assert!(n.abs_diff(*m) <= seeds_in(*k), "{what}: range {k:x} has {n} vs {m}");
                }
            }
            assert_eq!(a.2, HashSet::from([ports[0]]), "{what}: one sweep port");
            assert_eq!(a.2, b.2);
            // interleaved as upstream: round after round, one host of each /24 in range order
            // (a round may lose a host that is a seed, so rounds are counted with some slack)
            if ip.want_v4() {
                let order: Vec<u128> = masque_cidrs_v4().iter().map(|c| range_key(c.split('/').next().unwrap().parse().unwrap())).collect();
                let idx: Vec<usize> = ours
                    .iter()
                    .filter(|(addr, _)| addr.is_ipv4() && !a.0.iter().any(|e| e.1 == *addr))
                    .map(|(addr, _)| order.iter().position(|k| *k == range_key(*addr)).unwrap())
                    .collect();
                let rounds = 1 + idx.windows(2).filter(|w| w[1] <= w[0]).count();
                let per = st.sample_per_cidr;
                assert!(rounds <= per && rounds + 6 >= per, "{what}: {rounds} rounds of {per}");
            }
        }
    }
    // the v4 seeds lead, on the primary port, in upstream's order
    let st = ScanMode::Balanced.strategy();
    let out = build_candidates(&st, ports, &[ports[0]], IpScan::V4);
    let lead: Vec<(IpAddr, u16)> = MASQUE_SEEDS.iter().map(|s| (s.parse().unwrap(), 500)).collect();
    assert_eq!(&out[..MASQUE_SEEDS.len()], &lead[..]);
    let full = MASQUE_SEEDS.len() + MASQUE_CIDRS_V4.len() * 140 + MASQUE_SEEDS.len() * (ports.len() - 1);
    assert!(out.len() <= full && out.len() + MASQUE_SEEDS.len() >= full, "{}", out.len());
    // and the seeds on every other port close the list, 443 last for each seed
    let tail = &out[out.len() - (ports.len() - 1)..];
    assert_eq!(tail.iter().map(|c| c.1).collect::<Vec<_>>(), vec![1701, 4500, 4443, 8443, 8095, 443]);
}

#[test]
fn the_ranges_are_swept_on_one_port_and_443_gives_way() {
    assert_eq!(SWEEP_PORTS, 1, "upstream sweeps one port");
    // no port check (or nothing answered it): the first scan port, 500 by default, never 443
    assert_eq!(primary_ports(&[], MASQUE_PORTS), vec![500]);
    assert_ne!(primary_ports(&[], MASQUE_PORTS), vec![443]);
    // a port check: its best port, with 443 losing a tie
    let ms = Duration::from_millis;
    let mut t = vec![(443, 10, ms(20)), (8443, 10, ms(80)), (500, 4, ms(10))];
    rank_ports(&mut t, Some(443));
    let alive: Vec<u16> = t.iter().map(|e| e.0).collect();
    assert_eq!(primary_ports(&alive, MASQUE_PORTS), vec![8443]);
    // 443 leads only when it answered more seeds
    let mut t = vec![(443, 10, ms(90)), (8443, 9, ms(20))];
    rank_ports(&mut t, Some(443));
    let alive: Vec<u16> = t.iter().map(|e| e.0).collect();
    assert_eq!(primary_ports(&alive, MASQUE_PORTS), vec![443]);
    // ports the user named: the first of them
    assert_eq!(primary_ports(&[], &[443, 8443]), vec![443]);
}

// ---- background scan ---------------------------------------------------------------------------

fn seed(i: usize, port: u16, rtt_ms: u64) -> (&'static str, u16, u64) {
    (MASQUE_SEEDS[i], port, rtt_ms)
}

#[test]
fn the_launcher_starts_within_the_ceiling_and_moves_only_under_half() {
    let mut l = Launcher::new(Some(Duration::from_millis(100)));
    assert_eq!(l.offer(gw(1, 400)), Decision::Keep, "over the ceiling: no start");
    assert_eq!(l.offer(gw(2, 90)), Decision::Start(gw(2, 90)));
    assert_eq!(l.offer(gw(3, 45)), Decision::Keep, "exactly half is not under half");
    assert_eq!(l.offer(gw(4, 44)), Decision::Switch { from: gw(2, 90), to: gw(4, 44) });
    assert_eq!(l.offer(gw(5, 30)), Decision::Keep, "compared with the new one now");
    assert_eq!(l.offer(gw(6, 21)), Decision::Switch { from: gw(4, 44), to: gw(6, 21) });
    assert_eq!(l.finish(), None, "it started: no fallback");
    assert_eq!((l.verified, l.within, l.switches), (6, 5, 2));
    assert!(much_faster(Duration::from_millis(49), Duration::from_millis(100)));
    assert!(!much_faster(Duration::from_millis(50), Duration::from_millis(100)));

    // no ceiling: the first that passes starts
    let mut l = Launcher::new(None);
    assert_eq!(l.offer(gw(1, 5000)), Decision::Start(gw(1, 5000)));
    assert_eq!(l.offer(gw(2, 2400)), Decision::Switch { from: gw(1, 5000), to: gw(2, 2400) });

    // nothing within the ceiling: the fastest, once the scan is over
    let mut l = Launcher::new(Some(Duration::from_millis(100)));
    l.offer(gw(1, 800));
    l.offer(gw(2, 300));
    l.offer(gw(3, 500));
    assert_eq!(l.finish(), Some(gw(2, 300)));
    assert!(l.fell_back);
}

type Trace = Arc<parking_lot::Mutex<Vec<String>>>;

/// A background scan over fake gateways, one check at a time so the order is fixed: what it
/// emitted, its summary, and a trace of checks and events in the order they happened.
async fn fake_live(
    mode: ScanMode,
    rounds: u32,
    max_rtt_ms: u64,
    prefilter: bool,
    answers: &[(&str, u16, u64)],
) -> (Vec<ScanEvent>, LiveSummary, Trace, Seen) {
    fake_live_on(mode, rounds, max_rtt_ms, prefilter, answers, None).await
}

/// `fake_live` for a run already going on `in_use` (a remembered gateway).
async fn fake_live_on(
    mode: ScanMode,
    rounds: u32,
    max_rtt_ms: u64,
    prefilter: bool,
    answers: &[(&str, u16, u64)],
    in_use: Option<ProbeResult>,
) -> (Vec<ScanEvent>, LiveSummary, Trace, Seen) {
    let answers: Vec<(IpAddr, u16, Duration)> = answers
        .iter()
        .map(|(a, p, ms)| (a.parse().unwrap(), *p, Duration::from_millis(*ms)))
        .collect();
    let mut st = mode.strategy();
    st.concurrency = 1;
    let ports = [500, 1701, 4500, 4443, 8443, 8095, 443];
    let trace: Trace = Arc::default();
    let verified: Seen = Arc::default();
    let input = ScanInput {
        mode,
        st: &st,
        ip: IpScan::V4,
        ports: &ports,
        sweep: &[500],
        alive: &[500, 4500, 8443],
        avoid: &HashSet::new(),
        max_rtt: max_rtt_for(mode, Some(max_rtt_ms)),
        rounds,
        prefilter,
    };
    let mut events = Vec::new();
    let summary = run_live(
        &input,
        in_use,
        |cands: Vec<(IpAddr, u16)>| async move {
            // even last octets answer, odd ones stay silent; a batch hands over 24 at most
            let is_even = |a: &IpAddr| matches!(a, IpAddr::V4(v) if v.octets()[3] % 2 == 0);
            let (mut live, silent): (Vec<_>, Vec<_>) = cands.into_iter().partition(|(a, _)| is_even(a));
            live.truncate(24);
            QuickPass { live, silent, skipped: Vec::new() }
        },
        |ip, port| {
            let trace = trace.clone();
            let verified = verified.clone();
            let hit = answers
                .iter()
                .find(|(a, p, _)| *a == ip && *p == port)
                .map(|(_, _, rtt)| ProbeResult { ip, port, rtt: *rtt });
            async move {
                trace.lock().push(format!("check {ip}:{port}"));
                verified.lock().push((ip, port));
                hit
            }
        },
        |ev| {
            trace.lock().push(format!("{ev:?}"));
            events.push(ev);
        },
    )
    .await;
    (events, summary, trace, verified)
}

fn pr(a: &str, port: u16, ms: u64) -> ProbeResult {
    ProbeResult { ip: a.parse().unwrap(), port, rtt: Duration::from_millis(ms) }
}

#[tokio::test]
async fn every_mode_starts_on_the_first_gateway_within_the_ceiling_and_scans_on() {
    for mode in ALL_MODES {
        let (events, summary, trace, _) =
            fake_live(mode, 1, 100, false, &[seed(0, 500, 900), seed(2, 500, 80), seed(5, 8443, 70)]).await;
        let start = pr(MASQUE_SEEDS[2], 500, 80);
        assert_eq!(events.first(), Some(&ScanEvent::Start { gateway: start, fallback: false }), "{}", mode.label());
        // the start came out while checks were still to come: not at the end of the scan
        let trace = trace.lock();
        let at = trace.iter().position(|t| t.starts_with("Start")).unwrap();
        let after = trace[at..].iter().filter(|t| t.starts_with("check")).count();
        assert!(after > 100, "{}: only {after} checks after the start", mode.label());
        // 70 ms is not under half of 80: no switch, the run stays
        assert_eq!(events.len(), 1, "{}: {events:?}", mode.label());
        assert_eq!(summary.current, Some(start));
        assert_eq!(summary.switches, 0);
    }
}

#[tokio::test]
async fn a_gateway_under_half_the_rtt_of_the_one_in_use_takes_over() {
    let (events, summary, _, _) = fake_live(
        ScanMode::Balanced,
        1,
        500,
        false,
        &[
            seed(0, 500, 90), // start
            seed(1, 500, 50), // not under 45: kept
            seed(2, 500, 40), // under 45: switch, the new base
            seed(3, 500, 25), // not under 20: kept
            seed(4, 500, 19), // under 20: switch
        ],
    )
    .await;
    let a = pr(MASQUE_SEEDS[0], 500, 90);
    let c = pr(MASQUE_SEEDS[2], 500, 40);
    let e = pr(MASQUE_SEEDS[4], 500, 19);
    assert_eq!(
        events,
        vec![
            ScanEvent::Start { gateway: a, fallback: false },
            ScanEvent::Switch { from: a, to: c },
            ScanEvent::Switch { from: c, to: e },
        ]
    );
    assert_eq!((summary.switches, summary.current), (2, Some(e)));
}

#[tokio::test]
async fn without_a_ceiling_the_first_gateway_starts_and_the_half_rule_still_applies() {
    let (events, _, _, _) =
        fake_live(ScanMode::Turbo, 1, 0, false, &[seed(0, 500, 3000), seed(1, 500, 1600), seed(3, 500, 1400)]).await;
    let a = pr(MASQUE_SEEDS[0], 500, 3000);
    assert_eq!(events[0], ScanEvent::Start { gateway: a, fallback: false });
    assert_eq!(events[1..], [ScanEvent::Switch { from: a, to: pr(MASQUE_SEEDS[3], 500, 1400) }]);
}

#[tokio::test]
async fn the_background_scan_checks_every_candidate_of_every_round_then_stops() {
    let (events, summary, _, verified) =
        fake_live(ScanMode::Balanced, 3, 100, false, &[seed(5, 500, 80), ("162.159.193.20", 443, 30)]).await;
    assert_eq!(summary.rounds_run, 3, "a start does not end the scan");
    assert!(summary.plans[2].full_subnet);
    assert!(no_repeats_but_rechecks(&verified, &events));
    // every address of every range on every port, the seeds once on each port
    let first = first_round_addresses();
    let in_ranges = MASQUE_CIDRS_V4.len() * 254 * 7;
    let seeds_in_ranges: usize = verified.lock().iter().filter(|(a, _)| first.contains(a)).count();
    assert_eq!(seeds_in_ranges, MASQUE_SEEDS.len() * 7);
    assert_eq!(verified.lock().len(), in_ranges + summary.switches as usize, "each address:port of the ranges once, a switch's twice");
    // 443 off the seeds is only reached in the last round, and still taken
    assert_eq!(events.last(), Some(&ScanEvent::Switch { from: pr(MASQUE_SEEDS[5], 500, 80), to: pr("162.159.193.20", 443, 30) }));
}

#[tokio::test]
async fn with_the_quick_pass_the_background_scan_goes_on_in_batches_until_nothing_answers() {
    let (events, summary, _, verified) = fake_live(
        ScanMode::Balanced,
        2,
        100,
        true,
        &[seed(5, 500, 90), ("162.159.192.200", 500, 40)],
    )
    .await;
    assert_eq!(summary.rounds_run, 2);
    // every even host of round 1 got its check, though a batch hands over 24 at most
    let checked = verified.lock();
    let evens_in_round_one = checked.iter().filter(|(_, p)| *p == 500).count();
    assert!(evens_in_round_one > 24 * 3, "{evens_in_round_one}");
    assert!(checked.iter().all(|(a, _)| matches!(a, IpAddr::V4(v) if v.octets()[3] % 2 == 0)));
    drop(checked);
    assert!(no_repeats_but_rechecks(&verified, &events));
    assert!(events.contains(&ScanEvent::Switch { from: pr(MASQUE_SEEDS[5], 500, 90), to: pr("162.159.192.200", 500, 40) }));
}

#[tokio::test]
async fn with_nothing_within_the_ceiling_the_fastest_starts_once_a_round_is_over() {
    let (events, summary, trace, _) =
        fake_live(ScanMode::Verified, 2, 100, false, &[seed(0, 500, 900), seed(3, 4500, 300)]).await;
    assert_eq!(events, vec![ScanEvent::Start { gateway: pr(MASQUE_SEEDS[3], 4500, 300), fallback: true }]);
    assert!(summary.fell_back);
    assert_eq!(summary.rounds_run, 2, "the scan goes on after the start");
    let trace = trace.lock();
    let at = trace.iter().position(|t| t.starts_with("Start")).unwrap();
    assert!(trace[at..].iter().any(|t| t.starts_with("check")), "round 2 was still to come");
}

#[tokio::test]
async fn with_switching_off_a_turbo_scan_ends_on_its_first_gateway_within_the_ceiling() {
    let mut st = ScanMode::Turbo.strategy();
    st.concurrency = 1;
    let ports = [500, 1701, 4500, 4443, 8443, 8095, 443];
    let input = ScanInput {
        mode: ScanMode::Turbo,
        st: &st,
        ip: IpScan::V4,
        ports: &ports,
        sweep: &[500],
        alive: &[],
        avoid: &HashSet::new(),
        max_rtt: max_rtt_for(ScanMode::Turbo, Some(100)),
        rounds: rounds_for(ScanMode::Turbo, max_rtt_for(ScanMode::Turbo, Some(100)), Some(1), false),
        prefilter: false,
    };
    let slow = pr(MASQUE_SEEDS[0], 500, 900);
    let fast = pr(MASQUE_SEEDS[2], 500, 80);
    let out = run_rounds(&input, |_| async { QuickPass::default() }, |ip, port| async move {
        [slow, fast].into_iter().find(|g| g.ip == ip && g.port == port)
    })
    .await;
    assert_eq!(out.first, Some(fast), "the slow one before it does not end the scan");
}

#[tokio::test]
async fn the_run_gets_the_start_then_the_latest_switch_and_none_once_the_scan_is_over() {
    let (a, b, c) = (gw(1, 90), gw(2, 40), gw(3, 15));
    let (first, mut bg) = start_background(move |tx| async move {
        let _ = tx.send(ScanEvent::Start { gateway: a, fallback: false });
        let _ = tx.send(ScanEvent::Switch { from: a, to: b });
        let _ = tx.send(ScanEvent::Switch { from: b, to: c });
    })
    .await
    .unwrap();
    assert_eq!(first, a);
    tokio::time::sleep(Duration::from_millis(20)).await;
    assert_eq!(bg.next_switch().await, Some((a, c)), "two waiting: the latest, from the one in use");
    assert_eq!(bg.next_switch().await, None, "the scan is over");
    assert!(bg.finished());
    // a scan that ends with nothing: no gateway
    assert!(start_background(|_tx| async {}).await.is_err());
}

#[tokio::test]
async fn the_stop_signal_ends_the_background_scan() {
    let _turn = crate::utils::shutdown::tests::RUNS.lock().await;
    let run = crate::utils::shutdown::begin();
    let a = gw(1, 90);
    let (first, mut bg) = start_background(move |tx| async move {
        let _ = tx.send(ScanEvent::Start { gateway: a, fallback: false });
        // a scan that would go on for good
        loop {
            tokio::time::sleep(Duration::from_millis(5)).await;
            if tx.is_closed() {
                break;
            }
        }
    })
    .await
    .unwrap();
    assert_eq!(first, a);
    assert!(!bg.finished());
    drop(run);
    let ended = tokio::time::timeout(Duration::from_secs(2), bg.next_switch()).await;
    assert_eq!(ended, Ok(None), "the scan stopped with the run");
    assert!(bg.finished());

    // dropping it (a fresh scan, the library job ending) stops it too
    let (_, bg) = start_background(move |tx| async move {
        let _ = tx.send(ScanEvent::Start { gateway: a, fallback: false });
        std::future::pending::<()>().await;
    })
    .await
    .unwrap();
    let abort = bg.task.abort_handle();
    drop(bg);
    tokio::time::sleep(Duration::from_millis(20)).await;
    assert!(abort.is_finished());
}

#[tokio::test]
async fn the_run_loop_waits_for_switches_only_while_a_scan_goes_on() {
    use crate::transport::warp::masque::{back_after_failed_switch, next_switch, SWITCH_SETTLE};
    let mut none: Option<BackgroundScan> = None;
    assert!(tokio::time::timeout(Duration::from_millis(30), next_switch(&mut none)).await.is_err());
    let (a, b) = (gw(1, 90), gw(2, 40));
    let (_, bg) = start_background(move |tx| async move {
        let _ = tx.send(ScanEvent::Start { gateway: a, fallback: false });
        let _ = tx.send(ScanEvent::Switch { from: a, to: b });
    })
    .await
    .unwrap();
    let mut some = Some(bg);
    assert_eq!(next_switch(&mut some).await, (a, b));
    // the scan ends: no more switches, and the scan is let go
    assert!(tokio::time::timeout(Duration::from_millis(50), next_switch(&mut some)).await.is_err());
    assert!(some.is_none());

    let old: SocketAddr = "162.159.198.1:500".parse().unwrap();
    let quick = Duration::from_secs(3);
    assert_eq!(back_after_failed_switch(Some(old), true, quick), Some(old));
    assert_eq!(back_after_failed_switch(Some(old), false, quick), None, "closed cleanly");
    assert_eq!(back_after_failed_switch(Some(old), true, SWITCH_SETTLE), None, "it held a while");
    assert_eq!(back_after_failed_switch(None, true, quick), None, "no switch before");
}

// ---- the background scan goes on after the start ------------------------------------------------

/// Whether a fake network answers the quick pass at `a:port`: the MASQUE /24s and the CDN /24s
/// (which answer QUIC but fail the full check) on 500 and 4500; on 8443 only 162.159.198.0/24.
fn fake_quick_answers(a: IpAddr, port: u16) -> bool {
    let IpAddr::V4(v) = a else { return false };
    let o = v.octets();
    let masque = o[0] == 162 && o[1] == 159 && matches!(o[2], 192 | 193 | 195 | 196 | 197 | 198);
    let cdn = o[0] == 188 && o[1] == 114;
    match port {
        500 | 4500 => masque || cdn,
        8443 => o[0] == 162 && o[1] == 159 && o[2] == 198,
        _ => false,
    }
}

/// The fake full check: the MASQUE /24s pass, 800 to 1300 ms (all within a 1500 ms ceiling);
/// 162.159.193.77 on 4500, reached only from round 2, takes 300 ms.
fn fake_full_check(a: IpAddr, port: u16) -> Option<Duration> {
    let IpAddr::V4(v) = a else { return None };
    let o = v.octets();
    if !(o[0] == 162 && o[1] == 159 && matches!(o[2], 192 | 193 | 195 | 196 | 197 | 198)) {
        return None;
    }
    if !fake_quick_answers(a, port) {
        return None;
    }
    if o[2] == 193 && o[3] == 77 && port == 4500 {
        return Some(Duration::from_millis(300));
    }
    Some(Duration::from_millis(800 + (o[3] as u64 * 2)))
}

/// A quick pass that behaves like `quick_filter`: it stops once it has `want` answers (what it
/// did not reach stays for the next batch) and skips the rest of a range that stayed silent on
/// a port for its first `PRUNE_AFTER` probes.
async fn fake_quick_filter(cands: Vec<(IpAddr, u16)>, want: usize) -> QuickPass {
    use std::collections::HashMap;
    let mut tally: HashMap<(u128, u16), (u32, u32)> = HashMap::new();
    let mut pass = QuickPass::default();
    for (a, p) in cands {
        if pass.live.len() >= want {
            break;
        }
        let t = tally.entry((range_key(a), p)).or_default();
        if t.1 == 0 && t.0 >= PRUNE_AFTER {
            pass.skipped.push((a, p));
            continue;
        }
        t.0 += 1;
        if fake_quick_answers(a, p) {
            t.1 += 1;
            pass.live.push((a, p));
        } else {
            pass.silent.push((a, p));
        }
    }
    tokio::task::yield_now().await;
    pass
}

/// The whole flow of a run, as `hunt_gateway_live` and `run_masque` drive it: the scan runs as a
/// background task, the run takes the start and then keeps reading switches until the scan is
/// over. Every later round still gets its full checks after the tunnel started on the first
/// gateway within --max-rtt 1500.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn after_the_start_the_background_scan_still_full_checks_every_later_round() {
    let started = Arc::new(std::sync::atomic::AtomicBool::new(false));
    // (address, port, whether the run had started when the check began)
    let checks: Arc<parking_lot::Mutex<Vec<(IpAddr, u16, bool)>>> = Arc::default();
    let summary: Arc<parking_lot::Mutex<Option<LiveSummary>>> = Arc::default();
    let (first, mut bg) = {
        let started = started.clone();
        let checks = checks.clone();
        let summary = summary.clone();
        start_background(move |tx| async move {
            let st = ScanMode::Balanced.strategy();
            let want = (st.target_successes * 6).max(24);
            let ports = [500, 1701, 4500, 4443, 8443, 8095, 443];
            let avoid = HashSet::new();
            let input = ScanInput {
                mode: ScanMode::Balanced,
                st: &st,
                ip: IpScan::V4,
                ports: &ports,
                sweep: &[500],
                alive: &[500, 4500],
                avoid: &avoid,
                max_rtt: max_rtt_for(ScanMode::Balanced, Some(1500)),
                rounds: rounds_for(ScanMode::Balanced, max_rtt_for(ScanMode::Balanced, Some(1500)), None, true),
                prefilter: true,
            };
            let s = run_live(
                &input,
                None,
                |cands| fake_quick_filter(cands, want),
                |ip, port| {
                    let started = started.clone();
                    let checks = checks.clone();
                    async move {
                        checks.lock().push((ip, port, started.load(std::sync::atomic::Ordering::SeqCst)));
                        tokio::task::yield_now().await;
                        fake_full_check(ip, port).map(|rtt| ProbeResult { ip, port, rtt })
                    }
                },
                |ev| {
                    if matches!(ev, ScanEvent::Start { .. }) {
                        started.store(true, std::sync::atomic::Ordering::SeqCst);
                    }
                    let _ = tx.send(ev);
                },
            )
            .await;
            *summary.lock() = Some(s);
        })
        .await
        .unwrap()
    };
    assert!(first.rtt <= Duration::from_millis(1500));
    // the run goes on reading what the scan says, as run_masque does
    let mut switches = Vec::new();
    while let Some(sw) = tokio::time::timeout(Duration::from_secs(60), bg.next_switch()).await.expect("the scan hung") {
        switches.push(sw);
    }
    for _ in 0..200 {
        if bg.finished() {
            break;
        }
        tokio::time::sleep(Duration::from_millis(5)).await;
    }
    assert!(bg.finished());
    let summary = summary.lock().take().expect("the scan ran to its end");
    assert_eq!(summary.rounds_run, 3, "every round ran: {:?}", summary.stats);

    let st = ScanMode::Balanced.strategy();
    let round_one: HashSet<(IpAddr, u16)> =
        build_round_candidates(&plan_round(&st, 1, 3, &[500], &[500, 4500], &[500, 1701, 4500, 4443, 8443, 8095, 443]), &[500, 1701, 4500, 4443, 8443, 8095, 443], IpScan::V4)
            .into_iter()
            .collect();
    let checks = checks.lock();
    let after: Vec<_> = checks.iter().filter(|c| c.2).collect();
    let later_rounds = after.iter().filter(|c| !round_one.contains(&(c.0, c.1))).count();
    let on_8443 = after.iter().filter(|c| c.1 == 8443 && !first_round_addresses().contains(&c.0)).count();
    assert!(after.len() > 1000, "only {} full checks after the start", after.len());
    assert!(later_rounds > 1000, "only {later_rounds} full checks of rounds 2 and 3 after the start");
    assert!(on_8443 > 100, "round 3 (every port) got only {on_8443} full checks on 8443");
    for s in &summary.stats {
        assert!(s.checked > 0, "round {} full-checked nothing: {s:?}", s.round);
        assert!(s.batches > 1 || s.round == 3, "round {} ran a single batch: {s:?}", s.round);
    }
    // the 300 ms gateway of round 2 is under half of any start (800 ms or more)
    let fast = pr("162.159.193.77", 4500, 300);
    assert_eq!(switches.last().map(|s| s.1), Some(fast), "{switches:?}");
    assert_eq!(summary.current, Some(fast));
    let total_checked: usize = summary.stats.iter().map(|s| s.checked).sum();
    // a switch's gateway is checked a second time, outside the round's count
    assert_eq!(total_checked + summary.switches as usize, checks.len());
}

/// A full check that goes on for a while says how far it got every `progress_every`, and each
/// round counts what it did.
#[tokio::test]
async fn a_long_full_check_reports_its_progress_and_each_round_its_totals() {
    let mut st = ScanMode::Balanced.strategy();
    st.concurrency = 1;
    let ports = [500, 1701, 4500, 4443, 8443, 8095, 443];
    let avoid = HashSet::new();
    let input = ScanInput {
        mode: ScanMode::Balanced,
        st: &st,
        ip: IpScan::V4,
        ports: &ports,
        sweep: &[500],
        alive: &[500],
        avoid: &avoid,
        max_rtt: Some(Duration::from_millis(500)),
        rounds: 1,
        prefilter: true,
    };
    let a = pr(MASQUE_SEEDS[0], 500, 200);
    let summary = run_live_with(
        &input,
        None,
        |cands: Vec<(IpAddr, u16)>| async move {
            // three answer, the rest stay silent: one batch, then nothing is left
            let (live, silent) = (cands[..3].to_vec(), cands[3..].to_vec());
            QuickPass { live, silent, skipped: Vec::new() }
        },
        |ip, port| async move {
            tokio::time::sleep(Duration::from_millis(60)).await;
            (ip == a.ip && port == a.port).then_some(a)
        },
        |_| {},
        Duration::from_millis(25),
    )
    .await;
    let s = &summary.stats[0];
    assert_eq!((s.round, s.batches, s.quick_answered, s.checked, s.passed, s.left), (1, 1, 3, 3, 1, 0));
    assert_eq!(s.fastest, Some(a));
    assert!(s.heartbeats >= 3, "{s:?}");
    assert_eq!(
        in_use_line(Some(pr("162.159.198.1", 500, 820)), Some(Duration::from_millis(1500))),
        "in use 162.159.198.1:500(820ms), switches below 410ms"
    );
    assert_eq!(
        in_use_line(None, Some(Duration::from_millis(1500))),
        "nothing in use yet (waiting for one within 1500ms)"
    );
}

// ---- a run on a remembered gateway, the fallback after a round, the second check -----------------

#[test]
fn a_launcher_on_a_remembered_gateway_never_starts_and_never_switches_to_itself() {
    let mut l = Launcher::in_use(Some(Duration::from_millis(500)), Some(gw(1, 400)));
    assert_eq!(l.offer(gw(1, 100)), Decision::Keep, "the gateway in use is not a candidate for itself");
    assert!(!l.would_switch(&gw(1, 100)));
    assert_eq!(l.offer(gw(2, 300)), Decision::Keep, "not under half");
    assert_eq!(l.offer(gw(3, 199)), Decision::Switch { from: gw(1, 400), to: gw(3, 199) });
    assert_eq!(l.finish(), None);
}

#[test]
fn a_gateway_in_use_over_the_ceiling_gives_way_to_the_first_within_it() {
    let mut l = Launcher::in_use(Some(Duration::from_millis(500)), Some(gw(1, 900)));
    assert!(!l.would_switch(&gw(2, 600)), "over the ceiling and not under half");
    assert_eq!(l.offer(gw(2, 600)), Decision::Keep);
    assert_eq!(l.offer(gw(3, 480)), Decision::Switch { from: gw(1, 900), to: gw(3, 480) }, "within the ceiling, though not under half");
    assert_eq!(l.offer(gw(4, 300)), Decision::Keep, "within it now: only under half");
    assert_eq!(l.offer(gw(5, 239)), Decision::Switch { from: gw(3, 480), to: gw(5, 239) });
    // no ceiling: only the half rule
    let l = Launcher::in_use(None, Some(gw(1, 900)));
    assert!(!l.would_switch(&gw(2, 600)));
}

#[test]
fn the_in_use_line_says_when_the_gateway_is_over_the_ceiling() {
    let line = in_use_line(Some(pr("162.159.198.1", 500, 900)), Some(Duration::from_millis(500)));
    assert!(line.contains("over max-rtt") && line.contains("within 500ms"), "{line}");
}

#[tokio::test]
async fn a_run_on_a_remembered_gateway_scans_on_and_only_switches() {
    let remembered = pr(MASQUE_SEEDS[0], 500, 800);
    let (events, summary, _, _) = fake_live_on(
        ScanMode::Thorough,
        1,
        1500,
        false,
        &[seed(0, 500, 100), seed(1, 500, 500), seed(2, 500, 390)],
        Some(remembered),
    )
    .await;
    // no start; the remembered gateway itself (fast this time) is not a switch; 500 is not under
    // 400; 390 is
    assert_eq!(events, vec![ScanEvent::Switch { from: remembered, to: pr(MASQUE_SEEDS[2], 500, 390) }]);
    assert_eq!(summary.current, Some(pr(MASQUE_SEEDS[2], 500, 390)));
}

#[tokio::test]
async fn with_nothing_within_the_ceiling_the_fastest_starts_after_the_first_round() {
    let (events, summary, trace, _) =
        fake_live(ScanMode::Balanced, 2, 100, false, &[seed(0, 500, 900), seed(1, 500, 300), ("162.159.193.20", 443, 90)]).await;
    let fastest = pr(MASQUE_SEEDS[1], 500, 300);
    assert_eq!(events[0], ScanEvent::Start { gateway: fastest, fallback: true });
    // started before round 2 checked anything
    let trace = trace.lock();
    let at = trace.iter().position(|t| t.starts_with("Start")).unwrap();
    assert!(trace[at..].iter().any(|t| t.starts_with("check")), "round 2 goes on after the start");
    // round 2 finds one within the ceiling: the run moves to it
    assert_eq!(events[1..], [ScanEvent::Switch { from: fastest, to: pr("162.159.193.20", 443, 90) }]);
    assert!(summary.fell_back);
}

#[tokio::test]
async fn a_switch_needs_a_second_check_that_agrees() {
    use std::sync::atomic::{AtomicU32, Ordering};
    let st = ScanMode::Thorough.strategy();
    let ports = [500];
    let input = ScanInput {
        mode: ScanMode::Thorough,
        st: &st,
        ip: IpScan::V4,
        ports: &ports,
        sweep: &[500],
        alive: &[500],
        avoid: &HashSet::new(),
        max_rtt: Some(Duration::from_millis(1500)),
        rounds: 1,
        prefilter: false,
    };
    let in_use = pr(MASQUE_SEEDS[0], 500, 800);
    let lucky: IpAddr = MASQUE_SEEDS[1].parse().unwrap();
    let steady: IpAddr = MASQUE_SEEDS[2].parse().unwrap();
    let lucky_checks = Arc::new(AtomicU32::new(0));
    let mut events = Vec::new();
    run_live(
        &input,
        Some(in_use),
        |_| async { QuickPass::default() },
        |ip, port| {
            let lucky_checks = lucky_checks.clone();
            async move {
                let ms = if ip == lucky {
                    // fast once, then as slow as the one in use
                    if lucky_checks.fetch_add(1, Ordering::SeqCst) == 0 { 200 } else { 800 }
                } else if ip == steady {
                    350
                } else {
                    return None;
                };
                Some(ProbeResult { ip, port, rtt: Duration::from_millis(ms) })
            }
        },
        |ev| events.push(ev),
    )
    .await;
    assert_eq!(lucky_checks.load(Ordering::SeqCst), 2, "checked again before a switch");
    assert_eq!(events, vec![ScanEvent::Switch { from: in_use, to: pr(MASQUE_SEEDS[2], 500, 350) }]);
}
