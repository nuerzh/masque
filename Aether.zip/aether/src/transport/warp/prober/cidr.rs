use super::*;

/// The network mask of an IPv4 prefix length (0 gives an all-zero mask).
fn v4_mask(prefix: u8) -> u32 {
    if prefix == 0 {
        0
    } else {
        u32::MAX << (32 - u32::from(prefix))
    }
}

/// The network address and prefix length of an IPv4 CIDR. The address is masked to its network,
/// so `10.1.2.5/24` is `10.1.2.0/24`; a prefix above 32 is refused.
pub(super) fn parse_cidr_v4(cidr: &str) -> Option<(u32, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    let prefix: u8 = prefix.parse().ok().filter(|p| *p <= 32)?;
    let addr = u32::from(ip.parse::<Ipv4Addr>().ok()?);
    Some((addr & v4_mask(prefix), prefix))
}

/// Every host address of an IPv4 CIDR of at most 12 host bits (the network and broadcast
/// addresses left out); empty for a larger range, or one that does not parse.
pub(super) fn enumerate_cidr_v4(cidr: &str) -> Vec<Ipv4Addr> {
    let Some((base, prefix)) = parse_cidr_v4(cidr) else {
        return Vec::new();
    };
    let host_bits = 32 - u32::from(prefix);
    if host_bits == 0 {
        return vec![Ipv4Addr::from(base)];
    }
    if host_bits > 12 {
        return Vec::new();
    }
    // `base` is aligned to the range, so `base + off` stays inside it and cannot overflow
    let size = 1u32 << host_bits;
    (1..size - 1).map(|off| Ipv4Addr::from(base + off)).collect()
}

/// `n` distinct random host addresses of an IPv4 CIDR (never its network or broadcast address),
/// or every host when there are fewer.
pub(super) fn sample_cidr_v4(cidr: &str, n: usize) -> Vec<Ipv4Addr> {
    let Some((base, prefix)) = parse_cidr_v4(cidr) else {
        return Vec::new();
    };
    // 64-bit so that a /0 (2^32 addresses) needs no special case
    let size: u64 = 1u64 << (32 - u32::from(prefix));
    if size <= 2 {
        return vec![Ipv4Addr::from(base)];
    }

    let usable = size - 2;
    let want = (n as u64).min(usable) as usize;
    let mut rng = rand::rng();
    let mut chosen: HashSet<u64> = HashSet::with_capacity(want);
    let mut out = Vec::with_capacity(want);

    while out.len() < want {
        let off = 1 + rng.random_range(0..usable);
        if chosen.insert(off) {
            out.push(Ipv4Addr::from(base + off as u32));
        }
    }

    out
}

/// The network address and prefix length of an IPv6 CIDR, masked to its network; a prefix above
/// 128 is refused.
pub(super) fn parse_cidr_v6(cidr: &str) -> Option<(u128, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    let prefix: u8 = prefix.parse().ok().filter(|p| *p <= 128)?;
    let addr = u128::from(ip.parse::<Ipv6Addr>().ok()?);
    let mask = if prefix == 0 { 0 } else { u128::MAX << (128 - u32::from(prefix)) };
    Some((addr & mask, prefix))
}

/// The IPv6 address of gateway `v4` under the IPv6 prefix whose network address is `base`: the
/// IPv4 address sits in the low 32 bits, the way the MASQUE gateways are numbered (for example
/// 162.159.198.2 is 2606:4700:d0::a29f:c602). `base` must have those bits clear, which a masked
/// prefix of at most /96 does.
pub(super) fn embed_v4(base: u128, v4: Ipv4Addr) -> Ipv6Addr {
    Ipv6Addr::from(base | u128::from(u32::from(v4)))
}

/// The network address of each IPv6 CIDR of the scan, in order.
pub(super) fn v6_prefix_bases() -> Vec<u128> {
    masque_cidrs_v6()
        .iter()
        .filter_map(|c| parse_cidr_v6(c).map(|(base, _)| base))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_unaligned_cidr_is_masked_to_its_network() {
        assert_eq!(parse_cidr_v4("10.1.2.5/24"), Some((u32::from(Ipv4Addr::new(10, 1, 2, 0)), 24)));
        assert_eq!(parse_cidr_v4("10.1.2.5/0"), Some((0, 0)));
        assert_eq!(parse_cidr_v4("10.1.2.5/33"), None, "a prefix above 32 is refused");
        assert_eq!(parse_cidr_v6("2606:4700:102::1/48").map(|(_, p)| p), Some(48));
        assert_eq!(parse_cidr_v6("2606:4700:102::1/129"), None);
    }

    #[test]
    fn enumerating_the_top_of_the_address_space_does_not_overflow() {
        let hosts = enumerate_cidr_v4("255.255.255.0/24");
        assert_eq!(hosts.len(), 254);
        assert_eq!(hosts.first(), Some(&Ipv4Addr::new(255, 255, 255, 1)));
        assert_eq!(hosts.last(), Some(&Ipv4Addr::new(255, 255, 255, 254)));
        assert!(enumerate_cidr_v4("10.0.0.0/8").is_empty(), "too big to enumerate");
    }

    #[test]
    fn an_unaligned_cidr_samples_inside_its_network_without_overflow() {
        // base is not the network address: before masking, base + offset wrapped past the top
        for ip in sample_cidr_v4("255.255.255.7/24", 200) {
            assert!(ip.octets()[..3] == [255, 255, 255] && ip.octets()[3] != 0 && ip.octets()[3] != 255);
        }
        // a /0 is 2^32 addresses: no special case, no panic
        let wide = sample_cidr_v4("0.0.0.0/0", 50);
        assert_eq!(wide.len(), 50);
        assert_eq!(wide.iter().collect::<HashSet<_>>().len(), 50, "distinct");
    }

    #[test]
    fn a_sample_is_distinct_and_never_the_network_or_broadcast() {
        let s = sample_cidr_v4("192.0.2.0/24", 254);
        assert_eq!(s.len(), 254);
        assert_eq!(s.iter().collect::<HashSet<_>>().len(), 254);
        assert!(s.iter().all(|ip| ip.octets()[3] != 0 && ip.octets()[3] != 255));
        assert_eq!(sample_cidr_v4("192.0.2.1/32", 5), vec![Ipv4Addr::new(192, 0, 2, 1)]);
    }

    #[test]
    fn a_gateway_embeds_its_ipv4_address_under_each_prefix() {
        let gw: Ipv4Addr = "162.159.198.2".parse().unwrap();
        let base: u128 = u128::from("2606:4700:d0::".parse::<Ipv6Addr>().unwrap());
        assert_eq!(embed_v4(base, gw), "2606:4700:d0::a29f:c602".parse::<Ipv6Addr>().unwrap());
        let bases = v6_prefix_bases();
        assert_eq!(bases.len(), masque_cidrs_v6().len());
        for &b in &bases {
            let a = embed_v4(b, gw);
            assert_eq!(u128::from(a) >> 32, b >> 32, "the embedding stays inside its prefix");
        }
    }
}
