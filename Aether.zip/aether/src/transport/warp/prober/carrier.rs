//! The carrier a scan verifies gateways over, and how its quick pass probes them. Before this
//! module the two carriers were told apart by a `bool` passed through the scan code and branched
//! on in several places; now the choice and everything that depends on it live here.

use super::*;
use quick::ProbeKind;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Carrier {
    /// HTTP/2 over TCP.
    Http2,
    /// QUIC over UDP.
    Quic,
}

impl Carrier {
    /// The carrier the session uses now.
    pub fn current() -> Self {
        if crate::transport::warp::masque::http2::enabled() {
            Carrier::Http2
        } else {
            Carrier::Quic
        }
    }

    /// How the quick pass probes this carrier: a TCP connect for HTTP/2, a QUIC Initial for QUIC.
    pub(in crate::transport::warp::prober) fn probe_kind(self) -> ProbeKind {
        match self {
            Carrier::Http2 => ProbeKind::Tcp,
            Carrier::Quic => ProbeKind::Quic,
        }
    }

    /// Whether the quick pass can pipeline its probes: only the QUIC probe sends one datagram
    /// per address, so only it shares one socket.
    pub fn can_pipeline(self) -> bool {
        self == Carrier::Quic
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn each_carrier_probes_its_own_way() {
        assert_eq!(Carrier::Http2.probe_kind(), ProbeKind::Tcp);
        assert_eq!(Carrier::Quic.probe_kind(), ProbeKind::Quic);
        assert!(Carrier::Quic.can_pipeline());
        assert!(!Carrier::Http2.can_pipeline());
    }
}
