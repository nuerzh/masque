//! The scan's data: the address ranges and the seed gateways it probes. The lists built in below
//! are the defaults; `AETHER_SCAN_CATALOG` may name a JSON file that replaces any of them (see
//! `parse_catalog`).

use super::cidr::{parse_cidr_v4, parse_cidr_v6};
use super::*;
use std::sync::OnceLock;

#[cfg(test)]
pub const MASQUE_DOCUMENTED_CIDRS_V4: &[&str] = &["162.159.197.0/24", "162.159.198.0/24"];
#[cfg(test)]
pub const MASQUE_DOH_CIDRS_V4: &[&str] = &["162.159.36.0/24", "162.159.46.0/24"];
pub const MASQUE_CIDRS_V4: &[&str] = &[
    "162.159.196.0/24",
    "162.159.195.0/24",
    "162.159.192.0/24",
    "162.159.193.0/24",
    "162.159.204.0/24",
    "162.159.197.0/24",
    "162.159.198.0/24",
    "172.65.251.0/24",
    "188.114.96.0/24",
    "188.114.97.0/24",
    "188.114.98.0/24",
    "188.114.99.0/24",
    "162.159.36.0/24",
    "162.159.46.0/24",
];
pub const MASQUE_SEEDS: &[&str] = &[
    "162.159.196.1",
    "162.159.195.1",
    "162.159.192.1",
    "162.159.197.3",
    "162.159.197.1",
    "162.159.198.2",
    "162.159.198.1",
    "162.159.193.1",
];
pub const MASQUE_VERIFIED_GATEWAYS: &[&str] = &[
    "162.159.199.1",
    "162.159.199.2",
    "162.159.198.2",
    "162.159.198.1",
];
pub const MASQUE_CIDRS_V6: &[&str] = &[
    "2606:4700:d0::/48",
    "2606:4700:102::/48",
    "2606:4700:d1::/48",
];
pub const MASQUE_ZT_CIDRS_V4: &[&str] = &["162.159.197.0/24"];
pub const MASQUE_ZT_CIDRS_V6: &[&str] = &["2606:4700:102::/48"];
pub const MASQUE_SEEDS_V6: &[&str] = &[
    "2606:4700:d0::a29f:c602",
    "2606:4700:d1::a29f:c602",
    "2606:4700:d0::a29f:c601",
    "2606:4700:d0::a29f:c001",
];

/// The lists the scan uses: the built-in ones, or those a catalog file replaced.
#[derive(Debug)]
pub(super) struct Catalog {
    pub cidrs_v4: &'static [&'static str],
    pub cidrs_v6: &'static [&'static str],
    pub seeds_v4: &'static [&'static str],
    pub seeds_v6: &'static [&'static str],
    pub verified_v4: &'static [&'static str],
}

impl Catalog {
    pub(super) fn builtin() -> Self {
        Self {
            cidrs_v4: MASQUE_CIDRS_V4,
            cidrs_v6: MASQUE_CIDRS_V6,
            seeds_v4: MASQUE_SEEDS,
            seeds_v6: MASQUE_SEEDS_V6,
            verified_v4: MASQUE_VERIFIED_GATEWAYS,
        }
    }
}

/// A list of strings from a catalog file, each checked by `valid`. The strings are kept for the
/// life of the process, which is what the scan needs of them.
fn list(
    obj: &serde_json::Map<String, serde_json::Value>,
    key: &str,
    valid: fn(&str) -> bool,
) -> std::result::Result<Option<&'static [&'static str]>, String> {
    let Some(value) = obj.get(key) else {
        return Ok(None);
    };
    let items = value.as_array().ok_or_else(|| format!("{key} must be a list of strings"))?;
    let mut out: Vec<&'static str> = Vec::with_capacity(items.len());
    for item in items {
        let s = item.as_str().ok_or_else(|| format!("{key} must be a list of strings"))?;
        if !valid(s) {
            return Err(format!("{key}: {s:?} is not a valid entry"));
        }
        out.push(Box::leak(s.to_string().into_boxed_str()));
    }
    Ok(Some(Box::leak(out.into_boxed_slice())))
}

/// The catalog a JSON document gives: each list it names replaces the built-in one, and a list
/// it leaves out is kept. An unknown key or an entry that does not parse is an error, so that a
/// typo does not silently fall back to the defaults.
pub(super) fn parse_catalog(text: &str) -> std::result::Result<Catalog, String> {
    let value: serde_json::Value =
        serde_json::from_str(text).map_err(|e| format!("not JSON: {e}"))?;
    let obj = value.as_object().ok_or("the catalog is a JSON object")?;
    const KNOWN: [&str; 5] = ["cidrs_v4", "cidrs_v6", "seeds_v4", "seeds_v6", "verified_v4"];
    if let Some(bad) = obj.keys().find(|k| !KNOWN.contains(&k.as_str())) {
        return Err(format!("unknown key {bad:?}"));
    }
    let v4_cidr = |s: &str| parse_cidr_v4(s).is_some();
    let v6_cidr = |s: &str| parse_cidr_v6(s).is_some();
    let v4_addr = |s: &str| s.parse::<Ipv4Addr>().is_ok();
    let v6_addr = |s: &str| s.parse::<Ipv6Addr>().is_ok();
    let mut cat = Catalog::builtin();
    if let Some(l) = list(obj, "cidrs_v4", v4_cidr)? {
        cat.cidrs_v4 = l;
    }
    if let Some(l) = list(obj, "cidrs_v6", v6_cidr)? {
        cat.cidrs_v6 = l;
    }
    if let Some(l) = list(obj, "seeds_v4", v4_addr)? {
        cat.seeds_v4 = l;
    }
    if let Some(l) = list(obj, "seeds_v6", v6_addr)? {
        cat.seeds_v6 = l;
    }
    if let Some(l) = list(obj, "verified_v4", v4_addr)? {
        cat.verified_v4 = l;
    }
    Ok(cat)
}

/// The catalog in use: the file `AETHER_SCAN_CATALOG` names, read once, or the built-in one. A
/// file that cannot be read or does not parse is logged, and the built-in lists are used.
pub(super) fn current() -> &'static Catalog {
    static CATALOG: OnceLock<Catalog> = OnceLock::new();
    CATALOG.get_or_init(|| {
        let path = match crate::config::settings::var("AETHER_SCAN_CATALOG") {
            Ok(p) if !p.trim().is_empty() => p.trim().to_string(),
            _ => return Catalog::builtin(),
        };
        match std::fs::read_to_string(&path).map_err(|e| e.to_string()).and_then(|t| parse_catalog(&t)) {
            Ok(cat) => {
                log::info!("[scan] the ranges and seeds come from {path}");
                cat
            }
            Err(e) => {
                log::warn!("[scan] catalog {path}: {e}; the built-in ranges and seeds are used");
                Catalog::builtin()
            }
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_catalog_replaces_only_the_lists_it_names() {
        let cat = parse_catalog(r#"{"seeds_v4": ["162.159.198.9"]}"#).unwrap();
        assert_eq!(cat.seeds_v4, &["162.159.198.9"]);
        assert_eq!(cat.cidrs_v4, MASQUE_CIDRS_V4, "a list left out is kept");
        assert_eq!(cat.seeds_v6, MASQUE_SEEDS_V6);
    }

    #[test]
    fn a_catalog_with_a_typo_or_a_bad_entry_is_refused() {
        assert!(parse_catalog(r#"{"seed_v4": []}"#).unwrap_err().contains("unknown key"));
        assert!(parse_catalog(r#"{"cidrs_v4": ["10.0.0.0/33"]}"#).is_err());
        assert!(parse_catalog(r#"{"seeds_v6": ["162.159.198.9"]}"#).is_err());
        assert!(parse_catalog("[]").is_err());
        assert!(parse_catalog("not json").is_err());
    }

    #[test]
    fn the_built_in_catalog_is_the_constants() {
        let cat = Catalog::builtin();
        assert_eq!(cat.cidrs_v4, MASQUE_CIDRS_V4);
        assert_eq!(cat.verified_v4, MASQUE_VERIFIED_GATEWAYS);
    }
}
