use super::*;

// ---- background scan: start early, keep scanning, move to a much faster gateway ----------------
//
// The run does not wait for the scan to end. The first gateway whose full check comes in within
// --max-rtt (with --max-rtt 0, the first that passes) is announced at once and the tunnel starts
// on it, in every scan mode. When a round ends with nothing within the ceiling, the fastest found
// so far is announced (with a warning) and the scan goes on. A run that started on a remembered
// gateway hands the scan that gateway and the RTT it measured just now (`in_use`); the scan then
// announces no start, only switches.
//
// The scan goes on in the background over every candidate of every round (--scan-rounds). A
// gateway is announced as a switch when its check takes under half as long as the one in use, or,
// while the one in use is over the ceiling, when it is within it; a gateway that qualifies is
// checked a second time first and must qualify again on the slower of its two checks. The next
// comparison is against it. The gateway in use is never a candidate for itself. The RTT is the
// same as everywhere in the scan: the whole full check.
//
// Within a round the mode's own early ends (the target number of gateways and the quiet period
// after it, turbo's first answer) do not apply: a round ends when its candidates are all checked
// or its time (the mode's budget, per batch of the full check) runs out. With the quick pass on,
// a round goes in batches: the quick pass hands over its fastest answers, they get the full
// check, and the quick pass goes on with what it did not reach, until nothing in the round is
// left to probe or nothing more answers.

/// What a background scan tells the run.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScanEvent {
    /// Start the tunnel on `gateway`: the first within the ceiling, or (`fallback`) the fastest
    /// found when the scan ended with none within it.
    Start { gateway: ProbeResult, fallback: bool },
    /// Move the tunnel from `from` to `to`: its check took under half as long, or `from` is over
    /// the ceiling and `to` within it.
    Switch { from: ProbeResult, to: ProbeResult },
}

/// Whether `new` is fast enough to move to from `current`: under 50% of its RTT.
pub(super) fn much_faster(new: Duration, current: Duration) -> bool {
    new.saturating_mul(2) < current
}

/// What a background scan decides, gateway by gateway.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum Decision {
    Start(ProbeResult),
    Switch { from: ProbeResult, to: ProbeResult },
    Keep,
}

/// The decisions of a background scan: the gateway in use (the comparison base), the fastest
/// over the ceiling (the fallback), and what was seen.
#[derive(Debug, Default)]
pub(super) struct Launcher {
    pub max_rtt: Option<Duration>,
    pub current: Option<ProbeResult>,
    pub fastest_over: Option<ProbeResult>,
    pub verified: usize,
    pub within: usize,
    pub switches: u32,
    pub fell_back: bool,
}

impl Launcher {
    #[cfg(test)]
    pub fn new(max_rtt: Option<Duration>) -> Self {
        Launcher { max_rtt, ..Default::default() }
    }

    /// A launcher for a run already going on `in_use` (a remembered gateway, measured now).
    pub fn in_use(max_rtt: Option<Duration>, in_use: Option<ProbeResult>) -> Self {
        Launcher { max_rtt, current: in_use, ..Default::default() }
    }

    fn within(&self, rtt: Duration) -> bool {
        self.max_rtt.is_none_or(|cap| rtt <= cap)
    }

    fn same_as_current(&self, pr: &ProbeResult) -> bool {
        self.current.is_some_and(|c| c.ip == pr.ip && c.port == pr.port)
    }

    /// Whether `pr` would replace the gateway in use: under half its RTT, or within the ceiling
    /// while the one in use is over it. Never the gateway in use itself; never with nothing in
    /// use (that is a start).
    pub fn would_switch(&self, pr: &ProbeResult) -> bool {
        match self.current {
            Some(cur) if !self.same_as_current(pr) => {
                much_faster(pr.rtt, cur.rtt) || (!self.within(cur.rtt) && self.within(pr.rtt))
            }
            _ => false,
        }
    }

    /// Take a gateway that passed the full check.
    pub fn offer(&mut self, pr: ProbeResult) -> Decision {
        self.verified += 1;
        let within = self.within(pr.rtt);
        if within {
            self.within += 1;
        }
        if self.same_as_current(&pr) {
            return Decision::Keep;
        }
        match self.current {
            None if within => {
                self.current = Some(pr);
                Decision::Start(pr)
            }
            None => {
                if self.fastest_over.is_none_or(|f| pr.rtt < f.rtt) {
                    self.fastest_over = Some(pr);
                }
                Decision::Keep
            }
            Some(cur) if self.would_switch(&pr) => {
                self.current = Some(pr);
                self.switches += 1;
                Decision::Switch { from: cur, to: pr }
            }
            Some(_) => Decision::Keep,
        }
    }

    /// Take a gateway that passed the full check but whose second check did not confirm a
    /// switch: it counts, and the gateway in use stays.
    pub fn count_only(&mut self, pr: ProbeResult) {
        self.verified += 1;
        if self.within(pr.rtt) {
            self.within += 1;
        }
    }

    /// A round is over (or the scan): the fastest found so far, when nothing was within the
    /// ceiling to start on.
    pub fn finish(&mut self) -> Option<ProbeResult> {
        if self.current.is_some() {
            return None;
        }
        let pr = self.fastest_over?;
        self.current = Some(pr);
        self.fell_back = true;
        Some(pr)
    }
}

/// How a background scan ended.
#[derive(Debug)]
pub(super) struct LiveSummary {
    pub rounds_run: u32,
    pub verified: usize,
    pub within: usize,
    pub switches: u32,
    pub current: Option<ProbeResult>,
    pub fell_back: bool,
    /// The plan of every round that ran (read by the tests).
    #[cfg_attr(not(test), allow(dead_code))]
    pub plans: Vec<RoundPlan>,
    /// What every round that ran did (read by the tests).
    #[cfg_attr(not(test), allow(dead_code))]
    pub stats: Vec<RoundStats>,
}

/// How often a full check still going says how far it got. The scan goes on for minutes after
/// the tunnel started; without a line now and then it looks as if it had stopped.
pub(super) const PROGRESS_EVERY: Duration = Duration::from_secs(30);

/// What one round of a background scan did, logged when it ends.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub(super) struct RoundStats {
    pub round: u32,
    pub candidates: usize,
    pub batches: u32,
    /// Candidates that answered the quick pass.
    pub quick_answered: usize,
    /// Candidates that got the full check.
    pub checked: usize,
    pub passed: usize,
    pub fastest: Option<ProbeResult>,
    /// Candidates the round ended without probing (nothing more answered the quick pass, or a
    /// batch ran out of time).
    pub left: usize,
    pub heartbeats: u32,
}

/// What the full check of one batch did.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub(super) struct BatchStats {
    pub total: usize,
    pub checked: usize,
    pub passed: usize,
    pub fastest: Option<ProbeResult>,
    pub heartbeats: u32,
}

/// Where the scan is, for the progress lines: `round r/R batch b`.
#[derive(Debug, Clone, Copy)]
struct Place {
    round: u32,
    rounds: u32,
    batch: u32,
}

impl std::fmt::Display for Place {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "round {}/{} batch {}", self.round, self.rounds, self.batch)
    }
}

fn label(pr: &ProbeResult) -> String {
    format!("{}({:?})", SocketAddr::new(pr.ip, pr.port), pr.rtt)
}

/// `address:port(820ms)`, for the progress lines.
fn short(pr: &ProbeResult) -> String {
    format!("{}({}ms)", SocketAddr::new(pr.ip, pr.port), pr.rtt.as_millis())
}

fn short_or_none(pr: Option<ProbeResult>) -> String {
    pr.as_ref().map_or_else(|| "none".to_string(), short)
}

/// The gateway in use and the RTT a gateway must beat to replace it (under half of its RTT).
pub(super) fn in_use_line(current: Option<ProbeResult>, max_rtt: Option<Duration>) -> String {
    match current {
        Some(pr) => match max_rtt {
            Some(cap) if pr.rtt > cap => format!(
                "in use {} (over max-rtt), switches to any within {}ms",
                short(&pr),
                cap.as_millis()
            ),
            _ => format!("in use {}, switches below {}ms", short(&pr), (pr.rtt / 2).as_millis()),
        },
        None => match max_rtt {
            Some(cap) => format!("nothing in use yet (waiting for one within {}ms)", cap.as_millis()),
            None => "nothing in use yet".to_string(),
        },
    }
}

fn faster_of(a: Option<ProbeResult>, b: Option<ProbeResult>) -> Option<ProbeResult> {
    match (a, b) {
        (Some(x), Some(y)) => Some(if y.rtt < x.rtt { y } else { x }),
        (x, None) => x,
        (None, y) => y,
    }
}

/// The background scan over every round: `quick` is the quick pass, `verify` the full check,
/// `emit` gets every start and switch as it is decided.
pub(super) async fn run_live<Q, QF, V, VF, E>(
    inp: &ScanInput<'_>,
    in_use: Option<ProbeResult>,
    quick: Q,
    verify: V,
    emit: E,
) -> LiveSummary
where
    Q: Fn(Vec<(IpAddr, u16)>) -> QF,
    QF: std::future::Future<Output = QuickPass>,
    V: Fn(IpAddr, u16) -> VF,
    VF: std::future::Future<Output = Option<ProbeResult>>,
    E: FnMut(ScanEvent),
{
    run_live_with(inp, in_use, quick, verify, emit, PROGRESS_EVERY).await
}

/// `run_live` with a full check in progress logging every `progress_every`.
pub(super) async fn run_live_with<Q, QF, V, VF, E>(
    inp: &ScanInput<'_>,
    in_use: Option<ProbeResult>,
    quick: Q,
    verify: V,
    mut emit: E,
    progress_every: Duration,
) -> LiveSummary
where
    Q: Fn(Vec<(IpAddr, u16)>) -> QF,
    QF: std::future::Future<Output = QuickPass>,
    V: Fn(IpAddr, u16) -> VF,
    VF: std::future::Future<Output = Option<ProbeResult>>,
    E: FnMut(ScanEvent),
{
    let started = Instant::now();
    let st = inp.st;
    let mut launcher = Launcher::in_use(inp.max_rtt, in_use);
    let mut probed: HashSet<(IpAddr, u16)> = HashSet::new();
    let first_round = first_round_addresses();
    let mut quick_ever_answered = false;
    let mut plans = Vec::new();
    let mut stats = Vec::new();
    let mut rounds_run = 0;
    let rounds = inp.rounds.max(1);
    let cap_label = inp.max_rtt.map_or_else(|| "none".to_string(), |d| format!("{d:?}"));

    for round in 1..=rounds {
        let plan = plan_round(st, round, rounds, inp.sweep, inp.alive, inp.ports);
        let mut all = leave_out(build_round_candidates(&plan, inp.ports, inp.ip), inp.avoid);
        if round == 1 {
            log::info!(
                "[scan] scan mode={} ip={} candidates={} ports={:?} primary={:?} concurrency={} per_probe={:?} budget={:?} max_rtt={} rounds={} ({})",
                inp.mode.label(),
                inp.ip.label(),
                all.len(),
                inp.ports,
                inp.sweep,
                st.concurrency,
                st.per_probe_timeout,
                st.overall_deadline,
                cap_label,
                rounds,
                match in_use {
                    Some(pr) => format!("running on {} already, scanning in the background for a faster one", short(&pr)),
                    None => "starts on the first gateway within max-rtt, then scans on in the background".to_string(),
                },
            );
        } else {
            let (left, dup, seeds) = leave_out_probed(all, &probed, &first_round);
            all = left;
            log::info!(
                "[scan] background scan round {round}/{rounds}: sampling {}{} on ports {:?}: {} new candidate(s), {} address:port already probed and {} seed/verified left out",
                plan.sample_label(),
                if inp.ip.want_v6() { format!(" ({} per /48)", plan.sample_v6) } else { String::new() },
                plan.ports,
                all.len(),
                dup,
                seeds,
            );
        }
        plans.push(plan);
        rounds_run = round;

        let round_started = Instant::now();
        let mut rs = RoundStats { round, candidates: all.len(), ..Default::default() };
        let mut remaining = all;
        let mut batch = 0u32;
        while !remaining.is_empty() {
            batch += 1;
            let place = Place { round, rounds, batch };
            let candidates = if inp.prefilter {
                let quick_started = Instant::now();
                let probing = remaining.len();
                let pass = quick(remaining.clone()).await;
                let quick_took = quick_started.elapsed().as_secs();
                let mut gone: HashSet<(IpAddr, u16)> = pass.skipped.iter().copied().collect();
                gone.extend(pass.silent.iter().copied());
                gone.extend(pass.live.iter().copied());
                let (silent, skipped) = (pass.silent.len(), pass.skipped.len());
                probed.extend(pass.silent);
                rs.quick_answered += pass.live.len();
                if pass.live.is_empty() {
                    if batch == 1 && !quick_ever_answered {
                        log::warn!("[scan] quick pass found nothing; falling back to full handshakes on every candidate");
                        std::mem::take(&mut remaining)
                    } else {
                        remaining.retain(|c| !gone.contains(c));
                        rs.left = remaining.len();
                        log::info!(
                            "[scan] {place}: quick pass of {probing} candidate(s) in {quick_took}s: nothing more answered ({silent} silent, {skipped} skipped in silent ranges); round ends with {} not reached",
                            remaining.len()
                        );
                        break;
                    }
                } else {
                    quick_ever_answered = true;
                    remaining.retain(|c| !gone.contains(c));
                    log::info!(
                        "[scan] {place}: quick pass of {probing} candidate(s) in {quick_took}s: {} answered, {silent} silent, {skipped} skipped in silent ranges; {} left in this round",
                        pass.live.len(),
                        remaining.len()
                    );
                    pass.live
                }
            } else {
                std::mem::take(&mut remaining)
            };
            rs.batches = batch;
            let b = verify_live(st, candidates, &mut launcher, &mut probed, &verify, &mut emit, place, progress_every).await;
            rs.checked += b.checked;
            rs.passed += b.passed;
            rs.fastest = faster_of(rs.fastest, b.fastest);
            rs.heartbeats += b.heartbeats;
            rs.left += b.total - b.checked;
            log::info!(
                "[scan] {place}: full check {}/{} done, {} passed, fastest {}; {}",
                b.checked,
                b.total,
                b.passed,
                short_or_none(b.fastest),
                in_use_line(launcher.current, inp.max_rtt),
            );
        }
        log::info!(
            "[scan] round {round}/{rounds} finished in {}s: {} candidate(s), {} batch(es){}, {} full-checked, {} passed, fastest {}, {} not reached; {}",
            round_started.elapsed().as_secs(),
            rs.candidates,
            rs.batches,
            if inp.prefilter { format!(", {} answered the quick pass", rs.quick_answered) } else { String::new() },
            rs.checked,
            rs.passed,
            short_or_none(rs.fastest),
            rs.left,
            in_use_line(launcher.current, inp.max_rtt),
        );
        stats.push(rs);
        // Nothing within the ceiling after this round: start on the fastest so far rather than
        // wait for the whole scan; it goes on and moves to one within the ceiling when it comes.
        if let Some(pr) = launcher.finish() {
            log::warn!(
                "[scan] no gateway within max-rtt {:?} after {} of {} scan round(s) ({} answered, all slower); starting on the fastest so far {}:{} rtt={:?}{}",
                inp.max_rtt.unwrap_or_default(),
                round,
                rounds,
                launcher.verified,
                pr.ip,
                pr.port,
                pr.rtt,
                if round < rounds { ", scanning on for one within it" } else { "" },
            );
            emit(ScanEvent::Start { gateway: pr, fallback: true });
        }
    }
    let summary = LiveSummary {
        rounds_run,
        verified: launcher.verified,
        within: launcher.within,
        switches: launcher.switches,
        current: launcher.current,
        fell_back: launcher.fell_back,
        plans,
        stats,
    };
    match summary.current {
        Some(pr) => log::info!(
            "[scan] background scan finished in {:?}: {} round(s), {} gateway(s) passed ({} within max-rtt {}), {} switch(es); in use {}{}",
            started.elapsed(),
            summary.rounds_run,
            summary.verified,
            summary.within,
            cap_label,
            summary.switches,
            label(&pr),
            if summary.fell_back { " (fallback)" } else { "" },
        ),
        None => log::warn!(
            "[scan] scan finished in {:?} after {} round(s) with no gateway",
            started.elapsed(),
            summary.rounds_run
        ),
    }
    summary
}

/// The full check of one batch: every candidate is checked unless the mode's budget runs out
/// first; each gateway that passes goes to the launcher, and what it decides to `emit`. Every
/// `progress_every` while it goes on, a line says how far it got.
#[expect(clippy::too_many_arguments, reason = "the batch carries the scan state of run_live; a struct would only rename it")]
async fn verify_live<V, VF, E>(
    st: &Strategy,
    candidates: Vec<(IpAddr, u16)>,
    launcher: &mut Launcher,
    probed: &mut HashSet<(IpAddr, u16)>,
    verify: &V,
    emit: &mut E,
    place: Place,
    progress_every: Duration,
) -> BatchStats
where
    V: Fn(IpAddr, u16) -> VF,
    VF: std::future::Future<Output = Option<ProbeResult>>,
    E: FnMut(ScanEvent),
{
    let mut b = BatchStats { total: candidates.len(), ..Default::default() };
    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| async move { ((ip, port), verify(ip, port).await) }),
    )
    .buffer_unordered(st.concurrency.max(1));
    tokio::pin!(stream);
    let deadline = tokio::time::Instant::now() + st.overall_deadline;
    let mut progress = tokio::time::interval_at(tokio::time::Instant::now() + progress_every, progress_every);
    progress.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
    loop {
        tokio::select! {
            item = stream.next() => {
                let Some((pair, result)) = item else { return b };
                b.checked += 1;
                probed.insert(pair);
                let Some(pr) = result else { continue };
                b.passed += 1;
                b.fastest = faster_of(b.fastest, Some(pr));
                // A switch breaks the connections on the tunnel: one fast check is not enough.
                let pr = if launcher.would_switch(&pr) {
                    match verify(pr.ip, pr.port).await {
                        Some(again) => {
                            let slower = ProbeResult { rtt: pr.rtt.max(again.rtt), ..pr };
                            if launcher.would_switch(&slower) {
                                slower
                            } else {
                                log::info!(
                                    "[scan] {} looked faster but its second check took {:?}; keeping {}",
                                    short(&pr), again.rtt, short_or_none(launcher.current)
                                );
                                launcher.count_only(pr);
                                continue;
                            }
                        }
                        None => {
                            log::info!(
                                "[scan] {} looked faster but failed its second check; keeping {}",
                                short(&pr), short_or_none(launcher.current)
                            );
                            launcher.count_only(pr);
                            continue;
                        }
                    }
                } else {
                    pr
                };
                match launcher.offer(pr) {
                    Decision::Start(pr) => {
                        log::info!(
                            "[scan] started on {}:{} rtt={:?}, scanning continues in background",
                            pr.ip, pr.port, pr.rtt
                        );
                        emit(ScanEvent::Start { gateway: pr, fallback: false });
                    }
                    Decision::Switch { from, to } => {
                        log::info!("[scan] switching gateway {} -> {}", label(&from), label(&to));
                        emit(ScanEvent::Switch { from, to });
                    }
                    Decision::Keep => log::debug!(
                        "[scan] candidate ok {}:{} rtt={:?} (kept the gateway in use)",
                        pr.ip, pr.port, pr.rtt
                    ),
                }
            }
            _ = progress.tick() => {
                b.heartbeats += 1;
                log::info!(
                    "[scan] {place}: full check in progress, {}/{} checked, {} passed; {}",
                    b.checked,
                    b.total,
                    b.passed,
                    in_use_line(launcher.current, launcher.max_rtt),
                );
            }
            _ = tokio::time::sleep_until(deadline) => {
                log::info!(
                    "[scan] full-check budget {:?} spent with {} of {} candidate(s) checked",
                    st.overall_deadline, b.checked, b.total
                );
                return b;
            }
        }
    }
}
