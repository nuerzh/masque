//! The decisions a scan makes before it probes, as pure functions of what it knows. `prepare`
//! asks these and logs the answers; the rules themselves can be tested without a network.

use super::*;

/// The IP family a scan uses. `want` is what was asked for; `has_v6_route` says whether this host
/// has a usable IPv6 route. None when the scan cannot use any family.
pub fn decide_ip(want: IpScan, has_v6_route: bool) -> Option<IpScan> {
    if want.want_v6() && !has_v6_route {
        if want.want_v4() {
            Some(IpScan::V4)
        } else {
            None
        }
    } else {
        Some(want)
    }
}

/// Whether the quick pass runs at all. Through an upstream proxy it would measure the wrong
/// path, so there the scan keeps to full handshakes.
pub fn decide_prefilter(cfg: &ScanConfig, upstream_configured: bool) -> bool {
    cfg.prefilter && !upstream_configured
}

/// What a round does with the quick pass's answers.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QuickFallback {
    /// Verify the answers.
    Use,
    /// The quick pass found nothing and never has: verify every candidate with a full check.
    Full,
    /// Nothing new answered this round, after an earlier round did: nothing to verify.
    Skip,
}

/// The quick pass's answers decide the round, see `QuickFallback`.
pub fn quick_fallback(round: u32, any_live: bool, quick_ever_answered: bool) -> QuickFallback {
    if any_live {
        QuickFallback::Use
    } else if round == 1 || !quick_ever_answered {
        QuickFallback::Full
    } else {
        QuickFallback::Skip
    }
}

/// Whether a round that verified `counted` gateways within the ceiling leaves the next, deeper
/// round to run: only when none did, and there is a ceiling to be deeper about. Without a ceiling
/// the first round that verifies anything is the answer.
pub fn deeper_round_wanted(counted: usize, has_ceiling: bool) -> bool {
    counted == 0 && has_ceiling
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_round_decisions_follow_the_quick_pass_and_the_ceiling() {
        assert_eq!(quick_fallback(1, true, false), QuickFallback::Use);
        assert_eq!(quick_fallback(1, false, false), QuickFallback::Full, "round 1 always falls back");
        assert_eq!(quick_fallback(3, false, false), QuickFallback::Full, "nothing ever answered");
        assert_eq!(quick_fallback(3, false, true), QuickFallback::Skip, "it answered before; not now");
        assert!(deeper_round_wanted(0, true));
        assert!(!deeper_round_wanted(2, true), "found one: done");
        assert!(!deeper_round_wanted(0, false), "no ceiling: the first answer is the pick");
    }

    #[test]
    fn an_ipv6_scan_without_a_route_falls_back_to_ipv4_only_when_it_may() {
        assert_eq!(decide_ip(IpScan::Both, false), Some(IpScan::V4));
        assert_eq!(decide_ip(IpScan::V6, false), None, "no family left to scan");
        assert_eq!(decide_ip(IpScan::V6, true), Some(IpScan::V6));
        assert_eq!(decide_ip(IpScan::V4, false), Some(IpScan::V4));
    }

    #[test]
    fn the_quick_pass_is_off_behind_an_upstream_proxy_or_when_configured_off() {
        let cfg = ScanConfig::default();
        assert!(decide_prefilter(&cfg, false));
        assert!(!decide_prefilter(&cfg, true));
        let off = ScanConfig { prefilter: false, ..ScanConfig::default() };
        assert!(!decide_prefilter(&off, false));
    }
}
