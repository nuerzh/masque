//! The WARP tunnel: identities and their registration (`identity`, `account`, `zerotrust`,
//! `consts`), gateway scans (`scan`, `prober`, `tunnelping`), the MASQUE tunnel itself
//! (`masque/`: the run loop, HTTP/3 in `quic.rs`, HTTP/2 in `http2.rs`, the capsules of
//! CONNECT-IP in `proto.rs`; also the outer tunnel of --sunny), its userspace TCP/IP stack
//! (`netstack`), and what it dials out with (`net/`: TLS, HTTPS, --upstream).

pub mod account;
pub mod consts;
pub mod demand;
pub mod exitloc;
pub mod lastconn;
pub mod masque;
pub mod net;
pub mod netstack;
pub mod prober;
pub mod tunnelping;
pub mod zerotrust;

pub(crate) mod prelude;

mod common;
mod identity;
mod manager;
mod scan;

pub(crate) use common::*;
pub(crate) use identity::*;
pub(crate) use manager::run;
pub(crate) use masque::*;
pub(crate) use scan::*;

#[cfg(test)]
mod tests;
