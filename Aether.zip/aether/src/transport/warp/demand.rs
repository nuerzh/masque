//! Whether this run brings the WARP tunnel up at all (--warp-tunnel auto|on|off, --no-warp).
//!
//! `auto` (the default) starts it when something can only work through it: with a routed config
//! (`[route]` / `[[inbounds]]` / `[[outbounds]]` in the config file or a --route-config file),
//! an outbound a rule, `final` or a rule-set download can pick that rides WARP (`warp`,
//! `warp-local`, `proxy` / `tunnel` outside --sunny, a `sunnyquic` outbound with
//! `detour = "warp"`, and `sunny` (= `proxy` in --sunny) only when the --sunny client has
//! `detour = "warp"`), hijack-dns, a `resolve` with the resolver inside the tunnel, or a TUN
//! that answers dns through the tunnel. The --sunny client goes direct by default, so `sunny`
//! alone never starts WARP. Without a routed config every connection goes to `proxy`: WARP, or
//! in --sunny the sunny client (WARP only with its detour warp). `off` with something that
//! needs it is an error at start, naming what needs it: a connection must never quietly find
//! its outbound missing.

use crate::error::{AetherError, Result};
use crate::proxy::outbound::sunnyquic::Detour;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WarpTunnel {
    Auto,
    On,
    Off,
}

impl WarpTunnel {
    pub fn parse(v: &str) -> Option<WarpTunnel> {
        match v.trim().to_ascii_lowercase().as_str() {
            "" | "auto" => Some(WarpTunnel::Auto),
            "on" | "1" | "true" | "yes" | "always" => Some(WarpTunnel::On),
            "off" | "0" | "false" | "no" | "never" => Some(WarpTunnel::Off),
            _ => None,
        }
    }

    /// --warp-tunnel / AETHER_WARP_TUNNEL.
    pub fn from_env() -> Result<WarpTunnel> {
        let v = crate::config::settings::var("AETHER_WARP_TUNNEL").unwrap_or_default();
        WarpTunnel::parse(&v).ok_or_else(|| {
            AetherError::Other(format!("warp-tunnel {v:?}: use auto, on or off"))
        })
    }
}

/// The decision: `users` is what needs WARP (`None` without a routed config, where everything
/// goes to `proxy`). Ok(true) starts the tunnel.
pub fn decide(setting: WarpTunnel, users: Option<&[String]>) -> Result<bool> {
    let needed = match users {
        None => true,
        Some(list) => !list.is_empty(),
    };
    match setting {
        WarpTunnel::On => Ok(true),
        WarpTunnel::Auto => Ok(needed),
        WarpTunnel::Off if !needed => Ok(false),
        WarpTunnel::Off => Err(AetherError::Other(match users {
            None => "warp-tunnel off without a route in the config file (or a route-config \
                     file): every connection would go to proxy, the WARP tunnel (or the sunny \
                     client with detour: warp); write a route whose outbounds need no WARP \
                     (final = \"direct\", sunny-direct, sunny with its default detour direct, a \
                     [[outbounds]] of type sunnyquic with detour = \"direct\"), or drop warp-tunnel: off"
                .to_string(),
            Some(list) => format!(
                "warp-tunnel off, but the route of the config needs the WARP tunnel: {}; \
                 route those elsewhere, or use warp-tunnel: auto",
                list.join("; ")
            ),
        })),
    }
}

/// What this run does about the WARP tunnel, decided once the routes and the inbounds are
/// known and before any inbound serves.
#[derive(Debug, Clone)]
pub struct Plan {
    pub setting: WarpTunnel,
    /// What needs WARP (`None`: no routed config, everything goes to `proxy`).
    pub users: Option<Vec<String>>,
    /// Bring the WARP tunnel up (the gateway scan, the connect).
    pub start: bool,
    /// --sunny: how its client (`sunny`, and `proxy`) reaches the server; `None` without it.
    pub sunny: Option<Detour>,
}

/// --warp-tunnel against what this run's config needs; `off` with a need is an error here, as
/// is a --sunny detour other than direct or warp.
pub fn plan() -> Result<Plan> {
    let setting = WarpTunnel::from_env()?;
    let sunny = if crate::proxy::router::sunny_mode() {
        Some(crate::proxy::outbound::sunnyquic::settings::detour()?)
    } else {
        None
    };
    let users = users(sunny);
    let start = decide(setting, users.as_deref())?;
    Ok(Plan { setting, users, start, sunny })
}

impl Plan {
    /// The start-up log line: what needs WARP and whether the tunnel (and its scan) starts.
    pub fn describe(&self) -> String {
        let wait = crate::proxy::router::exits::WARP_START_WAIT.as_secs();
        let how = format!(
            "the gateway scan and the connect run alongside the inbounds, which serve right away; \
             connections to those outbounds wait for the tunnel (at most {wait}s each), the others go now"
        );
        let main = match (&self.users, self.start) {
            (_, false) => "the WARP tunnel is not started: nothing in the config (route, inbounds, outbounds) needs it \
                           (warp-tunnel: on starts it anyway); no scan, no registration"
                .to_string(),
            (None, true) if self.sunny == Some(Detour::Warp) => format!(
                "no route in the config: every connection goes to proxy, the sunny client, which has detour: warp \
                 and rides inside WARP MASQUE; starting the WARP tunnel: {how}"
            ),
            (None, true) => format!(
                "no route in the config: every connection goes to proxy, the WARP tunnel; starting it: {how}"
            ),
            (Some(list), true) if list.is_empty() && self.setting == WarpTunnel::On => {
                format!("warp-tunnel on: starting the WARP tunnel though nothing in the config needs it: {how}")
            }
            (Some(list), true) if !list.is_empty() => format!("these need the WARP tunnel: {}; starting it: {how}", list.join("; ")),
            (Some(_), true) => format!("starting the WARP tunnel: {how}"),
        };
        match self.sunny {
            Some(Detour::Direct) => format!(
                "{main}. sunny (and proxy) is the sunny sunnyquic client, which goes direct from this machine and needs no \
                 WARP (sunny.detour: warp puts it inside WARP MASQUE)"
            ),
            _ => main,
        }
    }
}

/// What of the TUN needs WARP: its dns answered through the tunnel (fake-ip off), or
/// --tun-direct-dns tunnel.
pub fn tun_users() -> Vec<String> {
    let mut out = Vec::new();
    if let Some(cfg) = crate::proxy::inbound::tun::config() {
        if cfg.fakeip.is_none() {
            out.push("the TUN without fake-ip answers dns through the tunnel".to_string());
        }
        if matches!(cfg.direct_dns, crate::proxy::inbound::tun::DirectDns::Tunnel) {
            out.push("tun.direct-dns: tunnel".to_string());
        }
    }
    out
}

/// Everything in this run that needs WARP, or `None` without a routed config when that sends
/// everything to WARP (`proxy` outside --sunny, or the --sunny client with detour warp).
/// `sunny`: how the --sunny client goes, `None` without --sunny.
pub fn users(sunny: Option<Detour>) -> Option<Vec<String>> {
    if !crate::proxy::router::configured() {
        // every connection goes to proxy: the --sunny client going direct needs no WARP
        return match sunny {
            Some(Detour::Direct) => Some(tun_users()),
            _ => None,
        };
    }
    let mut list = crate::proxy::router::router().map(|r| r.warp_users()).unwrap_or_default();
    list.extend(tun_users());
    Some(list)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proxy::router::{build, Caps, LoadOptions};
    use crate::config::file::test_routing as cfg;

    /// What needs WARP, the --sunny client going direct (its default).
    fn users_of(config: serde_json::Value) -> Vec<String> {
        users_with(config, Caps::ALL)
    }

    fn users_with(config: serde_json::Value, caps: Caps) -> Vec<String> {
        let spec = build(
            &config,
            LoadOptions {
                base_dir: std::path::PathBuf::new(),
                cache_dir: std::env::temp_dir().join("aether-demand-test"),
                caps,
            },
        )
        .unwrap();
        spec.router.warp_users()
    }

    #[test]
    fn the_setting_is_read_as_written() {
        assert_eq!(WarpTunnel::parse(""), Some(WarpTunnel::Auto));
        assert_eq!(WarpTunnel::parse("AUTO"), Some(WarpTunnel::Auto));
        assert_eq!(WarpTunnel::parse("on"), Some(WarpTunnel::On));
        assert_eq!(WarpTunnel::parse("off"), Some(WarpTunnel::Off));
        assert_eq!(WarpTunnel::parse("0"), Some(WarpTunnel::Off));
        assert_eq!(WarpTunnel::parse("maybe"), None);
    }

    #[test]
    fn a_plain_sunnyquic_server_needs_no_warp() {
        let users = users_of(cfg(r#"
            [[inbounds]]
            type = "sunnyquic"
            tag = "sunnyquic-inbound"
            listen = "0.0.0.0"
            listen_port = 8443

            [route]
            default_domain_resolver = { strategy = "prefer_ipv4" }
            final = "direct"
        "#));
        assert!(users.is_empty(), "{users:?}");
        assert!(!decide(WarpTunnel::Auto, Some(&users)).unwrap());
        assert!(!decide(WarpTunnel::Off, Some(&users)).unwrap());
        assert!(decide(WarpTunnel::On, Some(&users)).unwrap());
    }

    #[test]
    fn direct_block_and_local_resolve_need_no_warp() {
        let users = users_of(cfg(r#"
            [route]
            final = "direct"

            [[route.rules]]
            domain_suffix = ["ads.test"]
            action = "reject"

            [[route.rules]]
            domain_suffix = ["a.test"]
            outbound = "block"

            [[route.rules]]
            domain_suffix = ["b.test"]
            action = "resolve"
            server = "local"

            [[route.rules]]
            action = "sniff"

            [[route.rules]]
            ip_cidr = ["10.0.0.0/8"]
            outbound = "direct"
        "#));
        assert!(users.is_empty(), "{users:?}");
    }

    #[test]
    fn every_outbound_that_rides_warp_needs_it() {
        for tag in ["warp", "warp-local", "proxy", "tunnel"] {
            let rule = users_of(cfg(&format!(
                "[route]\nrules = [{{ domain_suffix = [\"x.test\"], outbound = \"{tag}\" }}]\nfinal = \"direct\"\n"
            )));
            assert_eq!(rule.len(), 1, "{tag}: {rule:?}");
            let fin = users_of(cfg(&format!("[route]\nfinal = \"{tag}\"\n")));
            assert_eq!(fin.len(), 1, "final {tag}: {fin:?}");
        }
        // final defaults to proxy
        assert_eq!(users_of(cfg(r#"
            [route]
            rules = [{ domain_suffix = ["x.test"], outbound = "direct" }]
        "#)).len(), 1);
        // declared outbounds of those types too
        let declared = users_of(cfg(r#"
            outbounds = [{ type = "warp-local", tag = "w" }]

            [route]
            rules = [{ domain_suffix = ["x.test"], outbound = "w" }]
            final = "direct"
        "#));
        assert_eq!(declared.len(), 1, "{declared:?}");
    }

    #[test]
    fn tunnel_dns_needs_warp() {
        let hijack = users_of(cfg(r#"
            [route]
            rules = [{ protocol = "dns", action = "hijack-dns" }]
            final = "direct"
        "#));
        assert_eq!(hijack.len(), 1, "{hijack:?}");
        let resolve = users_of(cfg(r#"
            [route]
            rules = [{ domain_suffix = ["x.test"], action = "resolve" }]
            final = "direct"
        "#));
        assert_eq!(resolve.len(), 1, "{resolve:?}");
        let dns_out = users_of(cfg(r#"
            outbounds = [{ type = "dns", tag = "dns-out" }]

            [route]
            rules = [{ port = 53, outbound = "dns-out" }]
            final = "direct"
        "#));
        assert_eq!(dns_out.len(), 1, "{dns_out:?}");
    }

    #[test]
    fn a_remote_rule_set_downloads_through_its_detour() {
        let set = |detour: Option<&str>| {
            let detour = detour.map(|d| format!("download_detour = \"{d}\"\n")).unwrap_or_default();
            users_of(cfg(&format!(
                "[route]\nfinal = \"direct\"\n\n[[route.rule_set]]\ntype = \"remote\"\ntag = \"x\"\n\
                 format = \"binary\"\nurl = \"https://e.test/x.srs\"\n{detour}"
            )))
        };
        assert_eq!(set(None).len(), 1, "no detour downloads through the tunnel");
        assert!(set(Some("direct")).is_empty());
        assert_eq!(set(Some("warp")).len(), 1);
    }

    #[test]
    fn off_with_something_that_needs_warp_is_an_error() {
        let users = vec!["final is warp".to_string()];
        let e = decide(WarpTunnel::Off, Some(&users)).unwrap_err().to_string();
        assert!(e.contains("final is warp"), "{e}");
        assert!(decide(WarpTunnel::Auto, Some(&users)).unwrap());
        // no routed config: the legacy run, always WARP
        assert!(decide(WarpTunnel::Auto, None).unwrap());
        assert!(decide(WarpTunnel::Off, None).is_err());
    }

    #[test]
    fn the_plan_says_what_needs_warp_and_whether_the_scan_starts() {
        let off = Plan { setting: WarpTunnel::Auto, users: Some(Vec::new()), start: false, sunny: None };
        let d = off.describe();
        assert!(d.contains("not started") && d.contains("no scan, no registration"), "{d}");
        let on = Plan {
            setting: WarpTunnel::Auto,
            users: Some(vec!["rule 3 routes to warp-local".into(), "final is warp".into()]),
            start: true,
            sunny: None,
        };
        let d = on.describe();
        assert!(d.starts_with("these need the WARP tunnel: rule 3 routes to warp-local; final is warp; starting it"), "{d}");
        assert!(d.contains("serve right away") && d.contains("at most 30s"), "{d}");
        let forced = Plan { setting: WarpTunnel::On, users: Some(Vec::new()), start: true, sunny: None };
        assert!(forced.describe().starts_with("warp-tunnel on"), "{}", forced.describe());
        let legacy = Plan { setting: WarpTunnel::Auto, users: None, start: true, sunny: None };
        assert!(legacy.describe().starts_with("no route"), "{}", legacy.describe());
    }

    /// `sunny` is the --sunny client, which goes direct by default: on its own it needs no
    /// WARP, wherever it is used (a rule, final, a rule-set download).
    #[test]
    fn sunny_alone_needs_no_warp() {
        for config in [
            "[route]\nrules = [{ domain_suffix = [\"x.test\"], outbound = \"sunny\" }]\nfinal = \"direct\"\n",
            "[route]\nfinal = \"sunny\"\n",
            "[route]\nfinal = \"direct\"\n\n[[route.rule_set]]\ntype = \"remote\"\ntag = \"x\"\nformat = \"binary\"\n\
             url = \"https://e.test/x.srs\"\ndownload_detour = \"sunny\"\n",
            "outbounds = [{ type = \"sunny\", tag = \"home\" }]\n\n[route]\nfinal = \"home\"\n",
        ] {
            let users = users_of(cfg(config));
            assert!(users.is_empty(), "{config}: {users:?}");
            assert!(!decide(WarpTunnel::Auto, Some(&users)).unwrap(), "{config}");
            assert!(!decide(WarpTunnel::Off, Some(&users)).unwrap(), "{config}: off must be fine");
        }
    }

    /// With `detour = "warp"` the --sunny client rides inside WARP MASQUE: then `sunny` needs
    /// WARP, and the log says why.
    #[test]
    fn sunny_with_detour_warp_needs_warp_and_the_log_says_why() {
        let users = users_with(
            cfg(r#"
            [route]
            rules = [{ domain_suffix = ["x.test"], outbound = "sunny" }]
            final = "direct"
        "#),
            Caps::SUNNY_OVER_WARP,
        );
        assert_eq!(users.len(), 1, "{users:?}");
        assert!(users[0].starts_with("rule 0 routes to sunny"), "{users:?}");
        assert!(users[0].contains("detour: warp") && users[0].contains("rides inside WARP MASQUE"), "{users:?}");
        let fin = users_with(cfg("[route]\nfinal = \"sunny\"\n"), Caps::SUNNY_OVER_WARP);
        assert_eq!(fin.len(), 1, "{fin:?}");
        assert!(fin[0].starts_with("final is sunny (the sunny sunnyquic client has detour"), "{fin:?}");
        let e = decide(WarpTunnel::Off, Some(&users)).unwrap_err().to_string();
        assert!(e.contains("routes to sunny"), "{e}");
    }

    /// The user's route: sunny for some sites, warp-local for others, final warp. With the
    /// --sunny client direct, WARP starts only for warp-local and final; sunny is not listed.
    #[test]
    fn a_route_of_sunny_warp_local_and_final_warp_needs_warp_only_for_the_warp_ones() {
        let route = r#"
            [route]
            final = "warp"

            [[route.rules]]
            action = "sniff"

            [[route.rules]]
            domain_suffix = ["hark.com"]
            outbound = "sunny"

            [[route.rules]]
            domain_suffix = ["example.cn"]
            outbound = "warp-local"
        "#;
        let direct = users_of(cfg(route));
        assert_eq!(direct, vec!["rule 2 routes to warp-local".to_string(), "final is warp".to_string()]);
        let over_warp = users_with(cfg(route), Caps::SUNNY_OVER_WARP);
        assert_eq!(over_warp.len(), 3, "{over_warp:?}");
        assert!(over_warp[0].starts_with("rule 1 routes to sunny"), "{over_warp:?}");
    }

    /// The start-up line says whether sunny goes direct (needing no WARP) or rides WARP.
    #[test]
    fn the_plan_says_how_sunny_goes() {
        let none = Plan { setting: WarpTunnel::Auto, users: Some(Vec::new()), start: false, sunny: Some(Detour::Direct) };
        let d = none.describe();
        assert!(d.starts_with("the WARP tunnel is not started"), "{d}");
        assert!(d.contains("no scan, no registration"), "{d}");
        assert!(d.contains("sunny (and proxy) is the sunny sunnyquic client, which goes direct") && d.contains("needs no WARP"), "{d}");
        let some = Plan {
            setting: WarpTunnel::Auto,
            users: Some(vec!["rule 2 routes to warp-local".into(), "final is warp".into()]),
            start: true,
            sunny: Some(Detour::Direct),
        };
        let d = some.describe();
        assert!(d.starts_with("these need the WARP tunnel: rule 2 routes to warp-local; final is warp; starting it"), "{d}");
        assert!(d.contains("goes direct from this machine and needs no WARP"), "{d}");
        let warp = Plan {
            setting: WarpTunnel::Auto,
            users: Some(vec!["rule 1 routes to sunny (the sunny sunnyquic client has detour: warp: it rides inside WARP MASQUE)".into()]),
            start: true,
            sunny: Some(Detour::Warp),
        };
        let d = warp.describe();
        assert!(d.contains("rides inside WARP MASQUE") && !d.contains("goes direct"), "{d}");
        let legacy = Plan { setting: WarpTunnel::Auto, users: None, start: true, sunny: Some(Detour::Warp) };
        assert!(legacy.describe().contains("proxy, the sunny client, which has detour: warp"), "{}", legacy.describe());
        let plain = Plan { setting: WarpTunnel::Auto, users: Some(Vec::new()), start: false, sunny: None };
        assert!(!plain.describe().contains("sunny"), "{}", plain.describe());
    }
}
