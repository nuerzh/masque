use super::prelude::*;

pub(crate) fn team_scope() -> Option<String> {
    zerotrust::TeamSettings::from_env().map(|settings| settings.team)
}

/// Where `base`'s file name starts, and where its extension's dot is when it has one.
fn split_file_name(base: &str) -> (usize, Option<usize>) {
    let dir_end = base.rfind(['/', '\\']).map_or(0, |i| i + 1);
    (dir_end, base[dir_end..].rfind('.').map(|rel| dir_end + rel))
}

pub(crate) fn enrolled_teams(base: &str) -> Vec<String> {
    let (dir_end, dot) = split_file_name(base);
    let dir = if dir_end == 0 { "." } else { &base[..dir_end] };
    let stem = &base[dir_end..dot.unwrap_or(base.len())];
    let prefix = format!("{stem}-team-");

    let entries = match std::fs::read_dir(dir) {
        Ok(entries) => entries,
        Err(_) => return Vec::new(),
    };

    let mut teams: Vec<String> = Vec::new();
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        let Some(rest) = name.strip_prefix(&prefix) else {
            continue;
        };
        let Some(team) = rest.strip_suffix(".yaml").or_else(|| rest.strip_suffix(".yml")) else {
            continue;
        };
        // the lastconn files of a team (`-team-<team>-lastconn-h3.yaml`) are no team of their own
        if team.is_empty() || team.ends_with("-secondary") || team.ends_with("-lastconn") || team.contains("-lastconn-") {
            continue;
        }
        if !teams.iter().any(|known| known == team) {
            teams.push(team.to_string());
        }
    }
    teams.sort();
    teams
}

pub(crate) async fn enrol_zero_trust(base: &str) {
    let known = enrolled_teams(base);

    let prompt = match known.first() {
        Some(team) => format!(
            "\nZero Trust organization.\n  already enrolled: {}\nTeam name from \
             <team>.cloudflareaccess.com, or blank to reuse '{}': ",
            known.join(", "),
            team
        ),
        None => "\nZero Trust organization.\nTeam name from <team>.cloudflareaccess.com \
                 (blank to cancel): "
            .to_string(),
    };

    let answer = prompt_line(&prompt).await.unwrap_or_default();
    let answer = answer.trim().to_string();

    let team = if answer.is_empty() {
        match known.first() {
            Some(team) => team.clone(),
            None => {
                log::info!("[identity] Zero Trust skipped; staying on personal WARP");
                return;
            }
        }
    } else {
        match zerotrust::normalize_team(&answer) {
            Some(team) => team,
            None => {
                log::warn!("[identity] '{answer}' is not a usable team name");
                return;
            }
        }
    };

    crate::config::settings::decide("AETHER_TEAM", &team);

    if known.contains(&team) {
        log::info!("[identity] reusing the saved enrolment for team {team}; no sign-in needed");
        return;
    }

    let needs_method = match zerotrust::TeamSettings::from_env() {
        Some(settings) => {
            !(settings.token.is_some() || settings.has_service_token() || settings.email.is_some())
        }
        None => {
            crate::config::settings::forget("AETHER_TEAM");
            return;
        }
    };

    if needs_method {
        let email = prompt_line("Email address for the one-time login code (blank to cancel): ")
            .await
            .unwrap_or_default();
        let email = email.trim().to_string();

        if email.is_empty() {
            log::warn!("[identity] no email given; staying on personal WARP");
            crate::config::settings::forget("AETHER_TEAM");
            return;
        }

        crate::config::settings::decide("AETHER_ACCESS_EMAIL", &email);
    }

    let settings = match zerotrust::TeamSettings::from_env() {
        Some(settings) => settings,
        None => {
            crate::config::settings::forget("AETHER_TEAM");
            return;
        }
    };

    match zerotrust::resolve_token(&settings).await {
        Ok(_) => log::info!("[identity] signed in to team {team}; now pick the transport to use"),
        Err(error) => {
            log::error!("[identity] Zero Trust sign-in failed: {error}");
            log::warn!("[identity] staying on personal WARP");
            crate::config::settings::forget("AETHER_TEAM");
            crate::config::settings::forget("AETHER_ACCESS_EMAIL");
        }
    }
}

pub(crate) async fn provision_account() -> Result<account::Identity> {
    match zerotrust::TeamSettings::from_env() {
        Some(settings) => {
            log::info!(
                "[identity] enrolling this device into the Zero Trust organization {} ({})",
                settings.team,
                settings.team_domain()
            );
            let identity =
                account::provision_team(consts::DEFAULT_MODEL, consts::DEFAULT_LOCALE, &settings)
                    .await?;
            Ok(account::refresh_profile(identity).await)
        }
        None => account::provision_wg(consts::DEFAULT_MODEL, consts::DEFAULT_LOCALE, None).await,
    }
}

pub(crate) async fn adopt_team_profile(identity: account::Identity) -> account::Identity {
    if team_scope().is_none() {
        return identity;
    }

    let identity = account::refresh_profile(identity).await;

    if !identity.gateway_proxy.is_empty() {
        if crate::config::settings::var("AETHER_GATEWAY").is_ok() {
            socks::set_gateway_proxy(&identity.gateway_proxy);
        } else {
            log::debug!(
                "[zerotrust] the organization offers a gateway proxy at {}; set zero-trust.gateway: true to route http through it",
                identity.gateway_proxy
            );
        }
    }

    if !identity.assigned_endpoint.is_empty() && crate::config::settings::var("AETHER_PEER").is_err() {
        let peer = format!("{}:443", identity.assigned_endpoint);
        if peer.parse::<SocketAddr>().is_ok() {
            log::info!("[identity] the organization assigned endpoint {peer}; trying it before scanning");
            crate::config::settings::decide("AETHER_TEAM_ENDPOINT", &peer);
        }
    }

    identity
}

pub(crate) fn masque_config_path(base: &str) -> String {
    if let Ok(p) = crate::config::settings::var("AETHER_MASQUE_CONFIG") {
        return p;
    }
    match team_scope() {
        Some(team) => derive_sibling_path(base, &format!("team-{team}")),
        None => consumer_identity_path(base),
    }
}

/// Where the consumer MASQUE identity lives: in the config file itself, unless an earlier
/// build already keeps it in `<config>-masque.yaml` (converted from `-masque.toml`), which is
/// then used as before.
pub(crate) fn consumer_identity_path(base: &str) -> String {
    let legacy = derive_sibling_path(base, "masque");
    if std::path::Path::new(&legacy).exists() {
        legacy
    } else {
        base.to_string()
    }
}

pub(crate) fn derive_sibling_path(base: &str, suffix: &str) -> String {
    match split_file_name(base).1 {
        Some(dot) => format!("{}-{}{}", &base[..dot], suffix, &base[dot..]),
        None => format!("{base}-{suffix}"),
    }
}

pub(crate) fn keep_saved_identity() -> bool {
    !matches!(
        crate::config::settings::var("AETHER_REPROVISION").as_deref(),
        Ok("0") | Ok("off") | Ok("false")
    )
}

/// Enables WARP on a device just registered, as the WARP toggle of the app does. A new identity is
/// saved only once this is done, and an identity file already there is never asked about again;
/// a failure here fails the registration, and nothing is saved.
pub(crate) async fn enable_warp_on(identity: &account::Identity) -> Result<()> {
    account::enable_warp(&identity.device_id, &identity.access_token).await?;
    log::info!("[identity] warp enabled for device {}", identity.device_id);
    Ok(())
}

/// The MASQUE identity saved at `config_path`, used as it is, or a new one registered now and given
/// its MASQUE key, saved once WARP is enabled on it, see [`enable_warp_on`].
pub(crate) async fn load_or_provision_masque(config_path: &str) -> Result<account::Identity> {
    if let Some(identity) = config::load(config_path)? {
        log::info!("[identity] loaded existing masque identity from {config_path}");
        let refused = if identity.has_masque_credentials() {
            let identity = adopt_team_profile(identity).await;
            if !identity.refused {
                config::save(config_path, &identity)?;
                return Ok(identity);
            }
            identity
        } else {
            log::info!("[identity] masque identity needs a certificate; enrolling masque key");
            match account::ensure_masque_enrolled(&identity).await {
                Ok(enrollment) => {
                    let identity = account::Identity {
                        cert_pem: enrollment.cert_pem,
                        key_pem: enrollment.key_pem,
                        cert_issued_at: enrollment.issued_at,
                        ..identity
                    };
                    config::save(config_path, &identity)?;
                    return Ok(identity);
                }
                Err(AetherError::IdentityRefused(reason)) => {
                    log::warn!("[identity] the saved masque identity was refused: {reason}");
                    account::Identity {
                        refused: true,
                        ..identity
                    }
                }
                Err(error) => return Err(error),
            }
        };

        if !keep_saved_identity() {
            return Ok(refused);
        }
        log::warn!("[identity] registering a fresh masque account to replace the refused identity");
    }

    log::info!("[identity] no masque identity found; provisioning dedicated masque account");
    let identity = provision_account().await?;
    let enrollment = account::ensure_masque_enrolled(&identity).await?;
    let identity = account::Identity {
        cert_pem: enrollment.cert_pem,
        key_pem: enrollment.key_pem,
        cert_issued_at: enrollment.issued_at,
        ..identity
    };
    let identity = adopt_team_profile(identity).await;
    enable_warp_on(&identity).await?;
    config::save(config_path, &identity)?;
    log::info!("[identity] provisioned and saved new masque identity to {config_path}");
    Ok(identity)
}

/// `--register`: makes sure the MASQUE identity exists, registering it when missing, and
/// returns without scanning or opening a tunnel. An identity file already there is kept, never
/// replaced.
pub(crate) fn register_request() -> Result<bool> {
    match env_value("AETHER_REGISTER") {
        None => Ok(false),
        Some(value) => match value.trim().to_lowercase().as_str() {
            "masque" | "all" | "1" | "yes" => Ok(true),
            other => Err(AetherError::Other(format!(
                "register takes masque (the only WARP identity left), not '{other}'"
            ))),
        },
    }
}

pub(crate) async fn register_identity(base_config: &str) -> Result<()> {
    let path = masque_config_path(base_config);
    let identity = load_or_provision_masque(&path).await?;
    log::info!(
        "[identity] masque identity ready in {path}: device={} ipv4={} ipv6={}",
        identity.device_id,
        identity.ipv4,
        identity.ipv6
    );
    Ok(())
}

/// What the core says about --ech as the MASQUE session starts, `given` or not.
pub(crate) fn ech_scope_note(given: bool) -> &'static str {
    if given {
        "[tls] tls.ech applies to the WARP API calls only; the MASQUE handshakes go without ECH (the WARP gateways turn it down)"
    } else {
        "[tls] the MASQUE handshakes go without ECH (the WARP gateways turn it down); their server name goes out in the clear"
    }
}

/// Logs `ech_scope_note` by --ech (AETHER_ECH).
pub(crate) fn log_ech_scope() {
    let given = crate::config::settings::var(tls::API_ECH_OPTION.variable)
        .is_ok_and(|value| !value.is_empty());
    log::info!("{}", ech_scope_note(given));
}

pub(crate) fn lastconn_path(config_path: &str) -> String {
    derive_sibling_path(config_path, "lastconn")
}
