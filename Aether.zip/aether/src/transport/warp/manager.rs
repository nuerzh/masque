use super::prelude::*;
use super::*;

/// The WARP tunnel manager: picks MASQUE plain or with --sunny inside it (--sunny with
/// [sunny] `detour = "warp"`; asking on a terminal when nothing chose), provisions the identity and keeps the tunnel up, reconnecting for as
/// long as the run lasts. Each tunnel that comes up publishes its userspace stack
/// (`router::exits::publish_stack`), which the `warp` outbounds use.
pub(crate) async fn run(config: &crate::config::Config) -> Result<()> {
    crate::proxy::router::exits::set_warp_expected(true);
    log_ech_scope();
    let base_config = config.base_config.clone();

    let protocol = match crate::config::settings::var("AETHER_PROTOCOL") {
        Ok(v) => Protocol::parse(&v)?,
        Err(_) if crate::proxy::router::sunny_mode() => Protocol::Sunny,
        Err(_) if crate::config::settings::var("AETHER_PEER").is_ok() => Protocol::Masque,
        Err(_) => select_protocol(&base_config).await,
    };
    // --sunny going direct (its default detour): its client is already made on a local
    // socket, so this tunnel is plain MASQUE, for warp / warp-local and whatever else needs it.
    let protocol = match protocol {
        Protocol::Sunny if crate::proxy::router::sunny_mode() && !crate::proxy::router::exits::sunny_over_warp() => {
            log::info!(
                "[warp] sunny goes direct (detour = \"direct\"): this WARP tunnel is plain MASQUE and carries only \
                 what needs WARP (warp, warp-local, ...), not sunny"
            );
            Protocol::Masque
        }
        p => p,
    };

    let config_path = masque_config_path(&base_config);
    let lastconn_base = lastconn_path(&config_path);
    lastconn::split_shared(&lastconn_base);
    select_masque_transport();
    let service = match protocol {
        Protocol::Masque => None,
        Protocol::Sunny => {
            // Asked for before the scan, so a missing server or password stops the run here
            // rather than after a gateway has been found.
            let settings = sunnyquic::Settings::resolve().await?;
            warn_ignored_on_sunny();
            Some(std::sync::Arc::new(sunnyquic::Client::new("sunny", settings, sunnyquic::Detour::Warp)?))
        }
    };
    let identity = load_or_provision_masque(&config_path).await?;
    match &service {
        None => log::info!(
            "[warp] identity ready: device={} ipv4={} ipv6={}",
            identity.device_id,
            identity.ipv4,
            identity.ipv6
        ),
        Some(_) => log::info!(
            "[warp] sunny: masque device={} carries sunnyquic to your own server",
            identity.device_id
        ),
    }
    // each carrier remembers its gateways in a file of its own
    let lastconn_path = lastconn::carrier_path(&lastconn_base, masque_carrier());
    let inner = match service {
        None => MasqueInner::Plain,
        Some(service) => MasqueInner::Sunny(service),
    };
    run_masque(identity, lastconn_path, inner).await
}
