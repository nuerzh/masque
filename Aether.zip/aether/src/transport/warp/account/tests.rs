use super::*;

#[test]
fn a_long_rejection_in_any_script_is_cut_without_panicking() {
    let body = format!("{}{}", "x".repeat(219), "é".repeat(200));
    let described = describe_rejection(reqwest::StatusCode::BAD_REQUEST, &body);
    assert!(described.contains('…'));
}

#[test]
fn the_certificate_lives_far_longer_than_a_day() {
    const { assert!(MASQUE_CERT_LIFETIME_DAYS >= 365) };
    const { assert!(MASQUE_CERT_LIFETIME_SECS > 86_400 * 300) };
}

#[test]
fn a_missing_issue_time_counts_as_expiring() {
    assert!(masque_cert_expiring(0));
}

#[test]
fn a_fresh_certificate_is_not_expiring() {
    assert!(!masque_cert_expiring(now_unix()));
}

#[test]
fn a_certificate_older_than_a_day_is_still_valid() {
    assert!(!masque_cert_expiring(now_unix() - 86_400 * 2));
}

#[test]
fn a_certificate_inside_the_renewal_window_is_expiring() {
    let issued = now_unix() - (MASQUE_CERT_LIFETIME_SECS - MASQUE_CERT_RENEW_BEFORE_SECS / 2);
    assert!(masque_cert_expiring(issued));
}

#[test]
fn a_certificate_issued_in_the_future_counts_as_expiring() {
    assert!(masque_cert_expiring(now_unix() + 86_400));
}

fn sample_identity(cert_issued_at: u64, with_cert: bool) -> Identity {
    Identity {
        device_id: "device".to_string(),
        access_token: "token".to_string(),
        cert_pem: if with_cert {
            b"cert".to_vec()
        } else {
            Vec::new()
        },
        key_pem: if with_cert {
            b"key".to_vec()
        } else {
            Vec::new()
        },
        cert_issued_at,
        ipv4: "172.16.0.2".to_string(),
        ipv6: String::new(),
        wg_private_key: [0u8; 32],
        wg_peer_public_key: [0u8; 32],
        client_id: [0u8; 3],
        organization: String::new(),
        gateway_proxy: String::new(),
        assigned_endpoint: String::new(),
        refused: false,
    }
}

#[test]
fn a_certificate_inside_its_lifetime_is_still_usable_offline() {
    let identity = sample_identity(now_unix() - 86_400 * 360, true);
    assert!(cert_still_usable(&identity));
}

#[test]
fn a_certificate_past_its_lifetime_is_not_usable() {
    let identity = sample_identity(now_unix() - MASQUE_CERT_LIFETIME_SECS - 10, true);
    assert!(!cert_still_usable(&identity));
}

#[test]
fn a_missing_certificate_is_never_usable() {
    let identity = sample_identity(now_unix(), false);
    assert!(!cert_still_usable(&identity));
}

#[test]
fn a_rate_limited_rejection_explains_the_wait() {
    let message = describe_rejection(
        reqwest::StatusCode::TOO_MANY_REQUESTS,
        "{\"success\":false,\"errors\":[{\"code\":1015,\"message\":\"rate limited\"}]}",
    );
    assert!(message.contains("rate limited"));
    assert!(message.contains("code 1015"));
    assert!(message.contains("wait a few minutes"));
}

#[test]
fn a_forbidden_rejection_mentions_the_flagged_address() {
    let message = describe_rejection(reqwest::StatusCode::FORBIDDEN, "");
    assert!(message.contains("flagged"));
}

#[test]
fn only_transient_statuses_are_retried() {
    assert!(worth_retrying(reqwest::StatusCode::TOO_MANY_REQUESTS));
    assert!(worth_retrying(reqwest::StatusCode::BAD_GATEWAY));
    assert!(!worth_retrying(reqwest::StatusCode::FORBIDDEN));
    assert!(!worth_retrying(reqwest::StatusCode::BAD_REQUEST));
}

#[test]
fn the_backoff_grows_and_stays_bounded() {
    let first = backoff_delay(0);
    let late = backoff_delay(6);
    assert!(first >= std::time::Duration::from_millis(API_BACKOFF_BASE_MS / 2));
    assert!(late <= std::time::Duration::from_millis(API_BACKOFF_CAP_MS * 2));
    assert!(late >= first);
}

#[test]
fn the_calls_to_the_api_are_fragmented_as_masque_over_http2_is() {
    // --fragment, --fragment-size and --fragment-delay. No other test sets them; the HTTP/2
    // dial reads them as well, and its ClientHello in pieces changes nothing a test checks.
    const SETTINGS: [&str; 3] = [
        "AETHER_MASQUE_H2_FRAGMENT",
        "AETHER_MASQUE_H2_FRAGMENT_SIZE",
        "AETHER_MASQUE_H2_FRAGMENT_DELAY",
    ];
    let before: Vec<Option<String>> =
        SETTINGS.iter().map(|key| crate::config::settings::var(key).ok()).collect();
    crate::config::settings::decide(SETTINGS[0], "1");
    crate::config::settings::decide(SETTINGS[1], "4-6");
    crate::config::settings::decide(SETTINGS[2], "1-3");
    let on = api_fragment();
    // Off when the setting says so, and without --fragment.
    crate::config::settings::decide(SETTINGS[0], "0");
    let off = api_fragment();
    crate::config::settings::forget(SETTINGS[0]);
    let unset = api_fragment();
    for (key, value) in SETTINGS.iter().zip(before) {
        match value {
            Some(value) => crate::config::settings::decide(key, value),
            None => crate::config::settings::forget(key),
        }
    }

    assert!(on.enabled);
    assert_eq!(
        (on.size_min, on.size_max, on.delay_min_ms, on.delay_max_ms),
        (4, 6, 1, 3)
    );
    assert!(!off.enabled);
    assert!(!unset.enabled);
}

#[test]
fn a_retry_after_is_waited_out_only_when_another_attempt_follows() {
    let asked = Some(std::time::Duration::from_secs(30));
    assert_eq!(retry_after_wait(0, asked), asked);
    assert_eq!(retry_after_wait(API_ATTEMPTS - 2, asked), asked);
    assert_eq!(retry_after_wait(API_ATTEMPTS - 1, asked), None);
    assert_eq!(retry_after_wait(0, None), None);
}

#[test]
fn a_retry_after_header_is_honoured_but_capped() {
    let mut headers = reqwest::header::HeaderMap::new();
    headers.insert(
        reqwest::header::RETRY_AFTER,
        reqwest::header::HeaderValue::from_static("120"),
    );
    assert_eq!(
        retry_after(&headers),
        Some(std::time::Duration::from_secs(API_RETRY_AFTER_CAP_SECS))
    );
}

#[test]
fn a_missing_retry_after_header_is_ignored() {
    let headers = reqwest::header::HeaderMap::new();
    assert!(retry_after(&headers).is_none());
}

#[test]
fn an_api_address_is_an_ip_address_or_a_domain_name_with_or_without_a_port() {
    let address = |value: Option<&str>| {
        match value {
            Some(value) => crate::config::settings::decide("AETHER_API_ADDRESS", value),
            None => crate::config::settings::forget("AETHER_API_ADDRESS"),
        }
        api_address().map_err(|e| e.to_string())
    };
    let at = |host: &str, port: u16| -> std::result::Result<(String, u16), String> {
        Ok((host.to_string(), port))
    };
    assert_eq!(address(None), at("api.cloudflareclient.com", 443));
    assert_eq!(address(Some("  ")), at("api.cloudflareclient.com", 443));
    assert_eq!(address(Some(" 188.114.97.6 ")), at("188.114.97.6", 443));
    assert_eq!(address(Some("188.114.97.6:443")), at("188.114.97.6", 443));
    assert_eq!(address(Some("188.114.97.6:2053")), at("188.114.97.6", 2053));
    assert_eq!(
        address(Some("[2606:4700::6810:1]")),
        at("2606:4700::6810:1", 443)
    );
    assert_eq!(
        address(Some("2606:4700::6810:1")),
        at("2606:4700::6810:1", 443)
    );
    assert_eq!(
        address(Some("[2606:4700::6810:1]:8443")),
        at("2606:4700::6810:1", 8443)
    );
    assert_eq!(
        address(Some("edge.example.com")),
        at("edge.example.com", 443)
    );
    assert_eq!(
        address(Some("edge.example.com:8443")),
        at("edge.example.com", 8443)
    );
    for refused in [
        "188.114.97.6:0",
        "188.114.97.6:65536",
        "edge.example.com:https",
        "https://edge.example.com",
        "edge example.com",
    ] {
        let said = address(Some(refused)).expect_err(refused);
        assert_eq!(
            said,
            format!(
                "api: api-address: {refused} is no IP address or domain name, with or without a port"
            )
        );
        assert!(check_api_address().is_err());
    }
    crate::config::settings::forget("AETHER_API_ADDRESS");
    assert!(check_api_address().is_ok());
}

#[tokio::test]
async fn the_api_takes_the_ech_key_and_a_run_starts_without_the_one_before() {
    // No other test calls the WARP API, so none sees the key change here; the hold clears
    // AETHER_ECH before and after.
    let _options = crate::transport::warp::net::tls::hold_options().await;
    remember_api_ech(vec![1, 2, 3]);
    assert_eq!(api_ech_in_use(), Some(vec![1, 2, 3]));
    forget_api_ech();
    assert_eq!(api_ech_in_use(), None);

    // --ech is the API's: without it no key, with it the key it gives.
    assert_eq!(api_ech().await.ok(), Some(None));
    let given = "AEX+DQBBrwAgACCbK1mYDYFz/BAn6S5t+Q/v+Oej3eFNxtPWgz50fNnFPAAEAAEAAQASY2xvdWRmbGFyZS1lY2guY29tAAA=";
    crate::config::settings::decide("AETHER_ECH", given);
    let key = crate::transport::warp::net::tls::decode_ech_config_list(given).expect("base64");
    assert_eq!(api_ech().await.ok(), Some(Some(key)));
    forget_api_ech();
}

#[tokio::test]
#[ignore = "registers a real warp device"]
async fn the_api_registers_a_real_device() {
    let (_, public) = generate_x25519_keypair();
    let body = Registration {
        key: public,
        install_id: String::new(),
        fcm_token: String::new(),
        tos: tos_timestamp(),
        model: "PC".to_string(),
        serial_number: random_android_serial(),
        os_version: String::new(),
        key_type: "curve25519".to_string(),
        tunnel_type: "wireguard".to_string(),
        locale: "en_US".to_string(),
    };

    let encoded = serde_json::to_vec(&body).expect("encode");
    let path = format!("/{}/reg", consts::API_VERSION);

    let account = api_call("registration", "POST", &path, Some(&encoded), None, None)
        .await
        .expect("the API should register a device");

    println!(
        "device={} ipv4={}",
        account.id, account.config.interface.addresses.v4
    );
    assert!(!account.id.is_empty());
    assert!(!account.token.is_empty());
    assert!(!account.config.peers.is_empty());
}

#[test]
fn a_generated_certificate_is_not_immediately_stale() {
    let pair = generate_masque_keypair().expect("keypair should be generated");
    assert!(!pair.cert_pem.is_empty());
    assert!(!pair.key_pem.is_empty());
    assert!(!masque_cert_expiring(now_unix()));
}
