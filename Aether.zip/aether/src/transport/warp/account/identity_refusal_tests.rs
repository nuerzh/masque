use super::*;
use reqwest::StatusCode;

#[test]
fn the_codes_that_mean_the_identity_is_gone() {
    for status in [
        StatusCode::UNAUTHORIZED,
        StatusCode::NOT_FOUND,
        StatusCode::GONE,
    ] {
        assert!(refuses_identity(status), "{status} means a dead identity");
    }
}

#[test]
fn a_flagged_network_is_not_mistaken_for_a_dead_identity() {
    assert!(
        !refuses_identity(StatusCode::FORBIDDEN),
        "403 is cloudflare refusing the address, the identity may be fine"
    );
    assert!(
        !refuses_identity(StatusCode::TOO_MANY_REQUESTS),
        "429 is rate limiting, not a dead identity"
    );
}

#[test]
fn a_server_or_transport_problem_is_not_a_dead_identity() {
    for status in [
        StatusCode::INTERNAL_SERVER_ERROR,
        StatusCode::BAD_GATEWAY,
        StatusCode::SERVICE_UNAVAILABLE,
        StatusCode::GATEWAY_TIMEOUT,
        StatusCode::REQUEST_TIMEOUT,
    ] {
        assert!(
            !refuses_identity(status),
            "{status} should be retried, not treated as a dead identity"
        );
    }
}

#[test]
fn anything_worth_retrying_is_never_called_a_dead_identity() {
    for code in 400..600u16 {
        let status = StatusCode::from_u16(code).unwrap();
        assert!(
            !(worth_retrying(status) && refuses_identity(status)),
            "{status} cannot be both retryable and a dead identity"
        );
    }
}
