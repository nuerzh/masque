use super::prelude::*;

pub(crate) fn parse_local_v4(s: &str) -> Ipv4Addr {
    s.split('/')
        .next()
        .unwrap_or(s)
        .parse()
        .unwrap_or(Ipv4Addr::UNSPECIFIED)
}

pub(crate) const TUNNEL_MTU: usize = 1280;

pub(crate) const H2_TUNNEL_MTU: usize = 1500;

pub(crate) fn masque_tunnel_mtu() -> usize {
    if let Some(mtu) = crate::config::settings::var("AETHER_MASQUE_MTU")
        .ok()
        .and_then(|value| value.trim().parse::<usize>().ok())
        .filter(|mtu| (576..=1500).contains(mtu))
    {
        return mtu;
    }

    if masque_h2::enabled() {
        H2_TUNNEL_MTU
    } else {
        TUNNEL_MTU
    }
}

pub(crate) fn noize_config() -> noize::NoizeConfig {
    let profile = crate::config::settings::var("AETHER_NOIZE").unwrap_or_else(|_| "firewall".to_string());
    log::info!("[warp] obfuscation profile: {profile}");
    noize::from_profile(&profile)
}

/// How long a tunnel has to stay up for its end not to count against the MASQUE gateway it went
/// through: one that carried the traffic this long proves it good, so its end, a network change
/// say, clears the ends counted before it. Only tunnels that end sooner, one after another, make
/// a run leave a gateway.
pub(crate) const TUNNEL_STAYED_UP: std::time::Duration = std::time::Duration::from_secs(300);

/// The ends in a row of the tunnels through one gateway, `in_a_row` before, after one
/// more that `lasted` this long: one more, or none once that tunnel stayed up [`TUNNEL_STAYED_UP`].
pub(crate) fn count_tunnel_end(in_a_row: u32, lasted: std::time::Duration) -> u32 {
    if lasted >= TUNNEL_STAYED_UP {
        0
    } else {
        in_a_row.saturating_add(1)
    }
}

pub(crate) async fn exit_policy_guard(
    stack: &netstack::StackHandle,
    policy: &Option<exitloc::Policy>,
) -> AetherError {
    match policy {
        Some(policy) => exitloc::watch(stack, policy).await,
        None => std::future::pending().await,
    }
}

pub(crate) type TunnelExit = tokio::task::JoinHandle<Result<()>>;

pub(crate) struct TaskGuard(pub(crate) Vec<tokio::task::AbortHandle>);

impl TaskGuard {
    pub(crate) fn new() -> Self {
        Self(Vec::new())
    }

    pub(crate) fn push(&mut self, handle: tokio::task::AbortHandle) {
        self.0.push(handle);
    }
}

impl Drop for TaskGuard {
    fn drop(&mut self) {
        for handle in self.0.drain(..) {
            handle.abort();
        }
    }
}

pub(crate) fn join_outcome(
    what: &str,
    result: std::result::Result<Result<()>, tokio::task::JoinError>,
) -> Result<()> {
    match result {
        Ok(Ok(())) => Err(AetherError::Other(format!("{what} stopped"))),
        Ok(Err(e)) => Err(e),
        Err(e) if e.is_cancelled() => Err(AetherError::Other(format!("{what} was cancelled"))),
        Err(e) => Err(AetherError::Other(format!("{what} panicked: {e}"))),
    }
}
