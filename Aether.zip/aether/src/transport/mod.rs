//! What carries traffic underneath the outbounds: the WARP tunnel (MASQUE over HTTP/3 and
//! HTTP/2), with its userspace stack, its registration and its scans. The sunnyquic client is
//! an outbound of its own (`proxy::outbound::sunnyquic`).

pub mod warp;
