//! What the unit tests share: scratch paths, loopback servers, certificates.

#[cfg(feature = "sunny")]
use std::net::SocketAddr;
use std::path::PathBuf;

#[cfg(feature = "sunny")]
use tokio::net::UdpSocket;
use tokio::net::{TcpListener, TcpStream};

/// `<temp>/aether-<tag>-<pid>`, not created; a file name when `tag` ends in an extension.
pub(crate) fn scratch(tag: &str) -> PathBuf {
    let pid = std::process::id();
    match tag.rsplit_once('.') {
        Some((stem, ext)) if !stem.is_empty() => std::env::temp_dir().join(format!("aether-{stem}-{pid}.{ext}")),
        _ => std::env::temp_dir().join(format!("aether-{tag}-{pid}")),
    }
}

/// `scratch(tag)`, created as a directory.
pub(crate) fn scratch_dir(tag: &str) -> PathBuf {
    let dir = scratch(tag);
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

/// `scratch(name)` holding `contents`: a config file a test reads.
pub(crate) fn scratch_file(name: &str, contents: &str) -> PathBuf {
    let path = scratch(name);
    std::fs::write(&path, contents).unwrap();
    path
}

/// Two ends of one loopback tcp connection: (dialed, accepted).
pub(crate) async fn tcp_pair() -> (TcpStream, TcpStream) {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let (dialed, accepted) = tokio::join!(TcpStream::connect(address), listener.accept());
    (dialed.unwrap(), accepted.unwrap().0)
}

/// A tcp echo server on loopback, serving until the test's runtime ends.
#[cfg(feature = "sunny")]
pub(crate) async fn tcp_echo() -> SocketAddr {
    serve_tcp_echo(TcpListener::bind("127.0.0.1:0").await.unwrap())
}

#[cfg(feature = "sunny")]
fn serve_tcp_echo(listener: TcpListener) -> SocketAddr {
    let address = listener.local_addr().unwrap();
    tokio::spawn(async move {
        while let Ok((mut s, _)) = listener.accept().await {
            tokio::spawn(async move {
                let (mut r, mut w) = s.split();
                let _ = tokio::io::copy(&mut r, &mut w).await;
            });
        }
    });
    address
}

/// A udp echo server on loopback.
#[cfg(feature = "sunny")]
pub(crate) async fn udp_echo() -> SocketAddr {
    serve_udp_echo(UdpSocket::bind("127.0.0.1:0").await.unwrap())
}

#[cfg(feature = "sunny")]
fn serve_udp_echo(socket: UdpSocket) -> SocketAddr {
    let address = socket.local_addr().unwrap();
    tokio::spawn(async move {
        let mut buf = vec![0u8; 65536];
        while let Ok((n, from)) = socket.recv_from(&mut buf).await {
            let _ = socket.send_to(&buf[..n], from).await;
        }
    });
    address
}

/// A port with a tcp and a udp echo server on it.
#[cfg(feature = "sunny")]
pub(crate) async fn echo_pair() -> u16 {
    loop {
        let tcp = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = tcp.local_addr().unwrap().port();
        let Ok(udp) = UdpSocket::bind(("127.0.0.1", port)).await else { continue };
        serve_tcp_echo(tcp);
        serve_udp_echo(udp);
        return port;
    }
}

/// A self-signed certificate for localhost in `dir`: (cert.pem, key.pem).
#[cfg(feature = "sunny")]
pub(crate) fn self_signed(dir: &std::path::Path) -> (PathBuf, PathBuf) {
    std::fs::create_dir_all(dir).unwrap();
    let made = rcgen::generate_simple_self_signed(vec!["localhost".to_string()]).unwrap();
    let (cert, key) = (dir.join("cert.pem"), dir.join("key.pem"));
    std::fs::write(&cert, made.cert.pem()).unwrap();
    std::fs::write(&key, made.signing_key.serialize_pem()).unwrap();
    (cert, key)
}

/// A CA and a localhost certificate it signed, as a user's own server would have, in `dir`:
/// (ca.pem, cert.pem, key.pem).
#[cfg(feature = "sunny")]
pub(crate) fn ca_signed(dir: &std::path::Path) -> (PathBuf, PathBuf, PathBuf) {
    std::fs::create_dir_all(dir).unwrap();
    let mut ca_params = rcgen::CertificateParams::new(Vec::<String>::new()).unwrap();
    ca_params.is_ca = rcgen::IsCa::Ca(rcgen::BasicConstraints::Unconstrained);
    ca_params.distinguished_name.push(rcgen::DnType::CommonName, "aether sunny test CA");
    let ca = rcgen::CertifiedIssuer::self_signed(ca_params, rcgen::KeyPair::generate().unwrap()).unwrap();
    let leaf_key = rcgen::KeyPair::generate().unwrap();
    let leaf = rcgen::CertificateParams::new(vec!["localhost".to_string()])
        .unwrap()
        .signed_by(&leaf_key, &ca)
        .unwrap();
    let (ca_path, cert_path, key_path) = (dir.join("ca.pem"), dir.join("cert.pem"), dir.join("key.pem"));
    std::fs::write(&ca_path, ca.pem()).unwrap();
    std::fs::write(&cert_path, leaf.pem()).unwrap();
    std::fs::write(&key_path, leaf_key.serialize_pem()).unwrap();
    (ca_path, cert_path, key_path)
}
