//! The run, in the order QuicProxy brings its core up: outbounds, dns, router, inbounds, then
//! the tunnels underneath; and the way back down (`shutdown_app`).

use crate::config::{cli, Config};
use crate::error::Result;
use crate::proxy::{inbound::tun, router};
use crate::transport::warp::{self, account};
use crate::transport::warp::{masque::quic, net::tls};
use crate::utils::{egress, logging, stats, sysprofile};

pub async fn run() -> Result<()> {
    run_with(std::env::args().skip(1).collect()).await
}

/// The core with these arguments: parse them, bring everything up, run until the tunnel ends
/// for good, then tear down what was set up.
pub async fn run_with(args: Vec<String>) -> Result<()> {
    // the command line names the config file and a command; every option is in that file
    let settings = match cli::parse_args(args)? {
        cli::Parsed::Done => return Ok(()),
        cli::Parsed::Run { config, action } => crate::config::load_settings(config.as_deref(), action)?,
    };
    let cleanup = settings.get("AETHER_TUN_CLEANUP") == Some("1");
    crate::config::settings::install(settings);
    if cleanup {
        let done = tun::cleanup_command();
        crate::config::settings::uninstall();
        return done;
    }
    // Dropped when the run returns or when the library's job drops this future: either way
    // the run's background tasks stop, --tun gives the system back and the run's settings go.
    let _scope = RunScope { _run: crate::utils::shutdown::begin() };
    let config = Config::from_env()?;
    init_app(&config).await?;
    // A registration serves no proxy, so it needs none of the inbounds.
    if warp::register_request()? {
        return warp::register_identity(&config.base_config).await;
    }
    let inbounds = init_inbounds(&config).await?;
    serve(&config, &inbounds.warp).await
}

struct RunScope {
    _run: crate::utils::shutdown::Run,
}

impl Drop for RunScope {
    fn drop(&mut self) {
        shutdown_app();
        crate::config::settings::uninstall();
    }
}

/// Everything up to the inbounds: logging, process limits, the option checks, outbounds, dns
/// and the router. An option or a config that does not parse stops the run here.
pub async fn init_app(config: &Config) -> Result<()> {
    logging::init();
    log::info!("[aether] Aether v{}", env!("CARGO_PKG_VERSION"));
    sysprofile::log_summary();
    sysprofile::raise_fd_limit();
    tun::prepare_env();
    egress::init()?;
    stats::init();
    stats::spawn_reporter();
    install_netstack_panic_guard();

    init_outbounds(config)?;
    init_dns(config)?;
    init_router(config)?;
    Ok(())
}

/// The outbounds' own options: a cipher string or a group list BoringSSL does not take, a
/// --masque-sni that is no domain name, or an address the calls to the WARP API cannot use,
/// stops the core here, with its option named.
pub fn init_outbounds(_config: &Config) -> Result<()> {
    tls::check_tls_options()?;
    quic::masque_sni()?;
    account::check_api_address()?;
    Ok(())
}

/// Resolver state that must not outlive a run: the key of the WARP API calls of an earlier
/// run of the library is not this run's.
pub fn init_dns(_config: &Config) -> Result<()> {
    account::forget_api_ech();
    Ok(())
}

/// A route config that does not parse stops the core here, before anything is routed by rules
/// other than the ones written.
pub fn init_router(_config: &Config) -> Result<()> {
    router::init()
}

/// The inbounds, up and serving, and what the run does about the WARP tunnel.
pub struct Inbounds {
    /// The mode's own listeners stay open while this is held.
    _listeners: crate::proxy::inbound::Listeners,
    pub warp: warp::demand::Plan,
}

/// The inbounds: the config's `inbounds` (a `tun` one turns the TUN on), the TUN's options and
/// the OS state it needs before the tunnel connects, then whether this run needs the WARP
/// tunnel, then the listeners and the TUN, serving at once. Nothing here waits for a prompt,
/// a scan or a tunnel: an outbound that needs no WARP works from the first connection, and one
/// that does waits for the tunnel `serve` brings up. A port in use, or --warp-tunnel off with
/// something that needs WARP, stops the run here.
pub async fn init_inbounds(config: &Config) -> Result<Inbounds> {
    crate::proxy::inbound::configure()?;
    // A `tun` inbound of the config turns the TUN on only here, after init_app chose the
    // socket mark without it.
    if crate::config::settings::var("AETHER_MARK").is_err() {
        tun::prepare_env();
        if crate::config::settings::var("AETHER_MARK").is_ok() {
            egress::init()?;
        }
    }
    tun::prepare()?;
    // Decided before anything serves: a connection to a WARP outbound must find out from its
    // first packet whether to wait for the tunnel or fail.
    let plan = warp::demand::plan()?;
    crate::proxy::router::exits::begin_run(
        plan.start,
        plan.sunny == Some(crate::proxy::outbound::sunnyquic::Detour::Warp),
    );
    log::info!("[aether] {}", plan.describe());
    tun::spawn();
    let listeners = crate::proxy::inbound::serve_listeners(config.listen, config.http_proxy).await?;
    crate::proxy::inbound::start().await?;
    log::info!("[aether] {}", inbounds_ready(config, plan.start));
    Ok(Inbounds { _listeners: listeners, warp: plan })
}

/// The start-up line saying the inbounds serve, before the WARP tunnel (if any) is up.
fn inbounds_ready(config: &Config, warp: bool) -> String {
    let mut list = vec![format!("socks5 {}", config.listen)];
    if let Some(h) = config.http_proxy {
        list.push(format!("http {h}"));
    }
    let configured = crate::proxy::inbound::config::count();
    if configured > 0 {
        list.push(format!("{configured} from inbounds"));
    }
    if tun::enabled() {
        list.push("tun".to_string());
    }
    let tail = if warp {
        "outbounds that need no WARP work now; the WARP tunnel comes up in the background"
    } else {
        "every outbound works now"
    };
    format!("inbounds ready: {}; {tail}", list.join(", "))
}

/// Carry the traffic: the WARP tunnel when the plan says so, until it ends for good; otherwise
/// the inbounds alone, until the process is stopped. --sunny going direct (its default) makes
/// its client first, WARP or not (a missing setting is asked for here, before the WARP
/// prompts); with detour warp the WARP manager makes it inside the tunnel, as before.
pub async fn serve(config: &Config, plan: &warp::demand::Plan) -> Result<()> {
    if plan.sunny == Some(crate::proxy::outbound::sunnyquic::Detour::Direct) {
        crate::proxy::outbound::sunnyquic::start_direct_sunny().await?;
    }
    if plan.start {
        return warp::run(config).await;
    }
    std::future::pending::<()>().await;
    Ok(())
}

/// --tun: whatever ended the run, give the system its routes and dns back.
pub fn shutdown_app() {
    tun::shutdown();
}

pub(crate) fn install_netstack_panic_guard() {
    // once per process: a library that starts the core again must not wrap the hook again
    static ONCE: std::sync::Once = std::sync::Once::new();
    ONCE.call_once(install_panic_hook);
}

fn install_panic_hook() {
    let default_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let from_netstack = info
            .location()
            .map(|l| l.file().contains("smoltcp"))
            .unwrap_or(false);
        if from_netstack {
            log::debug!("[netstack] recovered from a malformed segment: {info}");
        } else {
            default_hook(info);
        }
    }));
}

#[cfg(test)]
mod tests {
    use crate::utils::shutdown;

    async fn until(what: &str, check: impl Fn() -> bool) {
        for _ in 0..500 {
            if check() {
                return;
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        }
        panic!("timed out waiting until {what}");
    }

    /// The core started and stopped again and again, as a library's start and stop do (the
    /// job's future dropped), with a different route each time: every run brings up its own
    /// router and the watcher of its local rule set, and none of it outlives the run. Runs
    /// alone (the router, the settings and the run signal are the process's):
    /// `cargo test starting_and_stopping -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    #[ignore]
    async fn starting_and_stopping_the_core_again_and_again_leaves_no_tasks_behind() {
        let _turn = shutdown::tests::RUNS.lock().await;
        let dir = crate::test_util::scratch_dir("restart");
        std::fs::write(dir.join("set.json"), r#"{"version": 2, "rules": [{"domain_suffix": ["ads.example"]}]}"#).unwrap();
        let before = shutdown::live();
        for (round, last) in ["direct", "block", "direct", "block"].into_iter().enumerate() {
            let config = dir.join(format!("aether-{round}.yaml"));
            std::fs::write(
                &config,
                crate::config::yaml::yaml_of_toml(&format!(
                    "warp-tunnel = \"off\"\nbind = \"127.0.0.1:0\"\n\
                     [route]\nfinal = \"{last}\"\nrules = [{{ rule_set = \"ads\", action = \"reject\" }}]\n\n\
                     [[route.rule_set]]\ntag = \"ads\"\ntype = \"local\"\nformat = \"source\"\npath = \"set.json\"\n"
                )),
            )
            .unwrap();
            let args = ["-c", &config.to_string_lossy()].map(str::to_string).to_vec();
            let core = tokio::spawn(crate::run_with(args));
            until("the run watches its rule set", || shutdown::live() > before).await;
            let router = crate::proxy::router::router().expect("a router");
            assert_eq!(router.final_tag(), last, "round {round} routes by its own config");
            assert!(!core.is_finished(), "round {round}: the core stopped by itself");
            core.abort();
            let _ = core.await;
            until("the run's tasks are gone", || shutdown::live() == before).await;
            assert!(crate::config::settings::var("AETHER_WARP_TUNNEL").is_err(), "the run's settings went with it");
        }
        let _ = std::fs::remove_dir_all(dir);
    }

    // --- the inbounds and the WARP tunnel are independent -------------------------------------

    use std::net::SocketAddr;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    /// A tcp echo server on loopback.
    async fn echo_server() -> SocketAddr {
        let l = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = l.local_addr().unwrap();
        tokio::spawn(async move {
            while let Ok((mut s, _)) = l.accept().await {
                tokio::spawn(async move {
                    let mut buf = [0u8; 1024];
                    while let Ok(n) = s.read(&mut buf).await {
                        if n == 0 || s.write_all(&buf[..n]).await.is_err() {
                            break;
                        }
                    }
                });
            }
        });
        addr
    }

    fn free_port() -> u16 {
        std::net::TcpListener::bind("127.0.0.1:0").unwrap().local_addr().unwrap().port()
    }

    /// socks5 CONNECT to 127.0.0.1:`port` through `socks`, then one echo round trip.
    async fn socks_echo(socks: SocketAddr, port: u16) -> std::io::Result<()> {
        let mut s = tokio::net::TcpStream::connect(socks).await?;
        s.write_all(&[5, 1, 0]).await?;
        let mut g = [0u8; 2];
        s.read_exact(&mut g).await?;
        let mut req = vec![5, 1, 0, 1, 127, 0, 0, 1];
        req.extend_from_slice(&port.to_be_bytes());
        s.write_all(&req).await?;
        let mut rep = [0u8; 10];
        s.read_exact(&mut rep).await?;
        if rep[1] != 0 {
            return Err(std::io::Error::other(format!("socks5 reply {}", rep[1])));
        }
        s.write_all(b"ping").await?;
        let mut back = [0u8; 4];
        s.read_exact(&mut back).await?;
        assert_eq!(&back, b"ping");
        Ok(())
    }

    /// What the --sunny client would be once its WARP tunnel is up: here, plain tcp to loopback.
    struct LoopbackSunny;

    impl crate::proxy::router::exits::SunnyExit for LoopbackSunny {
        fn open_tcp<'a>(
            &'a self,
            host: &'a str,
            port: u16,
        ) -> crate::proxy::router::exits::BoxFuture<'a, std::io::Result<crate::proxy::outbound::BoxStream>> {
            Box::pin(async move {
                let s = tokio::net::TcpStream::connect((host, port)).await?;
                Ok(Box::new(s) as crate::proxy::outbound::BoxStream)
            })
        }
        fn open_udp(&self) -> crate::proxy::router::exits::BoxFuture<'_, std::io::Result<crate::proxy::outbound::SunnyUdp>> {
            Box::pin(async { Err(std::io::Error::other("no udp")) })
        }
    }

    /// The core up to and including its inbounds, as `run_with` brings it up, with `route` as
    /// the config; the WARP tunnel itself is never started here.
    async fn core_with_inbounds(route: &str, socks: SocketAddr, extra: &str) -> (super::Inbounds, std::path::PathBuf) {
        // the options (top-level keys, here in TOML) first, then the route's tables
        let text = crate::config::yaml::yaml_of_toml(&format!("bind = \"{socks}\"\n{extra}\n{route}"));
        let config = crate::test_util::scratch_file(&format!("indep-{}.yaml", socks.port()), &text);
        let settings = crate::config::load_settings(Some(&config.to_string_lossy()), crate::config::cli::Action::Run).unwrap();
        crate::config::settings::install(settings);
        let cfg = crate::config::Config::from_env().unwrap();
        super::init_app(&cfg).await.unwrap();
        let inbounds = tokio::time::timeout(std::time::Duration::from_secs(10), super::init_inbounds(&cfg))
            .await
            .expect("the inbounds came up without waiting for anything")
            .unwrap();
        (inbounds, config)
    }

    /// Nothing routed needs WARP: the plan says so, no WARP tunnel is expected (so `serve`
    /// never reaches the scan), and the inbounds serve direct at once.
    /// Runs alone: `cargo test no_warp_need -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    #[ignore]
    async fn with_no_warp_need_there_is_no_scan_no_prompt_and_the_inbounds_serve() {
        let _turn = shutdown::tests::RUNS.lock().await;
        let _run = shutdown::begin();
        let echo = echo_server().await;
        let socks: SocketAddr = format!("127.0.0.1:{}", free_port()).parse().unwrap();
        let route = "[route]\nfinal = \"direct\"\nrules = [{ domain_suffix = [\"ads.test\"], action = \"reject\" }]\n";
        let (inbounds, file) = core_with_inbounds(route, socks, "").await;
        assert!(!inbounds.warp.start, "{:?}", inbounds.warp);
        assert_eq!(inbounds.warp.users.as_deref(), Some(&[][..]));
        assert!(inbounds.warp.describe().contains("no scan, no registration"), "{}", inbounds.warp.describe());
        let config = crate::config::Config::from_env().unwrap();
        let plan = inbounds.warp.clone();
        let serving = tokio::spawn(async move { super::serve(&config, &plan).await });
        tokio::time::timeout(std::time::Duration::from_secs(5), socks_echo(socks, echo.port()))
            .await
            .expect("direct answered at once")
            .unwrap();
        tokio::time::sleep(std::time::Duration::from_millis(300)).await;
        // warp::run marks the run as expecting WARP before anything else (the scan)
        assert!(!crate::proxy::router::exits::warp_expected(), "the WARP tunnel was started");
        assert!(crate::proxy::router::exits::stack().is_none());
        assert!(!serving.is_finished(), "serve stopped by itself");
        serving.abort();
        drop(inbounds);
        crate::config::settings::uninstall();
        let _ = std::fs::remove_file(file);
    }

    /// Something routed needs WARP (`sunny`, the --sunny client with sunny.detour: warp, inside
    /// WARP MASQUE; `final` is warp): the plan starts the tunnel, yet before any tunnel exists
    /// the inbounds already serve `direct`, while a connection to `sunny` waits and goes through
    /// once it is up.
    /// Runs alone: `cargo test inbounds_serve_before -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    #[ignore]
    async fn the_inbounds_serve_before_the_warp_tunnel_and_warp_outbounds_wait_for_it() {
        let _turn = shutdown::tests::RUNS.lock().await;
        let _run = shutdown::begin();
        let direct_echo = echo_server().await;
        let sunny_echo = echo_server().await;
        let socks: SocketAddr = format!("127.0.0.1:{}", free_port()).parse().unwrap();
        let route = format!(
            "[route]\nfinal = \"warp\"\n\n[[route.rules]]\nport = {}\noutbound = \"direct\"\n\n\
             [[route.rules]]\nport = {}\noutbound = \"sunny\"\n",
            direct_echo.port(),
            sunny_echo.port()
        );
        // --sunny sunny.detour: warp: `sunny` is the sunnyquic client inside WARP MASQUE (never
        // started here)
        let (inbounds, file) = core_with_inbounds(&route, socks, "protocol = \"sunny\"\nsunny = { detour = \"warp\" }\n").await;
        assert!(inbounds.warp.start, "{:?}", inbounds.warp);
        assert_eq!(inbounds.warp.sunny, Some(crate::proxy::outbound::sunnyquic::Detour::Warp));
        assert!(crate::proxy::router::exits::sunny_over_warp());
        let users = inbounds.warp.users.clone().unwrap();
        assert!(users.iter().any(|u| u.contains("routes to sunny") && u.contains("WARP MASQUE")), "{users:?}");
        assert!(users.iter().any(|u| u == "final is warp"), "{users:?}");
        assert!(crate::proxy::router::exits::warp_expected());
        assert!(crate::proxy::router::exits::stack().is_none() && crate::proxy::router::exits::sunny().is_none());

        // no tunnel, no scan running at all: direct goes now
        tokio::time::timeout(std::time::Duration::from_secs(5), socks_echo(socks, direct_echo.port()))
            .await
            .expect("direct answered while the WARP tunnel is not up")
            .unwrap();

        // sunny waits for its tunnel ...
        let waiting = tokio::spawn(socks_echo(socks, sunny_echo.port()));
        tokio::time::sleep(std::time::Duration::from_millis(800)).await;
        assert!(!waiting.is_finished(), "sunny did not wait for the tunnel");
        // ... and goes through once it is up
        crate::proxy::router::exits::set_sunny(std::sync::Arc::new(LoopbackSunny));
        tokio::time::timeout(std::time::Duration::from_secs(5), waiting)
            .await
            .expect("sunny went on once its tunnel was up")
            .unwrap()
            .unwrap();
        drop(inbounds);
        crate::config::settings::uninstall();
        let _ = std::fs::remove_file(file);
    }

    /// --sunny alone (its client goes direct, the default): `sunny` needs no WARP, so with a
    /// route of sunny and direct the plan starts no tunnel (no prompt, no scan, no
    /// registration), and a connection to `sunny` waits only for its client, never for a tunnel.
    /// Runs alone: `cargo test sunny_direct_starts_no_warp -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    #[ignore]
    async fn sunny_direct_starts_no_warp_and_waits_only_for_its_client() {
        let _turn = shutdown::tests::RUNS.lock().await;
        let _run = shutdown::begin();
        let direct_echo = echo_server().await;
        let sunny_echo = echo_server().await;
        let socks: SocketAddr = format!("127.0.0.1:{}", free_port()).parse().unwrap();
        let route = format!(
            "[route]\nfinal = \"direct\"\n\n[[route.rules]]\nport = {}\noutbound = \"sunny\"\n",
            sunny_echo.port()
        );
        let (inbounds, file) = core_with_inbounds(&route, socks, "protocol = \"sunny\"\n").await;
        assert!(!inbounds.warp.start, "{:?}", inbounds.warp);
        assert_eq!(inbounds.warp.users.as_deref(), Some(&[][..]));
        assert_eq!(inbounds.warp.sunny, Some(crate::proxy::outbound::sunnyquic::Detour::Direct));
        let said = inbounds.warp.describe();
        assert!(said.contains("not started") && said.contains("goes direct from this machine and needs no WARP"), "{said}");
        assert!(!crate::proxy::router::exits::warp_expected(), "WARP was expected");
        assert!(!crate::proxy::router::exits::sunny_over_warp());

        tokio::time::timeout(std::time::Duration::from_secs(5), socks_echo(socks, direct_echo.port()))
            .await
            .expect("direct answered at once")
            .unwrap();
        // sunny waits for its client (serve makes it; here the test does) ...
        let waiting = tokio::spawn(socks_echo(socks, sunny_echo.port()));
        tokio::time::sleep(std::time::Duration::from_millis(800)).await;
        assert!(!waiting.is_finished(), "sunny did not wait for its client");
        crate::proxy::router::exits::set_sunny(std::sync::Arc::new(LoopbackSunny));
        tokio::time::timeout(std::time::Duration::from_secs(5), waiting)
            .await
            .expect("sunny went on once its client was there")
            .unwrap()
            .unwrap();
        assert!(crate::proxy::router::exits::stack().is_none(), "a WARP stack came up");

        // planned again it still starts nothing
        let plan = crate::transport::warp::demand::plan();
        drop(inbounds);
        crate::config::settings::uninstall();
        let _ = std::fs::remove_file(file);
        assert!(plan.is_ok_and(|p| !p.start));
    }
}
