//! Reads the parts of the packets TUN mode handles: the IPv4 header, the TCP or UDP ports and
//! payload, the standard WireGuard messages, and the answers of a DNS response.
//!
//! Nothing here touches the device, so all of it is testable on its own.

use std::net::Ipv4Addr;

pub const PROTO_TCP: u8 = 6;
pub const PROTO_UDP: u8 = 17;
pub const DNS_PORT: u16 = 53;

/// The five values that name one connection from the system.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct FlowKey {
    pub proto: u8,
    pub src: Ipv4Addr,
    pub sport: u16,
    pub dst: Ipv4Addr,
    pub dport: u16,
}

/// A TCP or UDP packet, with its payload.
#[derive(Clone, Copy, Debug)]
pub struct Packet<'a> {
    pub proto: u8,
    pub src: Ipv4Addr,
    pub sport: u16,
    pub dst: Ipv4Addr,
    pub dport: u16,
    pub payload: &'a [u8],
}

impl Packet<'_> {
    pub fn key(&self) -> FlowKey {
        FlowKey {
            proto: self.proto,
            src: self.src,
            sport: self.sport,
            dst: self.dst,
            dport: self.dport,
        }
    }
}

fn be16(pkt: &[u8], at: usize) -> u16 {
    u16::from_be_bytes([pkt[at], pkt[at + 1]])
}

/// Reads an IPv4 TCP or UDP packet. Anything else, a fragment, or a truncated packet gives `None`.
pub fn parse(pkt: &[u8]) -> Option<Packet<'_>> {
    if pkt.len() < 20 || pkt[0] >> 4 != 4 {
        return None;
    }
    let ihl = usize::from(pkt[0] & 0x0f) * 4;
    if ihl < 20 || pkt.len() < ihl {
        return None;
    }
    let total = usize::from(be16(pkt, 2));
    if total < ihl || total > pkt.len() {
        return None;
    }
    if be16(pkt, 6) & 0x3fff != 0 {
        return None;
    }
    let proto = pkt[9];
    let header_len = match proto {
        PROTO_UDP => 8,
        PROTO_TCP => {
            if pkt.len() < ihl + 20 {
                return None;
            }
            usize::from(pkt[ihl + 12] >> 4) * 4
        }
        _ => return None,
    };
    if pkt.len() < ihl + 4 {
        return None;
    }
    let payload_at = (ihl + header_len).min(total);
    Some(Packet {
        proto,
        src: Ipv4Addr::new(pkt[12], pkt[13], pkt[14], pkt[15]),
        sport: be16(pkt, ihl),
        dst: Ipv4Addr::new(pkt[16], pkt[17], pkt[18], pkt[19]),
        dport: be16(pkt, ihl + 2),
        payload: &pkt[payload_at..total],
    })
}

/// The name and the IPv4 answers of a DNS response, with the shortest TTL among those answers.
#[derive(Debug, PartialEq, Eq)]
pub struct DnsAnswer {
    pub name: String,
    pub addresses: Vec<Ipv4Addr>,
    pub ttl: u32,
}

/// Reads the first question and the A records of a DNS response. A query, or a malformed message,
/// gives `None`.
pub fn dns_answer(msg: &[u8]) -> Option<DnsAnswer> {
    if msg.len() < 12 {
        return None;
    }
    let flags = be16(msg, 2);
    if flags & 0x8000 == 0 {
        return None;
    }
    let qdcount = be16(msg, 4);
    let ancount = be16(msg, 6);
    if qdcount == 0 {
        return None;
    }

    let (name, mut pos) = read_name(msg, 12)?;
    pos = pos.checked_add(4)?;
    for _ in 1..qdcount {
        let (_, after) = read_name(msg, pos)?;
        pos = after.checked_add(4)?;
    }

    let mut addresses = Vec::new();
    let mut ttl = u32::MAX;
    for _ in 0..ancount {
        let (_, after) = read_name(msg, pos)?;
        let fixed = after;
        if msg.len() < fixed + 10 {
            return None;
        }
        let rtype = be16(msg, fixed);
        let rec_ttl = u32::from_be_bytes([
            msg[fixed + 4],
            msg[fixed + 5],
            msg[fixed + 6],
            msg[fixed + 7],
        ]);
        let rdlen = usize::from(be16(msg, fixed + 8));
        let rdata = fixed + 10;
        if msg.len() < rdata + rdlen {
            return None;
        }
        if rtype == 1 && rdlen == 4 {
            addresses.push(Ipv4Addr::new(
                msg[rdata],
                msg[rdata + 1],
                msg[rdata + 2],
                msg[rdata + 3],
            ));
            ttl = ttl.min(rec_ttl);
        }
        pos = rdata + rdlen;
    }

    Some(DnsAnswer {
        name,
        addresses,
        ttl: if ttl == u32::MAX { 0 } else { ttl },
    })
}

/// Reads a domain name at `pos`, following compression pointers. Returns the name, lower case
/// without its final dot, and the position just after the name where it was first written.
fn read_name(msg: &[u8], mut pos: usize) -> Option<(String, usize)> {
    let mut labels: Vec<String> = Vec::new();
    let mut resume: Option<usize> = None;
    let mut jumps = 0;
    loop {
        let len = *msg.get(pos)?;
        if len & 0xc0 == 0xc0 {
            let low = *msg.get(pos + 1)?;
            if resume.is_none() {
                resume = Some(pos + 2);
            }
            jumps += 1;
            if jumps > 32 {
                return None;
            }
            pos = (usize::from(len & 0x3f) << 8) | usize::from(low);
            continue;
        }
        if len & 0xc0 != 0 {
            return None;
        }
        pos += 1;
        if len == 0 {
            break;
        }
        let end = pos.checked_add(usize::from(len))?;
        let label = msg.get(pos..end)?;
        labels.push(String::from_utf8_lossy(label).to_lowercase());
        pos = end;
        if labels.len() > 127 {
            return None;
        }
    }
    let after = resume.unwrap_or(pos);
    Some((labels.join("."), after))
}

/// Whether a UDP payload is a WireGuard message: the standard lengths of handshake initiation,
/// response, cookie reply and transport data.
pub fn is_wireguard(payload: &[u8]) -> bool {
    crate::routing::looks_like_wireguard(payload)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ipv4_udp(src: [u8; 4], sport: u16, dst: [u8; 4], dport: u16, payload: &[u8]) -> Vec<u8> {
        let total = 20 + 8 + payload.len();
        let mut pkt = vec![0u8; total];
        pkt[0] = 0x45;
        pkt[2..4].copy_from_slice(&(total as u16).to_be_bytes());
        pkt[8] = 64;
        pkt[9] = PROTO_UDP;
        pkt[12..16].copy_from_slice(&src);
        pkt[16..20].copy_from_slice(&dst);
        pkt[20..22].copy_from_slice(&sport.to_be_bytes());
        pkt[22..24].copy_from_slice(&dport.to_be_bytes());
        pkt[24..26].copy_from_slice(&((8 + payload.len()) as u16).to_be_bytes());
        pkt[28..].copy_from_slice(payload);
        pkt
    }

    fn ipv4_tcp(sport: u16, dport: u16, payload: &[u8]) -> Vec<u8> {
        let total = 20 + 20 + payload.len();
        let mut pkt = vec![0u8; total];
        pkt[0] = 0x45;
        pkt[2..4].copy_from_slice(&(total as u16).to_be_bytes());
        pkt[8] = 64;
        pkt[9] = PROTO_TCP;
        pkt[12..16].copy_from_slice(&[10, 0, 0, 1]);
        pkt[16..20].copy_from_slice(&[93, 184, 216, 34]);
        pkt[20..22].copy_from_slice(&sport.to_be_bytes());
        pkt[22..24].copy_from_slice(&dport.to_be_bytes());
        pkt[32] = 0x50;
        pkt[40..].copy_from_slice(payload);
        pkt
    }

    /// A DNS response for `name` with one A record per address; the answer's name is a pointer
    /// back to the question, as real servers write it.
    fn dns_response(name: &str, addresses: &[[u8; 4]], ttl: u32) -> Vec<u8> {
        let mut msg = vec![0x12, 0x34, 0x81, 0x80, 0, 1];
        msg.extend_from_slice(&(addresses.len() as u16).to_be_bytes());
        msg.extend_from_slice(&[0, 0, 0, 0]);
        for label in name.split('.') {
            msg.push(label.len() as u8);
            msg.extend_from_slice(label.as_bytes());
        }
        msg.push(0);
        msg.extend_from_slice(&[0, 1, 0, 1]);
        for address in addresses {
            msg.extend_from_slice(&[0xc0, 0x0c]);
            msg.extend_from_slice(&[0, 1, 0, 1]);
            msg.extend_from_slice(&ttl.to_be_bytes());
            msg.extend_from_slice(&[0, 4]);
            msg.extend_from_slice(address);
        }
        msg
    }

    #[test]
    fn a_udp_packet_gives_its_ports_addresses_and_payload() {
        let pkt = ipv4_udp([10, 0, 0, 2], 5353, [1, 1, 1, 1], 53, b"query");
        let p = parse(&pkt).unwrap();
        assert_eq!(p.proto, PROTO_UDP);
        assert_eq!(p.src, Ipv4Addr::new(10, 0, 0, 2));
        assert_eq!(p.sport, 5353);
        assert_eq!(p.dst, Ipv4Addr::new(1, 1, 1, 1));
        assert_eq!(p.dport, 53);
        assert_eq!(p.payload, b"query");
    }

    #[test]
    fn a_tcp_packet_payload_starts_after_its_header() {
        let pkt = ipv4_tcp(40000, 443, b"\x16\x03\x01");
        let p = parse(&pkt).unwrap();
        assert_eq!(p.proto, PROTO_TCP);
        assert_eq!(p.dport, 443);
        assert_eq!(p.payload, b"\x16\x03\x01");
        assert_eq!(p.key().dst, Ipv4Addr::new(93, 184, 216, 34));
    }

    #[test]
    fn fragments_icmp_and_truncated_packets_are_not_read() {
        let mut fragment = ipv4_udp([10, 0, 0, 2], 1, [1, 1, 1, 1], 2, b"x");
        fragment[6] = 0x20;
        assert!(parse(&fragment).is_none());

        let mut icmp = ipv4_udp([10, 0, 0, 2], 1, [1, 1, 1, 1], 2, b"x");
        icmp[9] = 1;
        assert!(parse(&icmp).is_none());

        assert!(parse(&[0x45, 0, 0]).is_none());
        let pkt = ipv4_udp([10, 0, 0, 2], 1, [1, 1, 1, 1], 2, b"abc");
        assert!(parse(&pkt[..pkt.len() - 1]).is_none());
    }

    #[test]
    fn a_dns_response_gives_the_queried_name_and_its_addresses() {
        let msg = dns_response("cdn.example.org", &[[93, 184, 216, 34], [93, 184, 216, 35]], 300);
        let answer = dns_answer(&msg).unwrap();
        assert_eq!(answer.name, "cdn.example.org");
        assert_eq!(
            answer.addresses,
            vec![Ipv4Addr::new(93, 184, 216, 34), Ipv4Addr::new(93, 184, 216, 35)]
        );
        assert_eq!(answer.ttl, 300);
    }

    #[test]
    fn a_dns_query_or_an_empty_answer_is_not_a_mapping() {
        let mut query = dns_response("a.example", &[[1, 2, 3, 4]], 60);
        query[2] = 0x01;
        assert!(dns_answer(&query).is_none());

        let empty = dns_response("nothing.example", &[], 60);
        let answer = dns_answer(&empty).unwrap();
        assert!(answer.addresses.is_empty());
    }

    #[test]
    fn a_malformed_dns_message_is_refused_without_panicking() {
        let mut msg = dns_response("a.example", &[[1, 2, 3, 4]], 60);
        msg.truncate(20);
        assert!(dns_answer(&msg).is_none());
        assert!(dns_answer(&[0u8; 5]).is_none());

        let looping = [0x81, 0x80, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0xc0, 0x0c, 0, 1, 0, 1];
        assert!(dns_answer(&looping).is_none());
    }

    #[test]
    fn a_wireguard_message_is_recognised_by_its_length() {
        let mut init = vec![0u8; 148];
        init[0] = 1;
        assert!(is_wireguard(&init));
        assert!(!is_wireguard(b"\x16\x03\x01\x00\x05hello"));
    }
}
