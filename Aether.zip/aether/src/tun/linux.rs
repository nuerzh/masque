//! Linux TUN: `/dev/net/tun`, configured and routed with `ip` (iproute2).

use std::ffi::{CStr, CString};
use std::io;
use std::net::IpAddr;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};

use tokio::sync::mpsc;

use super::{unix, FromOs, NetRoute, PhysicalRoute, TunIface, Via};
use crate::error::{AetherError, Result};

const TUNSETIFF: u64 = 0x400454ca;
const IFF_TUN: i16 = 0x0001;
const IFF_NO_PI: i16 = 0x1000;

/// `struct ifreq` as the TUN ioctl uses it: a name and flags, padded to the kernel's size.
#[repr(C)]
struct IfReq {
    name: [libc::c_char; libc::IFNAMSIZ],
    flags: i16,
    pad: [u8; 22],
}

/// Nothing to keep here: the tasks that read and write the descriptor own it.
pub(super) struct Native;

/// Opens the device, sets its address and MTU and brings it up.
pub(super) fn open(
    mtu: usize,
    from_os: FromOs,
    to_os_rx: mpsc::Receiver<Vec<u8>>,
) -> Result<(String, u32, Native)> {
    let (fd, name) = create_device()?;
    let mtu_text = mtu.to_string();
    let address = format!("{}/32", super::SYSTEM_ADDR);
    run_ip(&[
        "link",
        "set",
        "dev",
        name.as_str(),
        "mtu",
        mtu_text.as_str(),
        "up",
    ])?;
    run_ip(&[
        "-4",
        "addr",
        "replace",
        address.as_str(),
        "dev",
        name.as_str(),
    ])?;
    let index = index_of(&name)?;
    unix::start(fd, from_os, to_os_rx)?;
    Ok((name, index, Native))
}

fn create_device() -> Result<(OwnedFd, String)> {
    // SAFETY: geteuid has no preconditions.
    if unsafe { libc::geteuid() } != 0 {
        return Err(AetherError::Other(
            "TUN mode needs root to open the device and change routes; run with sudo".into(),
        ));
    }

    // SAFETY: opening the TUN clone device by a constant path.
    let raw = unsafe {
        libc::open(
            b"/dev/net/tun\0".as_ptr().cast(),
            libc::O_RDWR | libc::O_CLOEXEC,
        )
    };
    if raw < 0 {
        return Err(AetherError::Other(format!(
            "cannot open /dev/net/tun: {}; the tun module must be loaded",
            io::Error::last_os_error()
        )));
    }
    // SAFETY: `raw` is a fresh descriptor that nothing else owns.
    let fd = unsafe { OwnedFd::from_raw_fd(raw) };

    let mut req = IfReq {
        name: [0; libc::IFNAMSIZ],
        flags: IFF_TUN | IFF_NO_PI,
        pad: [0; 22],
    };
    // SAFETY: `req` has the layout the kernel expects for TUNSETIFF.
    let rc = unsafe { libc::ioctl(fd.as_raw_fd(), TUNSETIFF as _, &mut req as *mut IfReq) };
    if rc < 0 {
        return Err(AetherError::Other(format!(
            "cannot create the tun device: {}",
            io::Error::last_os_error()
        )));
    }
    // SAFETY: the kernel leaves a NUL-terminated name in `req`.
    let name = unsafe { CStr::from_ptr(req.name.as_ptr()) }
        .to_string_lossy()
        .into_owned();
    Ok((fd, name))
}

fn index_of(name: &str) -> Result<u32> {
    let c = CString::new(name).map_err(|e| AetherError::Other(e.to_string()))?;
    // SAFETY: `c` is a valid NUL-terminated string.
    let index = unsafe { libc::if_nametoindex(c.as_ptr()) };
    if index == 0 {
        return Err(AetherError::Other(format!("no interface index for {name}")));
    }
    Ok(index)
}

/// The default IPv4 route as it is before TUN mode touches it. Refuses one that already points
/// at this device, which a crashed run can leave behind.
pub(super) fn physical_default(iface: &TunIface) -> Result<PhysicalRoute> {
    let out = run_ip(&["-4", "route", "show", "default"])?;
    let line = out
        .lines()
        .find(|line| line.starts_with("default"))
        .ok_or_else(|| {
            AetherError::Other("no default IPv4 route; TUN mode needs one to reach WARP".into())
        })?;
    let words: Vec<&str> = line.split_whitespace().collect();
    let after = |key: &str| {
        words
            .iter()
            .position(|w| *w == key)
            .and_then(|i| words.get(i + 1))
            .map(|w| w.to_string())
    };
    let ifname = after("dev")
        .ok_or_else(|| AetherError::Other(format!("cannot read the default route: {line}")))?;
    if ifname == iface.name {
        return Err(AetherError::Other(format!(
            "the default route already points at {}; remove the stale route first",
            iface.name
        )));
    }
    let gateway = after("via").and_then(|g| g.parse().ok());
    Ok(PhysicalRoute { gateway, ifname })
}

pub(super) fn route_add(route: &NetRoute, iface: &TunIface) -> Result<()> {
    let family = family_flag(route.dest);
    let dest = format!("{}/{}", route.dest, route.prefix);
    let mut args: Vec<&str> = vec![family, "route", "replace", dest.as_str()];
    let gateway = match &route.via {
        Via::Physical(physical) => physical.gateway.map(|gw| gw.to_string()),
        Via::Tunnel => None,
    };
    if let Some(text) = &gateway {
        args.push("via");
        args.push(text.as_str());
    }
    let device = match &route.via {
        Via::Physical(physical) => physical.ifname.as_str(),
        Via::Tunnel => iface.name.as_str(),
    };
    args.push("dev");
    args.push(device);
    run_ip(&args).map(|_| ())
}

pub(super) fn route_del(route: &NetRoute, iface: &TunIface) -> Result<()> {
    let family = family_flag(route.dest);
    let dest = format!("{}/{}", route.dest, route.prefix);
    let mut args: Vec<&str> = vec![family, "route", "del", dest.as_str()];
    if matches!(route.via, Via::Tunnel) {
        args.push("dev");
        args.push(iface.name.as_str());
    }
    run_ip(&args).map(|_| ())
}

fn family_flag(dest: IpAddr) -> &'static str {
    match dest {
        IpAddr::V4(_) => "-4",
        IpAddr::V6(_) => "-6",
    }
}

/// Runs `ip` with `args` and returns its standard output.
fn run_ip(args: &[&str]) -> Result<String> {
    let output = std::process::Command::new("ip")
        .args(args)
        .output()
        .map_err(|e| {
            AetherError::Other(format!("TUN mode needs the `ip` command (iproute2): {e}"))
        })?;
    if output.status.success() {
        Ok(String::from_utf8_lossy(&output.stdout).into_owned())
    } else {
        Err(AetherError::Other(format!(
            "`ip {}` failed: {}",
            args.join(" "),
            String::from_utf8_lossy(&output.stderr).trim()
        )))
    }
}
