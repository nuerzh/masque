//! Stand-in for platforms without a TUN backend. TUN mode is refused at startup there.

use tokio::sync::mpsc;

use super::{FromOs, NetRoute, PhysicalRoute, TunIface};
use crate::error::{AetherError, Result};

pub(super) struct Native;

fn unavailable() -> AetherError {
    AetherError::Other(
        "TUN mode is available on Linux, macOS and Windows only; run without --tun".into(),
    )
}

pub(super) fn open(
    _mtu: usize,
    _from_os: FromOs,
    _to_os_rx: mpsc::Receiver<Vec<u8>>,
) -> Result<(String, u32, Native)> {
    Err(unavailable())
}

pub(super) fn physical_default(_iface: &TunIface) -> Result<PhysicalRoute> {
    Err(unavailable())
}

pub(super) fn route_add(_route: &NetRoute, _iface: &TunIface) -> Result<()> {
    Err(unavailable())
}

pub(super) fn route_del(_route: &NetRoute, _iface: &TunIface) -> Result<()> {
    Err(unavailable())
}
