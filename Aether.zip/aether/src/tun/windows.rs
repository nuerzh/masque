//! Windows TUN: a WinTUN adapter (`wintun.dll` must sit next to the executable), addressed and
//! routed with `netsh` and `route`. The packet pump follows geph5's: a blocking reader thread and
//! a writer task on one session.

use std::net::{IpAddr, Ipv4Addr};
use std::process::Command;
use std::sync::Arc;

use tokio::sync::mpsc;

use super::{FromOs, NetRoute, PhysicalRoute, TunIface, Via, SYSTEM_ADDR};
use crate::error::{AetherError, Result};

const ADAPTER_NAME: &str = "Aether";
const ADAPTER_TYPE: &str = "aether";
/// WinTUN's ring capacity, in the range the driver accepts (a power of two).
const RING_CAPACITY: u32 = 0x40_0000;

/// The WinTUN handles. They stay alive for as long as the device does.
pub(super) struct Native {
    _wintun: wintun::Wintun,
    _adapter: Arc<wintun::Adapter>,
    session: Arc<wintun::Session>,
}

impl Drop for Native {
    fn drop(&mut self) {
        // Unblocks the reader thread, which is parked in `receive_blocking`.
        let _ = self.session.shutdown();
    }
}

/// Creates or reuses the adapter, addresses it and starts a session on it.
pub(super) fn open(
    mtu: usize,
    from_os: FromOs,
    mut to_os_rx: mpsc::Receiver<Vec<u8>>,
) -> Result<(String, u32, Native)> {
    // SAFETY: loads wintun.dll from the executable's directory or the system search path.
    let wintun = unsafe { wintun::load() }.map_err(|e| {
        AetherError::Other(format!(
            "cannot load wintun.dll (place it next to aether.exe): {e}"
        ))
    })?;

    let adapter = match wintun::Adapter::open(&wintun, ADAPTER_NAME) {
        Ok(existing) => existing,
        Err(_) => {
            wintun::Adapter::create(&wintun, ADAPTER_NAME, ADAPTER_TYPE, None).map_err(|e| {
                AetherError::Other(format!(
                    "cannot create the WinTUN adapter (run as administrator): {e}"
                ))
            })?
        }
    };

    adapter
        .set_network_addresses_tuple(
            IpAddr::V4(SYSTEM_ADDR),
            IpAddr::V4(Ipv4Addr::BROADCAST),
            None,
        )
        .map_err(|e| AetherError::Other(format!("cannot address the WinTUN adapter: {e}")))?;
    adapter
        .set_mtu(mtu)
        .map_err(|e| AetherError::Other(format!("cannot set the WinTUN MTU: {e}")))?;
    let index = adapter
        .get_adapter_index()
        .map_err(|e| AetherError::Other(format!("cannot read the WinTUN interface index: {e}")))?;

    let session = Arc::new(
        adapter
            .start_session(RING_CAPACITY)
            .map_err(|e| AetherError::Other(format!("cannot start a WinTUN session: {e}")))?,
    );

    // Reader: a blocking thread, because WinTUN waits on an event handle.
    let reader_session = Arc::clone(&session);
    std::thread::Builder::new()
        .name("aether-tun-read".into())
        .spawn(move || {
            while let Ok(packet) = reader_session.receive_blocking() {
                super::deliver(&from_os, packet.bytes().to_vec());
            }
        })?;

    // Writer: copy each packet into the ring and send it.
    let writer_session = Arc::clone(&session);
    tokio::spawn(async move {
        while let Some(packet) = to_os_rx.recv().await {
            let Ok(len) = u16::try_from(packet.len()) else {
                continue;
            };
            match writer_session.allocate_send_packet(len) {
                Ok(mut out) => {
                    out.bytes_mut().copy_from_slice(&packet);
                    writer_session.send_packet(out);
                }
                Err(e) => log::warn!("[-] tun write failed: {e}"),
            }
        }
    });

    Ok((
        ADAPTER_NAME.to_string(),
        index,
        Native {
            _wintun: wintun,
            _adapter: adapter,
            session,
        },
    ))
}

/// The default IPv4 route as it is before TUN mode touches it, taken from `route print`. Only a
/// route with a gateway is usable: an on-link default has nothing to send through.
pub(super) fn physical_default(_iface: &TunIface) -> Result<PhysicalRoute> {
    let out = run("route", &["print".into(), "0.0.0.0".into()])?;
    let mut best: Option<(u32, Ipv4Addr, Ipv4Addr)> = None;
    for line in out.lines() {
        let fields: Vec<&str> = line.split_whitespace().collect();
        if fields.len() != 5 || fields[0] != "0.0.0.0" || fields[1] != "0.0.0.0" {
            continue;
        }
        let (Ok(gateway), Ok(interface), Ok(metric)) = (
            fields[2].parse::<Ipv4Addr>(),
            fields[3].parse::<Ipv4Addr>(),
            fields[4].parse::<u32>(),
        ) else {
            continue;
        };
        if interface == SYSTEM_ADDR {
            continue;
        }
        if best.map_or(true, |(best_metric, _, _)| metric < best_metric) {
            best = Some((metric, gateway, interface));
        }
    }
    let (_, gateway, interface) = best.ok_or_else(|| {
        AetherError::Other(
            "no default IPv4 route with a gateway; TUN mode needs one to reach WARP".into(),
        )
    })?;
    Ok(PhysicalRoute {
        gateway: Some(gateway),
        ifname: interface.to_string(),
    })
}

/// Installs a route. Any route with the same destination is removed first.
pub(super) fn route_add(route: &NetRoute, iface: &TunIface) -> Result<()> {
    let _ = route_del(route, iface);
    match route.dest {
        IpAddr::V4(dest) => {
            let mut args: Vec<String> = vec![
                "ADD".into(),
                dest.to_string(),
                "MASK".into(),
                super::v4_mask(route.prefix).to_string(),
            ];
            match &route.via {
                Via::Physical(physical) => {
                    let gateway = physical.gateway.ok_or_else(|| {
                        AetherError::Other("a physical route needs a gateway on Windows".into())
                    })?;
                    args.push(gateway.to_string());
                }
                Via::Tunnel => {
                    args.push(SYSTEM_ADDR.to_string());
                    args.push("IF".into());
                    args.push(iface.index.to_string());
                }
            }
            args.push("METRIC".into());
            args.push("1".into());
            run("route", &args).map(|_| ())
        }
        IpAddr::V6(_) => {
            if !matches!(route.via, Via::Tunnel) {
                return Err(AetherError::Other(
                    "IPv6 routes are only installed through the device".into(),
                ));
            }
            run("netsh", &v6_route_args("add", route, iface)).map(|_| ())
        }
    }
}

pub(super) fn route_del(route: &NetRoute, iface: &TunIface) -> Result<()> {
    match route.dest {
        IpAddr::V4(dest) => run(
            "route",
            &[
                "DELETE".into(),
                dest.to_string(),
                "MASK".into(),
                super::v4_mask(route.prefix).to_string(),
            ],
        )
        .map(|_| ()),
        IpAddr::V6(_) => run("netsh", &v6_route_args("delete", route, iface)).map(|_| ()),
    }
}

fn v6_route_args(verb: &str, route: &NetRoute, iface: &TunIface) -> Vec<String> {
    vec![
        "interface".into(),
        "ipv6".into(),
        verb.into(),
        "route".into(),
        format!("prefix={}/{}", route.dest, route.prefix),
        format!("interface={}", iface.index),
        "store=active".into(),
    ]
}

/// Runs a system tool with `args` and returns its standard output.
fn run(program: &str, args: &[String]) -> Result<String> {
    let output = Command::new(program)
        .args(args)
        .output()
        .map_err(|e| AetherError::Other(format!("cannot run {program}: {e}")))?;
    if output.status.success() {
        Ok(String::from_utf8_lossy(&output.stdout).into_owned())
    } else {
        let stderr = if output.stderr.is_empty() {
            String::from_utf8_lossy(&output.stdout).into_owned()
        } else {
            String::from_utf8_lossy(&output.stderr).into_owned()
        };
        Err(AetherError::Other(format!(
            "`{program} {}` failed: {}",
            args.join(" "),
            stderr.trim()
        )))
    }
}
