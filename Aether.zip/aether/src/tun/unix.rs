//! Packet I/O on a TUN file descriptor, shared by Linux and macOS.
//!
//! Both read and write whole IP packets through one non-blocking descriptor. macOS `utun` frames
//! every packet with a 4-byte address-family word in front of it, so that is stripped on the way
//! in and added on the way out, the way geph5 does it.

use std::borrow::Cow;
use std::io;
use std::os::fd::{AsRawFd, OwnedFd, RawFd};
use std::sync::Arc;

use tokio::io::unix::AsyncFd;
use tokio::sync::mpsc;

use super::FromOs;
use crate::error::Result;

#[cfg(target_os = "macos")]
const FRAME_HEADER: usize = 4;
#[cfg(not(target_os = "macos"))]
const FRAME_HEADER: usize = 0;

/// Starts the read and write tasks of a TUN descriptor. The tasks keep the descriptor open.
pub(super) fn start(fd: OwnedFd, from_os: FromOs, to_os_rx: mpsc::Receiver<Vec<u8>>) -> Result<()> {
    set_nonblocking(fd.as_raw_fd())?;
    let fd = Arc::new(AsyncFd::new(fd)?);
    tokio::spawn(read_loop(Arc::clone(&fd), from_os));
    tokio::spawn(write_loop(fd, to_os_rx));
    Ok(())
}

fn set_nonblocking(fd: RawFd) -> io::Result<()> {
    // SAFETY: plain fcntl calls on a descriptor the caller owns.
    unsafe {
        let flags = libc::fcntl(fd, libc::F_GETFL);
        if flags < 0 {
            return Err(io::Error::last_os_error());
        }
        if libc::fcntl(fd, libc::F_SETFL, flags | libc::O_NONBLOCK) < 0 {
            return Err(io::Error::last_os_error());
        }
    }
    Ok(())
}

async fn read_loop(fd: Arc<AsyncFd<OwnedFd>>, from_os: FromOs) {
    let mut buf = vec![0u8; 65_536];
    loop {
        let n = match read_some(&fd, &mut buf).await {
            Ok(0) => {
                log::warn!("[-] tun device closed");
                return;
            }
            Ok(n) => n,
            Err(e) => {
                log::error!("[-] tun read failed: {e}");
                return;
            }
        };
        if n > FRAME_HEADER {
            super::deliver(&from_os, buf[FRAME_HEADER..n].to_vec());
        }
    }
}

async fn write_loop(fd: Arc<AsyncFd<OwnedFd>>, mut rx: mpsc::Receiver<Vec<u8>>) {
    while let Some(packet) = rx.recv().await {
        let framed = frame(&packet);
        if let Err(e) = write_packet(&fd, &framed).await {
            log::warn!("[-] tun write failed: {e}");
        }
    }
}

/// The bytes to write for one IP packet: the packet itself, or on macOS the packet behind its
/// address-family word, `AF_INET6` (30) for an IPv6 packet and `AF_INET` (2) otherwise.
fn frame(packet: &[u8]) -> Cow<'_, [u8]> {
    if FRAME_HEADER == 0 {
        return Cow::Borrowed(packet);
    }
    let family: u32 = if packet.first().map(|b| b >> 4) == Some(6) {
        30
    } else {
        2
    };
    let mut out = Vec::with_capacity(FRAME_HEADER + packet.len());
    out.extend_from_slice(&family.to_be_bytes());
    out.extend_from_slice(packet);
    Cow::Owned(out)
}

async fn read_some(fd: &AsyncFd<OwnedFd>, buf: &mut [u8]) -> io::Result<usize> {
    loop {
        let mut guard = fd.readable().await?;
        match guard.try_io(|inner| sys_read(inner.get_ref().as_raw_fd(), buf)) {
            Ok(result) => return result,
            Err(_would_block) => continue,
        }
    }
}

async fn write_packet(fd: &AsyncFd<OwnedFd>, buf: &[u8]) -> io::Result<()> {
    loop {
        let mut guard = fd.writable().await?;
        match guard.try_io(|inner| sys_write(inner.get_ref().as_raw_fd(), buf)) {
            Ok(Ok(n)) if n == buf.len() => return Ok(()),
            Ok(Ok(n)) => {
                return Err(io::Error::new(
                    io::ErrorKind::WriteZero,
                    format!("partial tun write: {n} of {} bytes", buf.len()),
                ))
            }
            Ok(Err(e)) => return Err(e),
            Err(_would_block) => continue,
        }
    }
}

fn sys_read(fd: RawFd, buf: &mut [u8]) -> io::Result<usize> {
    // SAFETY: `buf` is valid for `buf.len()` bytes.
    let n = unsafe { libc::read(fd, buf.as_mut_ptr().cast(), buf.len()) };
    if n < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(n as usize)
    }
}

fn sys_write(fd: RawFd, buf: &[u8]) -> io::Result<usize> {
    // SAFETY: `buf` is valid for `buf.len()` bytes.
    let n = unsafe { libc::write(fd, buf.as_ptr().cast(), buf.len()) };
    if n < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(n as usize)
    }
}
