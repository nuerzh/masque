//! The rules of TUN mode: which of the system's connections go through the tunnel, which are sent
//! out on this machine's own network, and which are refused.
//!
//! The rules are the routing rules. A connection is decided by its first packet, using the name
//! the system looked up for the address, taken from the DNS answers that pass through the device.
//! A TCP connection can also be decided by the first bytes it sends, where the TLS server name or
//! the HTTP host gives the name. A refused connection is dropped. A connection sent direct is kept
//! off the tunnel by routes to the physical interface: one for each address range the rules name,
//! and one for each address a direct name resolves to, added as the answer passes, before the
//! system connects. A direct connection whose packets still reach the device is sent through the
//! tunnel, because its socket was opened with the device's address.

use std::collections::HashMap;
use std::net::{IpAddr, Ipv4Addr};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use ipnet::IpNet;

use super::packet::{self, FlowKey, PROTO_TCP, PROTO_UDP};
use super::{locked, native, NetRoute, PhysicalRoute, TunIface, Via, INSTALLED};
use crate::routing::{self, Action, Flow, Host};
use crate::sniff;

/// A connection that has sent nothing for this long is forgotten.
const FLOW_IDLE: Duration = Duration::from_secs(600);
const MAX_FLOWS: usize = 16_384;
const MAX_NAMES: usize = 16_384;
const MAX_ROUTES: usize = 4_096;
/// A name is remembered for its answer's TTL, within these bounds.
const MIN_NAME_TTL: u32 = 30;
const MAX_NAME_TTL: u32 = 3_600;

struct FlowState {
    action: Action,
    last: Instant,
    sniffed: bool,
}

pub(crate) struct Policy {
    iface: TunIface,
    /// The physical default route, read when a route needs it and again after each rule change.
    physical: Mutex<Option<PhysicalRoute>>,
    /// The name behind each address the system was told, until the answer's TTL runs out.
    names: Mutex<HashMap<Ipv4Addr, (String, Instant)>>,
    flows: Mutex<HashMap<FlowKey, FlowState>>,
    /// Every route this policy has added and not yet removed.
    routes: Mutex<Vec<NetRoute>>,
    /// The address ranges the rules send direct that currently have a route.
    ranges: Mutex<Vec<(Ipv4Addr, u8)>>,
    warned_direct: AtomicBool,
}

impl Policy {
    pub(crate) fn new(iface: TunIface) -> Self {
        Self {
            iface,
            physical: Mutex::new(None),
            names: Mutex::new(HashMap::new()),
            flows: Mutex::new(HashMap::new()),
            routes: Mutex::new(Vec::new()),
            ranges: Mutex::new(Vec::new()),
            warned_direct: AtomicBool::new(false),
        }
    }

    /// Decides one packet the system sent. Returns false to drop it. Packets that are not TCP or
    /// UDP over IPv4 are left to the translation, which decides them itself.
    pub(crate) fn allow(&self, pkt: &[u8], now: Instant) -> bool {
        let Some(p) = packet::parse(pkt) else {
            return true;
        };
        let key = p.key();

        let mut flows = locked(&self.flows);
        if !flows.contains_key(&key) {
            if flows.len() >= MAX_FLOWS {
                flows.retain(|_, state| now.duration_since(state.last) < FLOW_IDLE);
                if flows.len() >= MAX_FLOWS {
                    flows.clear();
                }
            }
            let wireguard = p.proto == PROTO_UDP && packet::is_wireguard(p.payload);
            let name = self.name_of(p.dst, now);
            let action = decide(name.as_deref(), p.dst, p.dport, wireguard);
            if action != Action::Tunnel {
                log::debug!(
                    "[route] tun {}:{} -> {}:{}: {}",
                    p.src,
                    p.sport,
                    name.as_deref().unwrap_or(&p.dst.to_string()),
                    p.dport,
                    action.label()
                );
            }
            flows.insert(
                key,
                FlowState {
                    action,
                    last: now,
                    sniffed: false,
                },
            );
        }

        let Some(state) = flows.get_mut(&key) else {
            return true;
        };
        state.last = now;

        // The first bytes of a TCP connection can name the host even when DNS did not. A match
        // on them decides the rest of the connection.
        if state.action != Action::Block && p.proto == PROTO_TCP && !state.sniffed && !p.payload.is_empty() {
            state.sniffed = true;
            if let Some(name) = sniff::hostname(p.payload) {
                if let Some(action) = routing::current().matched(&Flow::new(Host::Domain(&name), p.dport)) {
                    state.action = action;
                }
            }
        }

        match state.action {
            Action::Block => false,
            Action::Direct => {
                if !self.warned_direct.swap(true, Ordering::Relaxed) {
                    log::warn!(
                        "[-] tun: a connection the rules send direct reached the device before its route was in place; it goes through the tunnel instead"
                    );
                }
                true
            }
            Action::Tunnel | Action::Resolve => true,
        }
    }

    /// Learns from a packet that is about to go to the system from the tunnel. A DNS answer gives
    /// the name behind its addresses, and when the rules send that name direct, a route keeps the
    /// addresses off the tunnel before the system connects to them.
    pub(crate) fn observe(&self, pkt: &[u8], now: Instant) {
        let Some(p) = packet::parse(pkt) else {
            return;
        };
        if p.proto != PROTO_UDP || p.sport != packet::DNS_PORT {
            return;
        }
        let Some(answer) = packet::dns_answer(p.payload) else {
            return;
        };
        if answer.addresses.is_empty() {
            return;
        }

        let ttl = Duration::from_secs(u64::from(answer.ttl.clamp(MIN_NAME_TTL, MAX_NAME_TTL)));
        {
            let mut names = locked(&self.names);
            if names.len() >= MAX_NAMES {
                names.retain(|_, (_, until)| *until > now);
            }
            for address in &answer.addresses {
                names.insert(*address, (answer.name.clone(), now + ttl));
            }
        }

        if routing::current().matched_name(&answer.name) == Some(Action::Direct) {
            for address in &answer.addresses {
                self.install_direct(IpAddr::V4(*address), 32);
            }
        }
    }

    /// Brings the routes for the address ranges the rules send direct in line with the rules in
    /// force. Called when the rules change and when a tunnel comes up.
    pub(crate) fn refresh(&self) {
        *locked(&self.physical) = None;
        // Connections are decided again by the rules now in force.
        locked(&self.flows).clear();
        let Some(physical) = self.default_physical() else {
            return;
        };

        let wanted: Vec<(Ipv4Addr, u8)> = routing::current()
            .direct_nets()
            .into_iter()
            .filter_map(|net| match net {
                // A range as wide as a half of the address space would take over the device's own
                // routes, so only the narrower ones are routed.
                IpNet::V4(v4) if v4.prefix_len() >= 8 => Some((v4.network(), v4.prefix_len())),
                _ => None,
            })
            .collect();

        let mut ranges = locked(&self.ranges);
        let gone: Vec<(Ipv4Addr, u8)> = ranges
            .iter()
            .filter(|range| !wanted.contains(range))
            .copied()
            .collect();
        for (dest, prefix) in gone {
            self.uninstall(&route_via(&physical, IpAddr::V4(dest), prefix));
        }
        ranges.retain(|range| wanted.contains(range));

        for (dest, prefix) in wanted {
            if ranges.contains(&(dest, prefix)) {
                continue;
            }
            if self.install(route_via(&physical, IpAddr::V4(dest), prefix)) {
                ranges.push((dest, prefix));
            }
        }
    }

    fn name_of(&self, address: Ipv4Addr, now: Instant) -> Option<String> {
        let names = locked(&self.names);
        names
            .get(&address)
            .filter(|(_, until)| *until > now)
            .map(|(name, _)| name.clone())
    }

    fn default_physical(&self) -> Option<PhysicalRoute> {
        let mut slot = locked(&self.physical);
        if slot.is_none() {
            *slot = native::physical_default(&self.iface).ok();
        }
        slot.clone()
    }

    fn install_direct(&self, dest: IpAddr, prefix: u8) -> bool {
        match self.default_physical() {
            Some(physical) => self.install(route_via(&physical, dest, prefix)),
            None => false,
        }
    }

    fn install(&self, route: NetRoute) -> bool {
        let mut routes = locked(&self.routes);
        if routes.contains(&route) {
            return true;
        }
        if routes.len() >= MAX_ROUTES {
            log::debug!("[-] tun: the route table for the rules is full; {}/{} is not routed", route.dest, route.prefix);
            return false;
        }
        match native::route_add(&route, &self.iface) {
            Ok(()) => {
                locked(&INSTALLED).push(route.clone());
                routes.push(route);
                true
            }
            Err(error) => {
                log::debug!("[-] tun: could not add the route {}/{}: {error}", route.dest, route.prefix);
                false
            }
        }
    }

    fn uninstall(&self, route: &NetRoute) {
        locked(&self.routes).retain(|installed| installed != route);
        locked(&INSTALLED).retain(|installed| installed != route);
        if let Err(error) = native::route_del(route, &self.iface) {
            log::warn!("[-] could not remove a tun route: {error}");
        }
    }
}

fn route_via(physical: &PhysicalRoute, dest: IpAddr, prefix: u8) -> NetRoute {
    NetRoute {
        dest,
        prefix,
        via: Via::Physical(physical.clone()),
    }
}

/// The action for a connection to `dst`, taking the name first when there is one, as the proxy
/// listeners do: a domain rule that matches decides, otherwise the address rules and the default.
fn decide(name: Option<&str>, dst: Ipv4Addr, port: u16, wireguard: bool) -> Action {
    let set = routing::current();
    if let Some(name) = name {
        if let Some(action) = set.matched(&Flow {
            host: Host::Domain(name),
            port,
            wireguard,
        }) {
            return action;
        }
    }
    set.decide(&Flow {
        host: Host::Ip(IpAddr::V4(dst)),
        port,
        wireguard,
    })
}
