//! macOS TUN: a `utun` device opened through the kernel control socket, addressed with `ifconfig`
//! and routed with `route`. The control-socket constants are the ones geph5 uses.

use std::ffi::{CStr, CString};
use std::io;
use std::net::IpAddr;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::process::Command;

use tokio::sync::mpsc;

use super::{unix, FromOs, NetRoute, PhysicalRoute, TunIface, Via};
use crate::error::{AetherError, Result};

const PF_SYSTEM: libc::c_int = 32;
const SYSPROTO_CONTROL: libc::c_int = 2;
const AF_SYSTEM: u8 = 32;
const AF_SYS_CONTROL: u16 = 2;
const UTUN_OPT_IFNAME: libc::c_int = 2;
/// `CTLIOCGINFO = _IOWR('N', 3, struct ctl_info)`; `sizeof(struct ctl_info)` is 100.
const CTLIOCGINFO: libc::c_ulong = 0xC064_4E03;
const UTUN_CONTROL_NAME: &[u8] = b"com.apple.net.utun_control";

#[repr(C)]
struct CtlInfo {
    ctl_id: u32,
    ctl_name: [libc::c_char; 96],
}

#[repr(C)]
struct SockaddrCtl {
    sc_len: u8,
    sc_family: u8,
    ss_sysaddr: u16,
    sc_id: u32,
    sc_unit: u32,
    sc_reserved: [u32; 5],
}

/// Nothing to keep here: the tasks that read and write the descriptor own it.
pub(super) struct Native;

/// Opens the utun device, addresses it and brings it up.
pub(super) fn open(
    mtu: usize,
    from_os: FromOs,
    to_os_rx: mpsc::Receiver<Vec<u8>>,
) -> Result<(String, u32, Native)> {
    // SAFETY: geteuid has no preconditions.
    if unsafe { libc::geteuid() } != 0 {
        return Err(AetherError::Other(
            "TUN mode needs root to open the utun device and change routes; run with sudo".into(),
        ));
    }
    let (fd, name) = create_utun()?;
    let mtu_text = mtu.to_string();
    let address = super::SYSTEM_ADDR.to_string();
    run(
        "ifconfig",
        &[
            name.as_str(),
            "inet",
            address.as_str(),
            address.as_str(),
            "mtu",
            mtu_text.as_str(),
            "up",
        ],
    )?;
    let index = index_of(&name)?;
    unix::start(fd, from_os, to_os_rx)?;
    Ok((name, index, Native))
}

/// Opens a `utun` control socket and lets the kernel pick the next free unit. Returns the
/// descriptor and the name it was given, such as `utun7`.
fn create_utun() -> Result<(OwnedFd, String)> {
    // SAFETY: plain socket call; the result is checked before use.
    let fd = unsafe { libc::socket(PF_SYSTEM, libc::SOCK_DGRAM, SYSPROTO_CONTROL) };
    if fd < 0 {
        return Err(io::Error::last_os_error().into());
    }
    // SAFETY: `fd` is a fresh descriptor that nothing else owns.
    let owned = unsafe { OwnedFd::from_raw_fd(fd) };

    let mut info = CtlInfo {
        ctl_id: 0,
        ctl_name: [0; 96],
    };
    for (i, b) in UTUN_CONTROL_NAME.iter().enumerate() {
        info.ctl_name[i] = *b as libc::c_char;
    }
    // SAFETY: `info` has the layout of `struct ctl_info`.
    if unsafe { libc::ioctl(owned.as_raw_fd(), CTLIOCGINFO, &mut info as *mut CtlInfo) } < 0 {
        return Err(io::Error::last_os_error().into());
    }

    // `sc_unit` 0 asks the kernel for the next free utun unit.
    let sc = SockaddrCtl {
        sc_len: std::mem::size_of::<SockaddrCtl>() as u8,
        sc_family: AF_SYSTEM,
        ss_sysaddr: AF_SYS_CONTROL,
        sc_id: info.ctl_id,
        sc_unit: 0,
        sc_reserved: [0; 5],
    };
    // SAFETY: `sc` is a valid sockaddr_ctl of the stated length.
    let rc = unsafe {
        libc::connect(
            owned.as_raw_fd(),
            &sc as *const SockaddrCtl as *const libc::sockaddr,
            std::mem::size_of::<SockaddrCtl>() as libc::socklen_t,
        )
    };
    if rc < 0 {
        return Err(io::Error::last_os_error().into());
    }

    let mut name_buf = [0u8; 64];
    let mut name_len = name_buf.len() as libc::socklen_t;
    // SAFETY: `name_buf` and `name_len` describe a writable buffer of the stated size.
    let rc = unsafe {
        libc::getsockopt(
            owned.as_raw_fd(),
            SYSPROTO_CONTROL,
            UTUN_OPT_IFNAME,
            name_buf.as_mut_ptr().cast(),
            &mut name_len,
        )
    };
    if rc < 0 {
        return Err(io::Error::last_os_error().into());
    }
    // SAFETY: the kernel leaves a NUL-terminated name in the buffer.
    let name = unsafe { CStr::from_ptr(name_buf.as_ptr().cast()) }
        .to_string_lossy()
        .into_owned();
    Ok((owned, name))
}

fn index_of(name: &str) -> Result<u32> {
    let c = CString::new(name).map_err(|e| AetherError::Other(e.to_string()))?;
    // SAFETY: `c` is a valid NUL-terminated string.
    let index = unsafe { libc::if_nametoindex(c.as_ptr()) };
    if index == 0 {
        return Err(AetherError::Other(format!("no interface index for {name}")));
    }
    Ok(index)
}

/// The default IPv4 route as it is before TUN mode touches it, read from `route -n get default`.
pub(super) fn physical_default(iface: &TunIface) -> Result<PhysicalRoute> {
    let out = run("route", &["-n", "get", "default"])?;
    let mut gateway = None;
    let mut ifname = None;
    for line in out.lines() {
        let line = line.trim();
        if let Some(value) = line.strip_prefix("gateway:") {
            gateway = value.trim().parse().ok();
        } else if let Some(value) = line.strip_prefix("interface:") {
            ifname = Some(value.trim().to_string());
        }
    }
    let ifname = ifname.ok_or_else(|| {
        AetherError::Other("no default IPv4 route; TUN mode needs one to reach WARP".into())
    })?;
    if ifname == iface.name {
        return Err(AetherError::Other(format!(
            "the default route already points at {}; remove the stale route first",
            iface.name
        )));
    }
    Ok(PhysicalRoute { gateway, ifname })
}

/// Installs a route. An existing route for the same destination is replaced.
pub(super) fn route_add(route: &NetRoute, iface: &TunIface) -> Result<()> {
    // A route left behind by an earlier run would make `add` fail; remove it first.
    let _ = route_del(route, iface);

    let dest = format!("{}/{}", route.dest, route.prefix);
    let mut args: Vec<&str> = vec!["-n", "add"];
    if is_v6(route.dest) {
        args.push("-inet6");
    }
    args.push("-net");
    args.push(dest.as_str());
    let gateway = match &route.via {
        Via::Physical(physical) => physical.gateway.map(|gw| gw.to_string()),
        Via::Tunnel => None,
    };
    match (&route.via, &gateway) {
        (_, Some(text)) => args.push(text.as_str()),
        (Via::Physical(physical), None) => {
            args.push("-interface");
            args.push(physical.ifname.as_str());
        }
        (Via::Tunnel, None) => {
            args.push("-interface");
            args.push(iface.name.as_str());
        }
    }
    run("route", &args).map(|_| ())
}

pub(super) fn route_del(route: &NetRoute, _iface: &TunIface) -> Result<()> {
    let dest = format!("{}/{}", route.dest, route.prefix);
    let mut args: Vec<&str> = vec!["-n", "delete"];
    if is_v6(route.dest) {
        args.push("-inet6");
    }
    args.push("-net");
    args.push(dest.as_str());
    run("route", &args).map(|_| ())
}

fn is_v6(dest: IpAddr) -> bool {
    matches!(dest, IpAddr::V6(_))
}

/// Runs a system tool and returns its standard output.
fn run(program: &str, args: &[&str]) -> Result<String> {
    let output = Command::new(program)
        .args(args)
        .output()
        .map_err(|e| AetherError::Other(format!("cannot run {program}: {e}")))?;
    if output.status.success() {
        Ok(String::from_utf8_lossy(&output.stdout).into_owned())
    } else {
        let stderr = String::from_utf8_lossy(&output.stderr);
        Err(AetherError::Other(format!(
            "`{program} {}` failed: {}",
            args.join(" "),
            stderr.trim()
        )))
    }
}
