//! Rule sets that come from a file or a URL and are kept up to date.
//!
//! A rule set is a named list of routing rules, written the same way as the rules themselves. The
//! routes file refers to it as `ruleset:TAG` inside a section, so the section's action applies to
//! every rule of the set, and the place of the reference decides where the set sits in the order,
//! as in sing-box.
//!
//! The sources are declared in a TOML file named by `AETHER_RULESETS` (or `--rulesets`):
//!
//! ```toml
//! dir = "rulesets"                       # where downloaded copies are kept, optional
//!
//! [[ruleset]]
//! tag = "ads"
//! url = "https://example.com/ads.txt"    # downloaded and refreshed
//! update = "24h"                         # how often to download again, optional
//!
//! [[ruleset]]
//! tag = "office"
//! path = "office.txt"                    # a local file, relative to this file
//! ```
//!
//! A local file is read again when its modification time changes, checked every fifteen seconds. A
//! remote copy is downloaded at start and then every `update` interval (a day by default, ten
//! minutes at least). Each download is kept in `dir`, so a restart works without the network, and a
//! failed download keeps the copy in use and is tried again ten minutes later. A download that
//! holds no rules at all is never taken over a copy that had rules. Downloads go out from this
//! machine, not through the tunnel.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::{Duration, Instant, SystemTime};

use serde::Deserialize;

use crate::error::{AetherError, Result};
use crate::routing;

const DEFAULT_INTERVAL: Duration = Duration::from_secs(24 * 3600);
const MIN_INTERVAL: Duration = Duration::from_secs(600);
const RETRY_AFTER_FAILURE: Duration = Duration::from_secs(600);
const LOCAL_CHECK: Duration = Duration::from_secs(15);
const DOWNLOAD_TIMEOUT: Duration = Duration::from_secs(60);
/// Largest rule set accepted, so a hostile or broken source cannot fill memory.
const MAX_BYTES: usize = 32 * 1024 * 1024;

#[derive(Deserialize)]
struct FileConfig {
    dir: Option<String>,
    #[serde(default)]
    ruleset: Vec<SourceConfig>,
}

#[derive(Deserialize)]
struct SourceConfig {
    tag: String,
    url: Option<String>,
    path: Option<String>,
    update: Option<String>,
}

enum Origin {
    Local {
        path: PathBuf,
        seen: Option<SystemTime>,
    },
    Remote {
        url: String,
        interval: Duration,
        cache: PathBuf,
    },
}

struct Source {
    tag: String,
    origin: Origin,
    next_due: Instant,
}

/// The text of every loaded rule set, by tag. Rebuilt into the rules whenever one changes.
static TEXTS: Mutex<Option<HashMap<String, String>>> = Mutex::new(None);

fn with_texts<T>(f: impl FnOnce(&mut HashMap<String, String>) -> T) -> T {
    let mut guard = TEXTS.lock().unwrap_or_else(|e| e.into_inner());
    f(guard.get_or_insert_with(HashMap::new))
}

/// The rule set file named by the environment, if one is.
pub fn config_path() -> Option<String> {
    std::env::var("AETHER_RULESETS")
        .ok()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
}

/// Reads the sources, loads every rule set once, and starts the refresh task. A remote set with
/// no copy on disk waits for its first download, which is tried now; if that fails the set is
/// empty until the next try.
pub async fn start(path: &str) -> Result<()> {
    let text = std::fs::read_to_string(path)
        .map_err(|e| AetherError::Other(format!("could not read the rule set file {path}: {e}")))?;
    let file: FileConfig = toml::from_str(&text)
        .map_err(|e| AetherError::Other(format!("the rule set file {path} is malformed: {e}")))?;

    let base = Path::new(path).parent().unwrap_or_else(|| Path::new("."));
    let dir = base.join(file.dir.unwrap_or_else(|| "rulesets".to_string()));
    std::fs::create_dir_all(&dir).map_err(|e| {
        AetherError::Other(format!("could not create the rule set directory {}: {e}", dir.display()))
    })?;

    let now = Instant::now();
    let mut sources: Vec<Source> = Vec::new();
    for config in file.ruleset {
        let tag = config.tag.trim().to_string();
        if tag.is_empty() || sources.iter().any(|source| source.tag == tag) {
            log::warn!("[-] rule set {:?} has no usable tag or repeats one; skipped", config.tag);
            continue;
        }
        let origin = match (config.url, config.path) {
            (Some(url), None) => {
                let interval = match config.update.as_deref() {
                    Some(raw) => parse_interval(raw).unwrap_or_else(|| {
                        log::warn!("[-] rule set {tag}: bad update interval {raw:?}; using 24h");
                        DEFAULT_INTERVAL
                    }),
                    None => DEFAULT_INTERVAL,
                };
                Origin::Remote {
                    url: url.trim().to_string(),
                    interval: interval.max(MIN_INTERVAL),
                    cache: dir.join(format!("{tag}.txt")),
                }
            }
            (None, Some(file_path)) => Origin::Local {
                path: base.join(file_path.trim()),
                seen: None,
            },
            _ => {
                log::warn!("[-] rule set {tag} needs exactly one of url or path; skipped");
                continue;
            }
        };
        sources.push(Source {
            tag,
            origin,
            next_due: now,
        });
    }

    for source in &mut sources {
        load_initial(source).await;
    }
    apply();

    let count = sources.len();
    tokio::spawn(run(sources));
    log::info!("[+] {count} rule set(s) configured from {path}");
    Ok(())
}

/// The first load of a source: a local file is read, a remote one comes from its copy on disk when
/// there is one, and is then downloaded now.
async fn load_initial(source: &mut Source) {
    let tag = source.tag.clone();
    match &mut source.origin {
        Origin::Local { path, seen } => {
            *seen = mtime(path.as_path());
            match std::fs::read_to_string(path.as_path()) {
                Ok(text) => store(&tag, text),
                Err(error) => log::warn!("[-] rule set {tag}: could not read {}: {error}", path.display()),
            }
            source.next_due = Instant::now() + LOCAL_CHECK;
        }
        Origin::Remote { url, interval, cache } => {
            if let Ok(text) = std::fs::read_to_string(&*cache) {
                if routing::count_entries(&text) > 0 {
                    store(&tag, text);
                }
            }
            match fetch(url.as_str()).await {
                Ok(text) => {
                    accept(&tag, cache.as_path(), text);
                    source.next_due = Instant::now() + *interval;
                }
                Err(error) => {
                    log::warn!("[-] rule set {tag}: download failed: {error}");
                    source.next_due = Instant::now() + RETRY_AFTER_FAILURE;
                }
            }
        }
    }
}

/// The refresh loop: local files are checked for changes, remote sets are downloaded when due.
async fn run(mut sources: Vec<Source>) {
    loop {
        tokio::time::sleep(LOCAL_CHECK).await;
        let now = Instant::now();
        for source in sources.iter_mut() {
            if now < source.next_due {
                continue;
            }
            let tag = source.tag.clone();
            match &mut source.origin {
                Origin::Local { path, seen } => {
                    source.next_due = now + LOCAL_CHECK;
                    let current = mtime(path.as_path());
                    if current != *seen {
                        *seen = current;
                        match std::fs::read_to_string(path.as_path()) {
                            Ok(text) => {
                                if accept_text(&tag, &text) {
                                    store(&tag, text);
                                    apply();
                                    log::info!("[+] rule set {tag} reloaded from {}", path.display());
                                }
                            }
                            Err(error) => {
                                log::warn!("[-] rule set {tag}: could not read {}: {error}", path.display())
                            }
                        }
                    }
                }
                Origin::Remote { url, interval, cache } => match fetch(url.as_str()).await {
                    Ok(text) => {
                        accept(&tag, cache.as_path(), text);
                        source.next_due = Instant::now() + *interval;
                    }
                    Err(error) => {
                        log::warn!("[-] rule set {tag}: download failed, keeping the rules in use: {error}");
                        source.next_due = Instant::now() + RETRY_AFTER_FAILURE;
                    }
                },
            }
        }
    }
}

/// Whether a downloaded or read text may replace the copy in use: it must hold rules, unless the
/// copy in use holds none either.
fn accept_text(tag: &str, text: &str) -> bool {
    let rules = routing::count_entries(text);
    let current = with_texts(|texts| texts.get(tag).map(|old| routing::count_entries(old)).unwrap_or(0));
    if rules == 0 && current > 0 {
        log::warn!("[-] rule set {tag}: the new copy holds no rules; keeping the one in use");
        return false;
    }
    true
}

/// Takes a downloaded copy: stores it, writes it to disk, and rebuilds the rules if it changed.
fn accept(tag: &str, cache: &Path, text: String) {
    if !accept_text(tag, &text) {
        return;
    }
    let unchanged = with_texts(|texts| texts.get(tag).map(|old| old == &text).unwrap_or(false));
    if let Err(error) = write_atomically(cache, &text) {
        log::warn!("[-] rule set {tag}: could not keep a copy at {}: {error}", cache.display());
    }
    if !unchanged {
        store(tag, text);
        apply();
        log::info!("[+] rule set {tag} updated");
    }
}

fn store(tag: &str, text: String) {
    with_texts(|texts| {
        texts.insert(tag.to_string(), text);
    });
}

/// Rebuilds the rules from the current texts and tells the TUN policy that they changed.
fn apply() {
    let texts = with_texts(|texts| texts.clone());
    routing::reload(&texts);
    crate::tun::rules_changed();
}

fn write_atomically(path: &Path, text: &str) -> std::io::Result<()> {
    let tmp = path.with_extension("txt.tmp");
    std::fs::write(&tmp, text)?;
    std::fs::rename(&tmp, path)
}

fn mtime(path: &Path) -> Option<SystemTime> {
    std::fs::metadata(path).and_then(|m| m.modified()).ok()
}

/// Downloads a rule set. Only a successful answer with a body counts.
async fn fetch(url: &str) -> Result<String> {
    let client = reqwest::Client::builder()
        .timeout(DOWNLOAD_TIMEOUT)
        .user_agent("aether-ruleset/1")
        .build()
        .map_err(|e| AetherError::Other(format!("could not start the download: {e}")))?;
    let response = client
        .get(url)
        .send()
        .await
        .and_then(|response| response.error_for_status())
        .map_err(|e| AetherError::Other(format!("{url}: {e}")))?;
    let bytes = response
        .bytes()
        .await
        .map_err(|e| AetherError::Other(format!("{url}: {e}")))?;
    if bytes.len() > MAX_BYTES {
        return Err(AetherError::Other(format!("{url}: larger than {MAX_BYTES} bytes")));
    }
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}

/// Reads an interval such as `90s`, `30m`, `12h`, `2d`, or a bare number of seconds.
pub fn parse_interval(raw: &str) -> Option<Duration> {
    let raw = raw.trim().to_lowercase();
    let (digits, unit) = match raw.char_indices().find(|(_, c)| !c.is_ascii_digit()) {
        Some((at, _)) => raw.split_at(at),
        None => (raw.as_str(), "s"),
    };
    let amount: u64 = digits.parse().ok()?;
    let seconds = match unit.trim() {
        "s" | "sec" | "second" | "seconds" => amount,
        "m" | "min" | "minute" | "minutes" => amount.checked_mul(60)?,
        "h" | "hour" | "hours" => amount.checked_mul(3600)?,
        "d" | "day" | "days" => amount.checked_mul(86_400)?,
        _ => return None,
    };
    Some(Duration::from_secs(seconds))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn intervals_accept_units_and_bare_seconds() {
        assert_eq!(parse_interval("90s"), Some(Duration::from_secs(90)));
        assert_eq!(parse_interval("30m"), Some(Duration::from_secs(1800)));
        assert_eq!(parse_interval("12h"), Some(Duration::from_secs(43_200)));
        assert_eq!(parse_interval("2d"), Some(Duration::from_secs(172_800)));
        assert_eq!(parse_interval("600"), Some(Duration::from_secs(600)));
        assert_eq!(parse_interval(" 1H "), Some(Duration::from_secs(3600)));
        assert_eq!(parse_interval("soon"), None);
        assert_eq!(parse_interval("5w"), None);
        assert_eq!(parse_interval(""), None);
    }

    #[test]
    fn the_config_file_parses_into_sources() {
        let text = r#"
dir = "cache"

[[ruleset]]
tag = "ads"
url = "https://example.com/ads.txt"
update = "6h"

[[ruleset]]
tag = "office"
path = "office.txt"
"#;
        let file: FileConfig = toml::from_str(text).unwrap();
        assert_eq!(file.dir.as_deref(), Some("cache"));
        assert_eq!(file.ruleset.len(), 2);
        assert_eq!(file.ruleset[0].tag, "ads");
        assert_eq!(file.ruleset[0].update.as_deref(), Some("6h"));
        assert_eq!(file.ruleset[1].path.as_deref(), Some("office.txt"));
    }

    #[test]
    fn an_empty_copy_never_replaces_one_with_rules() {
        with_texts(|texts| {
            texts.clear();
            texts.insert("guard".to_string(), "ads.example\n".to_string());
        });
        assert!(!accept_text("guard", "# nothing here\n\n"));
        assert!(accept_text("guard", "ads.example\nkeyword:x\n"));
        assert!(accept_text("fresh", "# nothing here\n"));
        with_texts(|texts| texts.clear());
    }
}
