//! TUN mode: the system's own IPv4 traffic goes through the tunnel, while the proxy listeners keep
//! working beside it.
//!
//! A TUN device is opened once per run. When a tunnel comes up, [`split`] puts the device between
//! that tunnel and the proxy stack: packets the system sends are translated to the tunnel's address
//! by [`crate::tunnat`], and the replies come back to it. The stack and the system use separate
//! port ranges on the same address, so each inbound packet goes to exactly one of them. Routes
//! point the system at the device only once the tunnel has been validated, and [`Session`] takes
//! them down again when the tunnel ends.
//!
//! The platform parts are in `tun/`: Linux (`/dev/net/tun`, `ip`), macOS (`utun`, `route`,
//! `ifconfig`) and Windows (WinTUN, `route`, `netsh`). The routes follow geph5's layout: two `/1`
//! routes capture everything without touching the physical default route, and the tunnel's own
//! endpoint and the local networks keep using the physical interface.

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::{Arc, Mutex, MutexGuard, OnceLock};
use std::time::Instant;

use tokio::sync::mpsc;

use crate::error::{AetherError, Result};
use crate::tunnat::{self, Nat};

#[cfg(any(target_os = "linux", target_os = "macos"))]
#[path = "tun/unix.rs"]
mod unix;

#[cfg(target_os = "linux")]
#[path = "tun/linux.rs"]
mod native;

#[cfg(target_os = "macos")]
#[path = "tun/macos.rs"]
mod native;

#[cfg(target_os = "windows")]
#[path = "tun/windows.rs"]
mod native;

#[cfg(not(any(target_os = "linux", target_os = "macos", target_os = "windows")))]
#[path = "tun/unsupported.rs"]
mod native;

mod packet;
mod policy;

const QUEUE: usize = 1024;

/// The address the system uses on the device. It is in the range reserved for benchmarking, so it
/// does not clash with a real network.
pub(crate) const SYSTEM_ADDR: Ipv4Addr = Ipv4Addr::new(198, 18, 0, 1);

/// Networks that stay on the local network instead of going into the tunnel.
const LOCAL_NETS: [(Ipv4Addr, u8); 3] = [
    (Ipv4Addr::new(10, 0, 0, 0), 8),
    (Ipv4Addr::new(172, 16, 0, 0), 12),
    (Ipv4Addr::new(192, 168, 0, 0), 16),
];

/// Whether TUN mode was asked for, by `--tun` or `AETHER_TUN`.
pub fn enabled() -> bool {
    matches!(
        std::env::var("AETHER_TUN").as_deref().map(str::trim),
        Ok("1") | Ok("true") | Ok("yes") | Ok("on")
    )
}

/// The device as the system names it. `index` is the interface index the platform tools use.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct TunIface {
    pub name: String,
    pub index: u32,
}

/// The physical default route, as it is before TUN mode touches it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct PhysicalRoute {
    pub gateway: Option<Ipv4Addr>,
    pub ifname: String,
}

/// Where a route sends packets: out of the physical interface, or into the device.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum Via {
    Physical(PhysicalRoute),
    Tunnel,
}

/// A route TUN mode installs. Installing and removing it is platform-specific.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct NetRoute {
    pub dest: IpAddr,
    pub prefix: u8,
    pub via: Via,
}

/// Packets the system sent into the device, waiting for the session that carries them.
pub(crate) type FromOs = Arc<Mutex<Option<mpsc::Sender<Vec<u8>>>>>;

static DEVICE: OnceLock<Arc<Device>> = OnceLock::new();

/// Every route this process has added and not yet removed. Read when the process is stopped, so
/// that the system is not left sending its traffic to a device that is gone.
static INSTALLED: Mutex<Vec<NetRoute>> = Mutex::new(Vec::new());

fn locked<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

/// The open device. Packets the system sends come out of `from_os` while a session holds it, and
/// packets for the system are written to `to_os`.
pub(crate) struct Device {
    pub(crate) iface: TunIface,
    to_os: mpsc::Sender<Vec<u8>>,
    from_os: FromOs,
    _native: native::Native,
    /// The routing rules applied to the system's packets, see `policy`.
    policy: Arc<policy::Policy>,
}

/// Hands a packet the system sent to the session that is currently attached, if any. Under
/// pressure the packet is dropped, as the network would drop it.
pub(crate) fn deliver(from_os: &FromOs, packet: Vec<u8>) {
    let sink = locked(from_os).clone();
    if let Some(sink) = sink {
        let _ = sink.try_send(packet);
    }
}

/// Opens the TUN device, once per run, and sets its address and MTU. The device carries no routes
/// yet, so the system's traffic is unchanged until a tunnel is up.
pub async fn open(mtu: usize) -> Result<()> {
    if DEVICE.get().is_some() {
        return Ok(());
    }
    let from_os: FromOs = Arc::new(Mutex::new(None));
    let (to_os, to_os_rx) = mpsc::channel(QUEUE);
    let (name, index, native) = native::open(mtu, Arc::clone(&from_os), to_os_rx)?;
    log::info!(
        "[+] tun device {name} is up (mtu {mtu}); traffic is sent through it once a tunnel is up"
    );
    let iface = TunIface { name, index };
    let policy = Arc::new(policy::Policy::new(iface.clone()));
    let device = Arc::new(Device {
        iface,
        to_os,
        from_os,
        _native: native,
        policy,
    });
    let _ = DEVICE.set(device);
    Ok(())
}

/// Makes sure that the routes this process added are removed when the process is stopped by a
/// signal. Call once, after [`open`].
pub fn remove_routes_on_signal() {
    tokio::spawn(async {
        wait_for_stop().await;
        log::info!("[*] stopping: removing the tun routes first");
        restore_routes();
        std::process::exit(130);
    });
}

#[cfg(unix)]
async fn wait_for_stop() {
    use tokio::signal::unix::{signal, SignalKind};
    let mut terminate = signal(SignalKind::terminate()).ok();
    tokio::select! {
        _ = tokio::signal::ctrl_c() => {}
        _ = async {
            match terminate.as_mut() {
                Some(stream) => {
                    stream.recv().await;
                }
                None => std::future::pending::<()>().await,
            }
        } => {}
    }
}

#[cfg(not(unix))]
async fn wait_for_stop() {
    let _ = tokio::signal::ctrl_c().await;
}

/// Called when the routing rules change: the routes for the address ranges the rules send direct
/// follow them. Without a device there is nothing to do.
pub fn rules_changed() {
    if let Some(device) = DEVICE.get() {
        device.policy.refresh();
    }
}

/// Removes every route this process still has installed, newest first.
pub fn restore_routes() {
    let Some(device) = DEVICE.get() else {
        return;
    };
    let pending = std::mem::take(&mut *locked(&INSTALLED));
    for route in pending.iter().rev() {
        if let Err(e) = native::route_del(route, &device.iface) {
            log::warn!("[-] could not remove a tun route: {e}");
        }
    }
}

/// Points the proxy stack's traffic and the system's traffic at a tunnel. Returns the receiver the
/// proxy stack should read in place of `inbound`, and the session that carries the system's share;
/// without a device both are unchanged.
///
/// `outbound` is where packets for the tunnel go, `ipv4` is the address WARP assigned to the
/// device. Call this before the tunnel starts, so that no inbound packet is missed.
pub fn split(
    outbound: mpsc::Sender<Vec<u8>>,
    inbound: mpsc::Receiver<Vec<u8>>,
    ipv4: Ipv4Addr,
) -> (mpsc::Receiver<Vec<u8>>, Option<Session>) {
    let Some(device) = DEVICE.get().cloned() else {
        return (inbound, None);
    };

    let (os_tx, mut os_rx) = mpsc::channel::<Vec<u8>>(QUEUE);
    let (stack_tx, stack_rx) = mpsc::channel::<Vec<u8>>(QUEUE);
    let nat = Arc::new(Mutex::new(Nat::new(ipv4)));
    *locked(&device.from_os) = Some(os_tx);

    let out_policy = Arc::clone(&device.policy);
    let out_nat = Arc::clone(&nat);
    let out_task = tokio::spawn(async move {
        while let Some(mut pkt) = os_rx.recv().await {
            if !out_policy.allow(&pkt, Instant::now()) {
                continue;
            }
            let keep = locked(&out_nat).outbound(&mut pkt, Instant::now());
            if keep && outbound.send(pkt).await.is_err() {
                break;
            }
        }
    });

    let to_os = device.to_os.clone();
    let in_nat = Arc::clone(&nat);
    let in_policy = Arc::clone(&device.policy);
    let in_task = tokio::spawn(async move {
        let mut inbound = inbound;
        while let Some(mut pkt) = inbound.recv().await {
            if tunnat::belongs_to_system(&pkt) {
                in_policy.observe(&pkt, Instant::now());
                let keep = locked(&in_nat).inbound(&mut pkt, Instant::now());
                if keep {
                    let _ = to_os.try_send(pkt);
                }
            } else if stack_tx.send(pkt).await.is_err() {
                break;
            }
        }
    });

    let session = Session {
        device,
        tasks: vec![out_task, in_task],
        routes: Mutex::new(Vec::new()),
    };
    (stack_rx, Some(session))
}

/// Destinations that stay off the tunnel: the tunnel's own endpoint, and the local networks.
/// Everything else is covered by the capture routes.
fn bypass_routes(endpoint: Ipv4Addr, physical: PhysicalRoute) -> Vec<NetRoute> {
    let via = Via::Physical(physical);
    let mut routes = vec![NetRoute {
        dest: IpAddr::V4(endpoint),
        prefix: 32,
        via: via.clone(),
    }];
    for (net, prefix) in LOCAL_NETS {
        routes.push(NetRoute {
            dest: IpAddr::V4(net),
            prefix,
            via: via.clone(),
        });
    }
    routes
}

/// The split routes that capture the system's traffic. IPv6 is captured too, and then dropped: the
/// NAT only translates IPv4, so IPv6 is blackholed rather than left to bypass the tunnel.
fn capture_routes() -> Vec<NetRoute> {
    let v4 = [Ipv4Addr::UNSPECIFIED, Ipv4Addr::new(128, 0, 0, 0)];
    let v6 = [
        Ipv6Addr::UNSPECIFIED,
        Ipv6Addr::new(0x8000, 0, 0, 0, 0, 0, 0, 0),
    ];
    v4.into_iter()
        .map(|net| NetRoute {
            dest: IpAddr::V4(net),
            prefix: 1,
            via: Via::Tunnel,
        })
        .chain(v6.into_iter().map(|net| NetRoute {
            dest: IpAddr::V6(net),
            prefix: 1,
            via: Via::Tunnel,
        }))
        .collect()
}

/// One tunnel's share of the system's traffic: its packet tasks, and the routes that send traffic
/// into the device while the tunnel lives.
pub struct Session {
    device: Arc<Device>,
    tasks: Vec<tokio::task::JoinHandle<()>>,
    /// The routes this session added, in the order they were added.
    routes: Mutex<Vec<NetRoute>>,
}

impl Session {
    /// Sends the system's traffic into the device, keeping the tunnel's own packets and the local
    /// network on the physical interface. Call this once the tunnel has been validated. The
    /// endpoint must be IPv4.
    pub fn activate(&self, endpoint: IpAddr) -> Result<()> {
        let IpAddr::V4(endpoint) = endpoint else {
            return Err(AetherError::Other(
                "TUN mode needs an IPv4 WARP endpoint; the chosen endpoint is IPv6".into(),
            ));
        };
        let iface = &self.device.iface;
        let physical = native::physical_default(iface)?;

        let mut routes = bypass_routes(endpoint, physical);
        routes.extend(capture_routes());

        let mut added: Vec<NetRoute> = Vec::new();
        for route in routes {
            if let Err(e) = native::route_add(&route, iface) {
                for done in added.iter().rev() {
                    let _ = native::route_del(done, iface);
                }
                return Err(e);
            }
            added.push(route);
        }

        locked(&INSTALLED).extend(added.iter().cloned());
        *locked(&self.routes) = added;
        self.device.policy.refresh();
        log::info!("[+] tun: system traffic now goes through {}", iface.name);
        Ok(())
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        for task in &self.tasks {
            task.abort();
        }
        *locked(&self.device.from_os) = None;

        let routes = std::mem::take(&mut *locked(&self.routes));
        for route in routes.iter().rev() {
            if let Err(e) = native::route_del(route, &self.device.iface) {
                log::warn!("[-] could not remove a tun route: {e}");
            }
        }
        locked(&INSTALLED).retain(|installed| !routes.contains(installed));
    }
}

/// The netmask of an IPv4 prefix, for the tools that take a mask rather than a length.
#[cfg(target_os = "windows")]
pub(crate) fn v4_mask(prefix: u8) -> Ipv4Addr {
    if prefix == 0 {
        Ipv4Addr::UNSPECIFIED
    } else {
        Ipv4Addr::from(u32::MAX << (32 - u32::from(prefix)))
    }
}
