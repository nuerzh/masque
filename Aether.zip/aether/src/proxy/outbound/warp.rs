//! `warp`: the WARP tunnel stack (MASQUE over HTTP/3 or HTTP/2), and only that.

use crate::proxy::prelude::*;

pub(crate) struct WarpOutbound;

impl AnyOutbound for WarpOutbound {
    fn tag(&self) -> &str {
        "warp"
    }

    fn via(&self) -> Via {
        Via::Warp
    }

    fn needs_warp(&self) -> bool {
        true
    }

    fn connect_stream<'a>(&'a self, req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>> {
        Box::pin(async move {
            let stack = req.exit.stack_soon("outbound warp").await?;
            let (host, port) = (req.host, req.port);
            let target = match req.resolved.first() {
                Some(ip) if host.parse::<IpAddr>().is_err() && gateway_proxy().filter(|_| should_use_gateway(port)).is_none() => Target::Ip(*ip),
                _ => match host.parse::<IpAddr>() {
                    Ok(ip) => Target::Ip(ip),
                    Err(_) => Target::Domain(host.to_string()),
                },
            };
            let (s, r, left) = open_tunneled(&stack, target, port).await?;
            Ok(Upstream::Tunnel(s, r, left))
        })
    }

    fn connect_packet(&self, req: PacketRequest<'_>) -> FlowRoute {
        FlowRoute::Warp(flow_addr(req.meta, req.ropts))
    }
}
