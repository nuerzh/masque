//! The sunnyquic client's udp socket, straight on the outer MASQUE tunnel's netstack.
//!
//! noq takes any `AsyncUdpSocket`; this one sends each datagram through a udp socket of the
//! current outer tunnel's netstack and hands back what that socket receives. Nothing is bound
//! on the machine. The outer tunnel changes as Aether reconnects; `attach` re-points the socket
//! at each new one, and the QUIC connection rides on (or the client redials it).
//!
//! noq always addresses the server as `nominal` (the address the client was configured with);
//! the datagrams go to wherever the server is now (`attach`'s `remote`, a fresh lookup of its
//! name), and its answers are handed to noq as coming from `nominal`.

use std::collections::VecDeque;
use std::fmt;
use std::io::{self, IoSliceMut};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll, Waker};

use noq::udp::{RecvMeta, Transmit};
use noq::{AsyncUdpSocket, UdpSender};
use parking_lot::Mutex;
use tokio::sync::{mpsc, Notify};

use crate::error::Result;
use crate::transport::warp::netstack::StackHandle;

/// Datagrams waiting for the netstack before senders are made to wait.
const SEND_QUEUE: usize = 1024;
/// Datagrams from the server waiting for noq before newer ones are dropped.
const RECV_QUEUE: usize = 2048;

struct Outgoing {
    queue: VecDeque<Vec<u8>>,
    waiting: Vec<Waker>,
}

struct Shared {
    nominal: SocketAddr,
    out: Mutex<Outgoing>,
    pump: Notify,
    link: Mutex<Option<(Arc<crate::transport::warp::netstack::UdpSender>, SocketAddr)>>,
    to_noq: mpsc::Sender<Vec<u8>>,
}

/// The handle Aether keeps: attach each outer tunnel to it.
#[derive(Clone)]
pub struct TunnelLink {
    shared: Arc<Shared>,
}

/// The socket handed to noq (once, when the endpoint is built).
pub struct TunnelSocket {
    shared: Arc<Shared>,
    from_net: mpsc::Receiver<Vec<u8>>,
}

impl fmt::Debug for TunnelSocket {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("TunnelSocket").field("nominal", &self.shared.nominal).finish()
    }
}

/// A socket whose datagrams to `nominal` travel through whatever tunnel is attached, and the
/// link to attach tunnels with. Must be called inside the tokio runtime (it starts the pump).
pub fn pair(nominal: SocketAddr) -> (TunnelSocket, TunnelLink) {
    let (to_noq, from_net) = mpsc::channel(RECV_QUEUE);
    let shared = Arc::new(Shared {
        nominal,
        out: Mutex::new(Outgoing { queue: VecDeque::new(), waiting: Vec::new() }),
        pump: Notify::new(),
        link: Mutex::new(None),
        to_noq,
    });
    tokio::spawn(pump(Arc::downgrade(&shared)));
    (TunnelSocket { shared: shared.clone(), from_net }, TunnelLink { shared })
}

/// Carry the queued datagrams into the attached tunnel, in order, waiting on the netstack
/// rather than dropping when it is busy. Ends when the socket and the link are both gone.
async fn pump(shared: std::sync::Weak<Shared>) {
    loop {
        let Some(s) = shared.upgrade() else { return };
        let batch: Vec<Vec<u8>> = {
            let mut out = s.out.lock();
            let batch = out.queue.drain(..).collect();
            for w in out.waiting.drain(..) {
                w.wake();
            }
            batch
        };
        if batch.is_empty() {
            // notify_one leaves a permit when nobody waits, so a datagram queued in between
            // is not missed; the timeout lets the pump end once the socket is gone
            let _ = tokio::time::timeout(std::time::Duration::from_secs(5), s.pump.notified()).await;
            drop(s);
            continue;
        }
        let link = s.link.lock().clone();
        match link {
            Some((tx, remote)) => {
                for data in batch {
                    crate::utils::stats::add_up(data.len());
                    if tx.send_to(remote, data).await.is_err() {
                        log::debug!("[sunnyquic] sunny: the outer tunnel went away mid-send");
                        break;
                    }
                }
            }
            None => log::trace!("[sunnyquic] sunny: no outer tunnel at the moment, dropped {} datagrams", batch.len()),
        }
    }
}

impl TunnelLink {
    /// Carry the socket through `stack` to the server at `remote`, until the guard is dropped.
    pub async fn attach(&self, stack: &StackHandle, remote: SocketAddr) -> Result<Attached> {
        let udp = stack.open_udp().await?;
        let (tx, mut rx) = udp.into_split();
        *self.shared.link.lock() = Some((Arc::new(tx), remote));
        self.shared.pump.notify_one();
        let to_noq = self.shared.to_noq.clone();
        let down = tokio::spawn(async move {
            while let Some((src, data)) = rx.recv().await {
                if src != remote {
                    continue;
                }
                crate::utils::stats::add_down(data.len());
                // a full queue means noq is behind: drop, as a busy udp socket would
                let _ = to_noq.try_send(data);
            }
        });
        Ok(Attached { shared: self.shared.clone(), down: down.abort_handle() })
    }
}

pub struct Attached {
    shared: Arc<Shared>,
    down: tokio::task::AbortHandle,
}

impl Drop for Attached {
    fn drop(&mut self) {
        self.down.abort();
        *self.shared.link.lock() = None;
    }
}

struct Sender {
    shared: Arc<Shared>,
}

impl fmt::Debug for Sender {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TunnelSocket sender")
    }
}

impl UdpSender for Sender {
    fn poll_send(self: Pin<&mut Self>, t: &Transmit<'_>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        let mut out = self.shared.out.lock();
        if out.queue.len() >= SEND_QUEUE {
            out.waiting.push(cx.waker().clone());
            drop(out);
            self.shared.pump.notify_one();
            return Poll::Pending;
        }
        // max_transmit_segments is 1, but split a batch anyway rather than send it whole
        match t.segment_size {
            Some(size) if size > 0 && size < t.contents.len() => {
                for seg in t.contents.chunks(size) {
                    out.queue.push_back(seg.to_vec());
                }
            }
            _ => out.queue.push_back(t.contents.to_vec()),
        }
        drop(out);
        self.shared.pump.notify_one();
        Poll::Ready(Ok(()))
    }
}

impl AsyncUdpSocket for TunnelSocket {
    fn create_sender(&self) -> Pin<Box<dyn UdpSender>> {
        Box::pin(Sender { shared: self.shared.clone() })
    }

    fn poll_recv(&mut self, cx: &mut Context<'_>, bufs: &mut [IoSliceMut<'_>], meta: &mut [RecvMeta]) -> Poll<io::Result<usize>> {
        let mut filled = 0;
        while filled < bufs.len().min(meta.len()) {
            let next = if filled == 0 {
                match self.from_net.poll_recv(cx) {
                    Poll::Ready(Some(d)) => d,
                    Poll::Ready(None) => return Poll::Ready(Err(io::Error::other("the sunny socket closed"))),
                    Poll::Pending => return Poll::Pending,
                }
            } else {
                match self.from_net.try_recv() {
                    Ok(d) => d,
                    Err(_) => break,
                }
            };
            let buf = &mut bufs[filled];
            let len = next.len().min(buf.len());
            buf[..len].copy_from_slice(&next[..len]);
            let mut m = RecvMeta::default();
            m.addr = self.shared.nominal;
            m.len = len;
            m.stride = len;
            meta[filled] = m;
            filled += 1;
        }
        Poll::Ready(Ok(filled))
    }

    fn local_addr(&self) -> io::Result<SocketAddr> {
        // only the family matters to noq; nothing is bound
        Ok(match self.shared.nominal.ip() {
            IpAddr::V4(_) => SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0),
            IpAddr::V6(_) => SocketAddr::new(IpAddr::V6(Ipv6Addr::UNSPECIFIED), 0),
        })
    }

    fn may_fragment(&self) -> bool {
        // the tunnel never fragments: a datagram larger than it carries is dropped, which is
        // what path MTU discovery needs to see
        false
    }
}
