//! The settings of a sunnyquic client: from the `sunny` mapping of the config file (or the file
//! sunny-config names; `Settings::resolve` / `from_env`), or from an `outbounds` entry of type
//! `sunnyquic` written as sing-box writes its outbounds (`parse`).

use std::net::{IpAddr, SocketAddr};
use std::path::Path;
use std::time::Duration;

use serde_json::Value;

use crate::error::{AetherError, Result};

/// Everything the sunny client is configured with: the `sunny` mapping of the config file, or
/// the YAML file sunny-config names.
#[derive(Debug, Clone)]
#[cfg_attr(not(feature = "sunny"), expect(dead_code, reason = "read and checked without the sunny feature too, used only with it"))]
pub struct Settings {
    /// host of the sunnyquic server, a name or an address, without brackets
    pub host: String,
    pub port: u16,
    pub username: String,
    pub password: String,
    /// the server name in the ClientHello, and the name its certificate is checked against
    pub server_name: String,
    pub alpn: Vec<String>,
    /// an extra CA (or self-signed certificate) to trust besides the system's roots
    pub ca: Option<std::path::PathBuf>,
    pub zero_rtt: bool,
    /// bbr, bbr3, cubic, new-reno; brutal only through the config file
    pub congestion: CongestionChoice,
    pub over_stream: bool,
    pub initial_mtu: Option<u16>,
    pub min_mtu: Option<u16>,
    pub mtu_discovery: bool,
    pub keep_alive_ms: u32,
    pub gso: bool,
    pub handshake: Duration,
    pub data_check: bool,
    /// cipher-suite-preference from the config file, kept as toml until the client is built
    pub cipher_suites: Option<toml::Value>,
}

#[derive(Debug, Clone)]
pub enum CongestionChoice {
    Named(String),
    /// the whole `congestion-control` value of the config file, e.g. a brutal table
    #[cfg_attr(not(feature = "sunny"), expect(dead_code, reason = "read and checked without the sunny feature too, used only with it"))]
    Raw(toml::Value),
}

const DEFAULT_KEEPALIVE_MS: u32 = 10_000;
const DEFAULT_HANDSHAKE_SECS: u64 = 15;

fn env(key: &str) -> Option<String> {
    if key.is_empty() {
        return None;
    }
    crate::config::settings::var(key)
        .ok()
        .map(|v| v.trim().to_string())
        .filter(|v| !v.is_empty())
}

fn parse_bool(key: &str, value: &str) -> Result<bool> {
    match value.trim().to_ascii_lowercase().as_str() {
        "1" | "true" | "yes" | "on" => Ok(true),
        "0" | "false" | "no" | "off" => Ok(false),
        other => Err(AetherError::Other(format!(
            "{key}: '{other}' is not a yes or no; use 1 or 0"
        ))),
    }
}

/// `host:port`, `[v6]:port`. The port is required, as for every other endpoint aether takes.
pub fn split_server(raw: &str) -> Result<(String, u16)> {
    let raw = raw.trim();
    let bad = || {
        AetherError::Other(format!(
            "sunny server '{raw}' is not host:port; e.g. sq.example.com:443 or 203.0.113.7:443 or \
             \"[2001:db8::7]:443\" (quoted in YAML)"
        ))
    };
    if let Ok(addr) = raw.parse::<SocketAddr>() {
        return Ok((addr.ip().to_string(), addr.port()));
    }
    let (host, port) = raw.rsplit_once(':').ok_or_else(bad)?;
    let port: u16 = port.parse().map_err(|_| bad())?;
    // An IPv6 address takes brackets, or its last group would be read as the port.
    if host.contains(':') && !(host.starts_with('[') && host.ends_with(']')) {
        return Err(bad());
    }
    let host = host.trim_start_matches('[').trim_end_matches(']');
    if host.is_empty() || port == 0 || host.contains(':') && host.parse::<IpAddr>().is_err() {
        return Err(bad());
    }
    if host.parse::<IpAddr>().is_err() && !crate::dns::valid_domain(host) {
        return Err(bad());
    }
    Ok((host.to_string(), port))
}

/// What the config file holds, the keys of a shadowquic `type: sunnyquic` outbound written in
/// YAML (`addr` or `server`, `username`, `password`, `server-name`, `alpn`, `cert-path` or `ca`, ...).
fn read_file(path: &str) -> Result<toml::Table> {
    let text = std::fs::read_to_string(path)
        .map_err(|e| AetherError::Other(format!("sunny-config {path}: {e}")))?;
    let table: toml::Table = crate::config::file::parse_table(&text)
        .map_err(|e| AetherError::Other(format!("sunny-config {path}: {e}")))?;
    // A file may keep the settings under sunny or sunnyquic, or at the top.
    for section in ["sunny", "sunnyquic"] {
        if let Some(toml::Value::Table(inner)) = table.get(section) {
            return Ok(inner.clone());
        }
    }
    Ok(table)
}

/// The keys with `_` read as `-` (`server_name` is `server-name`), as the rest of the config
/// file writes its keys the sing-box way.
fn normalize_keys(table: toml::Table, path: &str) -> Result<toml::Table> {
    let mut out = toml::Table::new();
    for (key, value) in table {
        let k = key.replace('_', "-");
        if out.insert(k.clone(), value).is_some() {
            return Err(AetherError::Other(format!("{path}: {k} is given twice (with - and with _)")));
        }
    }
    Ok(out)
}

const FILE_KEYS: &[&str] = &[
    "addr",
    "server",
    "username",
    "user",
    "password",
    "server-name",
    "sni",
    "alpn",
    "cert-path",
    "ca",
    "zero-rtt",
    "congestion-control",
    "over-stream",
    "initial-mtu",
    "min-mtu",
    "mtu-discovery",
    "keep-alive-interval",
    "gso",
    "cipher-suite-preference",
    "handshake-secs",
    "data-check",
    "no-data-check",
    "tag",
    "detour",
];

const REMOVED_HALF_CLOSE_KEY: &str = "half-close-timeout";
const REMOVED_HALF_CLOSE_VAR: &str = "AETHER_SUNNY_HALF_CLOSE_MS";

fn warn_half_close_removed(what: &str) {
    static ONCE: std::sync::Once = std::sync::Once::new();
    ONCE.call_once(|| {
        log::warn!(
            "[sunnyquic] {what} was removed and is ignored: a half-closed connection ends after AETHER_HALF_CLOSE_SECS"
        )
    });
}

struct Source {
    file: toml::Table,
    path: String,
    /// the directory of the file, where a relative `ca` is looked for
    dir: std::path::PathBuf,
}

/// What was asked for on a terminal because nothing else gave it.
#[derive(Default)]
struct Asked {
    server: Option<String>,
    username: Option<String>,
    password: Option<String>,
    server_name: Option<String>,
}

impl Source {
    /// The flags and AETHER_SUNNY_* (read as they are asked for) over --sunny-config, or
    /// without it over the `[sunny]` table of the config file.
    fn load() -> Result<Source> {
        use crate::config::file::{base_dir, main_path, sunny_table};
        let (file, path, dir) = match env("AETHER_SUNNY_CONFIG") {
            Some(p) => (read_file(&p)?, p.clone(), base_dir(Path::new(&p))),
            None => match sunny_table().map_err(AetherError::Other)? {
                Some((table, what)) => (table, what, base_dir(Path::new(&main_path()))),
                None => (toml::Table::new(), String::new(), Default::default()),
            },
        };
        Source::from_table(file, path, dir)
    }

    fn from_table(file: toml::Table, path: String, dir: std::path::PathBuf) -> Result<Source> {
        let mut file = normalize_keys(file, &path)?;
        // Removed in 2.3; an old config that still names it must keep starting.
        if file.remove(REMOVED_HALF_CLOSE_KEY).is_some() {
            warn_half_close_removed(&format!("{path}: {REMOVED_HALF_CLOSE_KEY}"));
        }
        for key in file.keys() {
            if !FILE_KEYS.contains(&key.as_str()) {
                return Err(AetherError::Other(format!(
                    "{path}: unknown key '{key}'; known keys: {}",
                    FILE_KEYS.join(", ")
                )));
            }
        }
        Ok(Source { file, path, dir })
    }

    fn string(&self, env_key: &str, keys: &[&str]) -> Result<Option<String>> {
        if let Some(v) = env(env_key) {
            return Ok(Some(v));
        }
        for key in keys {
            match self.file.get(*key) {
                Some(toml::Value::String(s)) => return Ok(Some(s.clone())),
                Some(toml::Value::Integer(i)) => return Ok(Some(i.to_string())),
                Some(toml::Value::Boolean(b)) => return Ok(Some(b.to_string())),
                Some(other) => {
                    return Err(AetherError::Other(format!(
                        "{}: {key} = {other} is not a plain value",
                        self.path
                    )))
                }
                None => {}
            }
        }
        Ok(None)
    }

    fn boolean(&self, env_key: &str, key: &str, default: bool) -> Result<bool> {
        match self.string(env_key, &[key])? {
            Some(v) => parse_bool(env_key, &v),
            None => Ok(default),
        }
    }

    fn number<T: std::str::FromStr>(&self, env_key: &str, key: &str) -> Result<Option<T>> {
        match self.string(env_key, &[key])? {
            Some(v) => v.parse::<T>().map(Some).map_err(|_| {
                AetherError::Other(format!("{env_key} / {key}: '{v}' is not a number in range"))
            }),
            None => Ok(None),
        }
    }
}

/// How the `sunny` outbound (the client of --sunny) reaches its server: --sunny-detour /
/// AETHER_SUNNY_DETOUR, else `detour` in --sunny-config or the [sunny] table, else `direct`.
/// Read when the run starts; a value other than direct or warp stops it there.
pub fn detour() -> Result<Detour> {
    if let Some(v) = env("AETHER_SUNNY_DETOUR") {
        return Detour::parse(&v)
            .ok_or_else(|| AetherError::Other(format!("sunny.detour {v:?}: use direct or warp")));
    }
    let src = Source::load()?;
    match src.string("", &["detour"])? {
        None => Ok(Detour::Direct),
        Some(v) => Detour::parse(&v)
            .ok_or_else(|| AetherError::Other(format!("{}: detour = {v:?}: use \"direct\" or \"warp\"", src.path))),
    }
}

/// Whether --sunny-config, or without it the [sunny] table of the config file, names a server.
/// An unreadable file counts as none here; reading the settings reports it.
pub fn server_in_config() -> bool {
    Source::load().is_ok_and(|src| src.file.contains_key("server") || src.file.contains_key("addr"))
}

impl Settings {
    /// Read the settings, asking on a terminal for the three that have no default (server,
    /// username, password) when nothing gave them.
    pub async fn resolve() -> Result<Settings> {
        let src = Source::load()?;
        let mut asked = Asked::default();
        if src.string("AETHER_SUNNY_SERVER", &["server", "addr"])?.is_none() {
            asked.server = crate::config::mode::prompt_line("\nsunnyquic server (host:port, e.g. sq.example.com:443): ")
                .await
                .filter(|s| !s.is_empty());
        }
        if src.string("AETHER_SUNNY_USER", &["username", "user"])?.is_none() {
            asked.username = crate::config::mode::prompt_line("sunnyquic username: ").await.filter(|s| !s.is_empty());
        }
        if src.string("AETHER_SUNNY_PASSWORD", &["password"])?.is_none() {
            asked.password = crate::config::mode::prompt_line("sunnyquic password: ").await.filter(|s| !s.is_empty());
        }
        if src.string("AETHER_SUNNY_SNI", &["server-name", "sni"])?.is_none() {
            let server = src.string("AETHER_SUNNY_SERVER", &["server", "addr"])?.or(asked.server.clone());
            if let Some((host, _)) = server.as_deref().and_then(|s| split_server(s).ok()) {
                if host.parse::<IpAddr>().is_ok() {
                    asked.server_name = crate::config::mode::prompt_line(&format!(
                        "sunnyquic server name, the one its certificate is for (default {host}): "
                    ))
                    .await
                    .filter(|s| !s.is_empty());
                }
            }
        }
        Settings::build(&src, asked)
    }

    /// The same settings, never asking: what is missing is an error (`sunny-direct`).
    pub fn from_env() -> Result<Settings> {
        Settings::build(&Source::load()?, Asked::default())
    }

    /// Everything but the server, the user and the password at its default.
    pub fn basic(host: &str, port: u16, username: &str, password: &str) -> Settings {
        Settings {
            host: host.trim_start_matches('[').trim_end_matches(']').to_string(),
            port,
            username: username.to_string(),
            password: password.to_string(),
            server_name: host.trim_start_matches('[').trim_end_matches(']').to_string(),
            alpn: vec!["h3".to_string()],
            ca: None,
            zero_rtt: true,
            congestion: CongestionChoice::Named("bbr".into()),
            over_stream: false,
            initial_mtu: None,
            min_mtu: None,
            mtu_discovery: false,
            keep_alive_ms: DEFAULT_KEEPALIVE_MS,
            gso: true,
            handshake: Duration::from_secs(DEFAULT_HANDSHAKE_SECS),
            data_check: false,
            cipher_suites: None,
        }
    }

    fn build(src: &Source, asked: Asked) -> Result<Settings> {
        if env(REMOVED_HALF_CLOSE_VAR).is_some() {
            warn_half_close_removed(REMOVED_HALF_CLOSE_VAR);
        }
        let server = src
            .string("AETHER_SUNNY_SERVER", &["server", "addr"])?
            .or(asked.server)
            .ok_or_else(|| missing("server"))?;
        let (host, port) = split_server(&server)?;
        let username = src
            .string("AETHER_SUNNY_USER", &["username", "user"])?
            .or(asked.username)
            .ok_or_else(|| missing("username"))?;
        let password = src
            .string("AETHER_SUNNY_PASSWORD", &["password"])?
            .or(asked.password)
            .ok_or_else(|| missing("password"))?;
        let server_name = src
            .string("AETHER_SUNNY_SNI", &["server-name", "sni"])?
            .or(asked.server_name)
            .unwrap_or_else(|| host.clone());

        let alpn = match env("AETHER_SUNNY_ALPN") {
            Some(v) => split_list(&v),
            None => match src.file.get("alpn") {
                Some(toml::Value::Array(items)) => items
                    .iter()
                    .filter_map(|v| v.as_str().map(str::to_string))
                    .collect(),
                Some(toml::Value::String(s)) => split_list(s),
                Some(other) => {
                    return Err(AetherError::Other(format!(
                        "{}: alpn = {other} is not a list of names",
                        src.path
                    )))
                }
                None => vec!["h3".to_string()],
            },
        };
        if alpn.is_empty() {
            return Err(AetherError::Other(
                "sunny.alpn is empty; the server needs at least one name in common, h3 by default"
                    .into(),
            ));
        }

        let ca = match env("AETHER_SUNNY_CA") {
            Some(v) => Some(std::path::PathBuf::from(v)),
            None => src.string("", &["ca", "cert-path"])?.map(|v| {
                let given = std::path::PathBuf::from(&v);
                let beside = src.dir.join(&given);
                if given.is_relative() && !given.is_file() && beside.is_file() {
                    beside
                } else {
                    given
                }
            }),
        };
        if let Some(ca) = &ca {
            if !ca.is_file() {
                return Err(AetherError::Other(format!(
                    "sunny.ca {}: no such file",
                    ca.display()
                )));
            }
        }

        let congestion = match env("AETHER_SUNNY_CC") {
            Some(v) => CongestionChoice::Named(v.to_ascii_lowercase()),
            None => match src.file.get("congestion-control") {
                Some(toml::Value::String(s)) => CongestionChoice::Named(s.to_ascii_lowercase()),
                Some(v) => CongestionChoice::Raw(v.clone()),
                None => CongestionChoice::Named("bbr".into()),
            },
        };
        if let CongestionChoice::Named(name) = &congestion {
            if !matches!(
                name.as_str(),
                "bbr" | "bbr3" | "cubic" | "new-reno" | "newreno"
            ) {
                return Err(AetherError::Other(format!(
                    "sunny congestion-control '{name}': use bbr, bbr3, cubic or new-reno (brutal needs its \
                     parameters, give it as a mapping in sunny or the sunny-config file)"
                )));
            }
        }

        let initial_mtu = src.number::<u16>("AETHER_SUNNY_MTU", "initial-mtu")?;
        let min_mtu = src.number::<u16>("AETHER_SUNNY_MIN_MTU", "min-mtu")?;
        for (what, v) in [("sunny.initial-mtu", initial_mtu), ("sunny.min-mtu", min_mtu)] {
            if let Some(v) = v {
                if !(1200..=1500).contains(&v) {
                    return Err(AetherError::Other(format!(
                        "{what} {v}: QUIC needs 1200 at least, and the tunnel carries 1500 at most"
                    )));
                }
            }
        }

        let handshake = src
            .number::<u64>("AETHER_SUNNY_HANDSHAKE_SECS", "handshake-secs")?
            .unwrap_or(DEFAULT_HANDSHAKE_SECS)
            .clamp(3, 120);

        Ok(Settings {
            host,
            port,
            username,
            password,
            server_name,
            alpn,
            ca,
            zero_rtt: src.boolean("AETHER_SUNNY_ZERO_RTT", "zero-rtt", true)?,
            congestion,
            over_stream: src.boolean("AETHER_SUNNY_UDP_OVER_STREAM", "over-stream", false)?,
            initial_mtu,
            min_mtu,
            mtu_discovery: src.boolean("AETHER_SUNNY_MTU_DISCOVERY", "mtu-discovery", false)?,
            keep_alive_ms: src
                .number::<u32>("AETHER_SUNNY_KEEPALIVE_MS", "keep-alive-interval")?
                .unwrap_or(DEFAULT_KEEPALIVE_MS),
            gso: src.boolean("AETHER_SUNNY_GSO", "gso", true)?,
            handshake: Duration::from_secs(handshake),
            data_check: !src.boolean("AETHER_SUNNY_NO_DATA_CHECK", "no-data-check", false)?
                && src.boolean("AETHER_SUNNY_DATA_CHECK", "data-check", true)?
                && env("AETHER_MASQUE_NO_DATA_CHECK").as_deref() != Some("1"),
            cipher_suites: src.file.get("cipher-suite-preference").cloned(),
        })
    }

    /// The udp payload the inner QUIC may put in one packet: the outer tunnel's MTU less the IP
    /// and udp headers of the packet that carries it there.
    #[cfg(any(feature = "sunny", test))]
    pub fn mtus(&self, outer_mtu: usize) -> (u16, u16) {
        let headers = if self.host.parse::<std::net::Ipv4Addr>().is_ok() {
            28
        } else {
            48
        };
        let fit = outer_mtu.saturating_sub(headers).clamp(1200, 1452) as u16;
        let initial = self.initial_mtu.unwrap_or(fit);
        let min = self.min_mtu.unwrap_or(1200).min(initial);
        (initial, min)
    }

    #[cfg(feature = "sunny")]
    pub fn server_label(&self) -> String {
        if self.host.contains(':') {
            format!("[{}]:{}", self.host, self.port)
        } else {
            format!("{}:{}", self.host, self.port)
        }
    }
}

fn split_list(v: &str) -> Vec<String> {
    v.split([',', ' '])
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(str::to_string)
        .collect()
}

fn missing(key: &str) -> AetherError {
    AetherError::Other(format!(
        "the sunny client (and sunny-direct) needs {key} in the sunny mapping of the config file \
         (or of the sunny-config file); nothing gave it and there is no terminal to ask on"
    ))
}

/// Fetch Cloudflare's trace page over `stream` (already connected to www.cloudflare.com:80
/// through the sunny exit), which names the address the request came out of: the sunnyquic
/// server's, when all is well.
#[cfg(feature = "sunny")]
pub async fn exit_trace<S>(mut s: S, timeout: Duration) -> Result<(String, String)>
where
    S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send,
{
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    let work = async move {
        s.write_all(
            b"GET /cdn-cgi/trace HTTP/1.1\r\nHost: www.cloudflare.com\r\nUser-Agent: aether\r\nConnection: close\r\n\r\n",
        )
        .await?;
        let mut body = Vec::new();
        s.read_to_end(&mut body).await?;
        let text = String::from_utf8_lossy(&body);
        let field = |name: &str| {
            text.lines()
                .find_map(|l| l.strip_prefix(name))
                .map(str::to_string)
        };
        match field("ip=") {
            Some(ip) => Ok((ip, field("loc=").unwrap_or_else(|| "?".into()))),
            None => Err(AetherError::Other(
                "the trace page came back without an address".into(),
            )),
        }
    };

    tokio::time::timeout(timeout, work)
        .await
        .map_err(|_| AetherError::Other(format!("no answer within {timeout:?}")))?
}

/// Where a sunnyquic client sends its QUIC packets from: `sunny` (the client of --sunny, by
/// [sunny] `detour` / --sunny-detour), `sunny-direct` (always direct) and a declared
/// `sunnyquic` outbound (its `detour`). Direct is the default everywhere.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Detour {
    /// A udp socket of this machine (on the physical interface while a TUN is up).
    Direct,
    /// A udp socket of the WARP stack.
    Warp,
}

impl Detour {
    pub fn parse(v: &str) -> Option<Detour> {
        match v.trim().to_ascii_lowercase().as_str() {
            "direct" => Some(Detour::Direct),
            "warp" => Some(Detour::Warp),
            _ => None,
        }
    }
}

/// The settings of a `sunnyquic` outbound written as sing-box writes its outbounds. A relative
/// certificate path is taken from `base` (the config file's directory).
pub(crate) fn parse(
    o: &serde_json::Map<String, Value>,
    path: &str,
    base: &Path,
    warn: &mut dyn FnMut(String),
) -> std::result::Result<(Settings, Detour), String> {
    let text = |key: &str| o.get(key).and_then(Value::as_str).map(str::trim).filter(|s| !s.is_empty());
    let server = text("server").ok_or_else(|| format!("{path}: missing server"))?;
    let (host, port) = match o.get("server_port").and_then(Value::as_u64) {
        Some(p) => {
            let port = u16::try_from(p).ok().filter(|p| *p > 0).ok_or_else(|| format!("{path}.server_port: {p}"))?;
            (server.trim_start_matches('[').trim_end_matches(']').to_string(), port)
        }
        None => split_server(server).map_err(|_| format!("{path}: missing server_port"))?,
    };
    let username = text("username")
        .or_else(|| text("user"))
        .ok_or_else(|| format!("{path}: missing username"))?;
    let password = text("password").ok_or_else(|| format!("{path}: missing password"))?;
    let mut s = Settings::basic(&host, port, username, password);

    if let Some(tls) = o.get("tls") {
        let tls = tls.as_object().ok_or_else(|| format!("{path}.tls: must be an object"))?;
        let tls_text = |key: &str| tls.get(key).and_then(Value::as_str).map(str::trim).filter(|s| !s.is_empty());
        if let Some(name) = tls_text("server_name") {
            s.server_name = name.to_string();
        }
        if let Some(p) = tls_text("certificate_path") {
            let file = if Path::new(p).is_absolute() { Path::new(p).to_path_buf() } else { base.join(p) };
            if !file.is_file() {
                return Err(format!("{path}.tls.certificate_path: {}: no such file", file.display()));
            }
            s.ca = Some(file);
        }
        match tls.get("alpn") {
            None | Some(Value::Null) => {}
            Some(Value::String(a)) => s.alpn = vec![a.clone()],
            Some(Value::Array(list)) => {
                s.alpn = list.iter().filter_map(Value::as_str).map(str::to_string).collect();
            }
            Some(other) => return Err(format!("{path}.tls.alpn: expected a list of names, found {other}")),
        }
        if s.alpn.is_empty() {
            return Err(format!("{path}.tls.alpn: empty; the server needs one name in common (h3 by default)"));
        }
        if tls.get("insecure").and_then(Value::as_bool) == Some(true) {
            return Err(format!(
                "{path}.tls.insecure: not supported; give the server's certificate (or its CA) in certificate_path"
            ));
        }
        for key in tls.keys() {
            if !matches!(key.as_str(), "enabled" | "server_name" | "certificate_path" | "alpn" | "insecure") {
                warn(format!("{path}.tls.{key}: has no effect on a sunnyquic outbound"));
            }
        }
    }
    if let Some(cc) = text("congestion_control") {
        let name = cc.to_ascii_lowercase().replace('_', "-");
        if !matches!(name.as_str(), "bbr" | "bbr3" | "cubic" | "new-reno" | "newreno") {
            return Err(format!("{path}.congestion_control: {cc:?}: use bbr, bbr3, cubic or new_reno"));
        }
        s.congestion = CongestionChoice::Named(name);
    }
    let flag = |key: &str| -> std::result::Result<Option<bool>, String> {
        match o.get(key) {
            None | Some(Value::Null) => Ok(None),
            Some(Value::Bool(b)) => Ok(Some(*b)),
            Some(other) => Err(format!("{path}.{key}: expected true or false, found {other}")),
        }
    };
    if let Some(z) = flag("zero_rtt")?.or(flag("zero_rtt_handshake")?) {
        s.zero_rtt = z;
    }
    if let Some(u) = flag("udp_over_stream")? {
        s.over_stream = u;
    }
    let detour = match text("detour") {
        None | Some("direct") => Detour::Direct,
        Some("warp") => Detour::Warp,
        Some(other) => {
            return Err(format!("{path}.detour: {other:?}: a sunnyquic outbound goes out direct or warp"))
        }
    };
    for key in o.keys() {
        if !matches!(
            key.as_str(),
            "type"
                | "tag"
                | "server"
                | "server_port"
                | "username"
                | "user"
                | "password"
                | "tls"
                | "congestion_control"
                | "zero_rtt"
                | "zero_rtt_handshake"
                | "udp_over_stream"
                | "detour"
        ) {
            warn(format!("{path}.{key}: has no effect on a sunnyquic outbound"));
        }
    }
    Ok((s, detour))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_server_needs_its_port() {
        assert_eq!(
            split_server("sq.example.com:443").unwrap(),
            ("sq.example.com".to_string(), 443)
        );
        assert_eq!(
            split_server("203.0.113.7:8443").unwrap(),
            ("203.0.113.7".to_string(), 8443)
        );
        assert_eq!(
            split_server("[2001:db8::7]:443").unwrap(),
            ("2001:db8::7".to_string(), 443)
        );
        assert!(split_server("sq.example.com").is_err());
        assert!(split_server("2001:db8::7:443").is_err());
        assert!(split_server("sq.example.com:0").is_err());
        assert!(split_server("bad host:443").is_err());
    }

    #[test]
    fn the_sunny_table_takes_underscores_and_hyphens() {
        let dir = crate::test_util::scratch("sunny-table");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("ca.pem"), "x").unwrap();
        let table: toml::Table = toml::from_str(
            r#"
            server = "sq.example.com:8443"
            username = "1114"
            password = "314"
            server_name = "www.bing.com"
            zero-rtt = false
            congestion_control = "cubic"
            ca = "ca.pem"
            keep_alive_interval = 5000
            "#,
        )
        .unwrap();
        let src = Source::from_table(table, "aether.toml sunny".into(), dir.clone()).unwrap();
        let s = Settings::build(&src, Asked::default()).unwrap();
        assert_eq!((s.host.as_str(), s.port), ("sq.example.com", 8443));
        assert_eq!(s.server_name, "www.bing.com");
        assert!(!s.zero_rtt);
        assert!(matches!(&s.congestion, CongestionChoice::Named(n) if n == "cubic"));
        assert_eq!(s.ca.as_deref(), Some(dir.join("ca.pem").as_path()), "a relative ca is found next to the config");
        assert_eq!(s.keep_alive_ms, 5000);

        let twice: toml::Table = toml::from_str("server_name = \"a\"\nserver-name = \"b\"\n").unwrap();
        let e = Source::from_table(twice, "t".into(), dir.clone()).err().unwrap().to_string();
        assert!(e.contains("twice"), "{e}");
        let unknown: toml::Table = toml::from_str("sever = \"a\"\n").unwrap();
        assert!(Source::from_table(unknown, "t".into(), dir.clone()).is_err());
        let with_detour: toml::Table = toml::from_str("detour = \"warp\"\nserver = \"a:1\"\n").unwrap();
        let src = Source::from_table(with_detour, "t".into(), dir.clone()).expect("detour is a key of sunny");
        assert_eq!(src.string("", &["detour"]).unwrap().as_deref(), Some("warp"));
        assert_eq!(Detour::parse("WARP"), Some(Detour::Warp));
        assert_eq!(Detour::parse(" direct "), Some(Detour::Direct));
        assert_eq!(Detour::parse("socks"), None);
        let removed: toml::Table = toml::from_str("half_close_timeout = 500\nserver = \"a:1\"\n").unwrap();
        let src = Source::from_table(removed, "t".into(), dir.clone()).expect("the removed key is only warned about");
        assert!(!src.file.contains_key(REMOVED_HALF_CLOSE_KEY));
        let _ = std::fs::remove_dir_all(dir);
    }

    fn settings(host: &str) -> Settings {
        Settings {
            host: host.into(),
            port: 443,
            username: "u".into(),
            password: "p".into(),
            server_name: host.into(),
            alpn: vec!["h3".into()],
            ca: None,
            zero_rtt: true,
            congestion: CongestionChoice::Named("bbr".into()),
            over_stream: false,
            initial_mtu: None,
            min_mtu: None,
            mtu_discovery: false,
            keep_alive_ms: DEFAULT_KEEPALIVE_MS,
            gso: true,
            handshake: Duration::from_secs(5),
            data_check: false,
            cipher_suites: None,
        }
    }

    #[cfg(feature = "sunny")]
    #[test]
    fn the_config_file_can_carry_brutal_and_cipher_suites() {
        let file: toml::Table = toml::from_str(
            r#"
            congestion-control = { brutal = { bandwidth = "100M" } }
            cipher-suite-preference = ["chacha20-poly1305", "aes128-gcm"]
            "#,
        )
        .unwrap();
        let mut s = settings("203.0.113.7");
        s.congestion = CongestionChoice::Raw(file["congestion-control"].clone());
        s.cipher_suites = Some(file["cipher-suite-preference"].clone());
        let relay: SocketAddr = "127.0.0.1:40000".parse().unwrap();
        let cfg = super::super::client::client_cfg(&s, relay, 1252, 1200).unwrap();
        match cfg.congestion {
            crate::proxy::sunnyquic::CongestionControl::Brutal(p) => {
                assert_eq!(p.bandwidth, 100 * 1024 * 1024)
            }
            other => panic!("not brutal: {other:?}"),
        }
        assert_eq!(cfg.cipher_suites.unwrap().len(), 2);
        assert_eq!(cfg.server, relay);
        assert_eq!((cfg.initial_mtu, cfg.min_mtu), (1252, 1200));

        s.congestion = CongestionChoice::Raw(toml::Value::Integer(7));
        assert!(super::super::client::client_cfg(&s, relay, 1252, 1200).is_err());
    }

    #[test]
    fn the_inner_quic_packets_fit_inside_the_outer_tunnel() {
        // HTTP/3 outer: 1280 inner MTU; the sunnyquic packet, with its own IP and udp header,
        // must fit, and QUIC never goes below 1200.
        assert_eq!(settings("203.0.113.7").mtus(1280), (1252, 1200));
        assert_eq!(settings("sq.example.com").mtus(1280), (1232, 1200));
        assert_eq!(settings("2001:db8::7").mtus(1280), (1232, 1200));
        // HTTP/2 outer carries 1500.
        assert_eq!(settings("203.0.113.7").mtus(1500), (1452, 1200));
        // A tiny tunnel cannot take QUIC below its floor.
        assert_eq!(settings("203.0.113.7").mtus(900), (1200, 1200));
        let mut given = settings("203.0.113.7");
        given.initial_mtu = Some(1300);
        given.min_mtu = Some(1250);
        assert_eq!(given.mtus(1280), (1300, 1250));
    }
}

#[cfg(test)]
mod outbound_tests {
    use super::*;

    /// One `[[outbounds]]` entry, written as in the config file.
    fn outbound(text: &str) -> Value {
        crate::config::file::table_to_json(&crate::config::file::parse_table(&crate::config::yaml::yaml_of_toml(text)).unwrap())
    }

    fn parsed(text: &str) -> std::result::Result<(Settings, Detour), String> {
        parse(outbound(text).as_object().unwrap(), "outbounds[0]", Path::new("/nonexistent"), &mut |_| {})
    }

    const BASE: &str = "server = \"1.2.3.4\"\nserver_port = 1\nusername = \"u\"\npassword = \"p\"\n";

    #[test]
    fn a_sing_box_style_outbound_is_read() {
        let (s, d) = parsed(
            r#"
            type = "sunnyquic"
            tag = "hk"
            server = "1.2.3.4"
            server_port = 8443
            username = "u"
            password = "p"
            tls = { server_name = "example.com", alpn = ["h3", "h2"] }
            congestion_control = "new_reno"
            zero_rtt = false
            "#,
        )
        .unwrap();
        assert_eq!((s.host.as_str(), s.port), ("1.2.3.4", 8443));
        assert_eq!((s.username.as_str(), s.password.as_str()), ("u", "p"));
        assert_eq!(s.server_name, "example.com");
        assert_eq!(s.alpn, vec!["h3", "h2"]);
        assert!(!s.zero_rtt);
        assert!(matches!(&s.congestion, CongestionChoice::Named(n) if n == "new-reno"));
        assert_eq!(d, Detour::Direct);
    }

    #[test]
    fn defaults_and_detour() {
        let (s, d) = parsed(
            r#"
            server = "sq.example.com"
            server_port = 443
            username = "u"
            password = "p"
            detour = "warp"
            "#,
        )
        .unwrap();
        assert_eq!(s.server_name, "sq.example.com");
        assert_eq!(s.alpn, vec!["h3"]);
        assert!(s.zero_rtt);
        assert_eq!(d, Detour::Warp);
        let (s, _) = parsed("server = \"[2001:db8::1]:8443\"\nusername = \"u\"\npassword = \"p\"\n").unwrap();
        assert_eq!((s.host.as_str(), s.port), ("2001:db8::1", 8443));
    }

    #[test]
    fn mistakes_are_named() {
        let with = |extra: &str| parsed(&format!("{BASE}{extra}\n")).unwrap_err();
        assert!(with("detour = \"socks\"").contains("detour"));
        assert!(with("congestion_control = \"brutal\"").contains("congestion_control"));
        assert!(with("tls = { certificate_path = \"missing.pem\" }").contains("certificate_path"));
        assert!(with("tls = { insecure = true }").contains("insecure"));
        assert!(parsed("server = \"1.2.3.4\"\nusername = \"u\"\npassword = \"p\"\n").unwrap_err().contains("server_port"));
        assert!(parsed("server = \"1.2.3.4\"\nserver_port = 1\npassword = \"p\"\n").unwrap_err().contains("username"));
    }

    #[test]
    fn a_relative_certificate_is_found_next_to_the_config() {
        let dir = crate::test_util::scratch("sq-out");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("ca.pem"), "x").unwrap();
        let o = outbound(&format!("{BASE}tls = {{ certificate_path = \"ca.pem\" }}\n"));
        let (s, _) = parse(o.as_object().unwrap(), "o", &dir, &mut |_| {}).unwrap();
        assert_eq!(s.ca.as_deref(), Some(dir.join("ca.pem").as_path()));
        let _ = std::fs::remove_dir_all(&dir);
    }
}
