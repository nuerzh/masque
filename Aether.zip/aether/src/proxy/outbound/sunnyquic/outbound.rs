//! The sunnyquic outbounds of the registry: `sunny` (the client of --sunny: on a local udp
//! socket by default, inside the WARP MASQUE tunnel with [sunny] `detour = "warp"`),
//! `sunny-direct` (built from the --sunny-* options, always on a local udp socket) and
//! every `sunnyquic` outbound a config declares (`detour: direct`, the default, or `warp`).
//! All of them are the one `Client`; only the socket under its QUIC differs.

use crate::proxy::prelude::*;

use super::{Client, Detour, Settings};

pub(crate) const SUNNY_DIRECT: &str = "sunny-direct";

pub(crate) struct SunnyQuicOutbound {
    tag: String,
    index: u16,
    client: Arc<Client>,
}

impl AnyOutbound for SunnyQuicOutbound {
    fn tag(&self) -> &str {
        &self.tag
    }

    fn via(&self) -> Via {
        Via::SunnyQuic
    }

    fn needs_warp(&self) -> bool {
        self.client.detour() == Detour::Warp
    }

    fn connect_stream<'a>(&'a self, req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>> {
        // the host as the inbound gave it: the sunnyquic server resolves a name
        Box::pin(async move { Ok(Upstream::Boxed(self.client.open_tcp(req.host, req.port).await?)) })
    }

    fn connect_packet(&self, _req: PacketRequest<'_>) -> FlowRoute {
        FlowRoute::Session(self.index)
    }

    fn packet_exit(&self) -> Option<Arc<dyn SunnyExit>> {
        Some(self.client.clone())
    }
}

/// Register the outbound `tag` (a second config with the same tag replaces it); the index the
/// router's `OutKind::Custom` carries.
pub(crate) fn register(tag: &str, settings: Settings, detour: Detour) -> std::result::Result<u16, String> {
    let client = Arc::new(Client::new(tag, settings, detour).map_err(|e| e.to_string())?);
    let tag = tag.to_string();
    Ok(crate::proxy::outbound::register(|index| Arc::new(SunnyQuicOutbound { tag, index, client })))
}

/// `sunny-direct`, from the --sunny-* options, registered on first use.
pub(crate) fn sunny_direct() -> std::result::Result<u16, String> {
    static LOCK: parking_lot::Mutex<()> = parking_lot::Mutex::new(());
    let _held = LOCK.lock();
    if let Some(index) = crate::proxy::outbound::by_tag(SUNNY_DIRECT) {
        return Ok(index);
    }
    let settings = Settings::from_env().map_err(|e| e.to_string())?;
    register(SUNNY_DIRECT, settings, Detour::Direct)
}

/// `sunny` going direct (the default, [sunny] `detour = "direct"`): read the --sunny settings
/// (asking on a terminal for what nothing gave), make the client on a local udp socket (bound
/// to the physical interface while a TUN is up, as `sunny-direct`) and publish it as the
/// `sunny` exit; the first handshake and the exit check run in the background, so a server that
/// is down shows in the log and the connections retry it. Called as the run starts, before
/// (and whether or not) the WARP tunnel starts. A bad setting stops the run.
pub(crate) async fn start_direct_sunny() -> Result<()> {
    let settings = Settings::resolve().await?;
    let client = Arc::new(Client::new("sunny", settings, Detour::Direct)?);
    client.start_direct();
    // without the sunny feature `Client::new` already failed
    #[cfg(feature = "sunny")]
    exits::set_sunny(client);
    #[cfg(not(feature = "sunny"))]
    drop(client);
    Ok(())
}

/// `sunny`: the sunnyquic client of --sunny, and only that: from a local udp socket by default,
/// over the WARP MASQUE tunnel with `detour = "warp"`. While it is not up its connections wait
/// for it (over WARP as `warp` waits for the tunnel; direct while the run makes it), then fail
/// (never WARP instead).
pub(crate) struct SunnyOutbound {
    pub(crate) index: u16,
}

impl AnyOutbound for SunnyOutbound {
    fn tag(&self) -> &str {
        "sunny"
    }

    fn via(&self) -> Via {
        Via::Sunny
    }

    fn needs_warp(&self) -> bool {
        exits::sunny_over_warp()
    }

    fn connect_stream<'a>(&'a self, req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>> {
        Box::pin(async move {
            // the host as the inbound gave it (a domain stays a domain: the sunnyquic server
            // resolves it); a `resolve` action's addresses are only for matching rules
            let who = if exits::sunny_over_warp() {
                "outbound sunny (the sunny client, detour warp: inside WARP MASQUE)"
            } else {
                "outbound sunny (the sunny client, direct)"
            };
            let sunny = exits::sunny_exit(who).await.map_err(AetherError::Other)?;
            Ok(Upstream::Boxed(sunny.open_tcp(req.host, req.port).await?))
        })
    }

    fn connect_packet(&self, _req: PacketRequest<'_>) -> FlowRoute {
        FlowRoute::Session(self.index)
    }

    fn packet_exit(&self) -> Option<Arc<dyn SunnyExit>> {
        exits::sunny()
    }
}
