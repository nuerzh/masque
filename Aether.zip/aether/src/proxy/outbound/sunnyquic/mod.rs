//! sunnyquic outbounds: the client (`client.rs`, on `proxy::sunnyquic`, in process), its settings
//! (`settings.rs`), the socket that carries it inside the WARP tunnel (`socket.rs`), and the
//! outbounds built on it (`outbound.rs`): `sunny` (--sunny), `sunny-direct` and the declared
//! `sunnyquic` outbounds. The server side is `proxy::inbound::sunnyquic`.
//!
//! --sunny: app -> aether inbound (socks5 / http / tun) -> router -> `sunny` -> the sunnyquic
//! client -> the WARP MASQUE tunnel's netstack (udp) -> WARP -> the user's own sunnyquic server
//! -> the internet. No port is opened on the machine for it: Aether's own inbounds hand tcp
//! streams and udp associations to the client directly.

pub mod client;
pub mod outbound;
pub mod settings;
#[cfg(feature = "sunny")]
pub mod socket;

pub use client::Client;
pub(crate) use outbound::*;
pub use settings::{Detour, Settings};
#[cfg(all(test, feature = "sunny"))]
pub use settings::CongestionChoice;

use std::future::Future;
use std::net::SocketAddr;
use std::pin::Pin;

pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;

/// A udp association through the sunny exit. Datagrams go out addressed by host (a name stays
/// a name: the sunnyquic server resolves it); answers come back with their source address
/// (`None` when the server named it by domain).
pub struct SunnyUdp {
    pub tx: tokio::sync::mpsc::Sender<(String, u16, Vec<u8>)>,
    pub rx: tokio::sync::mpsc::Receiver<(Option<SocketAddr>, Vec<u8>)>,
    pub guard: Option<tokio::task::AbortHandle>,
    /// Tasks that forward this session's answers elsewhere, stopped with it.
    pub pumps: Vec<tokio::task::AbortHandle>,
}

impl SunnyUdp {
    pub async fn send(&self, host: &str, port: u16, data: Vec<u8>) -> bool {
        self.tx.send((host.to_string(), port, data)).await.is_ok()
    }

    pub async fn recv(&mut self) -> Option<(Option<SocketAddr>, Vec<u8>)> {
        self.rx.recv().await
    }
}

impl Drop for SunnyUdp {
    fn drop(&mut self) {
        if let Some(g) = self.guard.take() {
            g.abort();
        }
        for p in self.pumps.drain(..) {
            p.abort();
        }
    }
}

/// The sunny outbound: the in-process sunnyquic client of --sunny (no loopback port in
/// between), or in tests anything that speaks the same.
pub trait SunnyExit: Send + Sync {
    fn open_tcp<'a>(&'a self, host: &'a str, port: u16) -> BoxFuture<'a, std::io::Result<crate::proxy::outbound::BoxStream>>;
    fn open_udp(&self) -> BoxFuture<'_, std::io::Result<SunnyUdp>>;
}

#[cfg(test)]
mod tests;
