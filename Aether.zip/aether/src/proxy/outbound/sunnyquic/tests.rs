#![allow(unused_imports)]

use std::net::{IpAddr, SocketAddr};
use std::sync::Arc;
use std::time::Duration;

use super::*;

/// The whole inner path, with the WARP tunnel stubbed: a netstack like the outer tunnel's, whose
/// IP packets a small udp NAT here carries to a real sunnyquic server on loopback, as Cloudflare
/// would carry them to the user's server. Then a socks5 client through `--bind` reaches a tcp
/// echo server out of the sunnyquic server's direct outbound, before and after the outer tunnel
/// is swapped for a new one, the way a reconnect swaps it.
#[cfg(all(test, feature = "sunny"))]
mod loopback {
    use super::*;
    use std::collections::HashMap;
    use std::net::Ipv4Addr;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::sync::mpsc;

    /// Where the netstack believes the server is; the NAT sends it to 127.0.0.1 instead.
    const FAKE_SERVER: Ipv4Addr = Ipv4Addr::new(198, 18, 0, 1);

    fn checksum(data: &[u8]) -> u32 {
        let mut sum = 0u32;
        for chunk in data.chunks(2) {
            let word = if chunk.len() == 2 {
                u16::from_be_bytes([chunk[0], chunk[1]])
            } else {
                u16::from_be_bytes([chunk[0], 0])
            };
            sum += word as u32;
        }
        sum
    }

    fn fold(mut sum: u32) -> u16 {
        while sum >> 16 != 0 {
            sum = (sum & 0xffff) + (sum >> 16);
        }
        !(sum as u16)
    }

    fn ipv4_udp(src: SocketAddr, dst: SocketAddr, payload: &[u8]) -> Vec<u8> {
        let (IpAddr::V4(s), IpAddr::V4(d)) = (src.ip(), dst.ip()) else {
            unreachable!()
        };
        let udp_len = 8 + payload.len();
        let total = 20 + udp_len;
        let mut p = vec![0u8; total];
        p[0] = 0x45;
        p[2..4].copy_from_slice(&(total as u16).to_be_bytes());
        p[6] = 0x40; // don't fragment
        p[8] = 64;
        p[9] = 17;
        p[12..16].copy_from_slice(&s.octets());
        p[16..20].copy_from_slice(&d.octets());
        let hc = fold(checksum(&p[..20]));
        p[10..12].copy_from_slice(&hc.to_be_bytes());
        p[20..22].copy_from_slice(&src.port().to_be_bytes());
        p[22..24].copy_from_slice(&dst.port().to_be_bytes());
        p[24..26].copy_from_slice(&(udp_len as u16).to_be_bytes());
        p[28..].copy_from_slice(payload);
        let mut pseudo = Vec::with_capacity(12 + udp_len);
        pseudo.extend_from_slice(&s.octets());
        pseudo.extend_from_slice(&d.octets());
        pseudo.extend_from_slice(&[0, 17]);
        pseudo.extend_from_slice(&(udp_len as u16).to_be_bytes());
        pseudo.extend_from_slice(&p[20..]);
        let mut uc = fold(checksum(&pseudo));
        if uc == 0 {
            uc = 0xffff;
        }
        p[26..28].copy_from_slice(&uc.to_be_bytes());
        p
    }

    fn parse_ipv4_udp(p: &[u8]) -> Option<(SocketAddr, SocketAddr, Vec<u8>)> {
        if p.len() < 28 || p[0] >> 4 != 4 || p[9] != 17 {
            return None;
        }
        let ihl = ((p[0] & 0x0f) as usize) * 4;
        let total = u16::from_be_bytes([p[2], p[3]]) as usize;
        let src = Ipv4Addr::new(p[12], p[13], p[14], p[15]);
        let dst = Ipv4Addr::new(p[16], p[17], p[18], p[19]);
        let u = &p[ihl..total.min(p.len())];
        let sport = u16::from_be_bytes([u[0], u[1]]);
        let dport = u16::from_be_bytes([u[2], u[3]]);
        let ulen = u16::from_be_bytes([u[4], u[5]]) as usize;
        Some((
            SocketAddr::new(IpAddr::V4(src), sport),
            SocketAddr::new(IpAddr::V4(dst), dport),
            u[8..ulen.min(u.len())].to_vec(),
        ))
    }

    /// A stand-in for the outer tunnel: a netstack whose packets a udp NAT delivers for real.
    /// Dropping the returned guard tears it down, as a dropped masque tunnel would.
    async fn stub_tunnel(
        local_v4: &str,
        real_server: SocketAddr,
    ) -> (crate::transport::warp::netstack::StackHandle, tokio::task::JoinHandle<()>) {
        let (out_tx, mut out_rx) = mpsc::channel::<Vec<u8>>(1024);
        let (in_tx, in_rx) = mpsc::channel::<Vec<u8>>(1024);
        let stack = crate::transport::warp::netstack::spawn(local_v4, "", 1280, in_rx, out_tx).unwrap();

        let nat = tokio::spawn(async move {
            let mut flows: HashMap<(SocketAddr, SocketAddr), Arc<tokio::net::UdpSocket>> =
                HashMap::new();
            let mut readers = tokio::task::JoinSet::new();
            while let Some(pkt) = out_rx.recv().await {
                let Some((src, dst, payload)) = parse_ipv4_udp(&pkt) else {
                    continue;
                };
                assert_eq!(
                    dst.ip(),
                    IpAddr::V4(FAKE_SERVER),
                    "only the server is dialled"
                );
                assert!(
                    pkt.len() <= 1280,
                    "a packet bigger than the tunnel MTU left the stack"
                );
                let sock = match flows.get(&(src, dst)) {
                    Some(s) => s.clone(),
                    None => {
                        let s = Arc::new(tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap());
                        let back = s.clone();
                        let in_tx = in_tx.clone();
                        readers.spawn(async move {
                            let mut buf = vec![0u8; 65536];
                            while let Ok(n) = back.recv(&mut buf).await {
                                let pkt = ipv4_udp(dst, src, &buf[..n]);
                                if in_tx.send(pkt).await.is_err() {
                                    break;
                                }
                            }
                        });
                        s.connect(real_server).await.unwrap();
                        flows.insert((src, dst), s.clone());
                        s
                    }
                };
                let _ = sock.send(&payload).await;
            }
        });
        (stack, nat)
    }

    /// socks5 UDP ASSOCIATE through `--bind`, a few datagrams to a udp echo server and back.
    async fn socks_udp_echo(listen: SocketAddr, target: SocketAddr) {
        let mut ctl = tokio::net::TcpStream::connect(listen).await.unwrap();
        ctl.write_all(&[5, 1, 0]).await.unwrap();
        let mut g = [0u8; 2];
        ctl.read_exact(&mut g).await.unwrap();
        ctl.write_all(&[5, 3, 0, 1, 0, 0, 0, 0, 0, 0])
            .await
            .unwrap();
        let mut rep = [0u8; 10];
        ctl.read_exact(&mut rep).await.unwrap();
        assert_eq!(rep[1], 0, "udp associate refused");
        let mut relay = SocketAddr::new(
            IpAddr::V4(Ipv4Addr::new(rep[4], rep[5], rep[6], rep[7])),
            u16::from_be_bytes([rep[8], rep[9]]),
        );
        if relay.ip().is_unspecified() {
            relay.set_ip(listen.ip());
        }
        let IpAddr::V4(ip) = target.ip() else {
            unreachable!()
        };
        let sock = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
        for round in 0..5u8 {
            let payload: Vec<u8> = (0..900).map(|i| (i as u8) ^ round).collect();
            let mut pkt = vec![0, 0, 0, 1];
            pkt.extend_from_slice(&ip.octets());
            pkt.extend_from_slice(&target.port().to_be_bytes());
            pkt.extend_from_slice(&payload);
            sock.send_to(&pkt, relay).await.unwrap();
            let mut buf = vec![0u8; 65536];
            let n = tokio::time::timeout(Duration::from_secs(5), sock.recv(&mut buf))
                .await
                .expect("no udp echo came back")
                .unwrap();
            assert!(n >= 10 && buf[3] == 1, "bad socks5 udp header");
            assert!(buf[10..n] == payload[..], "the udp echo came back changed");
        }
        drop(ctl);
    }

    async fn socks_echo(listen: SocketAddr, target: SocketAddr, size: usize) {
        let mut s = tokio::net::TcpStream::connect(listen).await.unwrap();
        s.write_all(&[5, 1, 0]).await.unwrap();
        let mut g = [0u8; 2];
        s.read_exact(&mut g).await.unwrap();
        assert_eq!(g, [5, 0]);
        let IpAddr::V4(ip) = target.ip() else {
            unreachable!()
        };
        let mut req = vec![5, 1, 0, 1];
        req.extend_from_slice(&ip.octets());
        req.extend_from_slice(&target.port().to_be_bytes());
        s.write_all(&req).await.unwrap();
        let mut rep = [0u8; 10];
        s.read_exact(&mut rep).await.unwrap();
        assert_eq!(rep[1], 0, "socks5 connect refused");

        let sent: Vec<u8> = (0..size).map(|i| (i * 7 % 251) as u8).collect();
        let (mut r, mut w) = s.into_split();
        let to_send = sent.clone();
        let writer = tokio::spawn(async move {
            w.write_all(&to_send).await.unwrap();
            w
        });
        let mut got = vec![0u8; size];
        r.read_exact(&mut got).await.unwrap();
        let _ = writer.await;
        assert!(got == sent, "the echo came back changed");
    }

    /// The user's sunnyquic server on loopback (user alice), and the --sunny client for it.
    async fn sunny_fixture() -> (Arc<Client>, SocketAddr) {
        // A CA and a localhost certificate it signed, as a user's own server would have.
        let (ca_path, cert_path, key_path) = crate::test_util::ca_signed(&crate::test_util::scratch("sunny"));

        // The user's sunnyquic server, with a direct outbound, on loopback.
        let server_port = {
            let probe = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
            probe.local_addr().unwrap().port()
        };
        let server_addr: SocketAddr = format!("127.0.0.1:{server_port}").parse().unwrap();
        let mut cfg = crate::proxy::sunnyquic::ServerConfig::new(server_addr, cert_path.clone(), key_path.clone());
        cfg.users = vec![("alice".into(), "wonderland".into())];
        let server = crate::proxy::sunnyquic::SunnyServer::bind(&cfg).unwrap();
        tokio::spawn(server.run(Arc::new(crate::proxy::sunnyquic::tests::Direct)));
        tokio::time::sleep(Duration::from_millis(200)).await;

        let settings = Settings {
            host: FAKE_SERVER.to_string(),
            port: server_port,
            username: "alice".into(),
            password: "wonderland".into(),
            server_name: "localhost".into(),
            alpn: vec!["h3".into()],
            ca: Some(ca_path.clone()),
            zero_rtt: true,
            congestion: CongestionChoice::Named("bbr".into()),
            over_stream: false,
            initial_mtu: None,
            min_mtu: None,
            mtu_discovery: false,
            keep_alive_ms: 1000,
            gso: true,
            handshake: Duration::from_secs(10),
            data_check: false,
            cipher_suites: None,
        };
        let client = Arc::new(Client::new("sunny", settings, Detour::Warp).unwrap());
        (client, server_addr)
    }

    fn free_tcp() -> SocketAddr {
        let probe = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        probe.local_addr().unwrap()
    }

    /// --sunny with a route config: Aether's routed listener sits on `--bind` in front of the
    /// sunnyquic client. Ignored by default because the router is process-global; run it alone:
    /// `cargo test routed_sunny -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    #[ignore]
    async fn routed_sunny_sends_final_through_sunnyquic_and_rules_elsewhere() {
        let _ = env_logger::builder().is_test(true).try_init();
        let echo_direct = crate::test_util::tcp_echo().await;
        let echo_sunny = crate::test_util::tcp_echo().await;
        let udp_echo = crate::test_util::udp_echo().await;
        let blocked = crate::test_util::tcp_echo().await;
        let cfg = crate::test_util::scratch("routed-sunny.yaml");
        std::fs::write(
            &cfg,
            crate::config::yaml::yaml_of_toml(&format!(
                r#"
                [route]
                final = "sunny"

                [[route.rules]]
                port = {}
                action = "reject"

                [[route.rules]]
                port = {}
                outbound = "direct"
                "#,
                blocked.port(),
                echo_direct.port()
            )),
        )
        .unwrap();
        crate::config::settings::decide("AETHER_ROUTE_CONFIG", cfg.to_string_lossy());
        crate::config::settings::decide("AETHER_PROTOCOL", "sunny");
        crate::proxy::router::init().unwrap();
        assert!(crate::proxy::router::router().is_some());

        let listen = free_tcp();
        let (client, server_addr) = sunny_fixture().await;
        let (stack, nat) = stub_tunnel("172.16.0.2/32", server_addr).await;
        client.attach(&stack).await.unwrap();
        let _listeners = crate::proxy::inbound::serve_listeners(listen, None).await.unwrap();

        let t = Duration::from_secs(20);
        tokio::time::timeout(t, socks_echo(listen, echo_sunny, 1 << 20)).await.expect("final sunny tcp");
        tokio::time::timeout(t, socks_udp_echo(listen, udp_echo)).await.expect("final sunny udp");
        tokio::time::timeout(t, socks_echo(listen, echo_direct, 64 << 10)).await.expect("direct tcp");

        // The reject rule: the socks5 reply is a failure.
        let mut s = tokio::net::TcpStream::connect(listen).await.unwrap();
        s.write_all(&[5, 1, 0]).await.unwrap();
        let mut g = [0u8; 2];
        s.read_exact(&mut g).await.unwrap();
        let mut req = vec![5, 1, 0, 1, 127, 0, 0, 1];
        req.extend_from_slice(&blocked.port().to_be_bytes());
        s.write_all(&req).await.unwrap();
        let mut rep = [0u8; 10];
        let n = tokio::time::timeout(t, s.read(&mut rep)).await.unwrap().unwrap_or(0);
        assert!(n == 0 || rep[1] != 0, "the rejected port was let through");

        // Take the outer tunnel away: the direct rule still works, the sunny final cannot,
        // which shows the final really went through sunnyquic.
        client.detach().await;
        nat.abort();
        drop(stack);
        tokio::time::sleep(Duration::from_millis(300)).await;
        tokio::time::timeout(t, socks_echo(listen, echo_direct, 64 << 10)).await.expect("direct tcp without the tunnel");
        let via_sunny = tokio::spawn(socks_echo(listen, echo_sunny, 4096));
        let r = tokio::time::timeout(Duration::from_secs(8), via_sunny).await;
        assert!(!matches!(r, Ok(Ok(()))), "the sunny final worked with no tunnel, so it was not going through sunnyquic");
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn sunnyquic_rides_a_stubbed_tunnel_and_survives_a_new_one() {
        let _ = env_logger::builder().is_test(true).try_init();
        let listen = free_tcp();
        let (client, server_addr) = sunny_fixture().await;
        let echo = crate::test_util::tcp_echo().await;

        // Aether's listener in front, everything to sunny.
        static SUNNY_ONLY: std::sync::OnceLock<crate::proxy::router::Router> = std::sync::OnceLock::new();
        let router = SUNNY_ONLY.get_or_init(|| {
            crate::proxy::router::build(
                &crate::config::file::test_routing("[route]\nfinal = \"sunny\"\n"),
                crate::proxy::router::LoadOptions {
                    base_dir: std::path::PathBuf::new(),
                    cache_dir: std::path::PathBuf::new(),
                    caps: crate::proxy::router::Caps::ALL,
                },
            )
            .unwrap()
            .router
        });
        let front = tokio::net::TcpListener::bind(listen).await.unwrap();
        let _front = tokio::spawn(crate::proxy::inbound::socks5::serve_socks_routed_by(
            front,
            crate::proxy::outbound::Exit::Current,
            router,
        ));

        // First outer tunnel.
        let (stack, nat) = stub_tunnel("172.16.0.2/32", server_addr).await;
        client.attach(&stack).await.unwrap();
        tokio::time::timeout(Duration::from_secs(20), socks_echo(listen, echo, 1 << 20))
            .await
            .expect("echo through the first tunnel timed out");

        let udp_echo = crate::test_util::udp_echo().await;
        tokio::time::timeout(Duration::from_secs(20), socks_udp_echo(listen, udp_echo))
            .await
            .expect("udp echo through the first tunnel timed out");

        // It drops; a new one comes up, from another address, as a reconnect would bring.
        client.detach().await;
        nat.abort();
        drop(stack);
        let (stack2, _nat2) = stub_tunnel("172.16.0.3/32", server_addr).await;
        client.attach(&stack2).await.unwrap();
        tokio::time::timeout(Duration::from_secs(40), socks_echo(listen, echo, 256 << 10))
            .await
            .expect("echo through the second tunnel timed out");

    }
}

/// The whole path on loopback, with no WARP at all: a sunnyquic server inbound of this process,
/// and socks5 clients through --bind whose connections leave by a declared `sunnyquic` outbound
/// (`hk`) or by `sunny-direct` (`final`). The targets are ports nothing listens on: only the
/// server's rules (on its inbound tag) re-point them at the echo servers, so an echo proves the
/// way went through the sunnyquic server. Process-global router, so it runs alone:
/// `cargo test sunny_direct_and_declared -- --ignored`.
#[cfg(all(test, feature = "sunny"))]
mod direct_loopback {
    use std::net::SocketAddr;
    use std::time::Duration;

    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::{TcpListener, TcpStream, UdpSocket};

    /// A port nothing listens on, tcp or udp.
    fn dead_port() -> u16 {
        loop {
            let t = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let port = t.local_addr().unwrap().port();
            if std::net::UdpSocket::bind(("127.0.0.1", port)).is_ok() {
                return port;
            }
        }
    }

    async fn greet(proxy: SocketAddr, cmd: u8, port: u16) -> (TcpStream, SocketAddr) {
        let mut s = TcpStream::connect(proxy).await.unwrap();
        s.write_all(&[5, 1, 0]).await.unwrap();
        let mut m = [0u8; 2];
        s.read_exact(&mut m).await.unwrap();
        assert_eq!(m, [5, 0]);
        let mut req = vec![5, cmd, 0, 1, 127, 0, 0, 1];
        req.extend_from_slice(&port.to_be_bytes());
        s.write_all(&req).await.unwrap();
        let mut rep = [0u8; 10];
        s.read_exact(&mut rep).await.unwrap();
        assert_eq!(rep[1], 0, "socks5 refused (reply {})", rep[1]);
        let ip = std::net::Ipv4Addr::new(rep[4], rep[5], rep[6], rep[7]);
        let bound = SocketAddr::from((if ip.is_unspecified() { std::net::Ipv4Addr::LOCALHOST } else { ip }, u16::from_be_bytes([rep[8], rep[9]])));
        (s, bound)
    }

    async fn tcp_echo(proxy: SocketAddr, port: u16) {
        let (s, _) = greet(proxy, 1, port).await;
        let sent: Vec<u8> = (0..150_000).map(|i| (i % 251) as u8).collect();
        let (mut r, mut w) = tokio::io::split(s);
        let to_send = sent.clone();
        let (_, got) = tokio::join!(async move { w.write_all(&to_send).await.unwrap() }, async move {
            let mut got = vec![0u8; 150_000];
            r.read_exact(&mut got).await.unwrap();
            got
        });
        assert!(got == sent, "tcp echo to port {port} came back changed");
    }

    async fn udp_echo(proxy: SocketAddr, port: u16) {
        let (_ctl, relay) = greet(proxy, 3, 0).await;
        let u = UdpSocket::bind("127.0.0.1:0").await.unwrap();
        for round in 0..3u8 {
            let mut p = vec![0, 0, 0, 1, 127, 0, 0, 1];
            p.extend_from_slice(&port.to_be_bytes());
            p.extend(std::iter::repeat_n(round, 600));
            u.send_to(&p, relay).await.unwrap();
            let mut b = vec![0u8; 2048];
            let (n, _) = tokio::time::timeout(Duration::from_secs(10), u.recv_from(&mut b)).await.expect("no udp echo").unwrap();
            assert_eq!(&b[10..n], &p[10..], "udp echo to port {port}, round {round}");
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    #[ignore]
    async fn sunny_direct_and_declared_sunnyquic_carry_tcp_and_udp_without_warp() {
        let _ = env_logger::builder().is_test(true).try_init();
        let (echo_hk, echo_sd) = (crate::test_util::echo_pair().await, crate::test_util::echo_pair().await);
        let (fake_hk, fake_sd) = (dead_port(), dead_port());
        let server_port = std::net::UdpSocket::bind("127.0.0.1:0").unwrap().local_addr().unwrap().port();
        let (cert, _) = crate::proxy::inbound::sunnyquic::self_signed("localhost").unwrap();

        // everything in the one config file: the sunny-direct client in [sunny], the server
        // inbound, a declared sunnyquic outbound and the route
        let config = format!(
            r#"
            [sunny]
            server = "127.0.0.1:{server_port}"
            username = "alice"
            password = "wonderland"
            server_name = "localhost"
            ca = {cert:?}

            [[inbounds]]
            type = "sunnyquic"
            tag = "sq-srv"
            listen = "127.0.0.1"
            listen_port = {server_port}
            users = [{{ name = "alice", password = "wonderland" }}]
            tls = {{ server_name = "localhost", alpn = ["h3"] }}
            zero_rtt = true
            congestion_control = "bbr"

            [[outbounds]]
            type = "sunnyquic"
            tag = "hk"
            server = "127.0.0.1"
            server_port = {server_port}
            username = "alice"
            password = "wonderland"
            tls = {{ server_name = "localhost", certificate_path = {cert:?}, alpn = ["h3"] }}
            congestion_control = "bbr"
            zero_rtt = true

            [route]
            default_domain_resolver = {{ strategy = "prefer_ipv4" }}
            final = "sunny-direct"

            [[route.rules]]
            inbound = ["sq-srv"]
            port = {fake_hk}
            outbound = "direct"
            override_port = {echo_hk}

            [[route.rules]]
            inbound = ["sq-srv"]
            port = {fake_sd}
            outbound = "direct"
            override_port = {echo_sd}

            [[route.rules]]
            inbound = ["sq-srv"]
            action = "reject"

            [[route.rules]]
            port = {fake_hk}
            outbound = "hk"
            "#
        );
        let file = crate::test_util::scratch_file("sunny-direct.yaml", &crate::config::yaml::yaml_of_toml(&config));
        crate::config::settings::forget("AETHER_ROUTE_CONFIG");
        crate::config::settings::decide("AETHER_CONFIG", file.to_string_lossy());

        crate::proxy::inbound::configure().unwrap();
        crate::proxy::router::init().unwrap();
        crate::proxy::inbound::start().await.unwrap();
        let socks: SocketAddr = format!("127.0.0.1:{}", dead_port()).parse().unwrap();
        let _listeners = crate::proxy::inbound::serve_listeners(socks, None).await.unwrap();

        // nothing in this config needs WARP: auto does not start it
        let users = crate::transport::warp::demand::users(None);
        assert_eq!(users.as_deref(), Some(&[][..]), "{users:?}");
        let setting = crate::transport::warp::demand::WarpTunnel::Auto;
        assert!(!crate::transport::warp::demand::decide(setting, users.as_deref()).unwrap());
        tokio::time::sleep(Duration::from_millis(200)).await;

        let t = Duration::from_secs(30);
        tokio::time::timeout(t, tcp_echo(socks, fake_hk)).await.expect("tcp through hk");
        tokio::time::timeout(t, tcp_echo(socks, fake_sd)).await.expect("tcp through sunny-direct");
        tokio::time::timeout(t, udp_echo(socks, fake_hk)).await.expect("udp through hk");
        tokio::time::timeout(t, udp_echo(socks, fake_sd)).await.expect("udp through sunny-direct");

        assert!(!crate::proxy::router::exits::warp_expected(), "WARP was expected");
        assert!(crate::proxy::router::exits::stack().is_none(), "a WARP stack came up");
        let _ = std::fs::remove_file(&file);
    }

    /// --sunny alone, end to end: the `sunny` outbound (and `proxy`) is the --sunny client on a
    /// local udp socket, carrying tcp and udp to a real sunnyquic server on loopback with no
    /// WARP at all; the plan starts no tunnel. With detour warp the same config needs WARP.
    /// Runs alone: `cargo test sunny_goes_direct_by_default -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    #[ignore]
    async fn sunny_goes_direct_by_default_and_carries_tcp_and_udp_without_warp() {
        let _ = env_logger::builder().is_test(true).try_init();
        let (echo_a, echo_b) = (crate::test_util::echo_pair().await, crate::test_util::echo_pair().await);
        let (fake_a, fake_b) = (dead_port(), dead_port());
        let server_port = std::net::UdpSocket::bind("127.0.0.1:0").unwrap().local_addr().unwrap().port();
        let (cert, _) = crate::proxy::inbound::sunnyquic::self_signed("localhost").unwrap();

        // [sunny] without detour: direct. final is sunny, a rule sends fake_b to proxy (= sunny).
        let config = format!(
            r#"
            [sunny]
            server = "127.0.0.1:{server_port}"
            username = "alice"
            password = "wonderland"
            server_name = "localhost"
            ca = {cert:?}
            data_check = false

            [[inbounds]]
            type = "sunnyquic"
            tag = "sq-srv"
            listen = "127.0.0.1"
            listen_port = {server_port}
            users = [{{ name = "alice", password = "wonderland" }}]
            tls = {{ server_name = "localhost", alpn = ["h3"] }}
            zero_rtt = true
            congestion_control = "bbr"

            [route]
            default_domain_resolver = {{ strategy = "prefer_ipv4" }}
            final = "sunny"

            [[route.rules]]
            inbound = ["sq-srv"]
            port = {fake_a}
            outbound = "direct"
            override_port = {echo_a}

            [[route.rules]]
            inbound = ["sq-srv"]
            port = {fake_b}
            outbound = "direct"
            override_port = {echo_b}

            [[route.rules]]
            inbound = ["sq-srv"]
            action = "reject"

            [[route.rules]]
            port = {fake_b}
            outbound = "proxy"
            "#
        );
        let file = crate::test_util::scratch_file("sunny-default-direct.yaml", &crate::config::yaml::yaml_of_toml(&config));
        crate::config::settings::forget("AETHER_ROUTE_CONFIG");
        crate::config::settings::decide("AETHER_CONFIG", file.to_string_lossy());
        crate::config::settings::decide("AETHER_PROTOCOL", "sunny");

        crate::proxy::inbound::configure().unwrap();
        crate::proxy::router::init().unwrap();
        crate::proxy::inbound::start().await.unwrap();
        let socks: SocketAddr = format!("127.0.0.1:{}", dead_port()).parse().unwrap();
        let _listeners = crate::proxy::inbound::serve_listeners(socks, None).await.unwrap();

        // sunny alone needs no WARP: auto does not start it, off is fine
        let plan = crate::transport::warp::demand::plan().unwrap();
        assert_eq!(plan.sunny, Some(crate::proxy::outbound::sunnyquic::Detour::Direct));
        assert!(!plan.start, "{plan:?}");
        assert_eq!(plan.users.as_deref(), Some(&[][..]));
        crate::proxy::router::exits::begin_run(plan.start, false);
        // what serve does for --sunny going direct
        crate::proxy::outbound::sunnyquic::start_direct_sunny().await.unwrap();
        tokio::time::sleep(Duration::from_millis(200)).await;

        let t = Duration::from_secs(30);
        tokio::time::timeout(t, tcp_echo(socks, fake_a)).await.expect("tcp through sunny (final)");
        tokio::time::timeout(t, tcp_echo(socks, fake_b)).await.expect("tcp through proxy (= sunny)");
        tokio::time::timeout(t, udp_echo(socks, fake_a)).await.expect("udp through sunny");
        tokio::time::timeout(t, udp_echo(socks, fake_b)).await.expect("udp through proxy");
        assert!(!crate::proxy::router::exits::warp_expected(), "WARP was expected");
        assert!(crate::proxy::router::exits::stack().is_none(), "a WARP stack came up");

        // the same config with detour warp: sunny and proxy need WARP, off refuses
        crate::config::settings::decide("AETHER_SUNNY_DETOUR", "warp");
        crate::proxy::router::init().unwrap();
        let plan = crate::transport::warp::demand::plan().unwrap();
        assert_eq!(plan.sunny, Some(crate::proxy::outbound::sunnyquic::Detour::Warp));
        assert!(plan.start, "{plan:?}");
        let users = plan.users.clone().unwrap();
        assert!(users.iter().any(|u| u.starts_with("rule 3 routes to proxy (proxy is the sunny sunnyquic client, detour")), "{users:?}");
        assert!(users.iter().any(|u| u.starts_with("final is sunny (the sunny sunnyquic client has detour")), "{users:?}");
        crate::config::settings::decide("AETHER_WARP_TUNNEL", "off");
        let e = crate::transport::warp::demand::plan().unwrap_err().to_string();
        assert!(e.contains("final is sunny"), "{e}");
        crate::config::settings::decide("AETHER_SUNNY_DETOUR", "socks");
        let e = crate::transport::warp::demand::plan().unwrap_err().to_string();
        assert!(e.contains("sunny.detour") && e.contains("direct or warp"), "{e}");
        for k in ["AETHER_SUNNY_DETOUR", "AETHER_WARP_TUNNEL", "AETHER_PROTOCOL"] {
            crate::config::settings::forget(k);
        }
        let _ = std::fs::remove_file(&file);
    }
}
