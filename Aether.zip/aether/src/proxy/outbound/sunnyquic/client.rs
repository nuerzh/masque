//! The sunnyquic client (`proxy::sunnyquic`, in process), with its noq endpoint on a socket
//! Aether hands it. One implementation for every sunnyquic outbound, whatever carries its QUIC packets:
//!
//! - `--sunny` (the `sunny` outbound) with [sunny] `detour = "warp"`: a socket of the WARP
//!   MASQUE tunnel's netstack (`socket::TunnelSocket`), attached eagerly to each tunnel
//!   `run_masque` brings up; by default (`detour = "direct"`) a local udp socket, as below;
//! - a declared `sunnyquic` outbound with `detour: warp`: the same socket, attached to the
//!   current WARP stack on first use and re-pointed as the tunnel reconnects;
//! - `sunny-direct` and `detour: direct`: a udp socket of this machine (`egress::udp_bind`).

#[cfg(feature = "sunny")]
pub use imp::*;

#[cfg(feature = "sunny")]
mod imp {
    use std::net::{IpAddr, SocketAddr};
    use std::sync::Arc;
    use std::time::Duration;

    use crate::proxy::sunnyquic::{Address, CongestionControl, SunnyClient};

    use super::super::settings::{exit_trace, CongestionChoice, Detour, Settings};
    use super::super::socket;
    use super::super::{BoxFuture, SunnyExit, SunnyUdp};
    use crate::error::{AetherError, Result};
    use crate::proxy::router::exits;
    use crate::transport::warp::netstack::StackHandle;

    /// One built sunnyquic client, as the router's outbounds talk to it.
    struct Exit {
        client: Arc<SunnyClient>,
    }

    impl SunnyExit for Exit {
        fn open_tcp<'a>(
            &'a self,
            host: &'a str,
            port: u16,
        ) -> BoxFuture<'a, std::io::Result<crate::proxy::socks::BoxStream>> {
            Box::pin(async move {
                let stream = self
                    .client
                    .open_tcp(&Address::new(host, port))
                    .await
                    .map_err(|e| std::io::Error::other(format!("sunny: {e}")))?;
                Ok(Box::new(stream) as crate::proxy::socks::BoxStream)
            })
        }

        fn open_udp(
            &self,
        ) -> BoxFuture<'_, std::io::Result<SunnyUdp>> {
            Box::pin(async move {
                let (tx, mut out_rx) = tokio::sync::mpsc::channel::<(String, u16, Vec<u8>)>(256);
                let (in_tx, rx) = tokio::sync::mpsc::channel(256);
                let mut assoc = self
                    .client
                    .associate_udp()
                    .await
                    .map_err(|e| std::io::Error::other(format!("sunny udp: {e}")))?;
                let task = tokio::spawn(async move {
                    loop {
                        tokio::select! {
                            m = out_rx.recv() => {
                                let Some((host, port, data)) = m else { return };
                                if assoc.tx.send((bytes::Bytes::from(data), Address::new(&host, port))).await.is_err() {
                                    return;
                                }
                            }
                            m = assoc.rx.recv() => {
                                let Some((data, from)) = m else { return };
                                if in_tx.send((from.socket_addr(), data.to_vec())).await.is_err() {
                                    return;
                                }
                            }
                        }
                    }
                });
                Ok(SunnyUdp { tx, rx, guard: Some(task.abort_handle()), pumps: Vec::new() })
            })
        }
    }

    /// A sunnyquic client. Built on first use (or, for `--sunny`, on the first tunnel), then
    /// kept; over WARP its socket is re-pointed at each WARP stack as the tunnel reconnects.
    pub struct Client {
        tag: String,
        settings: Settings,
        detour: Detour,
        state: tokio::sync::OnceCell<Built>,
        warp: tokio::sync::Mutex<Option<(StackHandle, socket::Attached)>>,
        shaken: tokio::sync::OnceCell<()>,
    }

    struct Built {
        client: Arc<SunnyClient>,
        link: Option<(socket::TunnelLink, SocketAddr)>,
    }

    impl Client {
        pub fn new(tag: &str, settings: Settings, detour: Detour) -> Result<Client> {
            // the config is checked here, at start
            client_cfg(&settings, SocketAddr::from(([192, 0, 2, 1], settings.port)), 1200, 1200)?;
            Ok(Client {
                tag: tag.to_string(),
                settings,
                detour,
                state: tokio::sync::OnceCell::new(),
                warp: tokio::sync::Mutex::new(None),
                shaken: tokio::sync::OnceCell::new(),
            })
        }

        pub fn detour(&self) -> Detour {
            self.detour
        }

        fn io(&self, e: impl std::fmt::Display) -> std::io::Error {
            std::io::Error::other(format!("{}: {e}", self.tag))
        }

        /// `--sunny`: carry the client's socket through this WARP tunnel, and on the first
        /// tunnel shake hands with the server and become the `sunny` outbound. A handshake that
        /// fails here fails the tunnel, so a wrong server shows up at start.
        pub async fn attach(self: &Arc<Self>, stack: &StackHandle) -> Result<()> {
            let client = self.ready_on(stack).await.map_err(|e| AetherError::Other(e.to_string()))?;
            log::info!("[sunnyquic] {}: udp to the sunnyquic server rides inside the masque tunnel (no local port)", self.tag);
            self.shaken
                .get_or_try_init(|| async {
                    self.handshake(&client).await?;
                    exits::set_sunny(self.clone());
                    Ok::<_, AetherError>(())
                })
                .await?;
            if self.settings.data_check {
                tokio::spawn(data_check(self.tag.clone(), client));
            }
            Ok(())
        }

        /// `--sunny` going direct: shake hands with the server and check the exit in the
        /// background. A failure is only logged: the client dials again on the next connection.
        pub fn start_direct(self: &Arc<Self>) {
            let me = self.clone();
            tokio::spawn(async move {
                let client = match me.ready().await {
                    Ok(c) => c,
                    Err(e) => {
                        log::warn!("[sunnyquic] {}: {e}; connections to sunny try again", me.tag);
                        return;
                    }
                };
                if let Err(e) = me.handshake(&client).await {
                    log::warn!("[sunnyquic] {e}; connections to sunny try again (sunny goes direct, it never falls back to WARP)");
                    return;
                }
                if me.settings.data_check {
                    data_check(me.tag.clone(), client).await;
                }
            });
        }

        /// Let go of the WARP stack the socket is on, as a tunnel that drops does.
        #[cfg(test)]
        pub async fn detach(&self) {
            *self.warp.lock().await = None;
        }

        async fn handshake(&self, client: &SunnyClient) -> Result<()> {
            let timeout = self.settings.handshake;
            log::info!("[sunnyquic] {}: QUIC handshake with the sunnyquic server (up to {timeout:?})", self.tag);
            // kept by the client: the first request reuses this connection instead of dialling again
            tokio::time::timeout(timeout, client.connection())
                .await
                .map_err(|_| {
                    AetherError::Other(format!(
                        "{}: no QUIC answer from {} within {timeout:?}: is the server up, the \
                         port open on udp, and the server name the one its certificate is for?",
                        self.tag,
                        self.settings.server_label()
                    ))
                })?
                .map_err(|e| AetherError::Other(format!("{}: QUIC handshake failed: {e}", self.tag)))?;
            log::info!("[sunnyquic] {}: QUIC handshake with {} done", self.tag, self.settings.server_label());
            Ok(())
        }

        /// The client, built (and, over WARP, on the current stack).
        async fn ready(&self) -> std::io::Result<Arc<SunnyClient>> {
            match self.detour {
                Detour::Direct => {
                    let built = self.state.get_or_try_init(|| self.build_direct()).await?;
                    Ok(built.client.clone())
                }
                Detour::Warp => {
                    let stack = match exits::stack() {
                        Some(s) => s,
                        None => match self.warp.lock().await.as_ref() {
                            // the tunnel it is on (a --sunny tunnel not published, a test)
                            Some((s, _)) => s.clone(),
                            None => self.wait_for_warp().await?,
                        },
                    };
                    self.ready_on(&stack).await
                }
            }
        }

        async fn wait_for_warp(&self) -> std::io::Result<StackHandle> {
            let who = format!("sunnyquic outbound {} (detour warp)", self.tag);
            exits::warp_stack(&who).await.map_err(std::io::Error::other)
        }

        async fn build_direct(&self) -> std::io::Result<Built> {
            use noq::Runtime;
            let remote = match self.settings.host.parse::<IpAddr>() {
                Ok(ip) => SocketAddr::new(ip, self.settings.port),
                Err(_) => *crate::proxy::socks::lookup_direct(&self.settings.host, self.settings.port)
                    .await?
                    .first()
                    .ok_or_else(|| self.io(format!("{} did not resolve", self.settings.host)))?,
            };
            // what an ordinary path carries without discovery: 1280 of IP payload
            let (initial_mtu, min_mtu) = self.settings.mtus(1280 + 28);
            let cfg = client_cfg(&self.settings, remote, initial_mtu, min_mtu).map_err(|e| self.io(e))?;
            let bind: SocketAddr = if remote.is_ipv4() {
                SocketAddr::from((std::net::Ipv4Addr::UNSPECIFIED, 0))
            } else {
                SocketAddr::from((std::net::Ipv6Addr::UNSPECIFIED, 0))
            };
            let sock = crate::utils::egress::udp_bind(bind)?.into_std()?;
            let wrapped = noq::TokioRuntime.wrap_udp_socket(sock)?;
            let client = SunnyClient::new(cfg, wrapped).map_err(|e| self.io(e))?;
            log::info!(
                "[sunnyquic] {}: sunnyquic to {} ({remote}) as '{}' from a local udp socket (sni {}, alpn {})",
                self.tag,
                self.settings.server_label(),
                self.settings.username,
                self.settings.server_name,
                self.settings.alpn.join(","),
            );
            Ok(Built { client: Arc::new(client), link: None })
        }

        /// Over WARP: the client built for `stack` (the server's name looked up through it, so
        /// the lookup never leaves on the local network), its socket attached there.
        async fn ready_on(&self, stack: &StackHandle) -> std::io::Result<Arc<SunnyClient>> {
            let mut current = self.warp.lock().await;
            let built = self
                .state
                .get_or_try_init(|| async {
                    let remote = match self.settings.host.parse::<IpAddr>() {
                        Ok(ip) => SocketAddr::new(ip, self.settings.port),
                        Err(_) => SocketAddr::new(
                            crate::proxy::socks::dns_resolve(stack, &self.settings.host).await.map_err(|e| self.io(e))?,
                            self.settings.port,
                        ),
                    };
                    let (initial_mtu, min_mtu) = self.settings.mtus(crate::transport::warp::masque_tunnel_mtu());
                    let cfg = client_cfg(&self.settings, remote, initial_mtu, min_mtu).map_err(|e| self.io(e))?;
                    let (sock, link) = socket::pair(remote);
                    let client = SunnyClient::new(cfg, Box::new(sock)).map_err(|e| self.io(e))?;
                    log::info!(
                        "[sunnyquic] {}: sunnyquic to {} ({remote}) as '{}' inside the WARP tunnel (sni {}, alpn {}, mtu \
                         {initial_mtu}/{min_mtu}, {} udp, 0-rtt {})",
                        self.tag,
                        self.settings.server_label(),
                        self.settings.username,
                        self.settings.server_name,
                        self.settings.alpn.join(","),
                        if self.settings.over_stream { "stream" } else { "datagram" },
                        if self.settings.zero_rtt { "on" } else { "off" },
                    );
                    Ok::<_, std::io::Error>(Built { client: Arc::new(client), link: Some((link, remote)) })
                })
                .await?;
            let (link, remote) = built.link.as_ref().ok_or_else(|| self.io("a direct client has no WARP socket"))?;
            if !current.as_ref().is_some_and(|(s, _)| s.same(stack)) {
                // the old attachment lets go of the link before the new one takes it
                *current = None;
                let attached = link.attach(stack, *remote).await.map_err(|e| self.io(e))?;
                *current = Some((stack.clone(), attached));
            }
            Ok(built.client.clone())
        }

        fn open_timeout(&self) -> Duration {
            self.settings.handshake + Duration::from_secs(5)
        }
    }

    /// A test request through the client, logging the address traffic leaves from: the
    /// sunnyquic server's, when all is well.
    async fn data_check(tag: String, client: Arc<SunnyClient>) {
        let exit = Exit { client };
        let probe = async {
            let s = exit.open_tcp("www.cloudflare.com", 80).await?;
            exit_trace(s, Duration::from_secs(20)).await
        };
        match probe.await {
            Ok((ip, loc)) => log::info!("[sunnyquic] {tag}: traffic leaves from {ip} ({loc}), the sunnyquic server's side"),
            Err(e) => log::warn!(
                "[sunnyquic] {tag}: a test request through the sunnyquic server failed: {e}. A wrong user or \
                 password shows up this way: the server closes the connection without a word"
            ),
        }
    }

    impl SunnyExit for Client {
        fn open_tcp<'a>(&'a self, host: &'a str, port: u16) -> BoxFuture<'a, std::io::Result<crate::proxy::socks::BoxStream>> {
            Box::pin(async move {
                let work = async {
                    let client = self.ready().await?;
                    Exit { client }.open_tcp(host, port).await
                };
                tokio::time::timeout(self.open_timeout(), work)
                    .await
                    .map_err(|_| self.io(format!("no stream to {host}:{port} within {:?}", self.open_timeout())))?
            })
        }

        fn open_udp(&self) -> BoxFuture<'_, std::io::Result<SunnyUdp>> {
            Box::pin(async move {
                let work = async {
                    let client = self.ready().await?;
                    Exit { client }.open_udp().await
                };
                tokio::time::timeout(self.open_timeout(), work)
                    .await
                    .map_err(|_| self.io(format!("no udp session within {:?}", self.open_timeout())))?
            })
        }
    }

    pub(crate) fn client_cfg(
        s: &Settings,
        server: SocketAddr,
        initial_mtu: u16,
        min_mtu: u16,
    ) -> Result<crate::proxy::sunnyquic::ClientConfig> {
        let congestion = match &s.congestion {
            CongestionChoice::Named(name) => match name.as_str() {
                "cubic" => CongestionControl::Cubic,
                "new-reno" | "newreno" => CongestionControl::NewReno,
                // noq has no BBRv1: "bbr" is BBRv3, as upstream makes it too
                _ => CongestionControl::Bbr3,
            },
            CongestionChoice::Raw(v) => v.clone().try_into().map_err(|e| {
                AetherError::Other(format!("sunny-config congestion-control: {e}"))
            })?,
        };
        let cipher_suites = match &s.cipher_suites {
            Some(v) => Some(v.clone().try_into().map_err(|e| {
                AetherError::Other(format!("sunny-config cipher-suite-preference: {e}"))
            })?),
            None => None,
        };
        Ok(crate::proxy::sunnyquic::ClientConfig {
            username: s.username.clone(),
            password: s.password.clone(),
            server,
            server_name: s.server_name.clone(),
            alpn: s.alpn.clone(),
            ca: s.ca.clone(),
            initial_mtu,
            min_mtu,
            congestion,
            zero_rtt: s.zero_rtt,
            over_stream: s.over_stream,
            keep_alive_ms: s.keep_alive_ms,
            gso: s.gso,
            mtu_discovery: s.mtu_discovery,
            cipher_suites,
        })
    }
}

/// Built without the `sunny` feature: no sunnyquic client can be made.
#[cfg(not(feature = "sunny"))]
pub struct Client;

#[cfg(not(feature = "sunny"))]
impl Client {
    pub fn new(_: &str, _: super::Settings, _: super::Detour) -> crate::error::Result<Client> {
        Err(crate::error::AetherError::Other(
            "this aether was built without the sunny feature, so it has no sunnyquic client".into(),
        ))
    }

    pub fn detour(&self) -> super::Detour {
        super::Detour::Direct
    }

    pub async fn attach(self: &std::sync::Arc<Self>, _: &crate::transport::warp::netstack::StackHandle) -> crate::error::Result<()> {
        unreachable!("no Client is ever built without the sunny feature")
    }

    pub fn start_direct(self: &std::sync::Arc<Self>) {
        unreachable!("no Client is ever built without the sunny feature")
    }
}

#[cfg(not(feature = "sunny"))]
impl super::SunnyExit for Client {
    fn open_tcp<'a>(&'a self, _: &'a str, _: u16) -> super::BoxFuture<'a, std::io::Result<crate::proxy::socks::BoxStream>> {
        Box::pin(async { Err(std::io::Error::other("built without the sunny feature")) })
    }

    fn open_udp(&self) -> super::BoxFuture<'_, std::io::Result<super::SunnyUdp>> {
        Box::pin(async { Err(std::io::Error::other("built without the sunny feature")) })
    }
}
