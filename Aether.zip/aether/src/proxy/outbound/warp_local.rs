//! `warp-local`: resolved by the resolver `direct` uses, connected through the WARP stack.

use crate::proxy::prelude::*;

/// What `warp-local` resolved with, for the log: the resolver `direct` uses.
pub(crate) fn local_dns_label() -> String {
    match crate::proxy::inbound::tun::direct_dns() {
        None => "system dns".to_string(),
        Some(crate::proxy::inbound::tun::DirectDns::Servers(list)) => format!(
            "direct dns {} over the physical interface",
            list.iter().map(|s| s.to_string()).collect::<Vec<_>>().join(", ")
        ),
        Some(crate::proxy::inbound::tun::DirectDns::Tunnel | crate::proxy::inbound::tun::DirectDns::System) => {
            "the tunnel's dns (tun.direct-dns: tunnel)".to_string()
        }
    }
}

/// The addresses `warp-local` connects to through WARP, and where they came from. An address
/// target is used as it is (nothing to resolve); a name is resolved by the resolver `direct`
/// uses (`lookup_direct`: the system resolver, or with the TUN the --tun-direct-dns servers
/// over the physical interface), unless a local `resolve` action already found addresses
/// (`local_resolved`). A fake-ip address is never returned.
pub(crate) async fn warp_local_addresses(
    host: &str,
    port: u16,
    local_resolved: &[IpAddr],
) -> std::io::Result<(Vec<IpAddr>, String)> {
    let name = host.trim_start_matches('[').trim_end_matches(']');
    if let Ok(ip) = name.parse::<IpAddr>() {
        if crate::proxy::inbound::tun::fakeip::is_fake(ip) {
            return Err(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                format!("{ip} is a fake-ip address with no name behind it"),
            ));
        }
        return Ok((vec![ip], "an address, no lookup".to_string()));
    }
    let mut out: Vec<IpAddr> = Vec::new();
    let from = if local_resolved.iter().any(|ip| !crate::proxy::inbound::tun::fakeip::is_fake(*ip)) {
        out.extend(local_resolved.iter().copied());
        "the local resolve action".to_string()
    } else {
        out.extend(lookup_direct(name, port).await?.into_iter().map(|a| a.ip()));
        local_dns_label()
    };
    let mut seen = Vec::new();
    out.retain(|ip| !crate::proxy::inbound::tun::fakeip::is_fake(*ip) && !seen.contains(ip) && {
        seen.push(*ip);
        true
    });
    if out.is_empty() {
        return Err(std::io::Error::new(std::io::ErrorKind::NotFound, format!("{name} did not resolve to any address")));
    }
    Ok((interleave_families(out), from))
}

/// The addresses in the resolver's order, the two families taking turns (the first address's
/// family first), so one unreachable family costs one attempt, not all of them.
pub(crate) fn interleave_families(ips: Vec<IpAddr>) -> Vec<IpAddr> {
    let Some(first) = ips.first().copied() else { return ips };
    let (mut a, mut b): (std::collections::VecDeque<IpAddr>, std::collections::VecDeque<IpAddr>) =
        ips.into_iter().partition(|ip| ip.is_ipv4() == first.is_ipv4());
    let mut out = Vec::with_capacity(a.len() + b.len());
    loop {
        match (a.pop_front(), b.pop_front()) {
            (None, None) => return out,
            (x, y) => out.extend(x.into_iter().chain(y)),
        }
    }
}

/// How long one address gets before `warp-local` tries the next (the last one gets the
/// stack's own connect timeout).
pub(crate) const WARP_LOCAL_ATTEMPT: Duration = Duration::from_secs(4);

/// `warp-local`: resolve `host` locally (`warp_local_addresses`), then `open` each address in
/// turn through WARP until one connects. `open` only ever gets an address, never a name.
pub(crate) async fn warp_local_connect<T, F, Fut>(host: &str, port: u16, local_resolved: &[IpAddr], mut open: F) -> Result<T>
where
    F: FnMut(IpAddr) -> Fut,
    Fut: Future<Output = Result<T>>,
{
    let (ips, from) = warp_local_addresses(host, port, local_resolved).await?;
    let list = ips.iter().map(|ip| ip.to_string()).collect::<Vec<_>>().join(", ");
    log::debug!("[route] {host}:{port} => warp-local (resolved {host} -> {list} via {from})");
    let mut last = None;
    for (i, ip) in ips.iter().enumerate() {
        let attempt = open(*ip);
        let r = if i + 1 < ips.len() {
            tokio::time::timeout(WARP_LOCAL_ATTEMPT, attempt)
                .await
                .unwrap_or_else(|_| Err(AetherError::Other(format!("{ip}:{port} did not answer in time"))))
        } else {
            attempt.await
        };
        match r {
            Ok(t) => return Ok(t),
            Err(e) => {
                log::debug!("[route] warp-local {ip}:{port} ({host}): {e}");
                last = Some(e);
            }
        }
    }
    Err(last.unwrap_or_else(|| AetherError::Other(format!("{host} did not resolve to any address"))))
}

pub(crate) struct WarpLocalOutbound;

impl AnyOutbound for WarpLocalOutbound {
    fn tag(&self) -> &str {
        "warp-local"
    }

    fn via(&self) -> Via {
        Via::WarpLocal
    }

    fn needs_warp(&self) -> bool {
        true
    }

    fn connect_stream<'a>(&'a self, req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>> {
        Box::pin(async move {
            // strict like warp: no WARP stack, no connection (never direct instead)
            let stack = req.exit.stack_soon("outbound warp-local").await?;
            let port = req.port;
            let (s, r, left) = warp_local_connect(req.host, port, req.resolved, |ip| {
                let stack = stack.clone();
                async move { open_tunneled(&stack, Target::Ip(ip), port).await }
            })
            .await?;
            Ok(Upstream::Tunnel(s, r, left))
        })
    }

    fn connect_packet(&self, req: PacketRequest<'_>) -> FlowRoute {
        // an address (the flow's own, an override, or a local `resolve` result) goes as it is;
        // a name is resolved locally when the flow is set up
        let (meta, ropts) = (req.meta, req.ropts);
        let port = ropts.override_port.unwrap_or(meta.port);
        let local = match &ropts.override_address {
            Some(a) => a.parse::<IpAddr>().ok().map(|ip| SocketAddr::new(ip, port)),
            None => meta
                .ip
                .or(meta.resolved.first().copied().filter(|_| meta.resolved_local))
                .map(|ip| SocketAddr::new(ip, port)),
        };
        match local.filter(|a| !crate::proxy::inbound::tun::fakeip::is_fake(a.ip())) {
            Some(a) => FlowRoute::Warp(Some(a)),
            None => FlowRoute::WarpLocal,
        }
    }
}
