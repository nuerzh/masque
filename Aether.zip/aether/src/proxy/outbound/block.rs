//! `block` / `reject`: refused.

use crate::proxy::prelude::*;

pub(crate) struct BlockOutbound;

impl AnyOutbound for BlockOutbound {
    fn tag(&self) -> &str {
        "block"
    }

    fn via(&self) -> Via {
        Via::Block
    }

    fn needs_warp(&self) -> bool {
        false
    }

    fn connect_stream<'a>(&'a self, _req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>> {
        Box::pin(async { Err(AetherError::Other("blocked".into())) })
    }

    fn connect_packet(&self, _req: PacketRequest<'_>) -> FlowRoute {
        FlowRoute::Drop
    }
}
