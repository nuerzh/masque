//! `direct`: out of this machine's own network (bound to the physical interface while a TUN is up).

use crate::proxy::prelude::*;

/// Split a TLS ClientHello record into several records (sing-box `tls_record_fragment`).
pub(crate) fn split_tls_records(head: &[u8]) -> Option<Vec<u8>> {
    if head.len() < 6 || head[0] != 0x16 || head[5] != 0x01 {
        return None;
    }
    let len = ((head[3] as usize) << 8) | head[4] as usize;
    if head.len() < 5 + len || len < 2 {
        return None;
    }
    let body = &head[5..5 + len];
    // cut inside the server name when there is one, else in the middle
    let cut = crate::utils::fragment::sni_host_range(head)
        .map(|(start, end)| (start + (end - start) / 2).saturating_sub(5))
        .filter(|c| *c > 0 && *c < body.len())
        .unwrap_or(body.len() / 2);
    let mut out = Vec::with_capacity(head.len() + 5);
    for part in [&body[..cut], &body[cut..]] {
        out.extend_from_slice(&head[..3]);
        out.extend_from_slice(&(part.len() as u16).to_be_bytes());
        out.extend_from_slice(part);
    }
    out.extend_from_slice(&head[5 + len..]);
    Some(out)
}

pub(crate) async fn dial_direct(host: &str, port: u16, resolved: &[IpAddr], client: IpAddr) -> std::io::Result<TcpStream> {
    let work = async {
        if !resolved.is_empty() {
            let mut last = None;
            for ip in resolved {
                if !direct_target_allowed(client, *ip) || crate::proxy::inbound::tun::fakeip::is_fake(*ip) {
                    continue;
                }
                match crate::utils::egress::tcp_connect(SocketAddr::new(*ip, port)).await {
                    Ok(s) => {
                        let _ = s.set_nodelay(true);
                        enable_keepalive(&s);
                        return Ok(s);
                    }
                    Err(e) => last = Some(e),
                }
            }
            if let Some(e) = last {
                return Err(e);
            }
        }
        connect_direct(host, port, client).await
    };
    tokio::time::timeout(DIRECT_CONNECT_TIMEOUT, work)
        .await
        .unwrap_or_else(|_| Err(std::io::Error::new(std::io::ErrorKind::TimedOut, format!("direct connect to {host}:{port} timed out"))))
}

pub(crate) struct DirectOutbound;

impl AnyOutbound for DirectOutbound {
    fn tag(&self) -> &str {
        "direct"
    }

    fn via(&self) -> Via {
        Via::Direct
    }

    fn needs_warp(&self) -> bool {
        false
    }

    fn connect_stream<'a>(&'a self, req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>> {
        Box::pin(async move { Ok(Upstream::Tcp(dial_direct(req.host, req.port, req.resolved, req.client).await?)) })
    }

    fn connect_packet(&self, req: PacketRequest<'_>) -> FlowRoute {
        FlowRoute::Direct(flow_addr(req.meta, req.ropts))
    }
}
