//! Outbounds: where a routed connection leaves, laid out as QuicProxy lays out its own. Every
//! outbound implements `AnyOutbound` (`connect_stream` for tcp, `connect_packet` for how a udp
//! flow is carried) and sits in one registry, looked up by tag or by the router's `OutKind`:
//!
//! - `direct`: this machine's own network (bound to the physical interface while a TUN is up)
//! - `block`
//! - `warp`: the WARP tunnel stack of the running mode
//! - `warp-local`: resolved here, carried by WARP
//! - `sunny`: the in-process sunnyquic client of --sunny, on a local udp socket by default
//!   ([sunny] `detour = "direct"`), riding the WARP MASQUE tunnel with `detour = "warp"`
//! - `sunny-direct` and the `sunnyquic` outbounds a config declares: the same sunnyquic client
//!   (`sunnyquic/`), on a local udp socket or (`detour: warp`) on the WARP stack
//!
//! The alias `proxy` / `tunnel` is the only tag that depends on the mode (`resolve`).

pub mod block;
pub mod direct;
#[cfg(test)]
pub mod socks5;
pub mod sunnyquic;
pub mod warp;
pub mod warp_local;

use super::prelude::*;
pub(crate) use direct::*;
#[cfg(test)]
pub(crate) use socks5::*;
pub(crate) use warp_local::*;

pub use sunnyquic::{BoxFuture, SunnyExit, SunnyUdp};

pub trait Duplex: AsyncRead + AsyncWrite + Send + Unpin {}
impl<T: AsyncRead + AsyncWrite + Send + Unpin> Duplex for T {}
pub type BoxStream = Box<dyn Duplex>;

/// What the router's `warp` / `tunnel` outbound means for this listener.
#[derive(Clone)]
pub(crate) enum Exit {
    /// Whatever WARP stack is current: the listeners outlive each tunnel.
    Current,
}

impl Exit {
    /// The WARP stack: the listener's own, or the current one.
    pub(crate) fn stack(&self) -> Option<StackHandle> {
        match self {
            Exit::Current => exits::stack(),
        }
    }

    /// The WARP stack, waiting for it while the WARP tunnel connects (the first tunnel of the
    /// run: the scan may still be going) or reconnects; `who` names the outbound in the error.
    pub(crate) async fn stack_soon(&self, who: &str) -> Result<StackHandle> {
        if let Some(s) = self.stack() {
            return Ok(s);
        }
        exits::warp_stack(who).await.map_err(AetherError::Other)
    }
}

/// The kind of exit an outbound is. Strict: `sunny` is only ever the --sunny client, `warp` only
/// ever the WARP stack; neither stands in for the other.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Via {
    Direct,
    Block,
    Warp,
    /// Resolved on this machine (as `direct` resolves), connected through the WARP stack.
    WarpLocal,
    /// The sunnyquic client of --sunny (direct by default, over WARP MASQUE with detour warp).
    Sunny,
    /// A sunnyquic client of its own (`sunny-direct`, a declared `sunnyquic` outbound).
    SunnyQuic,
}

impl Via {
    /// What `kind` is on this listener.
    #[cfg(test)]
    pub(crate) fn of(kind: OutKind, exit: &Exit) -> Via {
        outbound_for(kind, exit).via()
    }

    pub(crate) fn label(self) -> &'static str {
        match self {
            Via::Direct => "direct",
            Via::Block => "block",
            Via::Warp => "warp",
            Via::WarpLocal => "warp-local",
            Via::Sunny => "sunny",
            Via::SunnyQuic => "sunnyquic",
        }
    }
}

pub(crate) enum Upstream {
    Tunnel(TcpSender, tokio::sync::mpsc::Receiver<Vec<u8>>, Vec<u8>),
    Tcp(TcpStream),
    Boxed(BoxStream),
}

/// A tcp connection to open through an outbound.
pub(crate) struct StreamRequest<'a> {
    /// The target as the inbound gave it (a domain stays a domain).
    pub host: &'a str,
    pub port: u16,
    /// Addresses a `resolve` action found for it (`warp-local` only gets local ones).
    pub resolved: &'a [IpAddr],
    /// The client's address, for the `direct` loopback check.
    pub client: IpAddr,
    pub exit: &'a Exit,
}

/// A udp flow the router decided for an outbound.
pub(crate) struct PacketRequest<'a> {
    pub meta: &'a Metadata,
    pub ropts: &'a RouteOpts,
}

/// One outbound: how it opens a tcp stream and how it carries a udp flow.
pub(crate) trait AnyOutbound: Send + Sync {
    fn tag(&self) -> &str;
    fn via(&self) -> Via;
    /// Whether it rides the WARP tunnel (and so needs WARP to be started).
    fn needs_warp(&self) -> bool;
    fn connect_stream<'a>(&'a self, req: StreamRequest<'a>) -> BoxFuture<'a, Result<Upstream>>;
    /// How the flow goes: dropped, a datagram socket of the inbound's udp nat (direct, WARP),
    /// or a session of this outbound's own (`packet_exit`).
    fn connect_packet(&self, req: PacketRequest<'_>) -> FlowRoute;
    /// The client that carries this outbound's udp sessions, while it is up.
    fn packet_exit(&self) -> Option<Arc<dyn SunnyExit>> {
        None
    }
}

// ---------------------------------------------------------------------------------------------
// the registry

struct Registry {
    list: Vec<Arc<dyn AnyOutbound>>,
    by_tag: HashMap<String, u16>,
}

const DIRECT: u16 = 0;
const BLOCK: u16 = 1;
const WARP: u16 = 2;
const WARP_LOCAL: u16 = 3;
const SUNNY: u16 = 4;

fn registry() -> &'static parking_lot::RwLock<Registry> {
    static R: std::sync::OnceLock<parking_lot::RwLock<Registry>> = std::sync::OnceLock::new();
    R.get_or_init(|| {
        let list: Vec<Arc<dyn AnyOutbound>> = vec![
            Arc::new(direct::DirectOutbound),
            Arc::new(block::BlockOutbound),
            Arc::new(warp::WarpOutbound),
            Arc::new(warp_local::WarpLocalOutbound),
            Arc::new(sunnyquic::SunnyOutbound { index: SUNNY }),
        ];
        parking_lot::RwLock::new(Registry { list, by_tag: HashMap::new() })
    })
}

/// Add an outbound of a config (or sunny-direct) under its tag; its index is what the router's
/// `OutKind::Custom` carries.
pub(crate) fn register(make: impl FnOnce(u16) -> Arc<dyn AnyOutbound>) -> u16 {
    let mut r = registry().write();
    let index = r.list.len() as u16;
    let out = make(index);
    r.by_tag.insert(out.tag().to_string(), index);
    r.list.push(out);
    index
}

/// The index of a registered outbound by its tag.
pub(crate) fn by_tag(tag: &str) -> Option<u16> {
    registry().read().by_tag.get(tag).copied()
}

pub(crate) fn outbound_at(index: u16) -> Option<Arc<dyn AnyOutbound>> {
    registry().read().list.get(index as usize).cloned()
}

fn builtin(index: u16) -> Arc<dyn AnyOutbound> {
    outbound_at(index).expect("the builtin outbounds")
}

/// The outbound `kind` means. Only `proxy` / `tunnel` depends on the mode: sunnyquic in
/// --sunny, WARP otherwise.
pub(crate) fn outbound_for(kind: OutKind, _exit: &Exit) -> Arc<dyn AnyOutbound> {
    match kind {
        OutKind::Direct => builtin(DIRECT),
        OutKind::Block => builtin(BLOCK),
        OutKind::Warp => builtin(WARP),
        OutKind::WarpLocal => builtin(WARP_LOCAL),
        OutKind::Sunny => builtin(SUNNY),
        OutKind::Custom(index) => outbound_at(index).unwrap_or_else(|| builtin(BLOCK)),
        OutKind::Tunnel => {
            if crate::proxy::router::sunny_mode() {
                builtin(SUNNY)
            } else {
                builtin(WARP)
            }
        }
    }
}

/// Why `kind` needs WARP when that is not plain from its tag, for the start-up log;
/// `sunny_over_warp`: the --sunny client has `detour = "warp"`.
pub(crate) fn warp_reason(kind: OutKind, sunny_over_warp: bool) -> &'static str {
    match kind {
        OutKind::Sunny if sunny_over_warp => " (the sunny sunnyquic client has detour: warp: it rides inside WARP MASQUE)",
        OutKind::Tunnel if crate::proxy::router::sunny_mode() && sunny_over_warp => {
            " (proxy is the sunny sunnyquic client, detour: warp: inside WARP MASQUE)"
        }
        OutKind::Custom(index) if outbound_at(index).is_some_and(|o| o.via() == Via::SunnyQuic) => {
            " (a sunnyquic outbound with detour: warp)"
        }
        _ => "",
    }
}

/// Whether sending to `kind` needs the WARP tunnel, as the run starts. `sunny` (and `proxy` in
/// --sunny, which is `sunny`) only when the --sunny client has `detour = "warp"`; `proxy`
/// outside --sunny is WARP.
pub(crate) fn kind_needs_warp(kind: OutKind, sunny_over_warp: bool) -> bool {
    match kind {
        OutKind::Sunny => sunny_over_warp,
        OutKind::Tunnel if crate::proxy::router::sunny_mode() => sunny_over_warp,
        OutKind::Tunnel => true,
        OutKind::Custom(index) => outbound_at(index).is_some_and(|o| o.needs_warp()),
        k => outbound_for(k, &Exit::Current).needs_warp(),
    }
}

/// Open a tcp stream to `host:port` through `kind`.
pub(crate) async fn dial(
    kind: OutKind,
    host: &str,
    port: u16,
    resolved: &[IpAddr],
    client: IpAddr,
    exit: &Exit,
) -> Result<Upstream> {
    outbound_for(kind, exit).connect_stream(StreamRequest { host, port, resolved, client, exit }).await
}

// ---------------------------------------------------------------------------------------------
// detour listeners for rule-set downloads

/// A loopback socks5 listener that sends every connection to `kind`, for downloading rule sets
/// through it. Started on first use and kept for the run.
pub(crate) async fn detour_proxy(kind: OutKind) -> std::io::Result<SocketAddr> {
    use parking_lot::Mutex;
    // (kind, address, run): a listener of an earlier run is gone with it
    static LISTENERS: Mutex<Vec<(OutKind, SocketAddr, u64)>> = Mutex::new(Vec::new());

    // wait until the exit is there. Strict: `warp` waits for the WARP stack, `sunny` for the
    // sunnyquic client; only `proxy` / `tunnel` follows the mode (sunny in --sunny, else WARP).
    let kind = match kind {
        OutKind::Tunnel if crate::proxy::router::sunny_mode() => OutKind::Sunny,
        OutKind::Tunnel => OutKind::Warp,
        k => k,
    };
    match kind {
        OutKind::Direct | OutKind::Block | OutKind::Tunnel | OutKind::Custom(_) => {}
        OutKind::Warp | OutKind::WarpLocal => exits::wait_for(|| exits::stack().is_some()).await,
        OutKind::Sunny => exits::wait_for(|| exits::sunny().is_some()).await,
    }
    let run = crate::utils::shutdown::token();
    {
        let mut listeners = LISTENERS.lock();
        listeners.retain(|(_, _, generation)| *generation == run.generation());
        if let Some((_, addr, _)) = listeners.iter().find(|(k, _, _)| *k == kind) {
            return Ok(*addr);
        }
    }
    let listener = TcpListener::bind("127.0.0.1:0").await?;
    let addr = listener.local_addr()?;
    LISTENERS.lock().push((kind, addr, run.generation()));
    crate::utils::shutdown::spawn_with(run, async move {
        loop {
            let Ok((mut sock, _)) = listener.accept().await else { continue };
            tokio::spawn(async move {
                let Ok(Ok((cmd, target, port))) = tokio::time::timeout(HANDSHAKE_TIMEOUT, read_request(&mut sock)).await else {
                    return;
                };
                if cmd != CMD_CONNECT {
                    let _ = reply(&mut sock, REP_NOT_SUPPORTED).await;
                    return;
                }
                let host = target_host(&target);
                let client = sock.peer_addr().map(|a| a.ip()).unwrap_or(IpAddr::from([127, 0, 0, 1]));
                match dial(kind, &host, port, &[], client, &Exit::Current).await {
                    Ok(up) => {
                        if reply_bound(&mut sock, crate::utils::egress::WILDCARD_V4).await.is_err() {
                            return;
                        }
                        match up {
                            Upstream::Tunnel(s, r, left) => {
                                if !left.is_empty() && sock.write_all(&left).await.is_err() {
                                    return;
                                }
                                relay_tunneled(sock, s, r, half_close_linger()).await
                            }
                            Upstream::Tcp(t) => relay_direct(sock, t, half_close_linger()).await,
                            Upstream::Boxed(b) => relay_generic(sock, b, half_close_linger()).await,
                        }
                    }
                    Err(e) => {
                        log::debug!("[route] detour {} to {host}:{port}: {e}", kind.label());
                        let _ = reply(&mut sock, REP_GENERAL).await;
                    }
                }
            });
        }
    });
    Ok(addr)
}
