//! A socks5 client for tests (a sunny exit spoken to as a socks5 proxy).

use crate::proxy::prelude::*;

/// A socks5 CONNECT through the sunnyquic client's own listener.
pub(crate) async fn socks5_connect(proxy: SocketAddr, host: &str, port: u16) -> std::io::Result<TcpStream> {
    let mut s = TcpStream::connect(proxy).await?;
    let _ = s.set_nodelay(true);
    s.write_all(&[VER, 1, 0]).await?;
    let mut r = [0u8; 2];
    s.read_exact(&mut r).await?;
    if r != [VER, 0] {
        return Err(std::io::Error::other("the sunnyquic socks5 listener refused the greeting"));
    }
    let mut req = vec![VER, CMD_CONNECT, 0];
    push_socks_addr(&mut req, host, port);
    s.write_all(&req).await?;
    let mut rep = [0u8; 4];
    s.read_exact(&mut rep).await?;
    if rep[1] != REP_OK {
        return Err(std::io::Error::new(
            std::io::ErrorKind::ConnectionRefused,
            format!("sunnyquic refused {host}:{port} (socks5 reply {})", rep[1]),
        ));
    }
    read_addr(&mut s, rep[3]).await?;
    Ok(s)
}

pub(crate) fn push_socks_addr(out: &mut Vec<u8>, host: &str, port: u16) {
    if let Ok(ip) = host.parse::<IpAddr>() {
        return push_socket_addr(out, SocketAddr::new(ip, port));
    }
    let name = &host.as_bytes()[..host.len().min(255)];
    out.push(ATYP_DOMAIN);
    out.push(name.len() as u8);
    out.extend_from_slice(name);
    out.extend_from_slice(&port.to_be_bytes());
}

/// A sunny exit spoken to as a socks5 proxy (tcp connect and udp associate). Aether's own
/// --sunny client is in-process; this stands in for it in tests.
pub(crate) struct SocksSunny(pub(crate) SocketAddr);

impl exits::SunnyExit for SocksSunny {
    fn open_tcp<'a>(&'a self, host: &'a str, port: u16) -> exits::BoxFuture<'a, std::io::Result<BoxStream>> {
        Box::pin(async move { Ok(Box::new(socks5_connect(self.0, host, port).await?) as BoxStream) })
    }

    fn open_udp(&self) -> exits::BoxFuture<'_, std::io::Result<exits::SunnyUdp>> {
        Box::pin(socks5_udp(self.0))
    }
}

pub(crate) async fn socks5_udp(proxy: SocketAddr) -> std::io::Result<exits::SunnyUdp> {
    let mut c = TcpStream::connect(proxy).await?;
    c.write_all(&[VER, 1, 0]).await?;
    let mut r = [0u8; 2];
    c.read_exact(&mut r).await?;
    if r != [VER, 0] {
        return Err(std::io::Error::other("socks5 greeting refused"));
    }
    let local_ip = crate::utils::egress::wildcard_for(proxy).ip();
    let sock = UdpSocket::bind(SocketAddr::new(local_ip, 0)).await?;
    let mut req = vec![VER, CMD_UDP_ASSOCIATE, 0];
    push_socks_addr(&mut req, &local_ip.to_string(), 0);
    c.write_all(&req).await?;
    let mut rep = [0u8; 4];
    c.read_exact(&mut rep).await?;
    if rep[1] != REP_OK {
        return Err(std::io::Error::other(format!("socks5 udp associate refused ({})", rep[1])));
    }
    let (bound, port) = read_addr(&mut c, rep[3]).await?;
    let Target::Ip(ip) = bound else { return Err(std::io::Error::other("bad udp associate reply")) };
    let ip = if ip.is_unspecified() { proxy.ip() } else { ip };
    let relay = SocketAddr::new(ip, port);

    let (tx, mut out_rx) = tokio::sync::mpsc::channel::<(String, u16, Vec<u8>)>(256);
    let (in_tx, rx) = tokio::sync::mpsc::channel(256);
    let task = tokio::spawn(async move {
        let _control = c;
        let mut buf = vec![0u8; 65535];
        loop {
            tokio::select! {
                m = out_rx.recv() => {
                    let Some((host, port, data)) = m else { return };
                    let mut pkt = vec![0, 0, 0];
                    push_socks_addr(&mut pkt, &host, port);
                    pkt.extend_from_slice(&data);
                    let _ = sock.send_to(&pkt, relay).await;
                }
                r = sock.recv_from(&mut buf) => {
                    let Ok((n, _)) = r else { continue };
                    if let Some((src, (sport, data))) = parse_udp_request(&buf[..n]) {
                        let src = match src {
                            Target::Ip(ip) => Some(SocketAddr::new(ip, sport)),
                            Target::Domain(_) => None,
                        };
                        if in_tx.send((src, data)).await.is_err() {
                            return;
                        }
                    }
                }
            }
        }
    });
    Ok(exits::SunnyUdp { tx, rx, guard: Some(task.abort_handle()), pumps: Vec::new() })
}
