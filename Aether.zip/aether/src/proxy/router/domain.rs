//! Domain matchers with the exact semantics of sing-box (`sing/common/domain`).
//!
//! sing-box keeps `domain` / `domain_suffix` in a succinct trie of reversed names, and `.srs`
//! files carry that trie verbatim. The trie is decoded (or, for json rule sets, built) here and
//! walked with the same algorithm, so a name matches here exactly when it matches in sing-box:
//!
//! * `domain: example.com` matches only `example.com`;
//! * `domain_suffix: example.com` matches `example.com` and every name under it;
//! * `domain_suffix: .example.com` matches only names under it.
//!
//! The AdGuard matcher (rule item 16 of the binary format) is ported the same way.

use std::io::Read;

use super::srs::{read_uvarint, Error};

/// The label that ends a reversed key meaning "anything may follow" (`.example.com` suffixes,
/// and every suffix written by rule-set version 1).
const PREFIX_LABEL: u8 = b'\r';
/// The label that ends a reversed key meaning "this name or any name under it".
const ROOT_LABEL: u8 = b'\n';
/// AdGuard: `*` in a rule.
const ANY_LABEL: u8 = b'*';
/// AdGuard: a rule with no trailing `^`.
const SUFFIX_LABEL: u8 = 0x08;

#[derive(Debug, Clone, Default)]
struct SuccinctSet {
    leaves: Vec<u64>,
    label_bitmap: Vec<u64>,
    labels: Vec<u8>,
    /// ranks[w] = number of ones in label_bitmap words before w; one extra trailing entry.
    ranks: Vec<u32>,
}

fn get_bit(bm: &[u64], i: usize) -> bool {
    match bm.get(i >> 6) {
        Some(word) => word & (1u64 << (i & 63)) != 0,
        None => false,
    }
}

/// An out-of-range read of the label bitmap counts as a set bit, which ends every scan.
fn label_end(bm: &[u64], i: usize) -> bool {
    match bm.get(i >> 6) {
        Some(word) => word & (1u64 << (i & 63)) != 0,
        None => true,
    }
}

fn set_bit(bm: &mut Vec<u64>, i: usize) {
    while (i >> 6) >= bm.len() {
        bm.push(0);
    }
    bm[i >> 6] |= 1u64 << (i & 63);
}

fn ensure_len(bm: &mut Vec<u64>, i: usize) {
    while (i >> 6) >= bm.len() {
        bm.push(0);
    }
}

impl SuccinctSet {
    fn init(&mut self) {
        let mut ranks = Vec::with_capacity(self.label_bitmap.len() + 1);
        let mut n = 0u32;
        for word in &self.label_bitmap {
            ranks.push(n);
            n += word.count_ones();
        }
        ranks.push(n);
        self.ranks = ranks;
    }

    /// Ones in label_bitmap[0..i).
    fn rank1(&self, i: usize) -> usize {
        let word_i = i >> 6;
        if word_i >= self.label_bitmap.len() {
            return *self.ranks.last().unwrap_or(&0) as usize;
        }
        let j = i & 63;
        let mask = if j == 0 { 0 } else { (1u64 << j) - 1 };
        self.ranks[word_i] as usize + (self.label_bitmap[word_i] & mask).count_ones() as usize
    }

    fn count_zeros(&self, i: usize) -> usize {
        i - self.rank1(i)
    }

    /// Position of the i-th (0-based) set bit of label_bitmap.
    fn select1(&self, i: usize) -> usize {
        // the last word w with ranks[w] <= i
        let words = self.label_bitmap.len();
        if words == 0 {
            return 0;
        }
        let (mut lo, mut hi) = (0usize, words); // ranks[lo] <= i, find largest
        while lo + 1 < hi {
            let mid = (lo + hi) / 2;
            if self.ranks[mid] as usize <= i {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        // there may be empty words; advance while the word holds fewer ones than needed
        let mut w = lo;
        while w < words && self.ranks[w + 1] as usize <= i {
            w += 1;
        }
        if w >= words {
            return words << 6;
        }
        let mut word = self.label_bitmap[w];
        let mut k = i - self.ranks[w] as usize;
        while k > 0 {
            word &= word - 1;
            k -= 1;
        }
        (w << 6) + word.trailing_zeros() as usize
    }

    fn child(&self, bm_idx: usize) -> (usize, usize) {
        let node_id = self.count_zeros(bm_idx + 1);
        let next_bm = if node_id == 0 {
            0
        } else {
            self.select1(node_id - 1) + 1
        };
        (node_id, next_bm)
    }

    fn label_at(&self, bm_idx: usize, node_id: usize) -> Option<u8> {
        bm_idx
            .checked_sub(node_id)
            .and_then(|at| self.labels.get(at))
            .copied()
    }

    /// Port of newSuccinctSet; `keys` must be sorted and deduplicated.
    fn build(keys: &[Vec<u8>]) -> Self {
        let mut ss = SuccinctSet::default();
        let mut l_idx = 0usize;
        struct Elt {
            s: usize,
            e: usize,
            col: usize,
        }
        let mut queue = vec![Elt {
            s: 0,
            e: keys.len(),
            col: 0,
        }];
        let mut i = 0;
        while i < queue.len() {
            let (mut s, e, col) = (queue[i].s, queue[i].e, queue[i].col);
            if s < e && col == keys[s].len() {
                s += 1;
                set_bit(&mut ss.leaves, i);
            } else {
                ensure_len(&mut ss.leaves, i);
            }
            let mut j = s;
            while j < e {
                let frm = j;
                while j < e && keys[j][col] == keys[frm][col] {
                    j += 1;
                }
                queue.push(Elt {
                    s: frm,
                    e: j,
                    col: col + 1,
                });
                ss.labels.push(keys[frm][col]);
                ensure_len(&mut ss.label_bitmap, l_idx);
                l_idx += 1;
            }
            set_bit(&mut ss.label_bitmap, l_idx);
            l_idx += 1;
            i += 1;
        }
        ss.init();
        ss
    }

    /// The format of `succinctSet.Write`: a zero byte, then leaves, label bitmap and labels as
    /// uvarint-counted big-endian slices.
    fn read<R: Read>(r: &mut R) -> Result<Self, Error> {
        let mut first = [0u8; 1];
        r.read_exact(&mut first)?;
        let leaves = read_u64_slice(r)?;
        let label_bitmap = read_u64_slice(r)?;
        let n = read_uvarint(r)? as usize;
        if n > 1 << 30 {
            return Err(Error::Malformed("succinct set labels too long".into()));
        }
        let mut labels = vec![0u8; n];
        r.read_exact(&mut labels)?;

        let ones: usize = label_bitmap.iter().map(|w| w.count_ones() as usize).sum();
        let mut last_one: isize = -1;
        for (wi, word) in label_bitmap.iter().enumerate() {
            if *word != 0 {
                last_one = ((wi << 6) | (63 - word.leading_zeros() as usize)) as isize;
            }
        }
        let zeros = (last_one + 1) as usize - ones.min((last_one + 1) as usize);
        if ones != zeros + 1 || labels.len() != zeros {
            return Err(Error::Malformed("domain: malformed succinct set".into()));
        }
        let mut leaves = leaves;
        let words = ones.div_ceil(64);
        if leaves.len() < words {
            leaves.resize(words, 0);
        }
        let mut set = SuccinctSet {
            leaves,
            label_bitmap,
            labels,
            ranks: Vec::new(),
        };
        set.init();
        Ok(set)
    }

    /// Every key in the set (port of keys()); used by tests and for counting.
    #[cfg(test)]
    fn keys(&self) -> Vec<Vec<u8>> {
        let mut result = Vec::new();
        if get_bit(&self.leaves, 0) {
            result.push(Vec::new());
        }
        let mut current: Vec<u8> = Vec::new();
        let mut stack: Vec<(usize, usize)> = vec![(0, 0)];
        while let Some(top) = stack.last().copied() {
            let (node_id, bm_idx) = top;
            if label_end(&self.label_bitmap, bm_idx) {
                stack.pop();
                if let Some(parent) = stack.last_mut() {
                    current.pop();
                    parent.1 += 1;
                }
                continue;
            }
            let Some(label) = self.label_at(bm_idx, node_id) else {
                break;
            };
            current.push(label);
            let (next_node, next_bm) = self.child(bm_idx);
            if get_bit(&self.leaves, next_node) {
                result.push(current.clone());
            }
            stack.push((next_node, next_bm));
            if stack.len() > 4096 {
                break;
            }
        }
        result
    }
}

fn read_u64_slice<R: Read>(r: &mut R) -> Result<Vec<u64>, Error> {
    let n = read_uvarint(r)? as usize;
    if n > 1 << 27 {
        return Err(Error::Malformed("succinct set too large".into()));
    }
    let mut out = Vec::with_capacity(n);
    let mut b = [0u8; 8];
    for _ in 0..n {
        r.read_exact(&mut b)?;
        out.push(u64::from_be_bytes(b));
    }
    Ok(out)
}

fn reverse(name: &str) -> Vec<u8> {
    // sing-box reverses by runes; names are compared lowercased ASCII/UTF-8 alike.
    let mut out: Vec<u8> = Vec::with_capacity(name.len());
    for ch in name.chars().rev() {
        let mut buf = [0u8; 4];
        out.extend_from_slice(ch.encode_utf8(&mut buf).as_bytes());
    }
    out
}

/// `domain` + `domain_suffix` of one rule.
#[derive(Debug, Clone, Default)]
pub struct DomainMatcher {
    set: SuccinctSet,
}

impl DomainMatcher {
    /// Port of `domain.NewMatcher(domains, suffixes, false)`.
    pub fn new(domains: &[String], suffixes: &[String]) -> Self {
        let mut list: Vec<Vec<u8>> = Vec::with_capacity(domains.len() + suffixes.len());
        let mut seen = std::collections::HashSet::new();
        for suffix in suffixes {
            if suffix.is_empty() || !seen.insert(suffix.clone()) {
                continue;
            }
            if suffix.starts_with('.') {
                list.push(reverse(&format!("{}{suffix}", PREFIX_LABEL as char)));
            } else {
                list.push(reverse(&format!("{}{suffix}", ROOT_LABEL as char)));
            }
        }
        for domain in domains {
            if domain.is_empty() || !seen.insert(domain.clone()) {
                continue;
            }
            list.push(reverse(domain));
        }
        list.sort();
        list.dedup();
        Self {
            set: SuccinctSet::build(&list),
        }
    }

    pub fn read<R: Read>(r: &mut R) -> Result<Self, Error> {
        Ok(Self {
            set: SuccinctSet::read(r)?,
        })
    }

    #[cfg(test)]
    pub fn len(&self) -> usize {
        self.set.keys().len()
    }

    /// Port of `Matcher.Match`; `name` must already be lowercase.
    pub fn matches(&self, name: &str) -> bool {
        let key = reverse(name);
        let set = &self.set;
        if set.label_bitmap.is_empty() {
            return false;
        }
        let (mut node_id, mut bm_idx) = (0usize, 0usize);
        for &current in &key {
            loop {
                if label_end(&set.label_bitmap, bm_idx) {
                    return false;
                }
                let Some(next) = set.label_at(bm_idx, node_id) else {
                    return false;
                };
                if next == PREFIX_LABEL {
                    return true;
                }
                if next == ROOT_LABEL {
                    let next_node = set.count_zeros(bm_idx + 1);
                    if current == b'.' && get_bit(&set.leaves, next_node) {
                        return true;
                    }
                }
                if next == current {
                    break;
                }
                bm_idx += 1;
            }
            let (n, b) = set.child(bm_idx);
            node_id = n;
            bm_idx = b;
        }
        if get_bit(&set.leaves, node_id) {
            return true;
        }
        loop {
            if label_end(&set.label_bitmap, bm_idx) {
                return false;
            }
            let Some(next) = set.label_at(bm_idx, node_id) else {
                return false;
            };
            if next == PREFIX_LABEL || next == ROOT_LABEL {
                return true;
            }
            bm_idx += 1;
        }
    }

    /// The domains and suffixes, as `Matcher.Dump` gives them (for tests and diagnostics).
    #[cfg(test)]
    pub fn dump(&self) -> (Vec<String>, Vec<String>) {
        let mut domains = std::collections::BTreeSet::new();
        let mut prefixes = std::collections::BTreeSet::new();
        let mut suffixes = Vec::new();
        for key in self.set.keys() {
            let mut k = key.clone();
            k.reverse();
            let Ok(text) = String::from_utf8(k) else {
                continue;
            };
            let bytes = text.as_bytes();
            if bytes.is_empty() {
                continue;
            }
            match bytes[0] {
                PREFIX_LABEL => {
                    prefixes.insert(text[1..].to_string());
                }
                ROOT_LABEL => suffixes.push(text[1..].to_string()),
                _ => {
                    domains.insert(text);
                }
            }
        }
        for raw in prefixes {
            if let Some(root) = raw.strip_prefix('.') {
                if domains.remove(root) {
                    suffixes.push(root.to_string());
                    continue;
                }
            }
            suffixes.push(raw);
        }
        suffixes.sort();
        (domains.into_iter().collect(), suffixes)
    }
}

/// AdGuard DNS filter domain rules, as compiled into `.srs` files by sing-box.
#[derive(Debug, Clone, Default)]
pub struct AdGuardMatcher {
    set: SuccinctSet,
}

impl AdGuardMatcher {
    pub fn read<R: Read>(r: &mut R) -> Result<Self, Error> {
        Ok(Self {
            set: SuccinctSet::read(r)?,
        })
    }

    /// Port of `NewAdGuardMatcher` (only used by tests, rule sets carry the compiled form).
    #[cfg(test)]
    pub fn new(rule_lines: &[&str]) -> Self {
        let mut list: Vec<Vec<u8>> = Vec::new();
        for line in rule_lines {
            let mut line = line.to_string();
            let (mut is_suffix, mut has_start, mut has_end) = (false, false, false);
            if let Some(rest) = line.strip_prefix("||") {
                line = rest.to_string();
                is_suffix = true;
            } else if let Some(rest) = line.strip_prefix('|') {
                line = rest.to_string();
                has_start = true;
            }
            if let Some(rest) = line.strip_suffix('^') {
                line = rest.to_string();
                has_end = true;
            }
            if is_suffix {
                line = format!("{}{line}", ROOT_LABEL as char);
            } else if !has_start {
                line = format!("{}{line}", PREFIX_LABEL as char);
            }
            if !has_end {
                line = line.trim_end_matches('.').to_string();
                line.push(SUFFIX_LABEL as char);
            }
            list.push(reverse(&line));
        }
        list.sort();
        list.dedup();
        Self {
            set: SuccinctSet::build(&list),
        }
    }

    pub fn matches(&self, name: &str) -> bool {
        let mut key = reverse(name);
        if self.has(&key, 0, 0, 0) {
            return true;
        }
        loop {
            let mut with = vec![SUFFIX_LABEL];
            with.extend_from_slice(&key);
            if self.has(&with, 0, 0, 0) {
                return true;
            }
            match key.iter().position(|&b| b == b'.') {
                Some(idx) => key = key[idx + 1..].to_vec(),
                None => return false,
            }
        }
    }

    fn has(&self, key: &[u8], mut node_id: usize, mut bm_idx: usize, depth: usize) -> bool {
        if depth > 100 {
            return false;
        }
        let set = &self.set;
        if set.label_bitmap.is_empty() {
            return false;
        }
        for i in 0..key.len() {
            let current = key[i];
            loop {
                if label_end(&set.label_bitmap, bm_idx) {
                    return false;
                }
                let Some(next) = set.label_at(bm_idx, node_id) else {
                    return false;
                };
                if next == PREFIX_LABEL {
                    return true;
                }
                if next == ROOT_LABEL {
                    let next_node = set.count_zeros(bm_idx + 1);
                    if current == b'.' && get_bit(&set.leaves, next_node) {
                        return true;
                    }
                }
                if next == current {
                    break;
                }
                if next == ANY_LABEL || next == SUFFIX_LABEL {
                    let (nn, nb) = set.child(bm_idx);
                    if self.has(&key[i..], nn, nb, depth + 1) {
                        return true;
                    }
                    for j in i + 1..=key.len() {
                        if self.has(&key[j..], nn, nb, depth + 1) {
                            return true;
                        }
                    }
                }
                bm_idx += 1;
            }
            let (n, b) = set.child(bm_idx);
            node_id = n;
            bm_idx = b;
        }
        if get_bit(&set.leaves, node_id) {
            return true;
        }
        loop {
            if label_end(&set.label_bitmap, bm_idx) {
                return false;
            }
            let Some(next) = set.label_at(bm_idx, node_id) else {
                return false;
            };
            if next == PREFIX_LABEL || next == ROOT_LABEL || next == SUFFIX_LABEL {
                return true;
            }
            if next == ANY_LABEL {
                let (nn, nb) = set.child(bm_idx);
                return self.has(&[], nn, nb, depth + 1);
            }
            bm_idx += 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn m(domains: &[&str], suffixes: &[&str]) -> DomainMatcher {
        DomainMatcher::new(
            &domains.iter().map(|s| s.to_string()).collect::<Vec<_>>(),
            &suffixes.iter().map(|s| s.to_string()).collect::<Vec<_>>(),
        )
    }

    #[test]
    fn a_full_domain_matches_only_itself() {
        let matcher = m(&["example.com"], &[]);
        assert!(matcher.matches("example.com"));
        assert!(!matcher.matches("www.example.com"));
        assert!(!matcher.matches("xexample.com"));
        assert!(!matcher.matches("example.co"));
    }

    #[test]
    fn a_suffix_matches_the_name_and_its_subdomains_on_a_label_boundary() {
        let matcher = m(&[], &["example.com"]);
        assert!(matcher.matches("example.com"));
        assert!(matcher.matches("a.b.example.com"));
        assert!(!matcher.matches("notexample.com"));
        assert!(!matcher.matches("example.com.cn"));
    }

    #[test]
    fn a_dotted_suffix_matches_subdomains_only() {
        let matcher = m(&[], &[".example.com"]);
        assert!(!matcher.matches("example.com"));
        assert!(matcher.matches("www.example.com"));
        assert!(!matcher.matches("wwwexample.com"));
    }

    #[test]
    fn many_entries_share_the_trie_without_crosstalk() {
        let domains: Vec<String> = (0..500).map(|i| format!("host{i}.test")).collect();
        let suffixes: Vec<String> = (0..500).map(|i| format!("zone{i}.example")).collect();
        let matcher = DomainMatcher::new(&domains, &suffixes);
        for i in 0..500 {
            assert!(matcher.matches(&format!("host{i}.test")));
            assert!(!matcher.matches(&format!("a.host{i}.test")));
            assert!(matcher.matches(&format!("zone{i}.example")));
            assert!(matcher.matches(&format!("deep.zone{i}.example")));
        }
        assert!(!matcher.matches("host500.test"));
        assert!(!matcher.matches("zone5000.example"));
        let (d, s) = matcher.dump();
        assert_eq!(d.len(), 500);
        assert_eq!(s.len(), 500);
    }

    #[test]
    fn an_empty_matcher_matches_nothing() {
        let matcher = m(&[], &[]);
        assert!(!matcher.matches("example.com"));
        assert!(!matcher.matches(""));
    }

    #[test]
    fn adguard_rules_follow_the_filter_syntax() {
        let matcher = AdGuardMatcher::new(&["||ads.example^", "|exact.test^", "tracker", "ad*.cdn.test^"]);
        assert!(matcher.matches("ads.example"));
        assert!(matcher.matches("x.ads.example"));
        assert!(!matcher.matches("badads.example"));
        assert!(matcher.matches("exact.test"));
        assert!(!matcher.matches("a.exact.test"));
        assert!(matcher.matches("mytracker.net"));
        assert!(matcher.matches("ad12.cdn.test"));
        assert!(!matcher.matches("example.org"));
    }
}
