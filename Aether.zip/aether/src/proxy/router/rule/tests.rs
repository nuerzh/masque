use super::*;
use serde_json::json;

fn meta(host: &str, port: u16) -> Metadata {
    Metadata::new("socks", Network::Tcp, "127.0.0.1:40000".parse().unwrap(), host, port)
}

fn parse(v: Value) -> Rule {
    let lookup = |_: &str| None;
    let mut warn = |_m: String| {};
    let mut env = ParseEnv {
        headless: false,
        lookup_set: &lookup,
        warn: &mut warn,
    };
    parse_rule(&v, &mut env, "rule").unwrap()
}

fn hit(r: &Rule, m: &Metadata) -> bool {
    r.matches(m, Ctx::default())
}

#[test]
fn items_of_one_group_are_ored() {
    let r = parse(json!({"domain_suffix": ["a.test"], "domain_keyword": "zzz", "ip_cidr": "10.0.0.0/8"}));
    assert!(hit(&r, &meta("x.a.test", 1)));
    assert!(hit(&r, &meta("hazzzy.org", 1)));
    assert!(hit(&r, &meta("10.1.1.1", 1)));
    assert!(!hit(&r, &meta("b.test", 1)));
}

#[test]
fn groups_are_anded() {
    let r = parse(json!({"domain_suffix": "a.test", "port": [443], "network": "tcp"}));
    assert!(hit(&r, &meta("a.test", 443)));
    assert!(!hit(&r, &meta("a.test", 80)));
    let mut udp = meta("a.test", 443);
    udp.network = Network::Udp;
    assert!(!hit(&r, &udp));
}

#[test]
fn port_and_port_range_share_a_group() {
    let r = parse(json!({"port": 22, "port_range": ["1000:2000", ":10", "60000:"]}));
    for p in [22, 1500, 5, 61000] {
        assert!(hit(&r, &meta("h.test", p)), "{p}");
    }
    assert!(!hit(&r, &meta("h.test", 999)));
}

#[test]
fn invert_flips_the_result() {
    let r = parse(json!({"domain": "a.test", "invert": true}));
    assert!(!hit(&r, &meta("a.test", 1)));
    assert!(hit(&r, &meta("b.test", 1)));
}

#[test]
fn logical_and_or_with_invert() {
    let r = parse(json!({"type": "logical", "mode": "and", "rules": [
        {"domain_suffix": "a.test"}, {"port": 443, "invert": true}]}));
    assert!(hit(&r, &meta("a.test", 80)));
    assert!(!hit(&r, &meta("a.test", 443)));
    let r = parse(json!({"type": "logical", "mode": "or", "invert": true, "rules": [
        {"domain": "a.test"}, {"port": 53}]}));
    assert!(!hit(&r, &meta("a.test", 1)));
    assert!(!hit(&r, &meta("z.test", 53)));
    assert!(hit(&r, &meta("z.test", 1)));
}

#[test]
fn a_sniffed_domain_is_preferred_over_the_requested_name() {
    let r = parse(json!({"domain": "sniffed.test"}));
    let mut m = meta("1.2.3.4", 443);
    assert!(!hit(&r, &m));
    m.domain = Some("sniffed.test".into());
    assert!(hit(&r, &m));
}

#[test]
fn ip_cidr_uses_resolved_addresses_for_a_domain() {
    let r = parse(json!({"ip_cidr": "192.0.2.0/24"}));
    let mut m = meta("example.test", 80);
    assert!(!hit(&r, &m));
    m.resolved = vec!["192.0.2.9".parse().unwrap()];
    assert!(hit(&r, &m));
}

#[test]
fn private_and_source_items() {
    let r = parse(json!({"ip_is_private": true}));
    assert!(hit(&r, &meta("192.168.1.1", 80)));
    assert!(!hit(&r, &meta("1.1.1.1", 80)));
    let r = parse(json!({"source_ip_cidr": "127.0.0.0/8", "source_port_range": "40000:40010"}));
    assert!(hit(&r, &meta("1.1.1.1", 80)));
    let r = parse(json!({"source_ip_is_private": true, "source_port": 1}));
    assert!(!hit(&r, &meta("1.1.1.1", 80)));
}

#[test]
fn ip_version_and_inbound() {
    let r = parse(json!({"ip_version": 6, "inbound": ["socks"]}));
    assert!(hit(&r, &meta("2001:db8::1", 1)));
    assert!(!hit(&r, &meta("192.0.2.1", 1)));
    assert!(!hit(&r, &meta("example.test", 1)));
    let r = parse(json!({"inbound": "http"}));
    assert!(!hit(&r, &meta("a.test", 1)));
}

#[test]
fn unsupported_fields_never_match_and_removed_ones_are_errors() {
    let r = parse(json!({"wifi_ssid": "home"}));
    assert!(!hit(&r, &meta("a.test", 1)));
    let lookup = |_: &str| None;
    let mut warn = |_m: String| {};
    let mut env = ParseEnv { headless: false, lookup_set: &lookup, warn: &mut warn };
    assert!(parse_rule(&json!({"geosite": "cn"}), &mut env, "r").is_err());
    assert!(parse_rule(&json!({"domain": [""]}), &mut env, "r").is_err());
    assert!(parse_rule(&json!({"port_range": "80"}), &mut env, "r").is_err());
    assert!(parse_rule(&json!({"rule_set": "missing"}), &mut env, "r").is_err());
}

#[test]
fn protocol_needs_a_sniff() {
    let r = parse(json!({"protocol": ["tls", "quic"]}));
    let mut m = meta("a.test", 443);
    assert!(!hit(&r, &m));
    m.protocol = Some("tls");
    assert!(hit(&r, &m));
}
