//! Which local program opened a connection to the proxy (`process_name`, `process_path`,
//! `process_path_regex`). Linux and Android read /proc; Windows asks the IP helper for the
//! socket owner's pid. Elsewhere, and for clients on other machines, nothing is found and the
//! process conditions do not match.

use std::net::SocketAddr;

use super::rule::Network;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProcessInfo {
    pub pid: u32,
    pub path: String,
    /// The last path component, what `process_name` compares against.
    pub name: String,
}

impl ProcessInfo {
    pub fn from_path(pid: u32, path: String) -> Self {
        let name = path
            .rsplit(['/', '\\'])
            .next()
            .unwrap_or_default()
            .to_string();
        ProcessInfo { pid, path, name }
    }
}

/// `source` is the client's own address (its socket's local address); `local` is the address
/// of the listener it reached.
pub fn lookup(network: Network, source: SocketAddr, local: Option<SocketAddr>) -> Option<ProcessInfo> {
    let found = imp::lookup(network, source, local);
    match &found {
        Some(p) => log::trace!("[route] {source} belongs to {} (pid {})", p.path, p.pid),
        None => log::trace!("[route] no local process found for {source}"),
    }
    found
}

#[cfg(any(target_os = "linux", target_os = "android"))]
mod imp {
    use super::*;
    use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

    fn parse_addr(hex: &str) -> Option<SocketAddr> {
        let (ip, port) = hex.split_once(':')?;
        let port = u16::from_str_radix(port, 16).ok()?;
        let ip = match ip.len() {
            8 => {
                let v = u32::from_str_radix(ip, 16).ok()?;
                IpAddr::V4(Ipv4Addr::from(v.to_ne_bytes()))
            }
            32 => {
                let mut b = [0u8; 16];
                for w in 0..4 {
                    let v = u32::from_str_radix(&ip[w * 8..w * 8 + 8], 16).ok()?;
                    b[w * 4..w * 4 + 4].copy_from_slice(&v.to_ne_bytes());
                }
                IpAddr::V6(Ipv6Addr::from(b))
            }
            _ => return None,
        };
        Some(SocketAddr::new(ip, port))
    }

    fn same_ip(a: IpAddr, b: IpAddr) -> bool {
        crate::proxy::router::ipset::unmap(a) == crate::proxy::router::ipset::unmap(b)
    }

    /// The inode of the socket bound to `source` in /proc/net/{tcp,tcp6,udp,udp6}.
    pub(super) fn find_inode(table: &str, network: Network, source: SocketAddr, local: Option<SocketAddr>) -> Option<u64> {
        let mut fallback = None;
        for line in table.lines().skip(1) {
            let cols: Vec<&str> = line.split_whitespace().collect();
            if cols.len() < 10 {
                continue;
            }
            let (Some(l), Some(r)) = (parse_addr(cols[1]), parse_addr(cols[2])) else {
                continue;
            };
            if l.port() != source.port() {
                continue;
            }
            let inode: u64 = match cols[9].parse() {
                Ok(i) if i != 0 => i,
                _ => continue,
            };
            let ip_ok = same_ip(l.ip(), source.ip()) || l.ip().is_unspecified();
            if !ip_ok {
                continue;
            }
            match network {
                Network::Tcp => {
                    if let Some(local) = local {
                        if r.port() == local.port() {
                            return Some(inode);
                        }
                        fallback.get_or_insert(inode);
                    } else {
                        return Some(inode);
                    }
                }
                Network::Udp => return Some(inode),
            }
        }
        fallback
    }

    pub(super) fn lookup(network: Network, source: SocketAddr, local: Option<SocketAddr>) -> Option<ProcessInfo> {
        let names: &[&str] = match network {
            Network::Tcp => &["/proc/net/tcp", "/proc/net/tcp6"],
            Network::Udp => &["/proc/net/udp", "/proc/net/udp6"],
        };
        let inode = names.iter().find_map(|path| {
            let text = std::fs::read_to_string(path).ok()?;
            find_inode(&text, network, source, local)
        })?;
        let wanted = format!("socket:[{inode}]");
        let me = std::process::id();
        for entry in std::fs::read_dir("/proc").ok()?.flatten() {
            let Some(pid) = entry.file_name().to_str().and_then(|s| s.parse::<u32>().ok()) else {
                continue;
            };
            if pid == me {
                continue;
            }
            let Ok(fds) = std::fs::read_dir(entry.path().join("fd")) else {
                continue;
            };
            for fd in fds.flatten() {
                if let Ok(target) = std::fs::read_link(fd.path()) {
                    if target.as_os_str() == wanted.as_str() {
                        let exe = std::fs::read_link(entry.path().join("exe"))
                            .map(|p| p.to_string_lossy().trim_end_matches(" (deleted)").to_string())
                            .unwrap_or_default();
                        return Some(ProcessInfo::from_path(pid, exe));
                    }
                }
            }
        }
        None
    }
}

#[cfg(windows)]
mod imp {
    use super::*;
    use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    use windows_sys::Win32::Foundation::CloseHandle;
    use windows_sys::Win32::NetworkManagement::IpHelper::{
        GetExtendedTcpTable, GetExtendedUdpTable, TCP_TABLE_OWNER_PID_ALL, UDP_TABLE_OWNER_PID,
    };
    use windows_sys::Win32::System::Threading::{
        OpenProcess, QueryFullProcessImageNameW, PROCESS_QUERY_LIMITED_INFORMATION,
    };

    const AF_INET: u32 = 2;
    const AF_INET6: u32 = 23;

    fn table(network: Network, family: u32) -> Option<Vec<u8>> {
        let mut size: u32 = 0;
        for _ in 0..4 {
            let mut buf = vec![0u8; size as usize + 4096];
            size = buf.len() as u32;
            let rc = unsafe {
                match network {
                    Network::Tcp => GetExtendedTcpTable(
                        buf.as_mut_ptr().cast(),
                        &mut size,
                        0,
                        family,
                        TCP_TABLE_OWNER_PID_ALL,
                        0,
                    ),
                    Network::Udp => GetExtendedUdpTable(
                        buf.as_mut_ptr().cast(),
                        &mut size,
                        0,
                        family,
                        UDP_TABLE_OWNER_PID,
                        0,
                    ),
                }
            };
            if rc == 0 {
                buf.truncate(size as usize);
                return Some(buf);
            }
            if rc != 122 {
                // anything but ERROR_INSUFFICIENT_BUFFER
                return None;
            }
        }
        None
    }

    fn u32_at(b: &[u8], at: usize) -> Option<u32> {
        Some(u32::from_ne_bytes(b.get(at..at + 4)?.try_into().ok()?))
    }

    fn port_of(raw: u32) -> u16 {
        u16::from_be((raw & 0xffff) as u16)
    }

    pub(super) fn find_pid(network: Network, source: SocketAddr, local: Option<SocketAddr>) -> Option<u32> {
        let v6 = matches!(crate::proxy::router::ipset::unmap(source.ip()), IpAddr::V6(_));
        let family = if v6 { AF_INET6 } else { AF_INET };
        let families: &[u32] = if v6 { &[family] } else { &[AF_INET, AF_INET6] };
        for &family in families {
            let Some(buf) = table(network, family) else { continue };
            let count = u32_at(&buf, 0)? as usize;
            let row = match (network, family) {
                (Network::Tcp, AF_INET) => 24,
                (Network::Tcp, _) => 56,
                (Network::Udp, AF_INET) => 12,
                (Network::Udp, _) => 28,
            };
            let mut fallback = None;
            for i in 0..count {
                let at = 4 + i * row;
                let r = match buf.get(at..at + row) {
                    Some(r) => r,
                    None => break,
                };
                let (laddr, lport, rport, pid) = match (network, family) {
                    (Network::Tcp, AF_INET) => (
                        IpAddr::V4(Ipv4Addr::from(u32_at(r, 4)?.to_ne_bytes())),
                        port_of(u32_at(r, 8)?),
                        Some(port_of(u32_at(r, 16)?)),
                        u32_at(r, 20)?,
                    ),
                    (Network::Tcp, _) => {
                        let a: [u8; 16] = r[0..16].try_into().ok()?;
                        (IpAddr::V6(Ipv6Addr::from(a)), port_of(u32_at(r, 20)?), Some(port_of(u32_at(r, 44)?)), u32_at(r, 52)?)
                    }
                    (Network::Udp, AF_INET) => (
                        IpAddr::V4(Ipv4Addr::from(u32_at(r, 0)?.to_ne_bytes())),
                        port_of(u32_at(r, 4)?),
                        None,
                        u32_at(r, 8)?,
                    ),
                    (Network::Udp, _) => {
                        let a: [u8; 16] = r[0..16].try_into().ok()?;
                        (IpAddr::V6(Ipv6Addr::from(a)), port_of(u32_at(r, 20)?), None, u32_at(r, 24)?)
                    }
                };
                if lport != source.port() {
                    continue;
                }
                let same = crate::proxy::router::ipset::unmap(laddr) == crate::proxy::router::ipset::unmap(source.ip())
                    || laddr.is_unspecified();
                if !same || pid == std::process::id() {
                    continue;
                }
                match (rport, local) {
                    (Some(rp), Some(l)) if rp == l.port() => return Some(pid),
                    (Some(_), Some(_)) => {
                        fallback.get_or_insert(pid);
                    }
                    _ => return Some(pid),
                }
            }
            if fallback.is_some() {
                return fallback;
            }
        }
        None
    }

    pub(super) fn lookup(network: Network, source: SocketAddr, local: Option<SocketAddr>) -> Option<ProcessInfo> {
        let pid = find_pid(network, source, local)?;
        unsafe {
            let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
            if handle.is_null() {
                return Some(ProcessInfo::from_path(pid, String::new()));
            }
            let mut buf = vec![0u16; 1024];
            let mut len = buf.len() as u32;
            let ok = QueryFullProcessImageNameW(handle, 0, buf.as_mut_ptr(), &mut len);
            CloseHandle(handle);
            if ok == 0 {
                return Some(ProcessInfo::from_path(pid, String::new()));
            }
            Some(ProcessInfo::from_path(pid, String::from_utf16_lossy(&buf[..len as usize])))
        }
    }
}

#[cfg(not(any(target_os = "linux", target_os = "android", windows)))]
mod imp {
    use super::*;
    pub(super) fn lookup(_: Network, _: SocketAddr, _: Option<SocketAddr>) -> Option<ProcessInfo> {
        None
    }
}

#[cfg(all(test, any(target_os = "linux", target_os = "android")))]
mod tests {
    use super::*;

    #[test]
    fn the_proc_table_is_parsed_in_host_order() {
        let table = "  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode\n   0: 0100007F:9C40 0100007F:1F90 01 00000000:00000000 00:00000000 00000000  1000        0 424242 1 0000000000000000 20 4 30 10 -1\n";
        let found = imp::find_inode(
            table,
            Network::Tcp,
            "127.0.0.1:40000".parse().unwrap(),
            Some("127.0.0.1:8080".parse().unwrap()),
        );
        assert_eq!(found, Some(424242));
    }

    #[tokio::test]
    async fn our_own_test_client_is_found_in_proc() {
        // the client and the listener are both in this process, so the lookup skips our own
        // pid and must come back empty, but the inode search itself has to succeed.
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let client = tokio::net::TcpStream::connect(addr).await.unwrap();
        let (_server, peer) = listener.accept().await.unwrap();
        let text = std::fs::read_to_string("/proc/net/tcp").unwrap_or_default();
        if text.is_empty() {
            return;
        }
        assert!(imp::find_inode(&text, Network::Tcp, peer, Some(addr)).is_some());
        assert_eq!(lookup(Network::Tcp, client.local_addr().unwrap(), Some(addr)), None);
    }

    #[test]
    fn the_name_is_the_last_path_component() {
        let p = ProcessInfo::from_path(1, "/usr/bin/curl".into());
        assert_eq!(p.name, "curl");
        let p = ProcessInfo::from_path(1, r"C:\Program Files\App\app.exe".into());
        assert_eq!(p.name, "app.exe");
    }
}
