//! A set of IP addresses kept as sorted, merged ranges (what netipx.IPSet is in sing-box).

use std::net::IpAddr;

use ipnet::IpNet;

#[derive(Debug, Clone, Default)]
pub struct IpSet {
    v4: Vec<(u32, u32)>,
    v6: Vec<(u128, u128)>,
}

fn merge<T: Ord + Copy + num_like::Succ>(mut ranges: Vec<(T, T)>) -> Vec<(T, T)> {
    ranges.sort();
    let mut out: Vec<(T, T)> = Vec::with_capacity(ranges.len());
    for (from, to) in ranges {
        if let Some(last) = out.last_mut() {
            if from <= last.1 || last.1.succ() == Some(from) {
                if to > last.1 {
                    last.1 = to;
                }
                continue;
            }
        }
        out.push((from, to));
    }
    out
}

mod num_like {
    pub trait Succ: Sized {
        fn succ(self) -> Option<Self>;
    }
    impl Succ for u32 {
        fn succ(self) -> Option<Self> {
            self.checked_add(1)
        }
    }
    impl Succ for u128 {
        fn succ(self) -> Option<Self> {
            self.checked_add(1)
        }
    }
}

fn find<T: Ord + Copy>(ranges: &[(T, T)], v: T) -> bool {
    // the last range whose start is <= v
    let idx = ranges.partition_point(|r| r.0 <= v);
    idx > 0 && ranges[idx - 1].1 >= v
}

pub fn unmap(ip: IpAddr) -> IpAddr {
    match ip {
        IpAddr::V6(v6) => match v6.to_ipv4_mapped() {
            Some(v4) => IpAddr::V4(v4),
            None => IpAddr::V6(v6),
        },
        v4 => v4,
    }
}

#[derive(Default)]
pub struct IpSetBuilder {
    v4: Vec<(u32, u32)>,
    v6: Vec<(u128, u128)>,
}

impl IpSetBuilder {
    pub fn add_net(&mut self, net: IpNet) {
        match net {
            IpNet::V4(n) => self.v4.push((u32::from(n.network()), u32::from(n.broadcast()))),
            IpNet::V6(n) => self.v6.push((u128::from(n.network()), u128::from(n.broadcast()))),
        }
    }

    pub fn add_range(&mut self, from: IpAddr, to: IpAddr) -> bool {
        match (unmap(from), unmap(to)) {
            (IpAddr::V4(a), IpAddr::V4(b)) => {
                let (a, b) = (u32::from(a), u32::from(b));
                self.v4.push((a.min(b), a.max(b)));
                true
            }
            (IpAddr::V6(a), IpAddr::V6(b)) => {
                let (a, b) = (u128::from(a), u128::from(b));
                self.v6.push((a.min(b), a.max(b)));
                true
            }
            _ => false,
        }
    }

    /// An `ip_cidr` entry: a prefix or a bare address.
    pub fn add_text(&mut self, text: &str) -> Result<(), String> {
        let text = text.trim();
        if let Ok(net) = text.parse::<IpNet>() {
            self.add_net(net.trunc());
            return Ok(());
        }
        if let Ok(ip) = text.parse::<IpAddr>() {
            self.add_net(IpNet::from(ip));
            return Ok(());
        }
        Err(format!("{text:?} is not an ip address or prefix"))
    }

    pub fn build(self) -> IpSet {
        IpSet {
            v4: merge(self.v4),
            v6: merge(self.v6),
        }
    }
}

impl IpSet {
    pub fn contains(&self, ip: IpAddr) -> bool {
        match unmap(ip) {
            IpAddr::V4(v4) => find(&self.v4, u32::from(v4)),
            IpAddr::V6(v6) => find(&self.v6, u128::from(v6)),
        }
    }

    #[cfg(test)]
    pub fn ranges(&self) -> usize {
        self.v4.len() + self.v6.len()
    }

}

/// `!N.IsPublicAddr(addr)` of sing: private, loopback, multicast, link-local unicast,
/// interface-local multicast or unspecified (Go's net/netip definitions).
pub fn is_non_public(ip: IpAddr) -> bool {
    match unmap(ip) {
        IpAddr::V4(v4) => {
            let o = v4.octets();
            o[0] == 10
                || (o[0] == 172 && (o[1] & 0xf0) == 16)
                || (o[0] == 192 && o[1] == 168)
                || o[0] == 127
                || (o[0] & 0xf0) == 224
                || (o[0] == 169 && o[1] == 254)
                || v4.is_unspecified()
        }
        IpAddr::V6(v6) => {
            let s = v6.segments();
            (s[0] & 0xfe00) == 0xfc00
                || v6.is_loopback()
                || (s[0] & 0xff00) == 0xff00
                || (s[0] & 0xffc0) == 0xfe80
                || v6.is_unspecified()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn set(entries: &[&str]) -> IpSet {
        let mut b = IpSetBuilder::default();
        for e in entries {
            b.add_text(e).unwrap();
        }
        b.build()
    }

    #[test]
    fn prefixes_and_single_addresses_are_both_accepted() {
        let s = set(&["10.0.0.0/8", "1.1.1.1", "2001:db8::/32", "192.168.1.7/24"]);
        assert!(s.contains("10.200.0.1".parse().unwrap()));
        assert!(s.contains("1.1.1.1".parse().unwrap()));
        assert!(!s.contains("1.1.1.2".parse().unwrap()));
        assert!(s.contains("2001:db8:1::1".parse().unwrap()));
        assert!(!s.contains("2001:db9::1".parse().unwrap()));
        assert!(s.contains("192.168.1.200".parse().unwrap()));
        assert!(s.contains("::ffff:10.1.1.1".parse().unwrap()));
    }

    #[test]
    fn adjacent_and_overlapping_ranges_merge() {
        let s = set(&["10.0.0.0/9", "10.128.0.0/9", "10.0.0.0/16"]);
        assert_eq!(s.ranges(), 1);
        assert!(s.contains("10.255.255.255".parse().unwrap()));
    }

    #[test]
    fn garbage_is_an_error() {
        assert!(IpSetBuilder::default().add_text("not-an-ip").is_err());
    }

    #[test]
    fn non_public_follows_go_netip() {
        for a in ["10.1.1.1", "172.20.0.1", "192.168.0.1", "127.0.0.1", "169.254.1.1", "224.0.0.1", "0.0.0.0", "fd00::1", "fe80::1", "::1", "ff02::1", "::"] {
            assert!(is_non_public(a.parse().unwrap()), "{a}");
        }
        for a in ["8.8.8.8", "100.64.0.1", "172.32.0.1", "2606:4700::1111"] {
            assert!(!is_non_public(a.parse().unwrap()), "{a}");
        }
    }
}
