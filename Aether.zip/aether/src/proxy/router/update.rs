use super::*;

/// Start the background refresh of remote rule sets (once per run; they stop with it).
pub fn spawn_updaters() {
    static STARTED: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(u64::MAX);
    let Some(router) = router() else { return };
    let run = crate::utils::shutdown::token();
    if STARTED.swap(run.generation(), std::sync::atomic::Ordering::SeqCst) == run.generation() {
        return;
    }
    for slot in router.sets.clone() {
        match &slot.kind {
            Kind::Remote { .. } => {
                let router = router.clone();
                crate::utils::shutdown::spawn_with(run.clone(), async move { update_loop(router, slot).await });
            }
            Kind::Local { .. } => {
                let router = router.clone();
                crate::utils::shutdown::spawn_with(run.clone(), async move { watch_local(router, slot).await });
            }
            Kind::Inline => {}
        }
    }
}

pub(super) fn detour_kind(router: &Router, detour: &Option<String>) -> OutKind {
    match detour {
        Some(tag) => router.detours.get(tag).copied().unwrap_or(OutKind::Tunnel),
        None => OutKind::Tunnel,
    }
}

pub(super) async fn update_loop(router: Arc<Router>, slot: Arc<Slot>) {
    let Kind::Remote { url, detour, interval, .. } = slot.kind.clone() else { return };
    let kind = detour_kind(&router, &detour);
    let mut backoff = Duration::from_secs(5);
    loop {
        let meta = router.cache.load(&slot.tag, slot.format, &url).map(|(_, m)| m);
        let due = match (&meta, slot.is_loaded()) {
            (Some(m), true) => {
                let age = ruleset::now_secs().saturating_sub(m.updated);
                Duration::from_secs(interval.as_secs().saturating_sub(age))
            }
            _ => Duration::ZERO,
        };
        if !due.is_zero() {
            tokio::time::sleep(due).await;
            continue;
        }
        match download_once(&router, &slot, &url, kind, meta.as_ref()).await {
            Ok(changed) => {
                backoff = Duration::from_secs(5);
                if changed {
                    router.mark_loaded();
                }
                tokio::time::sleep(interval).await;
            }
            Err(e) => {
                log::warn!(
                    "[route] rule-set {} could not be downloaded through {}: {e}; retrying in {:?}",
                    slot.tag,
                    kind.effective().label(),
                    backoff
                );
                tokio::time::sleep(backoff).await;
                backoff = (backoff * 2).min(Duration::from_secs(300));
            }
        }
    }
}

pub(super) async fn download_once(router: &Router, slot: &Slot, url: &str, kind: OutKind, meta: Option<&CacheMeta>) -> Result<bool, String> {
    let via = crate::proxy::socks::detour_proxy(kind).await.map_err(|e| e.to_string())?;
    log::debug!("[route] downloading rule-set {} from {url} via {}", slot.tag, kind.effective().label());
    let meta = meta.filter(|_| slot.is_loaded());
    match ruleset::fetch(url, Some(via), meta).await? {
        Fetched::NotModified => {
            let mut m = meta.cloned().unwrap_or_default();
            m.updated = ruleset::now_secs();
            m.url = url.to_string();
            let _ = router.cache.store(&slot.tag, slot.format, None, &m);
            log::info!("[route] rule-set {} is up to date", slot.tag);
            Ok(false)
        }
        Fetched::New { data, etag, last_modified } => {
            let mut warnings = Vec::new();
            let compiled = ruleset::compile(&data, slot.format, &mut |w| warnings.push(w))?;
            for w in warnings {
                log::warn!("[route] rule-set {}: {w}", slot.tag);
            }
            let rules = compiled.rules.len();
            let m = CacheMeta {
                url: url.to_string(),
                etag,
                last_modified,
                updated: ruleset::now_secs(),
            };
            if let Err(e) = router.cache.store(&slot.tag, slot.format, Some(&data), &m) {
                log::warn!("[route] rule-set {}: could not write the cache in {}: {e}", slot.tag, router.cache.dir.display());
            }
            slot.install(compiled);
            log::info!("[route] rule-set {} updated ({} bytes, {rules} rules)", slot.tag, data.len());
            Ok(true)
        }
    }
}

pub(super) async fn watch_local(router: Arc<Router>, slot: Arc<Slot>) {
    let Kind::Local { path } = slot.kind.clone() else { return };
    let mut last = std::fs::metadata(&path).and_then(|m| m.modified()).ok();
    loop {
        tokio::time::sleep(Duration::from_secs(10)).await;
        let now = std::fs::metadata(&path).and_then(|m| m.modified()).ok();
        if now.is_none() || now == last {
            continue;
        }
        last = now;
        let mut warnings = Vec::new();
        match std::fs::read(&path).map_err(|e| e.to_string()).and_then(|d| ruleset::compile(&d, slot.format, &mut |w| warnings.push(w))) {
            Ok(c) => {
                slot.install(c);
                router.mark_loaded();
                log::info!("[route] rule-set {} reloaded from {}", slot.tag, path.display());
            }
            Err(e) => log::warn!("[route] rule-set {}: {} changed but cannot be used: {e}", slot.tag, path.display()),
        }
    }
}
