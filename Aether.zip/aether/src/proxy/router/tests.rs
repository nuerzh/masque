use super::*;
use serde_json::json;

/// A config written as the config file is (`[route]`, `[[outbounds]]`, ...), as the router
/// reads it.
fn cfg(text: &str) -> Value {
    crate::config::file::test_routing(text)
}

fn router(config: Value) -> Router {
    let dir = crate::test_util::scratch("route-test");
    build(
        &config,
        LoadOptions {
            base_dir: PathBuf::from("."),
            cache_dir: dir,
            caps: Caps::ALL,
        },
    )
    .unwrap()
    .router
}

fn meta(host: &str, port: u16) -> Metadata {
    Metadata::new("socks", rule::Network::Tcp, "127.0.0.1:50000".parse().unwrap(), host, port)
}

/// Run the router to a verdict, pretending a sniff found `sniffed` and a resolve found `ips`.
fn decide_with(r: &Router, m: &mut Metadata, sniffed: Option<(&'static str, &str)>, ips: &[&str]) -> (String, RouteOpts) {
    let mut opts = RouteOpts::default();
    let mut from = 0;
    for _ in 0..64 {
        match r.step(m, from, &mut opts) {
            Step::Done(Verdict::Route { tag, .. }) => return (tag, opts),
            Step::Done(Verdict::Reject { drop }) => return (if drop { "reject-drop".into() } else { "reject".into() }, opts),
            Step::Done(Verdict::HijackDns) => return ("hijack-dns".into(), opts),
            Step::Sniff { next, .. } => {
                m.sniffed = true;
                if let Some((p, d)) = sniffed {
                    m.protocol = Some(p);
                    if !d.is_empty() {
                        m.domain = Some(d.to_string());
                    }
                }
                from = next;
            }
            Step::Process { next } => {
                let _ = m.process.set(None);
                from = next;
            }
            Step::Resolve { next, .. } => {
                m.resolved = ips.iter().map(|s| s.parse().unwrap()).collect();
                from = next;
            }
        }
    }
    panic!("no verdict");
}

fn decide(r: &Router, host: &str, port: u16) -> String {
    decide_with(r, &mut meta(host, port), None, &[]).0
}

#[test]
fn final_defaults_to_the_tunnel_and_can_be_set() {
    let r = router(cfg(r#"
        [route]
        rules = []
    "#));
    assert_eq!(decide(&r, "example.com", 443), "tunnel");
    let r = router(cfg(r#"
        [route]
        final = "direct"
    "#));
    assert_eq!(decide(&r, "example.com", 443), "direct");
    let r = router(cfg(r#"
        [route]
        final = "sunny"
    "#));
    assert_eq!(r.final_kind, OutKind::Sunny);
}

#[test]
fn legacy_outbound_rules_and_actions_are_both_accepted() {
    let r = router(cfg(r#"
        [route]
        final = "proxy"

        [[route.rules]]
        domain_suffix = "cn"
        outbound = "direct"

        [[route.rules]]
        domain_keyword = "ads"
        action = "reject"

        [[route.rules]]
        port = 53
        action = "hijack-dns"

        [[route.rules]]
        domain = "drop.test"
        action = "reject"
        method = "drop"

        [[route.rules]]
        domain = "w.test"
        action = "route"
        outbound = "warp"
    "#));
    assert_eq!(decide(&r, "www.baidu.cn", 443), "direct");
    assert_eq!(decide(&r, "ads.example", 443), "reject");
    assert_eq!(decide(&r, "1.1.1.1", 53), "hijack-dns");
    assert_eq!(decide(&r, "drop.test", 1), "reject-drop");
    assert_eq!(decide(&r, "w.test", 1), "w.test".replace("w.test", "warp"));
    assert_eq!(decide(&r, "other.test", 1), "proxy");
}

#[test]
fn first_match_wins() {
    let r = router(cfg(r#"
        [[route.rules]]
        domain_suffix = "a.test"
        outbound = "block"

        [[route.rules]]
        domain_suffix = "a.test"
        outbound = "direct"
    "#));
    assert_eq!(decide(&r, "x.a.test", 1), "block");
}

#[test]
fn user_defined_outbound_tags_map_to_kinds() {
    let r = router(cfg(r#"
        [[outbounds]]
        type = "direct"
        tag = "LAN"

        [[outbounds]]
        type = "warp"
        tag = "cf"

        [[outbounds]]
        type = "sunny"
        tag = "home"

        [[outbounds]]
        type = "block"
        tag = "nope"

        [[outbounds]]
        type = "dns"
        tag = "dns-out"

        [route]
        final = "home"

        [[route.rules]]
        ip_is_private = true
        outbound = "LAN"

        [[route.rules]]
        domain = "c.test"
        outbound = "cf"

        [[route.rules]]
        domain = "h.test"
        outbound = "home"

        [[route.rules]]
        domain = "n.test"
        outbound = "nope"

        [[route.rules]]
        protocol = "dns"
        outbound = "dns-out"
    "#));
    assert_eq!(decide(&r, "192.168.1.1", 80), "LAN");
    assert_eq!(decide(&r, "c.test", 80), "cf");
    assert_eq!(decide(&r, "n.test", 80), "nope");
    assert_eq!(r.final_kind, OutKind::Sunny);
    let mut m = meta("9.9.9.9", 53);
    assert_eq!(decide_with(&r, &mut m, Some(("dns", "")), &[]).0, "hijack-dns");
}

#[test]
fn a_full_sing_box_config_is_understood() {
    let r = router(cfg(r#"
        inbounds = [{ type = "mixed", tag = "mixed-in" }]
        outbounds = [{ type = "vless", tag = "proxy-out" }, { type = "direct", tag = "direct-out" }]

        [log]
        level = "info"

        [route]
        rules = [{ action = "sniff" }, { domain_suffix = "lan", outbound = "direct-out" }]
        final = "proxy"
        auto_detect_interface = true
    "#));
    assert_eq!(decide(&r, "nas.lan", 445), "direct-out");
    assert_eq!(decide(&r, "x.org", 1), "proxy");
    assert_eq!(r.final_kind, OutKind::Tunnel);
}

fn build_with(config: Value, caps: Caps) -> Result<Spec, String> {
    let dir = crate::test_util::scratch("route-test");
    build(&config, LoadOptions { base_dir: PathBuf::from("."), cache_dir: dir, caps })
}

#[test]
fn outbounds_are_strict_no_fallback() {
    let no_sunny = Caps { sunny: false, sunny_over_warp: false };
    // sunny outside --sunny is a config error, wherever it is used
    for c in [
        cfg(r#"
            [route]
            final = "sunny"
        "#),
        cfg(r#"
            [route]
            rules = [{ domain = "a.test", outbound = "sunnyquic" }]
        "#),
        cfg(r#"
            outbounds = [{ type = "sunny", tag = "home" }]

            [route]
            rules = [{ domain = "a.test", outbound = "home" }]
        "#),
        cfg(r#"
            [route]
            rules = [{ domain = "a.test", action = "route", outbound = "sunny" }]
        "#),
        cfg(r#"
            [[route.rule_set]]
            type = "remote"
            tag = "x"
            format = "binary"
            url = "https://e.test/x.srs"
            download_detour = "sunny"
        "#),
    ] {
        let e = build_with(c.clone(), no_sunny).err().unwrap_or_else(|| panic!("accepted without sunny: {c}"));
        assert!(e.contains("this run does not have: set protocol: sunny") && e.contains("never falls back to WARP"), "{e}");
        assert!(e.contains("goes direct by default"), "{e}");
        assert!(build_with(c.clone(), Caps::ALL).is_ok());
        assert!(build_with(c, Caps::SUNNY_OVER_WARP).is_ok());
    }
    // an outbound defined but unused is fine
    assert!(build_with(cfg(r#"
        outbounds = [{ type = "sunny", tag = "home" }]

        [route]
        final = "warp"
    "#), no_sunny).is_ok());
    // a type Aether does not have is an error when used, never "the tunnel" instead
    let vless = cfg(r#"
        outbounds = [{ type = "vless", tag = "proxy-out" }]

        [route]
        final = "proxy-out"
    "#);
    let e = build_with(vless, Caps::ALL).err().expect("an unsupported outbound type was used");
    assert!(e.contains("vless"), "{e}");
    let unused = build_with(cfg(r#"
        outbounds = [{ type = "vless", tag = "proxy-out" }]

        [route]
    "#), Caps::ALL).unwrap();
    assert!(unused.warnings.iter().any(|w| w.contains("vless")));
}

#[test]
fn the_proxy_alias_follows_the_mode_and_sunny_never_becomes_warp() {
    assert_eq!(OutKind::Sunny.effective(), OutKind::Sunny);
    assert_eq!(OutKind::Warp.effective(), OutKind::Warp);
    let r = router(cfg(r#"
        [[route.rules]]
        domain = "s.test"
        outbound = "sunny"

        [[route.rules]]
        domain = "w.test"
        outbound = "warp"
    "#));
    let mut opts = RouteOpts::default();
    for (host, want) in [("s.test", OutKind::Sunny), ("w.test", OutKind::Warp), ("x.test", OutKind::Tunnel)] {
        let mut m = meta(host, 443);
        m.sniffed = true;
        match r.step(&mut m, 0, &mut opts) {
            Step::Done(Verdict::Route { kind, .. }) => assert_eq!(kind, want, "{host}"),
            other => panic!("{other:?}"),
        }
    }
}

#[test]
fn unknown_outbounds_rule_sets_and_actions_are_errors() {
    let bad = [
        cfg(r#"
            [route]
            rules = [{ domain = "a", outbound = "nowhere" }]
        "#),
        cfg(r#"
            [route]
            final = "nowhere"
        "#),
        cfg(r#"
            [route]
            rules = [{ rule_set = "missing", outbound = "direct" }]
        "#),
        cfg(r#"
            [route]
            rules = [{ domain = "a", action = "teleport" }]
        "#),
        cfg(r#"
            [route]
            rules = [{ domain = "a" }]
        "#),
        cfg(r#"
            [route]
            rules = [{}]
        "#),
        cfg(r#"
            [route]
            rules = [{ domain = "a", action = "reject", method = "drop", no_drop = true }]
        "#),
        cfg(r#"
            [route]
            rule_set = [{ type = "local", tag = "x", path = "/nonexistent/x.srs" }]
        "#),
        cfg(r#"
            [route]
            rule_set = [{ type = "remote", tag = "x", url = "https://h/x" }]
        "#),
    ];
    for c in bad {
        let dir = std::env::temp_dir();
        assert!(build(&c, LoadOptions { base_dir: PathBuf::from("."), cache_dir: dir, caps: Caps::ALL }).is_err(), "{c}");
    }
}

#[test]
fn sniff_is_a_non_final_action_and_feeds_later_rules() {
    let r = router(cfg(r#"
        [[route.rules]]
        inbound = "socks"
        action = "sniff"
        timeout = "500ms"

        [[route.rules]]
        protocol = "quic"
        action = "reject"

        [[route.rules]]
        domain_suffix = "google.com"
        outbound = "direct"
    "#));
    assert!(!r.auto_sniff);
    let mut m = meta("142.250.1.1", 443);
    assert_eq!(decide_with(&r, &mut m, Some(("tls", "www.google.com")), &[]).0, "direct");
    let mut m = meta("142.250.1.1", 443);
    assert_eq!(decide_with(&r, &mut m, Some(("quic", "www.google.com")), &[]).0, "reject");
    let mut m = meta("142.250.1.1", 443);
    assert_eq!(decide_with(&r, &mut m, None, &[]).0, "tunnel");
}

#[test]
fn domain_rules_without_a_sniff_action_sniff_first() {
    let r = router(cfg(r#"
        [route]
        rules = [{ domain = "x.test", outbound = "direct" }]
    "#));
    assert!(r.auto_sniff);
    let mut m = meta("10.9.9.9", 443);
    assert_eq!(decide_with(&r, &mut m, Some(("tls", "x.test")), &[]).0, "direct");
    let r = router(cfg(r#"
        [route]
        rules = [{ ip_cidr = "10.0.0.0/8", outbound = "direct" }]
    "#));
    assert!(!r.auto_sniff, "ip-only rules need no sniff");
}

#[test]
fn resolve_lets_ip_rules_match_a_domain() {
    let r = router(cfg(r#"
        [[route.rules]]
        action = "resolve"
        strategy = "ipv4_only"

        [[route.rules]]
        ip_cidr = "203.0.113.0/24"
        outbound = "direct"
    "#));
    let mut m = meta("cdn.example", 443);
    assert_eq!(decide_with(&r, &mut m, None, &["203.0.113.5"]).0, "direct");
    let mut m = meta("cdn.example", 443);
    assert_eq!(decide_with(&r, &mut m, None, &["198.51.100.1"]).0, "tunnel");
    // an ip destination is not resolved again
    let mut m = meta("203.0.113.9", 443);
    assert_eq!(decide_with(&r, &mut m, None, &[]).0, "direct");
}

#[test]
fn route_options_accumulate_until_the_final_action() {
    let r = router(cfg(r#"
        [[route.rules]]
        domain = "o.test"
        action = "route-options"
        override_port = 8443
        udp_timeout = "1m"

        [[route.rules]]
        domain = "o.test"
        outbound = "direct"
        override_address = "192.0.2.1"
        tls_record_fragment = true
    "#));
    let (tag, opts) = decide_with(&r, &mut meta("o.test", 443), None, &[]);
    assert_eq!(tag, "direct");
    assert_eq!(opts.override_port, Some(8443));
    assert_eq!(opts.override_address.as_deref(), Some("192.0.2.1"));
    assert!(opts.tls_record_fragment);
}

#[test]
fn bypass_without_outbound_is_skipped() {
    let r = router(cfg(r#"
        [[route.rules]]
        domain = "b.test"
        action = "bypass"

        [[route.rules]]
        domain = "b.test"
        action = "bypass"
        outbound = "direct"
    "#));
    assert_eq!(decide(&r, "b.test", 1), "direct");
}

#[test]
fn inline_rule_sets_merge_with_the_outer_rule() {
    let r = router(cfg(r#"
        [[route.rule_set]]
        type = "inline"
        tag = "cn"
        rules = [{ domain_suffix = ["cn"], ip_cidr = ["1.0.1.0/24"] }]

        [[route.rule_set]]
        type = "inline"
        tag = "multi"
        rules = [{ domain = "m1.test" }, { domain = "m2.test" }]

        [[route.rule_set]]
        tag = "src"
        rules = [{ ip_cidr = "127.0.0.0/8" }]

        # merged: the outer domain item and the set's items share the destination group
        [[route.rules]]
        rule_set = "cn"
        domain = "extra.test"
        port = 443
        outbound = "direct"

        # not mergeable (two rules): the outer groups must all match first
        [[route.rules]]
        rule_set = "multi"
        port = 80
        outbound = "block"

        [[route.rules]]
        rule_set = "src"
        rule_set_ip_cidr_match_source = true
        domain = "local-only.test"
        outbound = "warp"
    "#));
    assert_eq!(decide(&r, "www.gov.cn", 443), "direct");
    assert_eq!(decide(&r, "extra.test", 443), "direct");
    assert_eq!(decide(&r, "1.0.1.1", 443), "direct");
    assert_eq!(decide(&r, "www.gov.cn", 80), "tunnel");
    assert_eq!(decide(&r, "m2.test", 80), "block");
    assert_eq!(decide(&r, "m2.test", 81), "tunnel");
    // the source is 127.0.0.1, which the set matches as a source address
    assert_eq!(decide(&r, "local-only.test", 1), "warp");
    let mut m = Metadata::new("socks", rule::Network::Tcp, "192.168.7.7:1".parse().unwrap(), "local-only.test", 1);
    assert_eq!(decide_with(&r, &mut m, None, &[]).0, "tunnel");
}

#[test]
fn an_inverted_rule_set_rule() {
    let r = router(cfg(r#"
        [route]
        rule_set = [{ type = "inline", tag = "cn", rules = [{ domain_suffix = "cn" }] }]
        rules = [{ rule_set = "cn", invert = true, outbound = "warp" }]
        final = "direct"
    "#));
    assert_eq!(decide(&r, "a.cn", 1), "direct");
    assert_eq!(decide(&r, "a.com", 1), "warp");
}

#[test]
fn logical_route_rules() {
    let r = router(cfg(r#"
        [[route.rules]]
        type = "logical"
        mode = "and"
        rules = [{ network = "tcp" }, { port = 22 }]
        outbound = "direct"

        [[route.rules]]
        type = "logical"
        mode = "or"
        rules = [{ domain = "x.test" }, { ip_cidr = "8.8.8.8" }]
        action = "reject"
    "#));
    assert_eq!(decide(&r, "host.test", 22), "direct");
    assert_eq!(decide(&r, "x.test", 1), "reject");
    assert_eq!(decide(&r, "8.8.8.8", 1), "reject");
    assert_eq!(decide(&r, "y.test", 1), "tunnel");
    let dir = std::env::temp_dir();
    let nested_action = cfg(r#"
        [[route.rules]]
        type = "logical"
        mode = "and"
        rules = [{ port = 1, outbound = "direct" }]
        outbound = "direct"
    "#);
    assert!(build(&nested_action, LoadOptions { base_dir: ".".into(), cache_dir: dir, caps: Caps::ALL }).is_err());
}

#[test]
fn durations() {
    assert_eq!(parse_duration("1d").unwrap(), Duration::from_secs(86400));
    assert_eq!(parse_duration("1h30m").unwrap(), Duration::from_secs(5400));
    assert_eq!(parse_duration("300ms").unwrap(), Duration::from_millis(300));
    assert!(parse_duration("5x").is_err());
}

#[test]
fn a_remote_set_starts_from_its_cache_or_initial_path() {
    let dir = crate::test_util::scratch("route-cache");
    let _ = std::fs::remove_dir_all(&dir);
    let cache = Cache { dir: dir.clone() };
    let src = json!({"version": 3, "rules": [{"domain_suffix": "cached.test"}]}).to_string();
    cache
        .store("c", Format::Source, Some(src.as_bytes()), &CacheMeta { url: "https://h/c.json".into(), etag: None, last_modified: None, updated: ruleset::now_secs() })
        .unwrap();
    let init = dir.join("init.json");
    std::fs::write(&init, json!({"version": 1, "rules": [{"domain": "initial.test"}]}).to_string()).unwrap();
    let r = build(
        &cfg(&format!(
            r#"
            [[route.rule_set]]
            type = "remote"
            tag = "c"
            url = "https://h/c.json"
            download_detour = "direct"

            [[route.rule_set]]
            type = "remote"
            tag = "i"
            url = "https://h/i.json"
            initial_path = {init:?}

            [[route.rule_set]]
            type = "remote"
            tag = "n"
            format = "binary"
            url = "https://h/n"

            [[route.rules]]
            rule_set = ["c", "i"]
            outbound = "direct"

            [[route.rules]]
            rule_set = "n"
            outbound = "block"
            "#,
            init = init.to_string_lossy()
        )),
        LoadOptions { base_dir: ".".into(), cache_dir: dir.clone(), caps: Caps::ALL },
    )
    .unwrap()
    .router;
    assert!(r.sets.iter().find(|s| s.tag == "c").unwrap().is_loaded());
    assert!(r.sets.iter().find(|s| s.tag == "i").unwrap().is_loaded());
    assert!(!r.sets.iter().find(|s| s.tag == "n").unwrap().is_loaded());
    assert_eq!(decide(&r, "x.cached.test", 1), "direct");
    assert_eq!(decide(&r, "initial.test", 1), "direct");
    assert_eq!(decide(&r, "else.test", 1), "tunnel", "a set not yet downloaded matches nothing");
    assert_eq!(r.detours.get("direct"), Some(&OutKind::Direct));
    let _ = std::fs::remove_dir_all(dir);
}

#[tokio::test]
async fn wait_ready_gives_up_after_the_limit() {
    let mut r = router(cfg(r#"
        [route]
        rule_set = [{ type = "remote", tag = "n", format = "binary", url = "https://h/n" }]
    "#));
    r.wait_limit = Duration::from_millis(50);
    let started = std::time::Instant::now();
    r.wait_ready().await;
    assert!(started.elapsed() < Duration::from_secs(2));
}

/// Real rule sets from SagerNet's rule-set branches, when the test machine can reach GitHub
/// (set AETHER_TEST_SRS_DIR to a directory holding geosite-cn.srs and geoip-cn.srs to run
/// offline). Skipped when neither is available.
#[test]
fn real_geosite_and_geoip_srs_files() {
    let dir = crate::config::settings::var("AETHER_TEST_SRS_DIR").unwrap_or_else(|_| "/workspace/work/srs-testdata".into());
    let site = std::fs::read(Path::new(&dir).join("geosite-cn.srs"));
    let ip = std::fs::read(Path::new(&dir).join("geoip-cn.srs"));
    let (Ok(site), Ok(ip)) = (site, ip) else {
        eprintln!("skipping: no srs files in {dir}");
        return;
    };
    let mut warn = |_m: String| {};
    let site = ruleset::compile(&site, Format::Binary, &mut warn).expect("geosite-cn decodes");
    let ip = ruleset::compile(&ip, Format::Binary, &mut warn).expect("geoip-cn decodes");
    let hit = |set: &ruleset::CompiledSet, host: &str| set.rules.iter().any(|r| r.matches(&meta(host, 443), Ctx::default()));
    for name in ["baidu.com", "www.baidu.com", "qq.com", "www.taobao.com", "weibo.com", "a.b.163.com", "gov.cn", "www.gov.cn"] {
        assert!(hit(&site, name), "{name} should be in geosite-cn");
    }
    for name in ["google.com", "www.youtube.com", "github.com", "example.org"] {
        assert!(!hit(&site, name), "{name} should not be in geosite-cn");
    }
    for addr in ["114.114.114.114", "223.5.5.5", "180.101.50.188", "2400:3200::1"] {
        assert!(hit(&ip, addr), "{addr} should be in geoip-cn");
    }
    for addr in ["8.8.8.8", "1.1.1.1", "2606:4700::1111"] {
        assert!(!hit(&ip, addr), "{addr} should not be in geoip-cn");
    }
    assert!(site.mergeable().is_some(), "SagerNet's sets are one plain rule");
    if let Some(rule::Rule::Default(d)) = site.rules.first() {
        let domains: usize = d.dst_addr.iter().map(|i| match i { rule::Item::Domain(m) => m.len(), _ => 0 }).sum();
        eprintln!("geosite-cn: version {}, {} domain entries, {} items", site.version, domains, d.dst_addr.len());
        assert!(domains > 1000);
    }
    if let Ok(ads) = std::fs::read(Path::new(&dir).join("geosite-category-ads-all.srs")) {
        let ads = ruleset::compile(&ads, Format::Binary, &mut warn).unwrap();
        assert!(hit(&ads, "doubleclick.net") && hit(&ads, "ad.doubleclick.net"));
        assert!(!hit(&ads, "wikipedia.org"));
    }
    if let Ok(g) = std::fs::read(Path::new(&dir).join("geosite-geolocation-!cn.srs")) {
        let started = std::time::Instant::now();
        let g = ruleset::compile(&g, Format::Binary, &mut warn).unwrap();
        eprintln!("geolocation-!cn decoded in {:?}", started.elapsed());
        assert!(hit(&g, "www.google.com") && hit(&g, "github.com"));
        assert!(!hit(&g, "www.baidu.com"));
    }
}

#[test]
fn warp_local_is_a_builtin_tag_an_outbound_type_and_strict() {
    let r = router(cfg(r#"
        outbounds = [{ type = "warp-local", tag = "warp-cn-dns" }]

        [route]
        final = "warp-local"

        [[route.rules]]
        domain_suffix = ["a.test"]
        outbound = "warp-local"

        [[route.rules]]
        domain_suffix = ["b.test"]
        action = "route"
        outbound = "warp-cn-dns"
    "#));
    let mut opts = RouteOpts::default();
    for host in ["x.a.test", "b.test", "else.test"] {
        let mut m = meta(host, 443);
        m.sniffed = true;
        match r.step(&mut m, 0, &mut opts) {
            Step::Done(Verdict::Route { kind, .. }) => assert_eq!(kind, OutKind::WarpLocal, "{host}"),
            other => panic!("{host}: {other:?}"),
        }
    }
    assert_eq!(r.final_kind, OutKind::WarpLocal);
    assert_eq!(decide(&r, "b.test", 443), "warp-cn-dns");
    // download_detour too
    let s = build_with(
        cfg(r#"
            [[route.rule_set]]
            type = "remote"
            tag = "x"
            format = "binary"
            url = "https://e.test/x.srs"
            download_detour = "warp-local"
        "#),
        Caps::ALL,
    )
    .unwrap();
    assert_eq!(s.router.detours.get("warp-local"), Some(&OutKind::WarpLocal));
}

#[test]
fn a_local_rule_set_can_be_written_in_yaml() {
    let dir = crate::test_util::scratch_dir("route-yaml-set");
    std::fs::write(
        dir.join("mine.yaml"),
        "version: 3\nrules:\n  - domain_suffix: [corp.test]\n  - ip_cidr: [10.8.0.0/16]\n",
    )
    .unwrap();
    let r = build(
        &cfg(r#"
            [[route.rule_set]]
            type = "local"
            tag = "mine"
            path = "mine.yaml"

            [[route.rules]]
            rule_set = "mine"
            outbound = "direct"
        "#),
        LoadOptions { base_dir: dir.clone(), cache_dir: dir.clone(), caps: Caps::ALL },
    )
    .unwrap()
    .router;
    assert_eq!(decide(&r, "git.corp.test", 443), "direct");
    assert_eq!(decide(&r, "10.8.1.1", 22), "direct");
    assert_eq!(decide(&r, "else.test", 1), "tunnel");
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn a_toml_rule_set_of_an_earlier_build_is_converted_and_read() {
    let dir = crate::test_util::scratch_dir("route-toml-set");
    std::fs::write(dir.join("old.toml"), "version = 3\n\n[[rules]]\ndomain_suffix = [\"corp.test\"]\n").unwrap();
    let r = build(
        &cfg(r#"
            [[route.rule_set]]
            type = "local"
            tag = "old"
            path = "old.toml"

            [[route.rules]]
            rule_set = "old"
            outbound = "direct"
        "#),
        LoadOptions { base_dir: dir.clone(), cache_dir: dir.clone(), caps: Caps::ALL },
    )
    .unwrap()
    .router;
    assert_eq!(decide(&r, "git.corp.test", 443), "direct");
    assert!(dir.join("old.yaml").exists() && dir.join("old.toml.bak").exists());
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn the_removed_route_lists_are_refused_with_a_pointer_to_route() {
    for flag in ["--route-block", "--route-direct", "--routes"] {
        let e = crate::config::cli::parse_args(vec![flag.into(), "x".into()]).unwrap_err().to_string();
        assert!(e.contains("route:") && e.contains(flag), "{e}");
    }
}

#[test]
fn a_process_rule_asks_for_the_lookup_before_it_is_matched() {
    let r = router(cfg(r#"
        [route]
        rules = [{ port = 1, outbound = "direct" }, { process_name = ["curl"], outbound = "direct" }]
        final = "proxy"
    "#));
    let mut opts = RouteOpts::default();
    let mut m = meta("a.test", 443);
    assert!(matches!(r.step(&mut m, 0, &mut opts), Step::Process { next: 1 }));
    m.process.set(Some(process::ProcessInfo::from_path(7, "/usr/bin/curl".into()))).unwrap();
    assert!(matches!(r.step(&mut m, 1, &mut opts), Step::Done(Verdict::Route { ref tag, .. }) if tag == "direct"));
    // a connection an earlier rule decides never has its process looked up
    let mut early = meta("a.test", 1);
    assert!(matches!(r.step(&mut early, 0, &mut opts), Step::Done(_)));
    assert!(!early.process_known());
}

#[tokio::test]
async fn the_process_lookup_runs_off_the_runtime_and_is_kept() {
    let mut m = meta("a.test", 443);
    m.lookup_process().await;
    assert!(m.process_known());
    assert_eq!(m.process.get(), Some(&None), "nothing of ours listens on 127.0.0.1:50000");
}
