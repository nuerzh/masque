//! Decoder for sing-box binary rule sets (`.srs`, `common/srs/binary.go`).
//!
//! Layout: the magic `SRS`, one version byte (1..=5 at sing-box 1.14), then a zlib stream
//! holding a uvarint rule count and the rules. A rule is a type byte (0 default, 1 logical);
//! a default rule is a run of (item type, item payload) pairs closed by 0xFF and an invert
//! byte; a logical rule is a mode byte, a uvarint count of nested rules, and an invert byte.

use std::io::Read;

use super::domain::{AdGuardMatcher, DomainMatcher};
use super::ipset::{IpSet, IpSetBuilder};
use super::rule::{DefaultRule, Item, LogicalRule, Rule};

pub const MAGIC: [u8; 3] = *b"SRS";
/// The newest version sing-box 1.14 writes (RuleSetVersionCurrent).
pub const MAX_VERSION: u8 = 5;
const MAX_DEPTH: usize = 100;

#[derive(Debug)]
pub enum Error {
    Io(std::io::Error),
    Malformed(String),
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Error::Io(e) => write!(f, "{e}"),
            Error::Malformed(m) => write!(f, "{m}"),
        }
    }
}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        if e.kind() == std::io::ErrorKind::UnexpectedEof {
            Error::Malformed("unexpected end of rule-set data".into())
        } else {
            Error::Io(e)
        }
    }
}

pub fn read_uvarint<R: Read>(r: &mut R) -> Result<u64, Error> {
    let mut x: u64 = 0;
    let mut s: u32 = 0;
    for i in 0..10 {
        let mut b = [0u8; 1];
        r.read_exact(&mut b)?;
        let b = b[0];
        if b < 0x80 {
            if i == 9 && b > 1 {
                return Err(Error::Malformed("uvarint overflows 64 bits".into()));
            }
            return Ok(x | (b as u64) << s);
        }
        x |= ((b & 0x7f) as u64) << s;
        s += 7;
    }
    Err(Error::Malformed("uvarint overflows 64 bits".into()))
}

fn read_u8<R: Read>(r: &mut R) -> Result<u8, Error> {
    let mut b = [0u8; 1];
    r.read_exact(&mut b)?;
    Ok(b[0])
}

fn bounded(n: u64, what: &str) -> Result<usize, Error> {
    if n > 1 << 26 {
        return Err(Error::Malformed(format!("{what}: implausible length {n}")));
    }
    Ok(n as usize)
}

fn read_strings<R: Read>(r: &mut R) -> Result<Vec<String>, Error> {
    let n = bounded(read_uvarint(r)?, "string list")?;
    let mut out = Vec::with_capacity(n.min(4096));
    for _ in 0..n {
        let len = bounded(read_uvarint(r)?, "string")?;
        let mut buf = vec![0u8; len];
        r.read_exact(&mut buf)?;
        out.push(String::from_utf8_lossy(&buf).into_owned());
    }
    Ok(out)
}

fn read_u16s<R: Read>(r: &mut R) -> Result<Vec<u16>, Error> {
    let n = bounded(read_uvarint(r)?, "u16 list")?;
    let mut out = Vec::with_capacity(n.min(4096));
    for _ in 0..n {
        let mut b = [0u8; 2];
        r.read_exact(&mut b)?;
        out.push(u16::from_be_bytes(b));
    }
    Ok(out)
}

fn read_addr<R: Read>(r: &mut R) -> Result<std::net::IpAddr, Error> {
    let len = read_uvarint(r)?;
    match len {
        4 => {
            let mut b = [0u8; 4];
            r.read_exact(&mut b)?;
            Ok(std::net::IpAddr::from(b))
        }
        16 => {
            let mut b = [0u8; 16];
            r.read_exact(&mut b)?;
            Ok(std::net::IpAddr::from(b))
        }
        _ => Err(Error::Malformed(format!("bad address length {len}"))),
    }
}

/// netipx.IPSet as written by sing-box: a version byte (1), a big-endian u64 range count, then
/// (from, to) address pairs.
fn read_ip_set<R: Read>(r: &mut R) -> Result<IpSet, Error> {
    let version = read_u8(r)?;
    if version != 1 {
        return Err(Error::Malformed(format!("unknown ip set version {version}")));
    }
    let mut b = [0u8; 8];
    r.read_exact(&mut b)?;
    let n = bounded(u64::from_be_bytes(b), "ip set")?;
    let mut builder = IpSetBuilder::default();
    for _ in 0..n {
        let from = read_addr(r)?;
        let to = read_addr(r)?;
        if !builder.add_range(from, to) {
            return Err(Error::Malformed("ip range mixes families".into()));
        }
    }
    Ok(builder.build())
}

fn skip_prefix<R: Read>(r: &mut R) -> Result<(), Error> {
    read_addr(r)?;
    read_u8(r)?;
    Ok(())
}

/// Decode a whole `.srs` file into headless rules.
pub fn decode(data: &[u8]) -> Result<(u8, Vec<Rule>), Error> {
    if data.len() < 4 || data[..3] != MAGIC {
        return Err(Error::Malformed("not a sing-box rule-set file (no SRS magic)".into()));
    }
    let version = data[3];
    if version == 0 || version > MAX_VERSION {
        return Err(Error::Malformed(format!(
            "unsupported rule-set version {version} (this build reads 1..={MAX_VERSION})"
        )));
    }
    let mut z = std::io::BufReader::new(flate2::read::ZlibDecoder::new(&data[4..]));
    let n = bounded(read_uvarint(&mut z)?, "rule count")?;
    let mut rules = Vec::with_capacity(n.min(1024));
    for i in 0..n {
        rules.push(
            read_rule(&mut z, 0)
                .map_err(|e| Error::Malformed(format!("read rule[{i}]: {e}")))?,
        );
    }
    Ok((version, rules))
}

fn read_rule<R: Read>(r: &mut R, depth: usize) -> Result<Rule, Error> {
    if depth > MAX_DEPTH {
        return Err(Error::Malformed("logical rule nested too deep".into()));
    }
    match read_u8(r)? {
        0 => read_default(r).map(Rule::Default),
        1 => {
            let mode = read_u8(r)?;
            let and = match mode {
                0 => true,
                1 => false,
                m => return Err(Error::Malformed(format!("unknown logical mode {m}"))),
            };
            let n = bounded(read_uvarint(r)?, "logical rule")?;
            let mut rules = Vec::with_capacity(n.min(64));
            for _ in 0..n {
                rules.push(read_rule(r, depth + 1)?);
            }
            let invert = read_u8(r)? != 0;
            Ok(Rule::Logical(LogicalRule { and, rules, invert }))
        }
        t => Err(Error::Malformed(format!("unknown rule type {t}"))),
    }
}

fn read_default<R: Read>(r: &mut R) -> Result<DefaultRule, Error> {
    let mut rule = DefaultRule::default();
    let mut last = 0u8;
    loop {
        let item = read_u8(r)?;
        match item {
            // query_type: only meaningful for DNS rules; a connection never matches it.
            0 => {
                read_u16s(r)?;
                rule.push_item(Item::Never("query_type"));
            }
            1 => {
                let v = read_strings(r)?;
                rule.push_item(Item::network(&v));
            }
            2 => rule.push_dst_addr(Item::Domain(DomainMatcher::read(r)?)),
            3 => {
                let v = read_strings(r)?;
                rule.push_dst_addr(Item::DomainKeyword(v.iter().map(|s| s.to_lowercase()).collect()));
            }
            4 => {
                let v = read_strings(r)?;
                rule.push_dst_addr(Item::domain_regex(&v).map_err(Error::Malformed)?);
            }
            5 => rule.push_src_addr(Item::SourceIpCidr(read_ip_set(r)?)),
            6 => rule.push_dst_ipcidr(Item::IpCidr(read_ip_set(r)?)),
            7 => {
                let v = read_u16s(r)?;
                rule.push_src_port(Item::SourcePort(v.into_iter().collect()));
            }
            8 => {
                let v = read_strings(r)?;
                rule.push_src_port(Item::SourcePortRange(
                    super::rule::parse_port_ranges(&v).map_err(Error::Malformed)?,
                ));
            }
            9 => {
                let v = read_u16s(r)?;
                rule.push_dst_port(Item::Port(v.into_iter().collect()));
            }
            10 => {
                let v = read_strings(r)?;
                rule.push_dst_port(Item::PortRange(
                    super::rule::parse_port_ranges(&v).map_err(Error::Malformed)?,
                ));
            }
            11 => {
                let v = read_strings(r)?;
                rule.push_item(Item::ProcessName(v.into_iter().collect()));
            }
            12 => {
                let v = read_strings(r)?;
                rule.push_item(Item::ProcessPath(v.into_iter().collect()));
            }
            13 => {
                read_strings(r)?;
                rule.push_item(Item::Never("package_name"));
            }
            14 => {
                read_strings(r)?;
                rule.push_item(Item::Never("wifi_ssid"));
            }
            15 => {
                read_strings(r)?;
                rule.push_item(Item::Never("wifi_bssid"));
            }
            16 => rule.push_dst_addr(Item::AdGuard(AdGuardMatcher::read(r)?)),
            17 => {
                let v = read_strings(r)?;
                rule.push_item(Item::process_path_regex(&v).map_err(Error::Malformed)?);
            }
            18 => {
                // network_type: a uvarint-counted list of one-byte interface types
                let n = bounded(read_uvarint(r)?, "network_type")?;
                for _ in 0..n {
                    read_u8(r)?;
                }
                rule.push_item(Item::Never("network_type"));
            }
            19 => rule.push_item(Item::Never("network_is_expensive")),
            20 => rule.push_item(Item::Never("network_is_constrained")),
            21 => {
                let n = bounded(read_uvarint(r)?, "network_interface_address")?;
                for _ in 0..n {
                    read_u8(r)?;
                    let count = bounded(read_uvarint(r)?, "prefix list")?;
                    for _ in 0..count {
                        skip_prefix(r)?;
                    }
                }
                rule.push_item(Item::Never("network_interface_address"));
            }
            22 => {
                let count = bounded(read_uvarint(r)?, "prefix list")?;
                for _ in 0..count {
                    skip_prefix(r)?;
                }
                rule.push_item(Item::Never("default_interface_address"));
            }
            23 => {
                read_strings(r)?;
                rule.push_item(Item::Never("package_name_regex"));
            }
            0xFF => {
                rule.invert = read_u8(r)? != 0;
                return Ok(rule);
            }
            other => {
                return Err(Error::Malformed(format!(
                    "unknown rule item type {other}, last type {last}"
                )))
            }
        }
        last = item;
    }
}

/// Encoder for tests: writes a rule set holding default rules made of the given parts, in the
/// byte layout of `srs.Write`, so the decoder can be checked against hand-built files.
#[cfg(test)]
pub mod testenc {
    use std::io::Write;

    pub fn uvarint(out: &mut Vec<u8>, mut v: u64) {
        while v >= 0x80 {
            out.push((v as u8) | 0x80);
            v >>= 7;
        }
        out.push(v as u8);
    }

    pub fn strings(out: &mut Vec<u8>, item: u8, v: &[&str]) {
        out.push(item);
        uvarint(out, v.len() as u64);
        for s in v {
            uvarint(out, s.len() as u64);
            out.extend_from_slice(s.as_bytes());
        }
    }

    pub fn finish(version: u8, body: &[u8], rules: u64) -> Vec<u8> {
        let mut out = b"SRS".to_vec();
        out.push(version);
        let mut z = flate2::write::ZlibEncoder::new(Vec::new(), flate2::Compression::best());
        let mut head = Vec::new();
        uvarint(&mut head, rules);
        z.write_all(&head).unwrap();
        z.write_all(body).unwrap();
        out.extend_from_slice(&z.finish().unwrap());
        out
    }
}
