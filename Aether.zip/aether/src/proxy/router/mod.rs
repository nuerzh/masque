//! sing-box compatible routing for Aether's socks5 and http proxies.
//!
//! A `route` object as sing-box defines it (rules, rule actions, rule sets, final) decides for
//! every connection whether it goes `direct`, through the WARP tunnel (`warp`, or `warp-local`:
//! resolved on this machine, connected through WARP), through the sunnyquic client of --sunny
//! (`sunny`), or is refused (`block` / `reject`). See
//! Docs/ROUTE.zh.md (and the guide) for the supported fields.
//!
//! The rules are evaluated in order like sing-box's `matchRule`: non-final actions (`sniff`,
//! `resolve`, `route-options`) update the connection and evaluation goes on; the first final
//! action (`route`, `reject`, `hijack-dns`) decides. No match means `final`.

pub mod domain;
pub mod exits;
pub mod hostname;
pub mod ipset;
pub mod process;
pub mod rule;
pub mod ruleset;
pub mod sniff;
pub mod srs;

mod build;
mod global;
mod update;
pub use build::*;
pub use global::*;
pub use update::*;

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, Instant};

use serde_json::Value;

use rule::{parse_rule, Ctx, Metadata, ParseEnv, Rule};
use ruleset::{Cache, CacheMeta, Fetched, Format, Kind, Slot};
use sniff::Sniffer;

use crate::proxy::outbound::sunnyquic::SUNNY_DIRECT;

/// Where a connection is sent.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum OutKind {
    Direct,
    Block,
    /// The WARP tunnel stack (MASQUE over HTTP/3 or HTTP/2), and only that: never sunnyquic.
    Warp,
    /// `warp-local`: the name is resolved on this machine, by the same resolver `direct` uses
    /// (the system resolver; with --tun the --tun-direct-dns servers over the physical
    /// interface), and the connection to the address found then goes through the WARP stack.
    /// As strict as `warp`: needs a WARP stack, never falls back to another outbound.
    WarpLocal,
    /// The sunnyquic client of --sunny, and only that: other modes refuse a config that uses
    /// it. It goes from this machine's own udp socket by default ([sunny] `detour = "direct"`,
    /// no WARP); with `detour = "warp"` it rides the WARP MASQUE tunnel, and then while it is
    /// not up its connections wait for it as `warp` waits for the tunnel. Never WARP instead.
    Sunny,
    /// The alias `proxy` / `tunnel`, "the" tunnel of the running mode: `sunny` in --sunny
    /// (direct or over WARP, as its detour says), WARP otherwise. What `final` defaults to.
    Tunnel,
    /// An outbound of the registry by its index (`sunny-direct`, a declared `sunnyquic`).
    Custom(u16),
}

impl OutKind {
    pub fn label(self) -> &'static str {
        match self {
            OutKind::Direct => "direct",
            OutKind::Block => "block",
            OutKind::Warp => "warp",
            OutKind::WarpLocal => "warp-local",
            OutKind::Sunny => "sunny",
            OutKind::Tunnel => "tunnel",
            OutKind::Custom(_) => "sunnyquic",
        }
    }

    /// A name for logs: the alias `proxy` / `tunnel` as the mode resolves it (sunny in
    /// --sunny, else WARP). `sunny` and `warp` are always themselves.
    pub fn effective(self) -> OutKind {
        match self {
            OutKind::Tunnel if sunny_mode() => OutKind::Sunny,
            k => k,
        }
    }
}

/// Whether this run is --sunny (as lib.rs picks the protocol: AETHER_PROTOCOL, or a sunnyquic
/// server given with no protocol: --sunny-server, or `server` in [sunny] / --sunny-config).
pub fn sunny_mode() -> bool {
    let set = |k: &str| crate::config::settings::var(k).map(|v| !v.trim().is_empty()).unwrap_or(false);
    match crate::config::settings::var("AETHER_PROTOCOL") {
        Ok(v) => matches!(v.trim().to_lowercase().as_str(), "sunny" | "sunnyquic" | "sunny-over-masque"),
        Err(_) => set("AETHER_SUNNY_SERVER") || sunny_server_in_config(),
    }
}

/// Whether the --sunny client rides WARP: --sunny-detour / AETHER_SUNNY_DETOUR, else `detour`
/// of [sunny] / --sunny-config, else direct. Only --sunny has a sunny client; without it this
/// is `Ok(false)` whatever the setting says. A value other than direct or warp is an error.
pub fn sunny_over_warp() -> Result<bool, String> {
    if !sunny_mode() {
        return Ok(false);
    }
    use crate::proxy::outbound::sunnyquic::{settings, Detour};
    Ok(settings::detour().map_err(|e| e.to_string())? == Detour::Warp)
}

/// Read once: this is asked on every routing decision.
fn sunny_server_in_config() -> bool {
    static GIVEN: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *GIVEN.get_or_init(crate::proxy::outbound::sunnyquic::settings::server_in_config)
}

/// Which strict outbounds the running mode has.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Caps {
    /// `sunny`: only --sunny.
    pub sunny: bool,
    /// The --sunny client rides WARP ([sunny] `detour = "warp"`); by default it goes direct.
    pub sunny_over_warp: bool,
}

impl Caps {
    /// Every outbound, the --sunny client going direct (its default).
    pub const ALL: Caps = Caps { sunny: true, sunny_over_warp: false };
    /// Every outbound, the --sunny client inside WARP MASQUE (`detour = "warp"`).
    #[cfg(test)]
    pub const SUNNY_OVER_WARP: Caps = Caps { sunny: true, sunny_over_warp: true };

    pub fn from_env() -> Result<Caps, String> {
        Ok(Caps { sunny: sunny_mode(), sunny_over_warp: sunny_over_warp()? })
    }

    /// The config error for an outbound of `kind` this mode does not have.
    fn check(self, kind: OutKind, tag: &str, path: &str) -> Result<(), String> {
        match kind {
            OutKind::Sunny if !self.sunny => Err(format!(
                "{path}: outbound {tag:?} is sunny, the sunny sunnyquic client, which this run does not have: \
                 set protocol: sunny (with a server in sunny, or in the sunny-config file); it goes direct \
                 by default, detour: warp puts it inside WARP. sunny never falls back to WARP; for a \
                 sunnyquic server without protocol: sunny declare an outbound of type sunnyquic"
            )),
            _ => Ok(()),
        }
    }
}

fn warn_once(key: &'static str, msg: impl FnOnce() -> String) {
    static SEEN: parking_lot::Mutex<Vec<&'static str>> = parking_lot::Mutex::new(Vec::new());
    let mut seen = SEEN.lock();
    if !seen.contains(&key) {
        seen.push(key);
        log::warn!("[route] {}", msg());
    }
}

#[derive(Debug, Clone, Default)]
pub struct RouteOpts {
    pub override_address: Option<String>,
    pub override_port: Option<u16>,
    pub tls_fragment: bool,
    pub tls_fragment_delay: Option<Duration>,
    pub tls_record_fragment: bool,
}

impl RouteOpts {
    fn apply(&mut self, o: &RouteOpts) {
        if o.override_address.is_some() {
            self.override_address = o.override_address.clone();
        }
        if o.override_port.is_some() {
            self.override_port = o.override_port;
        }
        if o.tls_fragment {
            self.tls_fragment = true;
            self.tls_fragment_delay = o.tls_fragment_delay;
        }
        if o.tls_record_fragment {
            self.tls_record_fragment = true;
        }
    }
}

#[derive(Debug, Clone)]
pub enum Verdict {
    Route { kind: OutKind, tag: String },
    Reject { drop: bool },
    HijackDns,
}

#[derive(Debug, Clone)]
pub struct SniffOpts {
    pub sniffers: Vec<Sniffer>,
    pub timeout: Duration,
}

impl Default for SniffOpts {
    fn default() -> Self {
        SniffOpts {
            sniffers: Vec::new(),
            timeout: Duration::from_millis(300),
        }
    }
}

impl SniffOpts {
    pub fn stream(&self) -> Vec<Sniffer> {
        if self.sniffers.is_empty() {
            return Sniffer::STREAM.to_vec();
        }
        self.sniffers.iter().copied().filter(|s| Sniffer::STREAM.contains(s)).collect()
    }
    pub fn packet(&self) -> Vec<Sniffer> {
        if self.sniffers.is_empty() {
            return Sniffer::PACKET.to_vec();
        }
        self.sniffers.iter().copied().filter(|s| Sniffer::PACKET.contains(s)).collect()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Resolver {
    /// The system resolver of this machine.
    Local,
    /// Aether's resolver inside the tunnel (1.1.1.1 over WARP, the default).
    Tunnel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Strategy {
    AsIs,
    PreferIpv4,
    PreferIpv6,
    Ipv4Only,
    Ipv6Only,
}

#[derive(Debug, Clone)]
pub struct ResolveOpts {
    pub resolver: Resolver,
    pub strategy: Strategy,
    pub timeout: Duration,
}

impl Default for ResolveOpts {
    fn default() -> Self {
        ResolveOpts {
            resolver: Resolver::Tunnel,
            strategy: Strategy::AsIs,
            timeout: Duration::from_secs(10),
        }
    }
}

impl ResolveOpts {
    pub fn order(&self, mut ips: Vec<std::net::IpAddr>) -> Vec<std::net::IpAddr> {
        match self.strategy {
            Strategy::AsIs => {}
            Strategy::PreferIpv4 => ips.sort_by_key(|ip| ip.is_ipv6()),
            Strategy::PreferIpv6 => ips.sort_by_key(|ip| ip.is_ipv4()),
            Strategy::Ipv4Only => ips.retain(|ip| ip.is_ipv4()),
            Strategy::Ipv6Only => ips.retain(|ip| ip.is_ipv6()),
        }
        ips
    }
}

#[derive(Debug, Clone)]
enum Action {
    Route { kind: OutKind, tag: String, opts: RouteOpts },
    RouteOptions(RouteOpts),
    Reject { drop: bool },
    HijackDns,
    Sniff(SniffOpts),
    Resolve(ResolveOpts),
    /// `bypass` without an outbound: only meaningful in sing-box's tun pre-match.
    Skip,
}

impl Action {
    fn label(&self) -> String {
        match self {
            Action::Route { tag, .. } => format!("route({tag})"),
            Action::RouteOptions(_) => "route-options".into(),
            Action::Reject { drop } => if *drop { "reject(drop)".into() } else { "reject".into() },
            Action::HijackDns => "hijack-dns".into(),
            Action::Sniff(_) => "sniff".into(),
            Action::Resolve(_) => "resolve".into(),
            Action::Skip => "bypass(skip)".into(),
        }
    }
}

#[derive(Debug)]
struct RouteRule {
    rule: Rule,
    action: Action,
}

/// What the caller has to do before evaluation can go on.
#[derive(Debug)]
pub enum Step {
    Done(Verdict),
    Sniff { next: usize, opts: SniffOpts },
    Resolve { next: usize, opts: ResolveOpts },
    /// The rule at `next` reads the client's process: look it up off the async threads
    /// (`Metadata::lookup_process`), then step again from `next`.
    Process { next: usize },
}

pub struct Router {
    rules: Vec<RouteRule>,
    final_kind: OutKind,
    final_tag: String,
    sets: Vec<Arc<Slot>>,
    /// sniff before the first rule when the config has domain or protocol conditions but no
    /// sniff action (Aether's earlier behaviour; AETHER_ROUTE_SNIFF=0 turns it off).
    auto_sniff: bool,
    cache: Cache,
    started: parking_lot::Mutex<Option<Instant>>,
    loaded: tokio::sync::Notify,
    wait_limit: Duration,
    detours: HashMap<String, OutKind>,
    /// The --sunny client rides WARP (`Caps::sunny_over_warp`): `sunny` and, in --sunny,
    /// `proxy` need the WARP tunnel only then.
    sunny_over_warp: bool,
}

impl std::fmt::Debug for Router {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Router")
            .field("rules", &self.rules.len())
            .field("final", &self.final_tag)
            .field("sets", &self.sets.len())
            .finish()
    }
}

impl Router {
    pub fn rule_count(&self) -> usize {
        self.rules.len()
    }

    #[cfg(test)]
    pub fn final_tag(&self) -> &str {
        &self.final_tag
    }

    /// What in this config can only work with the WARP tunnel up, one line each; empty when
    /// nothing does. Every outbound a rule, `final` or a rule-set download can pick counts,
    /// as do hijack-dns and `resolve` with the resolver inside the tunnel.
    pub fn warp_users(&self) -> Vec<String> {
        use crate::proxy::outbound::{kind_needs_warp as needs, warp_reason as reason};
        let sw = self.sunny_over_warp;
        let kind_needs_warp = |k: OutKind| needs(k, sw);
        let warp_reason = |k: OutKind| reason(k, sw);
        let mut out = Vec::new();
        for (i, rr) in self.rules.iter().enumerate() {
            match &rr.action {
                Action::Route { kind, tag, .. } if kind_needs_warp(*kind) => {
                    out.push(format!("rule {i} routes to {tag}{}", warp_reason(*kind)))
                }
                Action::HijackDns => out.push(format!("rule {i} hijacks dns to the resolver inside the tunnel")),
                Action::Resolve(r) if r.resolver == Resolver::Tunnel => {
                    out.push(format!("rule {i} resolves with the dns inside the tunnel"))
                }
                _ => {}
            }
        }
        if kind_needs_warp(self.final_kind) {
            out.push(format!("final is {}{}", self.final_tag, warp_reason(self.final_kind)));
        }
        for slot in &self.sets {
            if let Kind::Remote { detour, .. } = &slot.kind {
                if kind_needs_warp(detour_kind(self, detour)) {
                    out.push(format!(
                        "rule-set {} downloads through {}",
                        slot.tag,
                        detour.as_deref().unwrap_or("the tunnel (it has no download_detour)")
                    ));
                }
            }
        }
        out
    }

    /// Run the rules from `from` until a final action, or until the caller must sniff or
    /// resolve first. `opts` collects the route options of the rules passed on the way.
    pub fn step(&self, m: &mut Metadata, from: usize, opts: &mut RouteOpts) -> Step {
        if from == 0 && self.auto_sniff && !m.sniffed {
            return Step::Sniff {
                next: 0,
                opts: SniffOpts::default(),
            };
        }
        for (idx, rr) in self.rules.iter().enumerate().skip(from) {
            if !m.process_known() && rr.rule.needs_process() {
                return Step::Process { next: idx };
            }
            if !rr.rule.matches(m, Ctx::default()) {
                continue;
            }
            log::debug!("[route] {} match[{idx}] => {}", m.describe(), rr.action.label());
            match &rr.action {
                Action::Route { kind, tag, opts: o } => {
                    opts.apply(o);
                    return Step::Done(Verdict::Route {
                        kind: *kind,
                        tag: tag.clone(),
                    });
                }
                Action::RouteOptions(o) => opts.apply(o),
                Action::Reject { drop } => return Step::Done(Verdict::Reject { drop: *drop }),
                Action::HijackDns => return Step::Done(Verdict::HijackDns),
                Action::Sniff(s) => {
                    if !m.sniffed && m.protocol.is_none() {
                        return Step::Sniff {
                            next: idx + 1,
                            opts: s.clone(),
                        };
                    }
                }
                Action::Resolve(r) => {
                    if m.fqdn.is_some() && m.ip.is_none() && m.resolved.is_empty() {
                        return Step::Resolve {
                            next: idx + 1,
                            opts: r.clone(),
                        };
                    }
                }
                Action::Skip => {}
            }
        }
        Step::Done(Verdict::Route {
            kind: self.final_kind,
            tag: self.final_tag.clone(),
        })
    }

    /// Hold a connection until every remote rule set has a first version (from the cache or a
    /// download), but never longer than the wait limit after the router started waiting.
    pub async fn wait_ready(&self) {
        if self.sets.iter().all(|s| s.is_loaded()) {
            return;
        }
        let started = *self.started.lock().get_or_insert_with(Instant::now);
        let deadline = started + self.wait_limit;
        loop {
            if self.sets.iter().all(|s| s.is_loaded()) {
                return;
            }
            let now = Instant::now();
            if now >= deadline {
                warn_once("rule-set-wait", || {
                    let missing: Vec<&str> = self
                        .sets
                        .iter()
                        .filter(|s| !s.is_loaded())
                        .map(|s| s.tag.as_str())
                        .collect();
                    format!(
                        "[route] rule sets {missing:?} are not available yet; routing without \
                         them until they download"
                    )
                });
                return;
            }
            let _ = tokio::time::timeout(deadline - now, self.loaded.notified()).await;
        }
    }

    fn mark_loaded(&self) {
        self.loaded.notify_waiters();
    }
}

#[cfg(test)]
mod tests;
