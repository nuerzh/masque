use super::*;

/// Go duration strings as sing-box takes them, plus `d` for days: `1d`, `12h30m`, `300ms`.
pub fn parse_duration(text: &str) -> Result<Duration, String> {
    let t = text.trim();
    if t.is_empty() {
        return Err("empty duration".into());
    }
    if let Ok(secs) = t.parse::<f64>() {
        return Ok(Duration::from_secs_f64(secs.max(0.0)));
    }
    let mut total = 0f64;
    let mut rest = t;
    while !rest.is_empty() {
        let num_end = rest
            .find(|c: char| !(c.is_ascii_digit() || c == '.'))
            .ok_or_else(|| format!("bad duration {text:?}"))?;
        let n: f64 = rest[..num_end].parse().map_err(|_| format!("bad duration {text:?}"))?;
        rest = &rest[num_end..];
        let unit_end = rest
            .find(|c: char| c.is_ascii_digit() || c == '.')
            .unwrap_or(rest.len());
        let unit = &rest[..unit_end];
        rest = &rest[unit_end..];
        let mult = match unit {
            "ns" => 1e-9,
            "us" | "µs" => 1e-6,
            "ms" => 1e-3,
            "s" => 1.0,
            "m" => 60.0,
            "h" => 3600.0,
            "d" => 86400.0,
            _ => return Err(format!("bad duration unit {unit:?} in {text:?}")),
        };
        total += n * mult;
    }
    Ok(Duration::from_secs_f64(total))
}

pub(super) fn duration_field(v: Option<&Value>, key: &str) -> Result<Option<Duration>, String> {
    match v {
        None | Some(Value::Null) => Ok(None),
        Some(Value::String(s)) if s.is_empty() => Ok(None),
        Some(Value::String(s)) => parse_duration(s).map(Some).map_err(|e| format!("{key}: {e}")),
        Some(Value::Number(n)) => Ok(Some(Duration::from_secs_f64(n.as_f64().unwrap_or(0.0)))),
        Some(other) => Err(format!("{key}: expected a duration, found {other}")),
    }
}

/// The builtin outbound tags, available without an `outbounds` list.
pub(super) fn builtin(tag: &str) -> Option<OutKind> {
    Some(match tag {
        "direct" => OutKind::Direct,
        "block" | "reject" => OutKind::Block,
        "warp" | "masque" => OutKind::Warp,
        "warp-local" => OutKind::WarpLocal,
        "sunny" | "sunnyquic" => OutKind::Sunny,
        "proxy" | "tunnel" => OutKind::Tunnel,
        _ => return None,
    })
}

pub(super) struct Outbounds {
    by_tag: HashMap<String, OutKind>,
    dns_tags: Vec<String>,
    /// Outbounds of types Aether does not have (tag -> type): an error when used.
    unsupported: HashMap<String, String>,
}

pub(super) fn parse_outbounds(v: Option<&Value>, base: &Path, warn: &mut dyn FnMut(String)) -> Result<Outbounds, String> {
    let mut by_tag = HashMap::new();
    let mut dns_tags = Vec::new();
    let mut unsupported = HashMap::new();
    let Some(list) = v else {
        return Ok(Outbounds { by_tag, dns_tags, unsupported });
    };
    let list = list.as_array().ok_or("outbounds must be an array")?;
    for (i, o) in list.iter().enumerate() {
        let ty = o.get("type").and_then(|t| t.as_str()).unwrap_or("");
        let tag = o
            .get("tag")
            .and_then(|t| t.as_str())
            .filter(|t| !t.is_empty())
            .unwrap_or(ty)
            .to_string();
        let kind = match ty {
            "direct" => OutKind::Direct,
            "block" => OutKind::Block,
            "warp" | "masque" => OutKind::Warp,
            "warp-local" => OutKind::WarpLocal,
            // with a server of its own: a sunnyquic client of its own; without: --sunny's
            "sunnyquic" if o.get("server").is_some() => {
                let path = format!("outbounds[{i}]");
                if builtin(&tag).is_some() || tag == SUNNY_DIRECT {
                    return Err(format!("{path}: tag {tag:?} is a builtin outbound; give this sunnyquic outbound a tag of its own"));
                }
                let obj = o.as_object().ok_or_else(|| format!("{path}: must be an object"))?;
                let (settings, detour) = crate::proxy::outbound::sunnyquic::settings::parse(obj, &path, base, warn)?;
                OutKind::Custom(crate::proxy::outbound::sunnyquic::register(&tag, settings, detour).map_err(|e| format!("{path}: {e}"))?)
            }
            "sunny-direct" => OutKind::Custom(crate::proxy::outbound::sunnyquic::sunny_direct().map_err(|e| format!("outbounds[{i}]: sunny-direct: {e}"))?),
            "sunny" | "sunnyquic" => OutKind::Sunny,
            "proxy" | "tunnel" => OutKind::Tunnel,
            "dns" => {
                dns_tags.push(tag);
                continue;
            }
            other => {
                warn(format!(
                    "outbounds[{i}]: type {other:?} ({tag}) does not exist in Aether; a rule, \
                     final or download_detour that uses it is a config error"
                ));
                unsupported.insert(tag, other.to_string());
                continue;
            }
        };
        by_tag.insert(tag, kind);
    }
    Ok(Outbounds { by_tag, dns_tags, unsupported })
}

impl Outbounds {
    fn resolve(&self, tag: &str) -> Option<OutKind> {
        if self.unsupported.contains_key(tag) {
            return None;
        }
        self.by_tag.get(tag).copied().or_else(|| builtin(tag)).or_else(|| {
            (tag == SUNNY_DIRECT).then(|| crate::proxy::outbound::sunnyquic::sunny_direct().ok().map(OutKind::Custom)).flatten()
        })
    }

    /// The kind of `tag`, checked against what the mode has.
    fn resolve_checked(&self, tag: &str, path: &str, caps: Caps) -> Result<OutKind, String> {
        if let Some(ty) = self.unsupported.get(tag) {
            return Err(format!(
                "{path}: outbound {tag:?} has type {ty:?}, which Aether does not have (it is not \
                 replaced by another outbound)"
            ));
        }
        if tag == SUNNY_DIRECT && !self.by_tag.contains_key(tag) {
            crate::proxy::outbound::sunnyquic::sunny_direct().map_err(|e| format!("{path}: outbound sunny-direct: {e}"))?;
        }
        let kind = self.resolve(tag).ok_or_else(|| format!("{path}: outbound not found: {tag}"))?;
        caps.check(kind, tag, path)?;
        Ok(kind)
    }
}

pub(super) fn parse_route_opts(o: &serde_json::Map<String, Value>, path: &str, warn: &mut dyn FnMut(String)) -> Result<RouteOpts, String> {
    let mut r = RouteOpts::default();
    if let Some(a) = o.get("override_address").and_then(|v| v.as_str()).filter(|s| !s.is_empty()) {
        r.override_address = Some(a.trim_start_matches('[').trim_end_matches(']').to_string());
    }
    if let Some(p) = o.get("override_port").and_then(|v| v.as_u64()).filter(|p| *p > 0) {
        r.override_port = Some(u16::try_from(p).map_err(|_| format!("{path}.override_port: {p}"))?);
    }
    r.tls_fragment = o.get("tls_fragment").and_then(|v| v.as_bool()).unwrap_or(false);
    r.tls_fragment_delay = duration_field(o.get("tls_fragment_fallback_delay"), &format!("{path}.tls_fragment_fallback_delay"))?;
    r.tls_record_fragment = o
        .get("tls_record_fragment")
        .map(|v| v.as_bool().unwrap_or_else(|| v.as_str().is_some_and(|s| !s.is_empty())))
        .unwrap_or(false);
    for key in [
        "network_strategy",
        "network_type",
        "fallback_network_type",
        "fallback_delay",
        "udp_disable_domain_unmapping",
        "udp_connect",
        "udp_timeout",
        "tls_spoof",
        "tls_spoof_method",
    ] {
        if o.get(key).is_some_and(|v| !v.is_null() && v != &Value::Bool(false) && v != "") {
            warn(format!("{path}.{key}: accepted but has no effect in Aether"));
        }
    }
    Ok(r)
}

pub(super) fn parse_resolve(o: &serde_json::Map<String, Value>, path: &str, base: &ResolveOpts, dns_server_tags: &HashMap<String, Resolver>, warn: &mut dyn FnMut(String)) -> Result<ResolveOpts, String> {
    let mut r = base.clone();
    if let Some(server) = o.get("server").and_then(|v| v.as_str()).filter(|s| !s.is_empty()) {
        r.resolver = resolver_of(server, dns_server_tags);
    }
    if let Some(s) = o.get("strategy").and_then(|v| v.as_str()).filter(|s| !s.is_empty()) {
        r.strategy = match s {
            "prefer_ipv4" => Strategy::PreferIpv4,
            "prefer_ipv6" => Strategy::PreferIpv6,
            "ipv4_only" => Strategy::Ipv4Only,
            "ipv6_only" => Strategy::Ipv6Only,
            other => return Err(format!("{path}.strategy: unknown strategy {other:?}")),
        };
    }
    if let Some(t) = duration_field(o.get("timeout"), &format!("{path}.timeout"))? {
        r.timeout = t;
    }
    for key in ["disable_cache", "disable_optimistic_cache", "rewrite_ttl", "client_subnet"] {
        if o.get(key).is_some_and(|v| !v.is_null() && v != &Value::Bool(false)) {
            warn(format!("{path}.{key}: accepted but has no effect in Aether"));
        }
    }
    Ok(r)
}

/// A dns server tag: `local` (and servers of type local/dhcp in a full sing-box config) use
/// this machine's resolver; anything else uses Aether's resolver inside the tunnel.
pub(super) fn resolver_of(tag: &str, dns_server_tags: &HashMap<String, Resolver>) -> Resolver {
    if let Some(r) = dns_server_tags.get(tag) {
        return *r;
    }
    match tag {
        "local" | "system" | "direct" => Resolver::Local,
        _ => Resolver::Tunnel,
    }
}

pub(super) fn parse_action(
    o: &serde_json::Map<String, Value>,
    path: &str,
    outs: &Outbounds,
    caps: Caps,
    default_resolver: &ResolveOpts,
    dns_server_tags: &HashMap<String, Resolver>,
    warn: &mut dyn FnMut(String),
) -> Result<Action, String> {
    let action = o.get("action").and_then(|v| v.as_str()).unwrap_or("");
    let tag_of = |key: &str| o.get(key).and_then(|v| v.as_str()).filter(|s| !s.is_empty());
    let route_to = |tag: &str, warn: &mut dyn FnMut(String)| -> Result<Action, String> {
        if outs.dns_tags.iter().any(|t| t == tag) {
            return Ok(Action::HijackDns);
        }
        let kind = outs.resolve_checked(tag, path, caps)?;
        Ok(Action::Route {
            kind,
            tag: tag.to_string(),
            opts: parse_route_opts(o, path, warn)?,
        })
    };
    match action {
        "" | "route" => {
            let tag = tag_of("outbound").ok_or_else(|| format!("{path}: missing outbound field"))?;
            route_to(tag, warn)
        }
        "route-options" => Ok(Action::RouteOptions(parse_route_opts(o, path, warn)?)),
        "direct" => {
            for key in ["bind_interface", "inet4_bind_address", "inet6_bind_address", "routing_mark", "reuse_addr", "connect_timeout", "tcp_fast_open", "tcp_multi_path", "udp_fragment", "domain_strategy"] {
                if o.contains_key(key) {
                    warn(format!("{path}.{key}: dial options of the direct action have no effect in Aether"));
                }
            }
            Ok(Action::Route {
                kind: OutKind::Direct,
                tag: "direct".into(),
                opts: parse_route_opts(o, path, warn)?,
            })
        }
        "bypass" => match tag_of("outbound") {
            Some(tag) => route_to(tag, warn),
            None => Ok(Action::Skip),
        },
        "reject" => {
            let method = o.get("method").and_then(|v| v.as_str()).unwrap_or("default");
            let drop = match method {
                "" | "default" | "reply" => false,
                "drop" => true,
                other => return Err(format!("{path}.method: unknown reject method {other:?}")),
            };
            if drop && o.get("no_drop").and_then(|v| v.as_bool()).unwrap_or(false) {
                return Err(format!("{path}: no_drop is not available with method drop"));
            }
            Ok(Action::Reject { drop })
        }
        "hijack-dns" => Ok(Action::HijackDns),
        "sniff" => {
            let mut s = SniffOpts::default();
            if let Some(v) = o.get("sniffer") {
                for name in rule::strings(&format!("{path}.sniffer"), v)? {
                    s.sniffers.push(
                        Sniffer::parse(&name).ok_or_else(|| format!("{path}.sniffer: unknown sniffer {name:?}"))?,
                    );
                }
            }
            if let Some(t) = duration_field(o.get("timeout"), &format!("{path}.timeout"))? {
                s.timeout = t;
            }
            Ok(Action::Sniff(s))
        }
        "resolve" => Ok(Action::Resolve(parse_resolve(o, path, default_resolver, dns_server_tags, warn)?)),
        other => Err(format!("{path}: unknown rule action {other:?}")),
    }
}

/// Everything a route config holds, ready to run.
pub struct Spec {
    pub router: Router,
    pub warnings: Vec<String>,
}

pub struct LoadOptions {
    pub base_dir: PathBuf,
    pub cache_dir: PathBuf,
    /// The strict outbounds the running mode has (`Caps::from_env()`).
    pub caps: Caps,
}

/// Build a router from a sing-box `route` object (or a whole sing-box config holding one).
pub fn build(config: &Value, opts: LoadOptions) -> Result<Spec, String> {
    let mut warnings: Vec<String> = Vec::new();
    let mut warn = |m: String| warnings.push(m);

    let (route, outbounds_v, dns_v) = if let Some(route) = config.get("route").filter(|r| r.is_object()) {
        (route, config.get("outbounds"), config.get("dns"))
    } else {
        (config, config.get("outbounds"), None)
    };
    let route_obj = route.as_object().ok_or("[route] must be a table")?;
    let outs = parse_outbounds(outbounds_v, &opts.base_dir, &mut warn)?;

    // dns servers of a full sing-box config: which tags mean the local resolver
    let mut dns_server_tags = HashMap::new();
    if let Some(servers) = dns_v.and_then(|d| d.get("servers")).and_then(|s| s.as_array()) {
        for s in servers {
            if let Some(tag) = s.get("tag").and_then(|t| t.as_str()) {
                let ty = s.get("type").and_then(|t| t.as_str()).unwrap_or("");
                let addr = s.get("address").and_then(|t| t.as_str()).unwrap_or("");
                let local = matches!(ty, "local" | "dhcp" | "resolved") || addr == "local";
                let detour_direct = s.get("detour").and_then(|t| t.as_str()).is_some_and(|d| outs.resolve(d) == Some(OutKind::Direct));
                dns_server_tags.insert(tag.to_string(), if local || detour_direct { Resolver::Local } else { Resolver::Tunnel });
            }
        }
    }

    const KNOWN: &[&str] = &["rules", "rule_set", "final", "default_domain_resolver", "find_process", "outbounds"];
    const IGNORED: &[&str] = &[
        "auto_detect_interface",
        "override_android_vpn",
        "default_interface",
        "default_mark",
        "default_network_strategy",
        "default_network_type",
        "default_fallback_network_type",
        "default_fallback_delay",
        "default_http_client",
        "find_neighbor",
        "dhcp_lease_files",
    ];
    for key in route_obj.keys() {
        if IGNORED.contains(&key.as_str()) {
            warn(format!("route.{key}: not applicable to Aether; ignored"));
        } else if key == "geoip" || key == "geosite" {
            warn(format!("route.{key}: removed in sing-box 1.12 (use rule_set); ignored"));
        } else if !KNOWN.contains(&key.as_str()) {
            warn(format!("route.{key}: unknown field ignored"));
        }
    }

    let mut default_resolver = ResolveOpts::default();
    match route_obj.get("default_domain_resolver") {
        None | Some(Value::Null) => {}
        Some(Value::String(tag)) => default_resolver.resolver = resolver_of(tag, &dns_server_tags),
        Some(Value::Object(o)) => {
            default_resolver = parse_resolve(o, "route.default_domain_resolver", &ResolveOpts::default(), &dns_server_tags, &mut warn)?
        }
        Some(other) => return Err(format!("route.default_domain_resolver: unexpected {other}")),
    }

    // rule sets
    let mut sets: Vec<Arc<Slot>> = Vec::new();
    let mut inline_sources: Vec<(Arc<Slot>, Value)> = Vec::new();
    let mut detours = HashMap::new();
    if let Some(list) = route_obj.get("rule_set") {
        let list = list.as_array().ok_or("route.rule_set must be an array")?;
        for (i, s) in list.iter().enumerate() {
            let path = format!("route.rule_set[{i}]");
            let o = s.as_object().ok_or_else(|| format!("{path}: must be an object"))?;
            let tags = rule::strings(&format!("{path}.tag"), o.get("tag").unwrap_or(&Value::Null))?;
            if tags.is_empty() {
                return Err(format!("{path}: missing tag"));
            }
            let ty = o.get("type").and_then(|t| t.as_str()).unwrap_or("");
            let fmt_of = |hint: &str| -> Result<Format, String> {
                match o.get("format").and_then(|f| f.as_str()).unwrap_or("") {
                    "source" => Ok(Format::Source),
                    "yaml" | "toml" => Ok(Format::Yaml),
                    "binary" => Ok(Format::Binary),
                    "" => ruleset::guess_format(hint)
                        .ok_or_else(|| format!("{path}: missing format (and none can be told from {hint:?})")),
                    other => Err(format!("{path}: unknown format {other:?}")),
                }
            };
            let (kind, format) = match ty {
                "inline" | "" if o.contains_key("rules") => (Kind::Inline, Format::Source),
                "inline" => return Err(format!("{path}: an inline rule set needs rules")),
                "local" => {
                    let p = o.get("path").and_then(|p| p.as_str()).ok_or_else(|| format!("{path}: missing path"))?;
                    let mut resolved = resolve_path(p, &opts.base_dir);
                    let format = fmt_of(p)?;
                    if format == Format::Yaml && crate::config::migrate::is_toml(&resolved.to_string_lossy()) {
                        // a rule set an earlier build read as TOML: read as the YAML it is converted to
                        resolved = std::path::PathBuf::from(
                            crate::config::migrate::adopt(&resolved.to_string_lossy()).map_err(|e| format!("{path}: {e}"))?,
                        );
                    }
                    (Kind::Local { path: resolved }, format)
                }
                "remote" => {
                    let url = o.get("url").and_then(|p| p.as_str()).ok_or_else(|| format!("{path}: missing url"))?;
                    let detour = o
                        .get("download_detour")
                        .and_then(|d| d.as_str())
                        .filter(|d| !d.is_empty())
                        .map(|d| d.to_string());
                    if let Some(d) = &detour {
                        let k = outs.resolve_checked(d, &format!("{path}.download_detour"), opts.caps)?;
                        if k == OutKind::Block {
                            return Err(format!("{path}.download_detour: cannot download through block"));
                        }
                        detours.insert(d.clone(), k);
                    }
                    let interval = duration_field(o.get("update_interval"), &format!("{path}.update_interval"))?
                        .unwrap_or(Duration::from_secs(86400))
                        .max(Duration::from_secs(60));
                    let initial_path = o
                        .get("initial_path")
                        .and_then(|p| p.as_str())
                        .filter(|p| !p.is_empty())
                        .map(|p| resolve_path(p, &opts.base_dir));
                    if o.contains_key("http_client") {
                        warn(format!("{path}.http_client: not supported; Aether downloads with its own client"));
                    }
                    (
                        Kind::Remote {
                            url: url.to_string(),
                            detour,
                            interval,
                            initial_path,
                        },
                        fmt_of(url)?,
                    )
                }
                other => return Err(format!("{path}: unknown rule-set type {other:?}")),
            };
            for tag in tags {
                if sets.iter().any(|s| s.tag == tag) {
                    return Err(format!("{path}: duplicate rule-set tag {tag}"));
                }
                let slot = Slot::new(tag, kind.clone(), format);
                if let Kind::Inline = kind {
                    inline_sources.push((slot.clone(), o.get("rules").cloned().unwrap_or(Value::Null)));
                }
                sets.push(slot);
            }
        }
    }
    for (slot, rules) in inline_sources {
        let compiled = ruleset::compile_headless(&rules, &mut warn).map_err(|e| format!("rule-set {}: {e}", slot.tag))?;
        slot.install(ruleset::CompiledSet { rules: compiled, version: 0 });
    }

    // local rule sets load now; remote ones from the cache (or initial_path) when there is one
    let cache = Cache { dir: opts.cache_dir.clone() };
    for slot in &sets {
        match &slot.kind {
            Kind::Inline => {}
            Kind::Local { path } => {
                let data = std::fs::read(path).map_err(|e| format!("rule-set {}: {}: {e}", slot.tag, path.display()))?;
                let compiled = ruleset::compile(&data, slot.format, &mut warn).map_err(|e| format!("rule-set {}: {e}", slot.tag))?;
                slot.install(compiled);
            }
            Kind::Remote { url, initial_path, .. } => {
                if let Some((data, meta)) = cache.load(&slot.tag, slot.format, url) {
                    match ruleset::compile(&data, slot.format, &mut warn) {
                        Ok(c) => {
                            log::info!(
                                "[route] rule-set {}: using the cached copy ({} bytes, {}s old)",
                                slot.tag,
                                data.len(),
                                ruleset::now_secs().saturating_sub(meta.updated)
                            );
                            slot.install(c);
                            continue;
                        }
                        Err(e) => warn(format!("rule-set {}: the cached copy is unusable ({e}); downloading again", slot.tag)),
                    }
                }
                if let Some(p) = initial_path {
                    match std::fs::read(p).map_err(|e| e.to_string()).and_then(|d| ruleset::compile(&d, slot.format, &mut warn)) {
                        Ok(c) => slot.install(c),
                        Err(e) => warn(format!("rule-set {}: initial_path {}: {e}", slot.tag, p.display())),
                    }
                }
            }
        }
    }

    let lookup_set = |tag: &str| sets.iter().find(|s| s.tag == tag).cloned();
    let mut rules: Vec<RouteRule> = Vec::new();
    let empty = Vec::new();
    let configured = route_obj.get("rules").and_then(|r| r.as_array()).unwrap_or(&empty);
    if route_obj.get("rules").is_some_and(|r| !r.is_array()) {
        return Err("route.rules must be an array".into());
    }
    let all: Vec<(String, &Value)> =
        configured.iter().enumerate().map(|(i, v)| (format!("route.rules[{i}]"), v)).collect();
    for (path, v) in all {
        let o = v.as_object().ok_or_else(|| format!("{path}: a rule must be an object"))?;
        if o.keys().all(|k| k == "invert" || k == "type") {
            return Err(format!("{path}: missing conditions"));
        }
        let action = parse_action(o, &path, &outs, opts.caps, &default_resolver, &dns_server_tags, &mut warn)?;
        let mut env = ParseEnv {
            headless: false,
            lookup_set: &lookup_set,
            warn: &mut warn,
        };
        let rule = parse_rule(v, &mut env, &path)?;
        rules.push(RouteRule { rule, action });
    }

    let (final_kind, final_tag) = match route_obj.get("final").and_then(|f| f.as_str()).filter(|f| !f.is_empty()) {
        Some(tag) => (outs.resolve_checked(tag, "route.final", opts.caps)?, tag.to_string()),
        None => (OutKind::Tunnel, "tunnel".to_string()),
    };

    let has_sniff = rules.iter().any(|r| matches!(r.action, Action::Sniff(_)));
    let wants_names = rules.iter().any(|r| r.rule.needs_domain());
    let auto_sniff = !has_sniff
        && wants_names
        && !matches!(crate::config::settings::var("AETHER_ROUTE_SNIFF").as_deref(), Ok("0") | Ok("off") | Ok("false"));

    let mut unsupported = Vec::new();
    for r in &rules {
        r.rule.unsupported(&mut unsupported);
    }
    if !unsupported.is_empty() {
        warn(format!("conditions that never match in Aether: {}", unsupported.join(", ")));
    }

    let wait_limit = crate::config::settings::var("AETHER_ROUTE_WAIT")
        .ok()
        .and_then(|v| parse_duration(&v).ok())
        .unwrap_or(Duration::from_secs(45));

    Ok(Spec {
        router: Router {
            rules,
            final_kind,
            final_tag,
            sets,
            auto_sniff,
            cache,
            started: parking_lot::Mutex::new(None),
            loaded: tokio::sync::Notify::new(),
            wait_limit,
            detours,
            sunny_over_warp: opts.caps.sunny_over_warp,
        },
        warnings,
    })
}

pub(super) fn resolve_path(p: &str, base: &Path) -> PathBuf {
    let path = PathBuf::from(p);
    if path.is_absolute() || path.exists() {
        return path;
    }
    let joined = base.join(&path);
    if joined.exists() {
        joined
    } else {
        path
    }
}
