//! Protocol sniffers of the `sniff` action (sing-box `common/sniff`): what protocol a
//! connection speaks and, for TLS, HTTP and QUIC, the domain it asks for.

use ring::aead;
use ring::hkdf;

/// One sniffer, by its sing-box name.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Sniffer {
    Tls,
    Http,
    Quic,
    Dns,
    Stun,
    BitTorrent,
    Dtls,
    Ssh,
    Rdp,
    Ntp,
}

impl Sniffer {
    pub fn parse(name: &str) -> Option<Sniffer> {
        Some(match name {
            "tls" => Sniffer::Tls,
            "http" => Sniffer::Http,
            "quic" => Sniffer::Quic,
            "dns" => Sniffer::Dns,
            "stun" => Sniffer::Stun,
            "bittorrent" => Sniffer::BitTorrent,
            "dtls" => Sniffer::Dtls,
            "ssh" => Sniffer::Ssh,
            "rdp" => Sniffer::Rdp,
            "ntp" => Sniffer::Ntp,
            _ => return None,
        })
    }

    pub const STREAM: &'static [Sniffer] = &[
        Sniffer::Tls,
        Sniffer::Http,
        Sniffer::Dns,
        Sniffer::BitTorrent,
        Sniffer::Ssh,
        Sniffer::Rdp,
    ];

    pub const PACKET: &'static [Sniffer] = &[
        Sniffer::Dns,
        Sniffer::Quic,
        Sniffer::Stun,
        Sniffer::BitTorrent,
        Sniffer::Dtls,
        Sniffer::Ntp,
    ];
}

/// What a sniffer learnt.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Sniffed {
    pub protocol: &'static str,
    pub domain: Option<String>,
    pub client: Option<String>,
}

#[derive(Debug, PartialEq, Eq)]
pub enum Outcome {
    Found(Sniffed),
    /// Could still turn out to be one of the sniffers' protocols with more bytes.
    NeedMore,
    NotFound,
}

/// Ports whose protocols speak first from the server; sniffing them would only stall.
pub fn skip_port(port: u16) -> bool {
    matches!(port, 25 | 465 | 587 | 143 | 993 | 110 | 995)
}

fn be16(b: &[u8], at: usize) -> Option<usize> {
    Some(((*b.get(at)? as usize) << 8) | *b.get(at + 1)? as usize)
}

fn be24(b: &[u8], at: usize) -> Option<usize> {
    Some(((*b.get(at)? as usize) << 16) | ((*b.get(at + 1)? as usize) << 8) | *b.get(at + 2)? as usize)
}

/// Sniff the first bytes of a stream.
pub fn stream(buf: &[u8], sniffers: &[Sniffer]) -> Outcome {
    let mut more = false;
    for s in sniffers {
        let r = match s {
            Sniffer::Tls => tls(buf),
            Sniffer::Http => http(buf),
            Sniffer::Dns => dns_stream(buf),
            Sniffer::BitTorrent => bittorrent_stream(buf),
            Sniffer::Ssh => ssh(buf),
            Sniffer::Rdp => rdp(buf),
            _ => Outcome::NotFound,
        };
        match r {
            Outcome::Found(f) => return Outcome::Found(f),
            Outcome::NeedMore => more = true,
            Outcome::NotFound => {}
        }
    }
    if more {
        Outcome::NeedMore
    } else {
        Outcome::NotFound
    }
}

/// Sniff one or more datagrams of a flow (QUIC may need two Initial packets).
pub fn packets(datagrams: &[Vec<u8>], sniffers: &[Sniffer]) -> Outcome {
    let Some(first) = datagrams.first() else {
        return Outcome::NotFound;
    };
    let mut more = false;
    for s in sniffers {
        let r = match s {
            Sniffer::Dns => dns_packet(first),
            Sniffer::Quic => quic(datagrams),
            Sniffer::Stun => stun(first),
            Sniffer::BitTorrent => bittorrent_packet(first),
            Sniffer::Dtls => dtls(first),
            Sniffer::Ntp => ntp(first),
            _ => Outcome::NotFound,
        };
        match r {
            Outcome::Found(f) => return Outcome::Found(f),
            Outcome::NeedMore => more = true,
            Outcome::NotFound => {}
        }
    }
    if more {
        Outcome::NeedMore
    } else {
        Outcome::NotFound
    }
}

fn found(protocol: &'static str, domain: Option<String>) -> Outcome {
    Outcome::Found(Sniffed {
        protocol,
        domain,
        client: None,
    })
}

fn tls(buf: &[u8]) -> Outcome {
    if buf.is_empty() {
        return Outcome::NeedMore;
    }
    if buf[0] != 0x16 {
        return Outcome::NotFound;
    }
    if buf.len() < 6 {
        return Outcome::NeedMore;
    }
    if buf[1] != 0x03 || buf[5] != 0x01 {
        return Outcome::NotFound;
    }
    // the whole ClientHello, which may span records
    let Some(record_len) = be16(buf, 3) else {
        return Outcome::NeedMore;
    };
    let Some(hello_len) = be24(buf, 6) else {
        return Outcome::NeedMore;
    };
    let want = 5 + 4 + hello_len;
    if buf.len() < (5 + record_len).min(want) {
        return Outcome::NeedMore;
    }
    if record_len >= 4 + hello_len {
        return found("tls", crate::proxy::router::hostname::tls_sni(buf));
    }
    // a ClientHello split over several records: join their bodies
    let mut body = Vec::with_capacity(4 + hello_len);
    let mut at = 0;
    while body.len() < 4 + hello_len {
        if buf.len() < at + 5 {
            return Outcome::NeedMore;
        }
        if buf[at] != 0x16 {
            return found("tls", None);
        }
        let len = be16(buf, at + 3).unwrap_or(0);
        if buf.len() < at + 5 + len {
            return Outcome::NeedMore;
        }
        body.extend_from_slice(&buf[at + 5..at + 5 + len]);
        at += 5 + len;
    }
    found("tls", client_hello_sni(&body))
}

/// The SNI of a bare handshake message (a ClientHello without a record header).
pub fn client_hello_sni(handshake: &[u8]) -> Option<String> {
    if handshake.len() > 0xffff {
        return None;
    }
    let mut record = vec![0x16, 0x03, 0x01];
    record.extend_from_slice(&(handshake.len() as u16).to_be_bytes());
    record.extend_from_slice(handshake);
    crate::proxy::router::hostname::tls_sni(&record)
}

const HTTP_METHODS: &[&str] = &[
    "GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS ", "CONNECT ", "PATCH ", "TRACE ",
];

fn http(buf: &[u8]) -> Outcome {
    let prefix_ok = HTTP_METHODS.iter().any(|m| {
        let n = m.len().min(buf.len());
        buf[..n].eq_ignore_ascii_case(&m.as_bytes()[..n])
    });
    if !prefix_ok {
        return Outcome::NotFound;
    }
    if !HTTP_METHODS
        .iter()
        .any(|m| buf.len() >= m.len() && buf[..m.len()].eq_ignore_ascii_case(m.as_bytes()))
    {
        return Outcome::NeedMore;
    }
    let Some(end) = buf.windows(4).position(|w| w == b"\r\n\r\n") else {
        return if buf.len() > 16 * 1024 {
            Outcome::NotFound
        } else {
            Outcome::NeedMore
        };
    };
    let head = String::from_utf8_lossy(&buf[..end]);
    let mut host = None;
    for line in head.split("\r\n").skip(1) {
        if let Some((k, v)) = line.split_once(':') {
            if k.trim().eq_ignore_ascii_case("host") {
                let v = v.trim();
                let h = if let Some(rest) = v.strip_prefix('[') {
                    rest.split(']').next().unwrap_or("").to_string()
                } else {
                    v.rsplit_once(':')
                        .filter(|(_, p)| p.parse::<u16>().is_ok())
                        .map(|(h, _)| h.to_string())
                        .unwrap_or_else(|| v.to_string())
                };
                let h = h.trim_end_matches('.').to_lowercase();
                if !h.is_empty() && h.parse::<std::net::IpAddr>().is_err() {
                    host = Some(h);
                }
                break;
            }
        }
    }
    found("http", host)
}

fn dns_header_ok(p: &[u8]) -> bool {
    p.len() >= 12
        && p[2] & 0x80 == 0
        && (p[4] != 0 || p[5] != 0)
        && p[6] == 0
        && p[7] == 0
        && p[8] == 0
        && p[9] == 0
}

fn dns_question_ok(p: &[u8]) -> bool {
    // walk the first question's name
    let mut at = 12;
    loop {
        let Some(&len) = p.get(at) else {
            return false;
        };
        if len == 0 {
            return p.len() >= at + 5;
        }
        if len & 0xc0 != 0 {
            return false;
        }
        at += 1 + len as usize;
    }
}

fn dns_packet(p: &[u8]) -> Outcome {
    if dns_header_ok(p) && dns_question_ok(p) {
        found("dns", None)
    } else {
        Outcome::NotFound
    }
}

fn dns_stream(buf: &[u8]) -> Outcome {
    let Some(len) = be16(buf, 0) else {
        return Outcome::NeedMore;
    };
    if len < 12 {
        return Outcome::NotFound;
    }
    let body = &buf[2..];
    if body.len() > 2 && body[2] & 0x80 != 0 {
        return Outcome::NotFound;
    }
    if body.len() > 5 && body[4] == 0 && body[5] == 0 {
        return Outcome::NotFound;
    }
    for i in 6..10 {
        if body.len() > i && body[i] != 0 {
            return Outcome::NotFound;
        }
    }
    if body.len() < len {
        return Outcome::NeedMore;
    }
    dns_packet(&body[..len])
}

fn bittorrent_stream(buf: &[u8]) -> Outcome {
    const HEADER: &[u8] = b"\x13BitTorrent protocol";
    let n = HEADER.len().min(buf.len());
    if buf.is_empty() {
        return Outcome::NeedMore;
    }
    if buf[..n] != HEADER[..n] {
        return Outcome::NotFound;
    }
    if n < HEADER.len() {
        return Outcome::NeedMore;
    }
    found("bittorrent", None)
}

fn bittorrent_packet(p: &[u8]) -> Outcome {
    // UDP tracker connect
    if p.len() >= 16
        && u64::from_be_bytes(p[0..8].try_into().unwrap()) == 0x41727101980
        && u32::from_be_bytes(p[8..12].try_into().unwrap()) == 0
    {
        return found("bittorrent", None);
    }
    // uTP
    if p.len() >= 20 {
        let version = p[0] & 0x0f;
        let ty = p[0] >> 4;
        if version == 1 && ty <= 4 {
            let mut ext = p[1];
            let mut at = 20;
            let mut ok = true;
            while ext != 0 {
                let (Some(&next), Some(&len)) = (p.get(at), p.get(at + 1)) else {
                    ok = false;
                    break;
                };
                if next > 4 {
                    ok = false;
                    break;
                }
                ext = next;
                at += 2 + len as usize;
                if at > p.len() {
                    ok = false;
                    break;
                }
            }
            if ok {
                return found("bittorrent", None);
            }
        }
    }
    Outcome::NotFound
}

fn ssh(buf: &[u8]) -> Outcome {
    const PREFIX: &[u8] = b"SSH-2.0-";
    let n = PREFIX.len().min(buf.len());
    if buf.is_empty() {
        return Outcome::NeedMore;
    }
    if buf[..n] != PREFIX[..n] {
        return Outcome::NotFound;
    }
    if n < PREFIX.len() {
        return Outcome::NeedMore;
    }
    let Some(eol) = buf.iter().position(|&b| b == b'\n') else {
        return if buf.len() > 255 { Outcome::NotFound } else { Outcome::NeedMore };
    };
    let line = String::from_utf8_lossy(&buf[PREFIX.len()..eol]).trim_end_matches('\r').to_string();
    Outcome::Found(Sniffed {
        protocol: "ssh",
        domain: None,
        client: Some(line),
    })
}

fn rdp(buf: &[u8]) -> Outcome {
    let expect: [(usize, u8); 6] = [(0, 0x03), (1, 0x00), (2, 0x00), (3, 19), (4, 14), (5, 0xe0)];
    for (at, v) in expect {
        match buf.get(at) {
            None => return Outcome::NeedMore,
            Some(b) if *b != v => return Outcome::NotFound,
            _ => {}
        }
    }
    match buf.get(11) {
        None => Outcome::NeedMore,
        Some(1) => found("rdp", None),
        _ => Outcome::NotFound,
    }
}

fn stun(p: &[u8]) -> Outcome {
    if p.len() < 20 || u32::from_be_bytes(p[4..8].try_into().unwrap()) != 0x2112A442 {
        return Outcome::NotFound;
    }
    if p.len() < 20 + be16(p, 2).unwrap_or(0) {
        return Outcome::NotFound;
    }
    found("stun", None)
}

fn dtls(p: &[u8]) -> Outcome {
    if p.len() < 13 || !matches!(p[0], 20 | 21 | 22 | 23 | 25) || p[1] != 0xfe || !matches!(p[2], 0xff | 0xfd) {
        return Outcome::NotFound;
    }
    found("dtls", None)
}

fn ntp(p: &[u8]) -> Outcome {
    if p.len() < 48 {
        return Outcome::NotFound;
    }
    let vn = (p[0] >> 3) & 7;
    let mode = p[0] & 7;
    if !(vn == 3 || vn == 4) || mode != 3 {
        return Outcome::NotFound;
    }
    let delay = u32::from_be_bytes(p[4..8].try_into().unwrap());
    let disp = u32::from_be_bytes(p[8..12].try_into().unwrap());
    if delay as f64 / 65536.0 > 16.0 || disp as f64 / 65536.0 > 16.0 {
        return Outcome::NotFound;
    }
    found("ntp", None)
}

// ---------------------------------------------------------------------------------------------
// QUIC (RFC 9000/9001, and RFC 9369 for version 2)

const QUIC_V1: u32 = 1;
const QUIC_V2: u32 = 0x6b3343cf;
const QUIC_DRAFT29: u32 = 0xff00001d;
const SALT_V1: [u8; 20] = [
    0x38, 0x76, 0x2c, 0xf7, 0xf5, 0x59, 0x34, 0xb3, 0x4d, 0x17, 0x9a, 0xe6, 0xa4, 0xc8, 0x0c, 0xad,
    0xcc, 0xbb, 0x7f, 0x0a,
];
const SALT_V2: [u8; 20] = [
    0x0d, 0xed, 0xe3, 0xde, 0xf7, 0x00, 0xa6, 0xdb, 0x81, 0x93, 0x81, 0xbe, 0x6e, 0x26, 0x9d, 0xcb,
    0xf9, 0xbd, 0x2e, 0xd9,
];
const SALT_DRAFT29: [u8; 20] = [
    0xaf, 0xbf, 0xec, 0x28, 0x99, 0x93, 0xd2, 0x4c, 0x9e, 0x97, 0x86, 0xf1, 0x9c, 0x61, 0x11, 0xe0,
    0x43, 0x90, 0xa8, 0x99,
];

struct Len(usize);
impl hkdf::KeyType for Len {
    fn len(&self) -> usize {
        self.0
    }
}

fn expand_label(prk: &hkdf::Prk, label: &str, len: usize) -> Option<Vec<u8>> {
    let full = format!("tls13 {label}");
    let mut info = Vec::with_capacity(4 + full.len());
    info.extend_from_slice(&(len as u16).to_be_bytes());
    info.push(full.len() as u8);
    info.extend_from_slice(full.as_bytes());
    info.push(0);
    let parts = [info.as_slice()];
    let okm = prk.expand(&parts, Len(len)).ok()?;
    let mut out = vec![0u8; len];
    okm.fill(&mut out).ok()?;
    Some(out)
}

fn varint(b: &[u8], at: &mut usize) -> Option<u64> {
    let first = *b.get(*at)?;
    let len = 1usize << (first >> 6);
    let bytes = b.get(*at..*at + len)?;
    let mut v = (first & 0x3f) as u64;
    for x in &bytes[1..] {
        v = (v << 8) | *x as u64;
    }
    *at += len;
    Some(v)
}

/// Decrypt the client Initial packets of one datagram; returns the CRYPTO frames (offset, data).
fn quic_initial_crypto(datagram: &[u8], out: &mut Vec<(u64, Vec<u8>)>) -> Result<(), bool> {
    // Err(true) = not quic at all, Err(false) = quic but undecodable
    let mut rest = datagram;
    let mut any = false;
    while rest.len() > 7 && rest[0] & 0x80 != 0 {
        let b0 = rest[0];
        if b0 & 0x40 == 0 {
            return if any { Ok(()) } else { Err(true) };
        }
        let version = u32::from_be_bytes(rest[1..5].try_into().unwrap());
        let (salt, prefix, initial_type) = match version {
            QUIC_V1 => (&SALT_V1, "quic", 0u8),
            QUIC_DRAFT29 => (&SALT_DRAFT29, "quic", 0u8),
            QUIC_V2 => (&SALT_V2, "quicv2", 1u8),
            _ => return if any { Ok(()) } else { Err(true) },
        };
        let ptype = (b0 >> 4) & 3;
        let mut at = 5;
        let dcid_len = *rest.get(at).ok_or(false)? as usize;
        at += 1;
        let dcid = rest.get(at..at + dcid_len).ok_or(false)?.to_vec();
        at += dcid_len;
        let scid_len = *rest.get(at).ok_or(false)? as usize;
        at += 1 + scid_len;
        if ptype != initial_type {
            // a 0-RTT or other long packet: skip it by its length if we can
            if ptype == 3 && version != QUIC_V2 || ptype == 0 && version == QUIC_V2 {
                return Ok(()); // retry: no length
            }
            let len = varint(rest, &mut at).ok_or(false)? as usize;
            if rest.len() < at + len {
                return Ok(());
            }
            rest = &rest[at + len..];
            continue;
        }
        let token_len = varint(rest, &mut at).ok_or(false)? as usize;
        at += token_len;
        let length = varint(rest, &mut at).ok_or(false)? as usize;
        let pn_offset = at;
        if rest.len() < pn_offset + length || length < 20 {
            return Err(false);
        }
        let packet = &rest[..pn_offset + length];

        let initial = hkdf::Salt::new(hkdf::HKDF_SHA256, salt).extract(&dcid);
        let client = expand_label(&initial, "client in", 32).ok_or(false)?;
        let client = hkdf::Prk::new_less_safe(hkdf::HKDF_SHA256, &client);
        let key = expand_label(&client, &format!("{prefix} key"), 16).ok_or(false)?;
        let iv = expand_label(&client, &format!("{prefix} iv"), 12).ok_or(false)?;
        let hp = expand_label(&client, &format!("{prefix} hp"), 16).ok_or(false)?;

        let sample = packet.get(pn_offset + 4..pn_offset + 20).ok_or(false)?;
        let hpk = aead::quic::HeaderProtectionKey::new(&aead::quic::AES_128, &hp).map_err(|_| false)?;
        let mask = hpk.new_mask(sample).map_err(|_| false)?;
        let mut header = packet[..pn_offset + 4].to_vec();
        header[0] ^= mask[0] & 0x0f;
        let pn_len = (header[0] & 3) as usize + 1;
        let mut pn: u64 = 0;
        for i in 0..pn_len {
            header[pn_offset + i] ^= mask[1 + i];
            pn = (pn << 8) | header[pn_offset + i] as u64;
        }
        header.truncate(pn_offset + pn_len);
        let mut nonce = [0u8; 12];
        nonce.copy_from_slice(&iv);
        for (i, b) in pn.to_be_bytes().iter().enumerate() {
            nonce[4 + i] ^= b;
        }
        let mut payload = packet[pn_offset + pn_len..].to_vec();
        let k = aead::LessSafeKey::new(aead::UnboundKey::new(&aead::AES_128_GCM, &key).map_err(|_| false)?);
        let plain = k
            .open_in_place(aead::Nonce::assume_unique_for_key(nonce), aead::Aad::from(&header), &mut payload)
            .map_err(|_| false)?;
        parse_frames(plain, out);
        any = true;
        rest = &rest[pn_offset + length..];
    }
    if any {
        Ok(())
    } else {
        Err(true)
    }
}

fn parse_frames(p: &[u8], out: &mut Vec<(u64, Vec<u8>)>) {
    let mut at = 0;
    while at < p.len() {
        let Some(ty) = varint(p, &mut at) else { return };
        match ty {
            0x00 | 0x01 => {}
            0x02 | 0x03 => {
                let (Some(_), Some(_), Some(count), Some(_)) = (
                    varint(p, &mut at),
                    varint(p, &mut at),
                    varint(p, &mut at),
                    varint(p, &mut at),
                ) else {
                    return;
                };
                for _ in 0..count.min(256) {
                    if varint(p, &mut at).is_none() || varint(p, &mut at).is_none() {
                        return;
                    }
                }
                if ty == 0x03 {
                    for _ in 0..3 {
                        if varint(p, &mut at).is_none() {
                            return;
                        }
                    }
                }
            }
            0x06 => {
                let (Some(off), Some(len)) = (varint(p, &mut at), varint(p, &mut at)) else {
                    return;
                };
                let Some(data) = p.get(at..at + len as usize) else { return };
                out.push((off, data.to_vec()));
                at += len as usize;
            }
            _ => return,
        }
    }
}

fn quic(datagrams: &[Vec<u8>]) -> Outcome {
    let mut frames = Vec::new();
    for (i, d) in datagrams.iter().enumerate() {
        match quic_initial_crypto(d, &mut frames) {
            Ok(()) => {}
            Err(true) if i == 0 => return Outcome::NotFound,
            Err(_) => {}
        }
    }
    if frames.is_empty() {
        return Outcome::NotFound;
    }
    // reassemble from offset 0
    frames.sort_by_key(|(o, _)| *o);
    let mut stream: Vec<u8> = Vec::new();
    loop {
        let mut progressed = false;
        for (off, data) in &frames {
            let off = *off as usize;
            let end = off + data.len();
            if off <= stream.len() && end > stream.len() {
                stream.extend_from_slice(&data[stream.len() - off..]);
                progressed = true;
            }
        }
        if !progressed {
            break;
        }
    }
    if stream.len() < 4 {
        return Outcome::NeedMore;
    }
    if stream[0] != 0x01 {
        return Outcome::NotFound;
    }
    let hello_len = be24(&stream, 1).unwrap_or(0);
    if stream.len() < 4 + hello_len {
        return Outcome::NeedMore;
    }
    found("quic", client_hello_sni(&stream[..4 + hello_len]))
}

#[cfg(test)]
mod tests {
    use super::*;

    pub fn client_hello(name: &str) -> Vec<u8> {
        // a minimal TLS 1.2-style ClientHello carrying one server_name
        let mut sni = Vec::new();
        sni.push(0);
        sni.extend_from_slice(&(name.len() as u16).to_be_bytes());
        sni.extend_from_slice(name.as_bytes());
        let mut list = (sni.len() as u16).to_be_bytes().to_vec();
        list.extend_from_slice(&sni);
        let mut ext = vec![0, 0];
        ext.extend_from_slice(&(list.len() as u16).to_be_bytes());
        ext.extend_from_slice(&list);
        let mut body = vec![0x03, 0x03];
        body.extend_from_slice(&[7u8; 32]);
        body.push(0);
        body.extend_from_slice(&[0, 2, 0x13, 0x01]);
        body.extend_from_slice(&[1, 0]);
        body.extend_from_slice(&(ext.len() as u16).to_be_bytes());
        body.extend_from_slice(&ext);
        let mut hs = vec![1];
        hs.extend_from_slice(&(body.len() as u32).to_be_bytes()[1..]);
        hs.extend_from_slice(&body);
        hs
    }

    fn record(hs: &[u8]) -> Vec<u8> {
        let mut r = vec![0x16, 0x03, 0x01];
        r.extend_from_slice(&(hs.len() as u16).to_be_bytes());
        r.extend_from_slice(hs);
        r
    }

    #[test]
    fn tls_sni_and_partial_reads() {
        let rec = record(&client_hello("www.example.com"));
        assert_eq!(
            stream(&rec, Sniffer::STREAM),
            Outcome::Found(Sniffed { protocol: "tls", domain: Some("www.example.com".into()), client: None })
        );
        assert_eq!(stream(&rec[..20], Sniffer::STREAM), Outcome::NeedMore);
    }

    #[test]
    fn a_client_hello_split_over_two_records_is_joined() {
        let hs = client_hello("split.example.org");
        let (a, b) = hs.split_at(20);
        let mut buf = record(a);
        buf.extend_from_slice(&record(b));
        match stream(&buf, &[Sniffer::Tls]) {
            Outcome::Found(f) => assert_eq!(f.domain.as_deref(), Some("split.example.org")),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn http_host_header() {
        let req = b"GET / HTTP/1.1\r\nHost: Example.COM:8080\r\nAccept: */*\r\n\r\n";
        match stream(req, Sniffer::STREAM) {
            Outcome::Found(f) => {
                assert_eq!(f.protocol, "http");
                assert_eq!(f.domain.as_deref(), Some("example.com"));
            }
            o => panic!("{o:?}"),
        }
        assert_eq!(stream(b"GE", Sniffer::STREAM), Outcome::NeedMore);
        assert_eq!(stream(b"\x00\x01garbage-bytes-here", &[Sniffer::Http, Sniffer::Tls]), Outcome::NotFound);
    }

    #[test]
    fn ssh_rdp_bittorrent_dns_stream() {
        match stream(b"SSH-2.0-OpenSSH_9.6\r\n", Sniffer::STREAM) {
            Outcome::Found(f) => {
                assert_eq!(f.protocol, "ssh");
                assert_eq!(f.client.as_deref(), Some("OpenSSH_9.6"));
            }
            o => panic!("{o:?}"),
        }
        let rdp_req = [0x03, 0x00, 0x00, 0x13, 0x0e, 0xe0, 0, 0, 0, 0, 0, 0x01, 0, 8, 0, 3, 0, 0, 0];
        assert!(matches!(stream(&rdp_req, Sniffer::STREAM), Outcome::Found(Sniffed { protocol: "rdp", .. })));
        let bt = b"\x13BitTorrent protocol\0\0\0\0\0\0\0\0";
        assert!(matches!(stream(bt, Sniffer::STREAM), Outcome::Found(Sniffed { protocol: "bittorrent", .. })));
        let mut q = vec![0u8, 29];
        q.extend_from_slice(&dns_query());
        assert!(matches!(stream(&q, Sniffer::STREAM), Outcome::Found(Sniffed { protocol: "dns", .. })));
    }

    fn dns_query() -> Vec<u8> {
        let mut q = vec![0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0];
        q.extend_from_slice(b"\x07example\x03com\x00");
        q.extend_from_slice(&[0, 1, 0, 1]);
        q
    }

    #[test]
    fn udp_sniffers() {
        assert!(matches!(packets(&[dns_query()], Sniffer::PACKET), Outcome::Found(Sniffed { protocol: "dns", .. })));
        let mut stun_pkt = vec![0x00, 0x01, 0x00, 0x00, 0x21, 0x12, 0xA4, 0x42];
        stun_pkt.extend_from_slice(&[9u8; 12]);
        assert!(matches!(packets(&[stun_pkt], Sniffer::PACKET), Outcome::Found(Sniffed { protocol: "stun", .. })));
        let mut ntp_pkt = vec![0u8; 48];
        ntp_pkt[0] = 0x23; // v4 client
        assert!(matches!(packets(&[ntp_pkt], Sniffer::PACKET), Outcome::Found(Sniffed { protocol: "ntp", .. })));
        let mut dtls_pkt = vec![22, 0xfe, 0xfd];
        dtls_pkt.extend_from_slice(&[0u8; 20]);
        assert!(matches!(packets(&[dtls_pkt], Sniffer::PACKET), Outcome::Found(Sniffed { protocol: "dtls", .. })));
        let mut tracker = 0x41727101980u64.to_be_bytes().to_vec();
        tracker.extend_from_slice(&[0, 0, 0, 0, 1, 2, 3, 4]);
        assert!(matches!(packets(&[tracker], Sniffer::PACKET), Outcome::Found(Sniffed { protocol: "bittorrent", .. })));
        assert_eq!(packets(&[b"random junk that is not anything".to_vec()], Sniffer::PACKET), Outcome::NotFound);
    }

    /// RFC 9001 appendix A.2: the sample client Initial packet, whose ClientHello names
    /// example.com.
    pub fn rfc9001_client_initial() -> Vec<u8> {
        let hex = "c000000001088394c8f03e5157080000449e7b9aec34d1b1c98dd7689fb8ec11d242b123dc9bd8bab936b47d92ec356c\
0bab7df5976d27cd449f63300099f3991c260ec4c60d17b31f8429157bb35a1282a643a8d2262cad67500cadb8e7378c\
8eb7539ec4d4905fed1bee1fc8aafba17c750e2c7ace01e6005f80fcb7df621230c83711b39343fa028cea7f7fb5ff89\
eac2308249a02252155e2347b63d58c5457afd84d05dfffdb20392844ae812154682e9cf012f9021a6f0be17ddd0c208\
4dce25ff9b06cde535d0f920a2db1bf362c23e596d11a4f5a6cf3948838a3aec4e15daf8500a6ef69ec4e3feb6b1d98e\
610ac8b7ec3faf6ad760b7bad1db4ba3485e8a94dc250ae3fdb41ed15fb6a8e5eba0fc3dd60bc8e30c5c4287e53805db\
059ae0648db2f64264ed5e39be2e20d82df566da8dd5998ccabdae053060ae6c7b4378e846d29f37ed7b4ea9ec5d82e7\
961b7f25a9323851f681d582363aa5f89937f5a67258bf63ad6f1a0b1d96dbd4faddfcefc5266ba6611722395c906556\
be52afe3f565636ad1b17d508b73d8743eeb524be22b3dcbc2c7468d54119c7468449a13d8e3b95811a198f3491de3e7\
fe942b330407abf82a4ed7c1b311663ac69890f4157015853d91e923037c227a33cdd5ec281ca3f79c44546b9d90ca00\
f064c99e3dd97911d39fe9c5d0b23a229a234cb36186c4819e8b9c5927726632291d6a418211cc2962e20fe47feb3edf\
330f2c603a9d48c0fcb5699dbfe5896425c5bac4aee82e57a85aaf4e2513e4f05796b07ba2ee47d80506f8d2c25e50fd\
14de71e6c418559302f939b0e1abd576f279c4b2e0feb85c1f28ff18f58891ffef132eef2fa09346aee33c28eb130ff2\
8f5b766953334113211996d20011a198e3fc433f9f2541010ae17c1bf202580f6047472fb36857fe843b19f5984009dd\
c324044e847a4f4a0ab34f719595de37252d6235365e9b84392b061085349d73203a4a13e96f5432ec0fd4a1ee65accd\
d5e3904df54c1da510b0ff20dcc0c77fcb2c0e0eb605cb0504db87632cf3d8b4dae6e705769d1de354270123cb11450e\
fc60ac47683d7b8d0f811365565fd98c4c8eb936bcab8d069fc33bd801b03adea2e1fbc5aa463d08ca19896d2bf59a07\
1b851e6c239052172f296bfb5e72404790a2181014f3b94a4e97d117b438130368cc39dbb2d198065ae3986547926cd2\
162f40a29f0c3c8745c0f50fba3852e566d44575c29d39a03f0cda721984b6f440591f355e12d439ff150aab7613499d\
bd49adabc8676eef023b15b65bfc5ca06948109f23f350db82123535eb8a7433bdabcb909271a6ecbcb58b936a88cd4e\
8f2e6ff5800175f113253d8fa9ca8885c2f552e657dc603f252e1a8e308f76f0be79e2fb8f5d5fbbe2e30ecadd220723\
c8c0aea8078cdfcb3868263ff8f0940054da48781893a7e49ad5aff4af300cd804a6b6279ab3ff3afb64491c85194aab\
760d58a606654f9f4400e8b38591356fbf6425aca26dc85244259ff2b19c41b9f96f3ca9ec1dde434da7d2d392b905dd\
f3d1f9af93d1af5950bd493f5aa731b4056df31bd267b6b90a079831aaf579be0a39013137aac6d404f518cfd4684064\
7e78bfe706ca4cf5e9c5453e9f7cfd2b8b4c8d169a44e55c88d4a9a7f9474241e221af44860018ab0856972e194cd934";
        let hex: String = hex.chars().filter(|c| c.is_ascii_hexdigit()).collect();
        (0..hex.len()).step_by(2).map(|i| u8::from_str_radix(&hex[i..i + 2], 16).unwrap()).collect()
    }

    #[test]
    fn the_rfc9001_initial_packet_yields_its_server_name() {
        let pkt = rfc9001_client_initial();
        match packets(std::slice::from_ref(&pkt), Sniffer::PACKET) {
            Outcome::Found(f) => {
                assert_eq!(f.protocol, "quic");
                assert_eq!(f.domain.as_deref(), Some("example.com"));
            }
            o => panic!("{o:?}"),
        }
        // a corrupted packet is still QUIC-shaped but cannot be read
        let mut bad = pkt;
        let n = bad.len();
        bad[n - 30] ^= 0xff;
        assert_ne!(packets(&[bad], &[Sniffer::Quic]), Outcome::Found(Sniffed { protocol: "quic", domain: Some("example.com".into()), client: None }));
    }

    #[test]
    fn skip_ports_are_the_server_first_ones() {
        assert!(skip_port(25) && skip_port(993) && !skip_port(443));
    }
}
