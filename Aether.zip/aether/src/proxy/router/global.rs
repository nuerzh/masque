use super::*;

/// Replaced by each run's `init`, so a library that starts the core again routes by the
/// config of the new run.
pub(super) static ROUTER: parking_lot::RwLock<Option<Arc<Router>>> = parking_lot::RwLock::new(None);

/// The router every inbound goes through. With nothing configured every connection takes
/// `final`, the tunnel of the running mode (`proxy`), which is what Aether did before routing.
pub fn router() -> Option<Arc<Router>> {
    if let Some(r) = ROUTER.read().as_ref() {
        return Some(r.clone());
    }
    let loaded = match load_from_env() {
        Ok(r) => r,
        Err(e) => {
            log::error!("[route] {e}");
            None
        }
    };
    Some(ROUTER.write().get_or_insert_with(|| Arc::new(loaded.unwrap_or_else(default_router))).clone())
}

/// The router of a run with no route config: no rules, `final` = `proxy`.
pub fn default_router() -> Router {
    build(
        &Value::Object(Default::default()),
        LoadOptions {
            base_dir: PathBuf::new(),
            cache_dir: ruleset::default_cache_dir(),
            caps: Caps::ALL,
        },
    )
    .expect("the default route")
    .router
}

/// Load the routed config (`config_value`). Errors in the config stop Aether at start (call
/// `init`) rather than routing in some unintended way.
pub fn init() -> crate::error::Result<()> {
    let loaded = load_from_env().map_err(crate::error::AetherError::Other)?;
    *ROUTER.write() = Some(Arc::new(loaded.unwrap_or_else(default_router)));
    if let Some(r) = router() {
        log::info!(
            "[route] routing: {} rules, {} rule sets, final {}",
            r.rule_count(),
            r.sets.len(),
            r.final_tag
        );
        if r.auto_sniff {
            log::info!("[route] domain rules are present without a sniff action; sniffing IP connections first");
        }
    }
    Ok(())
}

/// The routed config of this run (the TOML config file's `inbounds`, `outbounds`, `route` and
/// `dns`, or those of a --route-config TOML file), as json, with the directory relative paths
/// in it are taken from. Its `route` is the router's; its `inbounds` are read by
/// `proxy::inbound`.
pub fn config_value() -> Result<(Option<Value>, PathBuf), String> {
    crate::config::file::routing()
}

pub(super) static CONFIGURED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// Whether a routed config (the config file's tables, or --route-config) was loaded.
pub fn configured() -> bool {
    CONFIGURED.load(std::sync::atomic::Ordering::Relaxed)
}

pub(super) fn load_from_env() -> Result<Option<Router>, String> {
    refuse_removed_lists()?;
    let (config, base) = config_value()?;
    CONFIGURED.store(config.is_some(), std::sync::atomic::Ordering::Relaxed);
    let Some(config) = config else { return Ok(None) };
    let spec = build(
        &config,
        LoadOptions {
            base_dir: base,
            cache_dir: ruleset::default_cache_dir(),
            caps: Caps::from_env()?,
        },
    )?;
    for w in &spec.warnings {
        log::warn!("[route] {w}");
    }
    Ok(Some(spec.router))
}

/// The variables of the removed --route-block / --route-direct / --routes lists: a run that
/// still sets one would otherwise route differently from what its owner expects.
pub(super) const REMOVED_LIST_VARS: [(&str, &str); 3] = [
    ("AETHER_ROUTE_BLOCK", "--route-block"),
    ("AETHER_ROUTE_DIRECT", "--route-direct"),
    ("AETHER_ROUTES_FILE", "--routes"),
];

pub(crate) fn removed_lists_message(what: &str) -> String {
    format!(
        "{what} was removed: write these as rules in the route mapping of the YAML config file (or \
         of the route-config file), e.g.\nroute:\n  rules:\n    - {{ domain_suffix: [ads.example], action: reject }}\n    \
         - {{ ip_is_private: true, outbound: direct }}"
    )
}

pub(super) fn refuse_removed_lists() -> Result<(), String> {
    for (var, flag) in REMOVED_LIST_VARS {
        if crate::config::settings::var(var).is_ok_and(|v| !v.trim().is_empty()) {
            return Err(removed_lists_message(&format!("{var} ({flag})")));
        }
    }
    Ok(())
}
