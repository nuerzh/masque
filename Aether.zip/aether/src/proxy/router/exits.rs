//! Where traffic can leave: the WARP tunnel stack, or the sunnyquic client of --sunny (direct
//! by default, inside WARP MASQUE with `detour = "warp"`).
//! Tunnels come and go as
//! Aether reconnects; this keeps the current one for the router, the rule-set downloader and
//! the sunny proxy (whose client outlives each outer tunnel).

use std::sync::Arc;

use parking_lot::RwLock;
use tokio::sync::watch;

use crate::transport::warp::netstack::StackHandle;

struct Exits {
    stack: RwLock<Option<StackHandle>>,
    sunny: RwLock<Option<Arc<dyn SunnyExit>>>,
    changed: watch::Sender<u64>,
}

fn exits() -> &'static Exits {
    static E: std::sync::OnceLock<Exits> = std::sync::OnceLock::new();
    E.get_or_init(|| Exits {
        stack: RwLock::new(None),
        sunny: RwLock::new(None),
        changed: watch::channel(0).0,
    })
}

fn bump() {
    exits().changed.send_modify(|v| *v += 1);
}

/// The WARP tunnel stack now carrying traffic.
pub fn set_stack(stack: &StackHandle) {
    *exits().stack.write() = Some(stack.clone());
    WARP_EVER_UP.store(true, Ordering::Relaxed);
    bump();
}

pub fn stack() -> Option<StackHandle> {
    exits().stack.read().clone()
}

/// Publish the stack of a tunnel that just came up, for as long as the guard lives: the WARP
/// outbounds use it until the tunnel ends and the guard takes it back.
pub fn publish_stack(stack: &StackHandle) -> Published {
    set_stack(stack);
    Published(stack.clone())
}

pub struct Published(StackHandle);

impl Drop for Published {
    fn drop(&mut self) {
        let mut current = exits().stack.write();
        if current.as_ref().is_some_and(|s| s.same(&self.0)) {
            *current = None;
            drop(current);
            bump();
        }
    }
}

/// Whether this run brings a WARP tunnel up (a connection may wait for it while it connects).
/// Turning it on keeps what an earlier call of this run learned (a tunnel already came up);
/// `begin_run` starts over.
pub fn set_warp_expected(on: bool) {
    let was = WARP_EXPECTED.swap(on, Ordering::Relaxed);
    if on != was {
        WARP_EVER_UP.store(false, Ordering::Relaxed);
        WAIT_ANNOUNCED.store(false, Ordering::Relaxed);
    }
}

/// The core decided, before any inbound serves, whether this run brings the WARP tunnel up.
/// Nothing an earlier run of the library left (a tunnel that was up) counts for this one.
/// `sunny_over_warp`: the --sunny client of this run rides WARP (`detour = "warp"`); by default
/// it goes direct and never waits for the tunnel.
pub fn begin_run(warp: bool, sunny_over_warp: bool) {
    SUNNY_OVER_WARP.store(sunny_over_warp, Ordering::Relaxed);
    *exits().sunny.write() = None;
    WARP_EXPECTED.store(warp, Ordering::Relaxed);
    WARP_EVER_UP.store(false, Ordering::Relaxed);
    WAIT_ANNOUNCED.store(false, Ordering::Relaxed);
}

pub fn warp_expected() -> bool {
    WARP_EXPECTED.load(Ordering::Relaxed)
}

use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

static WARP_EXPECTED: AtomicBool = AtomicBool::new(false);
/// A tunnel of this run came up at least once: from then on a missing stack is a reconnect.
static WARP_EVER_UP: AtomicBool = AtomicBool::new(false);
static WAIT_ANNOUNCED: AtomicBool = AtomicBool::new(false);
static SUNNY_OVER_WARP: AtomicBool = AtomicBool::new(false);

/// Whether the --sunny client of this run rides WARP ([sunny] `detour = "warp"`).
pub fn sunny_over_warp() -> bool {
    SUNNY_OVER_WARP.load(Ordering::Relaxed)
}

/// How long a connection to an outbound that rides WARP waits for the first tunnel of the run:
/// the inbounds serve from the start, while the gateway scan and the
/// handshake may still take a while.
pub const WARP_START_WAIT: Duration = Duration::from_secs(30);
/// How long it waits while a tunnel that was up reconnects.
pub const WARP_RECONNECT_WAIT: Duration = Duration::from_secs(5);

/// How long a connection waits for the WARP tunnel now; `None` when this run has none.
pub fn warp_wait() -> Option<Duration> {
    if !warp_expected() {
        return None;
    }
    Some(if WARP_EVER_UP.load(Ordering::Relaxed) { WARP_RECONNECT_WAIT } else { WARP_START_WAIT })
}

/// The WARP stack, waiting for it as `warp_wait` says. `who` names the outbound for the log
/// and the error.
pub async fn warp_stack(who: &str) -> Result<StackHandle, String> {
    wait_exit(stack, warp_wait(), who).await
}

/// How long a connection to `sunny` waits for the --sunny client when it goes direct: the
/// client is made as the run starts (after its settings are read, which may ask on the
/// terminal), not after any tunnel.
pub const SUNNY_START_WAIT: Duration = Duration::from_secs(30);

/// The sunnyquic client of --sunny. With `detour = "warp"` it rides WARP (it is up once a
/// tunnel is and the server answered) and is waited for as the WARP stack is; going direct (the
/// default) it is waited for only while the run makes it, never for a tunnel.
pub async fn sunny_exit(who: &str) -> Result<Arc<dyn SunnyExit>, String> {
    if sunny_over_warp() {
        return wait_exit(sunny, warp_wait(), who).await;
    }
    wait_direct_sunny(sunny, SUNNY_START_WAIT, who).await
}

/// `get` now, or once the run made the direct --sunny client, within `wait`.
pub(crate) async fn wait_direct_sunny<T>(get: impl Fn() -> Option<T>, wait: Duration, who: &str) -> Result<T, String> {
    if let Some(found) = get() {
        return Ok(found);
    }
    log::debug!("[route] {who}: waiting for the sunny client (at most {wait:?})");
    let _ = tokio::time::timeout(wait, wait_for(|| get().is_some())).await;
    get().ok_or_else(|| {
        format!(
            "{who}: the sunny client was not made within {wait:?} (its settings are still being asked for, or reading \
             them failed); it goes direct, needs no WARP, and never falls back to another outbound"
        )
    })
}

/// `get` now, or once it gives something within `wait` (`None`: this run has no WARP tunnel).
pub(crate) async fn wait_exit<T>(get: impl Fn() -> Option<T>, wait: Option<Duration>, who: &str) -> Result<T, String> {
    if let Some(found) = get() {
        return Ok(found);
    }
    let Some(wait) = wait else {
        return Err(format!(
            "{who} rides the WARP tunnel, and this run has no WARP tunnel (see warp-tunnel); it never falls back to another outbound"
        ));
    };
    let first = !WARP_EVER_UP.load(Ordering::Relaxed);
    if first && !WAIT_ANNOUNCED.swap(true, Ordering::Relaxed) {
        log::info!(
            "[route] the WARP tunnel is not up yet: connections to outbounds that ride it wait for it (at most {}s each); the other outbounds go now",
            wait.as_secs()
        );
    }
    log::debug!("[route] {who}: waiting for the WARP tunnel (at most {wait:?})");
    let _ = tokio::time::timeout(wait, wait_for(|| get().is_some())).await;
    get().ok_or_else(|| {
        if first {
            format!(
                "{who}: the WARP tunnel did not come up within {wait:?} (still choosing the transport, scanning or connecting); \
                 it never falls back to another outbound"
            )
        } else {
            format!(
                "{who}: the WARP tunnel is reconnecting and was not back within {wait:?}; it never falls back to another outbound"
            )
        }
    })
}

pub use crate::proxy::outbound::sunnyquic::{BoxFuture, SunnyExit};
#[cfg(test)]
pub use crate::proxy::outbound::sunnyquic::SunnyUdp;

/// The sunnyquic client of --sunny.
#[cfg(any(feature = "sunny", test))]
pub fn set_sunny(exit: Arc<dyn SunnyExit>) {
    *exits().sunny.write() = Some(exit);
    bump();
}

pub fn sunny() -> Option<Arc<dyn SunnyExit>> {
    exits().sunny.read().clone()
}

/// Wait until `ready` says yes, re-checking each time an exit changes.
pub async fn wait_for(ready: impl Fn() -> bool) {
    let mut rx = exits().changed.subscribe();
    loop {
        if ready() {
            return;
        }
        if rx.changed().await.is_err() {
            return;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A stand-in for an exit, so these tests never touch the run's own.
    fn slot() -> Arc<RwLock<Option<u32>>> {
        Arc::new(RwLock::new(None))
    }

    #[tokio::test]
    async fn an_exit_that_is_up_is_used_at_once() {
        let s = slot();
        *s.write() = Some(7);
        let got = wait_exit(|| *s.read(), None, "outbound warp").await;
        assert_eq!(got, Ok(7));
    }

    #[tokio::test]
    async fn a_run_without_warp_fails_at_once_without_waiting() {
        let s = slot();
        let started = std::time::Instant::now();
        let e = wait_exit(|| *s.read(), None, "outbound warp").await.unwrap_err();
        assert!(started.elapsed() < Duration::from_millis(100));
        assert!(e.contains("no WARP tunnel") && e.contains("never falls back"), "{e}");
    }

    /// Before the tunnel is up a connection waits; once it is published, it goes on.
    #[tokio::test]
    async fn a_warp_outbound_waits_for_the_tunnel_and_goes_on_once_it_is_up() {
        let s = slot();
        let waiter = {
            let s = s.clone();
            tokio::spawn(async move { wait_exit(|| *s.read(), Some(Duration::from_secs(10)), "outbound warp").await })
        };
        tokio::time::sleep(Duration::from_millis(200)).await;
        assert!(!waiter.is_finished(), "it did not wait");
        *s.write() = Some(3);
        bump();
        let got = tokio::time::timeout(Duration::from_secs(2), waiter).await.expect("it went on").unwrap();
        assert_eq!(got, Ok(3));
    }

    /// A tunnel that does not come up in time is an error naming the outbound and the wait.
    #[tokio::test]
    async fn a_warp_outbound_gives_up_after_its_wait() {
        let s = slot();
        let started = std::time::Instant::now();
        let e = wait_exit(|| *s.read(), Some(Duration::from_millis(150)), "outbound warp-local").await.unwrap_err();
        assert!(started.elapsed() >= Duration::from_millis(150));
        assert!(started.elapsed() < Duration::from_secs(2));
        assert!(e.starts_with("outbound warp-local: the WARP tunnel"), "{e}");
        assert!(e.contains("within 150ms") && e.contains("never falls back"), "{e}");
    }

    /// A direct --sunny client is waited for while the run makes it, with its own error that
    /// says it needs no WARP.
    #[tokio::test]
    async fn a_direct_sunny_client_is_waited_for_only_while_it_is_made() {
        let s = slot();
        let e = wait_direct_sunny(|| *s.read(), Duration::from_millis(100), "outbound sunny").await.unwrap_err();
        assert!(e.starts_with("outbound sunny: the sunny client was not made within 100ms"), "{e}");
        assert!(e.contains("needs no WARP") && !e.contains("WARP tunnel"), "{e}");
        let waiter = {
            let s = s.clone();
            tokio::spawn(async move { wait_direct_sunny(|| *s.read(), Duration::from_secs(10), "outbound sunny").await })
        };
        tokio::time::sleep(Duration::from_millis(100)).await;
        assert!(!waiter.is_finished());
        *s.write() = Some(9);
        bump();
        let got = tokio::time::timeout(Duration::from_secs(2), waiter).await.expect("it went on").unwrap();
        assert_eq!(got, Ok(9));
    }

    #[test]
    fn the_first_tunnel_gets_a_longer_wait_than_a_reconnect() {
        assert!(WARP_START_WAIT > WARP_RECONNECT_WAIT);
        assert_eq!(WARP_START_WAIT, Duration::from_secs(30));
    }
}
