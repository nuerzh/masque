//! Rule sets: `inline`, `local` and `remote`, in `source` (json) or `binary` (.srs) format.
//!
//! A remote set is fetched through its `download_detour` (default: the tunnel, so GitHub is
//! reachable where it is blocked directly), kept in the cache directory together with its
//! ETag, reused from there on the next start (so routing works offline), and refreshed every
//! `update_interval` (default 1d) in the background. A new version is parsed in full before it
//! replaces the old one, and the cache file is written to a temporary name and renamed, so a
//! bad download or a crash mid-write never leaves a broken set behind.

use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use parking_lot::RwLock;
use serde_json::Value;

use super::rule::{parse_rule, DefaultRule, ParseEnv, Rule};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Format {
    /// sing-box's source format, json (what remote rule sets are published as)
    Source,
    /// the same `version` and `rules`, written in YAML (a local rule set of one's own)
    Yaml,
    Binary,
}

impl Format {
    fn ext(self) -> &'static str {
        match self {
            Format::Source => "json",
            Format::Yaml => "yaml",
            Format::Binary => "srs",
        }
    }
}

#[derive(Debug, Clone)]
pub enum Kind {
    Inline,
    Local {
        path: PathBuf,
    },
    Remote {
        url: String,
        /// An outbound tag; None means the default (the tunnel).
        detour: Option<String>,
        interval: Duration,
        initial_path: Option<PathBuf>,
    },
}

#[derive(Debug, Default)]
pub struct CompiledSet {
    pub rules: Vec<Rule>,
    #[cfg_attr(not(test), expect(dead_code, reason = "checked by the tests of the parsers"))]
    pub version: u8,
}

impl CompiledSet {
    /// sing-box merges a set into the outer rule's groups when it is one plain rule.
    pub fn mergeable(&self) -> Option<&DefaultRule> {
        if self.rules.len() != 1 {
            return None;
        }
        match &self.rules[0] {
            Rule::Default(d) if !d.invert && d.rule_set.is_none() => Some(d),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub struct Slot {
    pub tag: String,
    pub kind: Kind,
    pub format: Format,
    current: RwLock<Arc<CompiledSet>>,
    loaded: AtomicBool,
    process: AtomicBool,
}

impl Slot {
    pub fn new(tag: String, kind: Kind, format: Format) -> Arc<Slot> {
        Arc::new(Slot {
            tag,
            kind,
            format,
            current: RwLock::new(Arc::new(CompiledSet::default())),
            loaded: AtomicBool::new(false),
            process: AtomicBool::new(false),
        })
    }

    pub fn current(&self) -> Arc<CompiledSet> {
        self.current.read().clone()
    }

    pub fn is_loaded(&self) -> bool {
        self.loaded.load(Ordering::Acquire)
    }

    /// Whether the installed version has process conditions.
    pub fn needs_process(&self) -> bool {
        self.process.load(Ordering::Acquire)
    }

    pub fn install(&self, set: CompiledSet) {
        self.process.store(set.rules.iter().any(Rule::needs_process), Ordering::Release);
        *self.current.write() = Arc::new(set);
        self.loaded.store(true, Ordering::Release);
    }
}

pub fn guess_format(path_or_url: &str) -> Option<Format> {
    let base = path_or_url.split(['?', '#']).next().unwrap_or("");
    if base.ends_with(".srs") {
        Some(Format::Binary)
    } else if base.ends_with(".json") {
        Some(Format::Source)
    } else if base.ends_with(".yaml") || base.ends_with(".yml") || base.ends_with(".toml") {
        // a .toml rule set of an earlier build is converted to .yaml where it is loaded
        Some(Format::Yaml)
    } else {
        None
    }
}

/// Parse a rule set in any of the formats.
pub fn compile(data: &[u8], format: Format, warn: &mut dyn FnMut(String)) -> Result<CompiledSet, String> {
    match format {
        Format::Binary => {
            let (version, rules) = super::srs::decode(data).map_err(|e| e.to_string())?;
            Ok(CompiledSet { rules, version })
        }
        Format::Source => {
            let v: Value = serde_json::from_slice(data).map_err(|e| format!("rule-set json: {e}"))?;
            compile_source(&v, warn)
        }
        Format::Yaml => {
            let text = std::str::from_utf8(data).map_err(|e| format!("rule-set yaml: {e}"))?;
            let t = crate::config::file::parse_table(text).map_err(|e| format!("rule-set {e}"))?;
            compile_source(&crate::config::file::table_to_json(&t), warn)
        }
    }
}

/// The source format: `{"version": 1..5, "rules": [headless rules]}`.
pub fn compile_source(v: &Value, warn: &mut dyn FnMut(String)) -> Result<CompiledSet, String> {
    let version = v
        .get("version")
        .and_then(|x| x.as_u64())
        .ok_or("rule-set json: missing version")?;
    if version == 0 || version > super::srs::MAX_VERSION as u64 {
        return Err(format!("rule-set json: unsupported version {version}"));
    }
    let rules = v.get("rules").cloned().unwrap_or(Value::Array(Vec::new()));
    compile_headless(&rules, warn).map(|rules| CompiledSet {
        rules,
        version: version as u8,
    })
}

pub fn compile_headless(rules: &Value, warn: &mut dyn FnMut(String)) -> Result<Vec<Rule>, String> {
    let list = rules.as_array().ok_or("rule-set: rules must be an array")?;
    let lookup = |_: &str| None;
    let mut env = ParseEnv {
        headless: true,
        lookup_set: &lookup,
        warn,
    };
    list.iter()
        .enumerate()
        .map(|(i, r)| parse_rule(r, &mut env, &format!("rules[{i}]")))
        .collect()
}

// ---------------------------------------------------------------------------------------------
// cache

pub fn default_cache_dir() -> PathBuf {
    if let Ok(dir) = crate::config::settings::var("AETHER_ROUTE_CACHE_DIR") {
        if !dir.trim().is_empty() {
            return PathBuf::from(dir.trim());
        }
    }
    #[cfg(windows)]
    {
        if let Ok(base) = std::env::var("LOCALAPPDATA") {
            return PathBuf::from(base).join("aether").join("rule-sets");
        }
    }
    #[cfg(not(windows))]
    {
        if let Ok(base) = std::env::var("XDG_CACHE_HOME") {
            if !base.is_empty() {
                return PathBuf::from(base).join("aether").join("rule-sets");
            }
        }
        if let Ok(home) = std::env::var("HOME") {
            if !home.is_empty() {
                return PathBuf::from(home).join(".cache").join("aether").join("rule-sets");
            }
        }
    }
    PathBuf::from("aether-rule-sets")
}

fn safe_name(tag: &str) -> String {
    tag.chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' { c } else { '_' })
        .collect()
}

#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct CacheMeta {
    pub url: String,
    #[serde(default)]
    pub etag: Option<String>,
    #[serde(default)]
    pub last_modified: Option<String>,
    /// Unix seconds of the last successful download (or confirmation by 304).
    pub updated: u64,
}

pub struct Cache {
    pub dir: PathBuf,
}

pub fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

impl Cache {
    fn data_path(&self, tag: &str, format: Format) -> PathBuf {
        self.dir.join(format!("{}.{}", safe_name(tag), format.ext()))
    }

    fn meta_path(&self, tag: &str) -> PathBuf {
        self.dir.join(format!("{}.meta.json", safe_name(tag)))
    }

    pub fn load(&self, tag: &str, format: Format, url: &str) -> Option<(Vec<u8>, CacheMeta)> {
        let meta: CacheMeta =
            serde_json::from_slice(&std::fs::read(self.meta_path(tag)).ok()?).ok()?;
        if meta.url != url {
            log::info!("[route] rule-set {tag}: the cached copy is of another url; fetching anew");
            return None;
        }
        let data = std::fs::read(self.data_path(tag, format)).ok()?;
        Some((data, meta))
    }

    pub fn store(&self, tag: &str, format: Format, data: Option<&[u8]>, meta: &CacheMeta) -> std::io::Result<()> {
        std::fs::create_dir_all(&self.dir)?;
        if let Some(data) = data {
            write_atomic(&self.data_path(tag, format), data)?;
        }
        let meta = serde_json::to_vec_pretty(meta).map_err(std::io::Error::other)?;
        write_atomic(&self.meta_path(tag), &meta)
    }
}

pub fn write_atomic(path: &Path, data: &[u8]) -> std::io::Result<()> {
    let tmp = path.with_extension(format!(
        "{}.tmp{}",
        path.extension().and_then(|e| e.to_str()).unwrap_or(""),
        std::process::id()
    ));
    {
        use std::io::Write;
        let mut f = std::fs::File::create(&tmp)?;
        f.write_all(data)?;
        f.sync_all()?;
    }
    // rename over an existing file is atomic on unix and replaces it on windows
    match std::fs::rename(&tmp, path) {
        Ok(()) => Ok(()),
        Err(e) => {
            let _ = std::fs::remove_file(&tmp);
            Err(e)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// download

pub enum Fetched {
    New {
        data: Vec<u8>,
        etag: Option<String>,
        last_modified: Option<String>,
    },
    NotModified,
}

/// Fetch `url`, through a local socks5 proxy when `via` names one (the detour listener).
pub async fn fetch(url: &str, via: Option<std::net::SocketAddr>, meta: Option<&CacheMeta>) -> Result<Fetched, String> {
    let mut builder = reqwest::Client::builder()
        .timeout(Duration::from_secs(90))
        .connect_timeout(Duration::from_secs(30))
        .user_agent(concat!("aether/", env!("CARGO_PKG_VERSION"), " (sing-box rule-set)"))
        .no_proxy();
    if let Some(addr) = via {
        let proxy = reqwest::Proxy::all(format!("socks5h://{addr}")).map_err(|e| e.to_string())?;
        builder = builder.proxy(proxy);
    }
    let client = builder.build().map_err(|e| e.to_string())?;
    let mut req = client.get(url);
    if let Some(meta) = meta {
        if let Some(etag) = &meta.etag {
            req = req.header("If-None-Match", etag);
        }
        if let Some(lm) = &meta.last_modified {
            req = req.header("If-Modified-Since", lm);
        }
    }
    let resp = req.send().await.map_err(|e| format!("{e}"))?;
    if resp.status() == reqwest::StatusCode::NOT_MODIFIED {
        return Ok(Fetched::NotModified);
    }
    if !resp.status().is_success() {
        return Err(format!("http status {}", resp.status()));
    }
    let header = |name: &str| {
        resp.headers()
            .get(name)
            .and_then(|v| v.to_str().ok())
            .map(|s| s.to_string())
    };
    let etag = header("etag");
    let last_modified = header("last-modified");
    let data = resp.bytes().await.map_err(|e| format!("{e}"))?;
    if data.len() > 64 << 20 {
        return Err("rule-set is larger than 64 MiB".into());
    }
    Ok(Fetched::New {
        data: data.to_vec(),
        etag,
        last_modified,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proxy::router::rule::{Ctx, Metadata, Network};
    use serde_json::json;

    fn meta(host: &str, port: u16) -> Metadata {
        Metadata::new("socks", Network::Tcp, "127.0.0.1:1".parse().unwrap(), host, port)
    }

    fn any(set: &CompiledSet, m: &Metadata) -> bool {
        set.rules.iter().any(|r| r.matches(m, Ctx::default()))
    }

    #[test]
    fn json_source_versions_1_to_3_parse() {
        for version in 1..=3 {
            let v = json!({"version": version, "rules": [
                {"domain_suffix": ["cn", "baidu.com"], "domain": "exact.test"},
                {"ip_cidr": ["1.0.1.0/24", "2001:250::/35"]},
                {"type": "logical", "mode": "and", "rules": [{"domain_keyword": "ads"}, {"port": 443}]}
            ]});
            let mut warn = |_m: String| {};
            let set = compile_source(&v, &mut warn).unwrap();
            assert_eq!(set.version, version);
            assert!(any(&set, &meta("www.baidu.com", 1)));
            assert!(any(&set, &meta("exact.test", 1)));
            assert!(!any(&set, &meta("a.exact.test", 1)));
            assert!(any(&set, &meta("1.0.1.77", 1)));
            assert!(any(&set, &meta("2001:250::1", 1)));
            assert!(any(&set, &meta("myads.example", 443)));
            assert!(!any(&set, &meta("myads.example", 80)));
            assert!(set.mergeable().is_none());
        }
    }

    #[test]
    fn json_source_rejects_bad_versions_and_route_only_fields() {
        let mut warn = |_m: String| {};
        assert!(compile_source(&json!({"version": 9, "rules": []}), &mut warn).is_err());
        assert!(compile_source(&json!({"rules": []}), &mut warn).is_err());
        let mut warned = Vec::new();
        let mut w = |m: String| warned.push(m);
        let set = compile_source(&json!({"version": 2, "rules": [{"domain": "a.test", "outbound": "direct"}]}), &mut w).unwrap();
        assert!(set.mergeable().is_some());
        assert!(!warned.is_empty(), "outbound inside a headless rule is not a condition");
    }

    #[test]
    fn hand_built_srs_files_of_every_version_decode() {
        use crate::proxy::router::srs::testenc::*;
        for version in 1..=5u8 {
            let mut body = Vec::new();
            body.push(0); // default rule
            strings(&mut body, 3, &["tracker"]); // domain_keyword
            uvarint_item_ports(&mut body, 9, &[443, 8443]);
            strings(&mut body, 10, &["1000:2000"]);
            body.push(0xff);
            body.push(0);
            // a second, logical rule: or(network udp, invert(port 53))
            body.push(1);
            body.push(1);
            uvarint(&mut body, 2);
            body.push(0);
            strings(&mut body, 1, &["udp"]);
            body.push(0xff);
            body.push(0);
            body.push(0);
            uvarint_item_ports(&mut body, 9, &[53]);
            body.push(0xff);
            body.push(1);
            body.push(0); // logical invert
            let file = finish(version, &body, 2);
            let mut warn = |_m: String| {};
            let set = compile(&file, Format::Binary, &mut warn).unwrap();
            assert_eq!(set.version, version);
            assert!(any(&set, &meta("x.tracker.example", 443)));
            assert!(any(&set, &meta("x.tracker.example", 1500)));
            assert!(any(&set, &meta("x.example", 1)), "logical: not port 53");
            assert!(!any(&set, &meta("x.example", 53)));
        }
    }

    fn uvarint_item_ports(out: &mut Vec<u8>, item: u8, ports: &[u16]) {
        out.push(item);
        crate::proxy::router::srs::testenc::uvarint(out, ports.len() as u64);
        for p in ports {
            out.extend_from_slice(&p.to_be_bytes());
        }
    }

    #[test]
    fn a_wrong_magic_or_version_is_refused() {
        let mut warn = |_m: String| {};
        assert!(compile(b"XYZ\x01abc", Format::Binary, &mut warn).is_err());
        assert!(compile(b"SRS\x09abc", Format::Binary, &mut warn).is_err());
        let file = crate::proxy::router::srs::testenc::finish(1, &[0, 0x63], 1);
        assert!(compile(&file, Format::Binary, &mut warn).is_err(), "unknown item type");
    }

    #[test]
    fn formats_are_guessed_from_the_name() {
        assert_eq!(guess_format("https://x/geosite-cn.srs"), Some(Format::Binary));
        assert_eq!(guess_format("rules/a.json?raw=1"), Some(Format::Source));
        assert_eq!(guess_format("rules/a.txt"), None);
    }

    #[test]
    fn the_cache_round_trips_and_ignores_another_url() {
        let dir = crate::test_util::scratch("rs-cache");
        let cache = Cache { dir: dir.clone() };
        let meta = CacheMeta { url: "https://a/x.srs".into(), etag: Some("\"e\"".into()), last_modified: None, updated: 5 };
        cache.store("geo/site:cn", Format::Binary, Some(b"SRS\x01data"), &meta).unwrap();
        let (data, m) = cache.load("geo/site:cn", Format::Binary, "https://a/x.srs").unwrap();
        assert_eq!(data, b"SRS\x01data");
        assert_eq!(m.etag.as_deref(), Some("\"e\""));
        assert!(cache.load("geo/site:cn", Format::Binary, "https://b/x.srs").is_none());
        let leftovers: Vec<_> = std::fs::read_dir(&dir).unwrap().flatten()
            .filter(|e| e.file_name().to_string_lossy().contains(".tmp")).collect();
        assert!(leftovers.is_empty());
        let _ = std::fs::remove_dir_all(dir);
    }
}
