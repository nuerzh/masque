//! Compiled rules and the matching semantics of sing-box (`route/rule/rule_abstract.go`).
//!
//! A default rule's conditions fall into four address/port groups plus the rest:
//!
//! * source address: `source_ip_cidr`, `source_ip_is_private`
//! * source port: `source_port`, `source_port_range`
//! * destination address: `domain`, `domain_suffix`, `domain_keyword`, `domain_regex`,
//!   `ip_cidr`, `ip_is_private` (the ip items join the source group instead when the rule
//!   says `rule_set_ip_cidr_match_source`)
//! * destination port: `port`, `port_range`
//! * everything else (`network`, `protocol`, `inbound`, `ip_version`, `process_*`, ...)
//!
//! Within a group any item may match (OR); every group present must be satisfied and every
//! other item must match (AND). `rule_set` items are merged into the outer rule's groups when
//! the set is a single plain rule, exactly as sing-box does; otherwise the outer groups must
//! all be satisfied and any rule of the set must match. `invert` flips the result.

use std::collections::HashSet;
use std::net::{IpAddr, SocketAddr};
use std::sync::Arc;

use regex::Regex;
use serde_json::Value;

use super::domain::{AdGuardMatcher, DomainMatcher};
use super::ipset::{is_non_public, unmap, IpSet, IpSetBuilder};
use super::process::ProcessInfo;
use super::ruleset::Slot;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Network {
    Tcp,
    Udp,
}

impl Network {
    pub fn as_str(self) -> &'static str {
        match self {
            Network::Tcp => "tcp",
            Network::Udp => "udp",
        }
    }
}

/// What a connection looks like to the rules (sing-box's InboundContext, the parts that
/// matter to Aether's proxies).
#[derive(Debug)]
pub struct Metadata {
    /// The inbound tag: `socks` (the --bind listener), `http` (--http-proxy).
    pub inbound: String,
    pub network: Network,
    pub source: SocketAddr,
    /// The address the inbound was given: a domain (lowercase, no trailing dot) or an ip.
    pub fqdn: Option<String>,
    pub ip: Option<IpAddr>,
    pub port: u16,
    /// A domain learnt by sniffing (TLS SNI, HTTP Host, QUIC SNI).
    pub domain: Option<String>,
    pub protocol: Option<&'static str>,
    pub client: Option<String>,
    /// Addresses from a `resolve` action.
    pub resolved: Vec<IpAddr>,
    /// Whether `resolved` came from this machine's resolver (`resolve` with server `local`),
    /// not from the resolver inside the tunnel: only then may `warp-local` dial them.
    pub resolved_local: bool,
    pub sniffed: bool,
    pub process: std::sync::OnceLock<Option<ProcessInfo>>,
    /// The listener the client reached, for the process lookup.
    pub local: Option<SocketAddr>,
}

impl Metadata {
    pub fn new(inbound: &str, network: Network, source: SocketAddr, host: &str, port: u16) -> Self {
        let host = host.trim().trim_start_matches('[').trim_end_matches(']');
        let (fqdn, ip) = match host.parse::<IpAddr>() {
            Ok(ip) => (None, Some(unmap(ip))),
            Err(_) => (Some(host.trim_end_matches('.').to_lowercase()), None),
        };
        Metadata {
            inbound: inbound.to_string(),
            network,
            source,
            fqdn,
            ip,
            port,
            domain: None,
            protocol: None,
            client: None,
            resolved: Vec::new(),
            resolved_local: false,
            sniffed: false,
            process: std::sync::OnceLock::new(),
            local: None,
        }
    }

    /// The name domain rules look at: a sniffed domain first, then the requested one.
    pub fn match_domain(&self) -> Option<&str> {
        self.domain.as_deref().or(self.fqdn.as_deref())
    }

    pub fn process_known(&self) -> bool {
        self.process.get().is_some()
    }

    /// The process lookup scans /proc (or asks the Windows IP helper), so it runs on the
    /// blocking pool rather than on a runtime worker.
    pub async fn lookup_process(&mut self) {
        if self.process_known() {
            return;
        }
        let (network, source, local) = (self.network, self.source, self.local);
        let found = tokio::task::spawn_blocking(move || super::process::lookup(network, source, local))
            .await
            .unwrap_or_default();
        let _ = self.process.set(found);
    }

    fn process(&self) -> Option<&ProcessInfo> {
        self.process
            .get_or_init(|| super::process::lookup(self.network, self.source, self.local))
            .as_ref()
    }

    pub fn describe(&self) -> String {
        let host = match (&self.fqdn, &self.ip) {
            (Some(d), _) => d.clone(),
            (None, Some(IpAddr::V6(v6))) => format!("[{v6}]"),
            (None, Some(ip)) => ip.to_string(),
            _ => "?".into(),
        };
        let mut s = format!("{} {}:{}", self.network.as_str(), host, self.port);
        if let Some(d) = &self.domain {
            if Some(d) != self.fqdn.as_ref() {
                s.push_str(&format!(" (sniffed {d})"));
            }
        }
        s
    }
}

/// The two flags sing-box keeps on the metadata while it matches inside a rule set.
#[derive(Clone, Copy, Default)]
pub struct Ctx {
    pub match_source: bool,
    pub accept_empty: bool,
}

#[derive(Debug)]
pub enum Item {
    Inbound(HashSet<String>),
    IpVersion6(bool),
    Network(HashSet<Network>),
    Protocol(HashSet<String>),
    Client(HashSet<String>),
    Domain(DomainMatcher),
    DomainKeyword(Vec<String>),
    DomainRegex(Vec<Regex>),
    AdGuard(AdGuardMatcher),
    SourceIpCidr(IpSet),
    SourceIpIsPrivate,
    IpCidr(IpSet),
    IpIsPrivate,
    SourcePort(HashSet<u16>),
    SourcePortRange(Vec<(u16, u16)>),
    Port(HashSet<u16>),
    PortRange(Vec<(u16, u16)>),
    ProcessName(HashSet<String>),
    ProcessPath(HashSet<String>),
    ProcessPathRegex(Vec<Regex>),
    /// A condition Aether cannot evaluate (wifi_ssid, package_name, ...): never matches.
    Never(&'static str),
}

impl Item {
    pub fn network(values: &[String]) -> Item {
        let mut set = HashSet::new();
        for v in values {
            match v.to_lowercase().as_str() {
                "tcp" => {
                    set.insert(Network::Tcp);
                }
                "udp" => {
                    set.insert(Network::Udp);
                }
                _ => {}
            }
        }
        Item::Network(set)
    }

    pub fn domain_regex(values: &[String]) -> Result<Item, String> {
        let mut out = Vec::new();
        for (i, v) in values.iter().enumerate() {
            out.push(Regex::new(v).map_err(|e| format!("domain_regex[{i}] {v:?}: {e}"))?);
        }
        Ok(Item::DomainRegex(out))
    }

    pub fn process_path_regex(values: &[String]) -> Result<Item, String> {
        let mut out = Vec::new();
        for (i, v) in values.iter().enumerate() {
            out.push(Regex::new(v).map_err(|e| format!("process_path_regex[{i}] {v:?}: {e}"))?);
        }
        Ok(Item::ProcessPathRegex(out))
    }

    fn needs_process(&self) -> bool {
        matches!(self, Item::ProcessName(_) | Item::ProcessPath(_) | Item::ProcessPathRegex(_))
    }

    fn needs_domain(&self) -> bool {
        matches!(
            self,
            Item::Domain(_) | Item::DomainKeyword(_) | Item::DomainRegex(_) | Item::AdGuard(_)
        )
    }

    fn matches(&self, m: &Metadata, ctx: Ctx) -> bool {
        match self {
            Item::Inbound(set) => set.contains(&m.inbound),
            Item::IpVersion6(v6) => m.ip.is_some_and(|ip| ip.is_ipv6() == *v6),
            Item::Network(set) => set.contains(&m.network),
            Item::Protocol(set) => m.protocol.is_some_and(|p| set.contains(p)),
            Item::Client(set) => m.client.as_ref().is_some_and(|c| set.contains(c)),
            Item::Domain(matcher) => m.match_domain().is_some_and(|d| matcher.matches(d)),
            Item::DomainKeyword(words) => m
                .match_domain()
                .is_some_and(|d| words.iter().any(|w| d.contains(w.as_str()))),
            Item::DomainRegex(res) => m
                .match_domain()
                .is_some_and(|d| res.iter().any(|re| re.is_match(d))),
            Item::AdGuard(matcher) => m.match_domain().is_some_and(|d| matcher.matches(d)),
            Item::SourceIpCidr(set) => set.contains(m.source.ip()),
            Item::SourceIpIsPrivate => is_non_public(m.source.ip()),
            Item::IpCidr(set) => {
                if ctx.match_source {
                    return set.contains(m.source.ip());
                }
                if let Some(ip) = m.ip {
                    return set.contains(ip);
                }
                if !m.resolved.is_empty() {
                    return m.resolved.iter().any(|ip| set.contains(*ip));
                }
                ctx.accept_empty
            }
            Item::IpIsPrivate => {
                if let Some(ip) = m.ip {
                    return is_non_public(ip);
                }
                m.resolved.iter().any(|ip| is_non_public(*ip))
            }
            Item::SourcePort(set) => set.contains(&m.source.port()),
            Item::SourcePortRange(ranges) => {
                let p = m.source.port();
                ranges.iter().any(|(a, b)| p >= *a && p <= *b)
            }
            Item::Port(set) => set.contains(&m.port),
            Item::PortRange(ranges) => ranges.iter().any(|(a, b)| m.port >= *a && m.port <= *b),
            Item::ProcessName(names) => m.process().is_some_and(|p| {
                !p.path.is_empty() && names.contains(&p.name)
            }),
            Item::ProcessPath(paths) => m
                .process()
                .is_some_and(|p| !p.path.is_empty() && paths.contains(&p.path)),
            Item::ProcessPathRegex(res) => m
                .process()
                .is_some_and(|p| !p.path.is_empty() && res.iter().any(|re| re.is_match(&p.path))),
            Item::Never(_) => false,
        }
    }
}

const SRC_ADDR: u8 = 1;
const SRC_PORT: u8 = 2;
const DST_ADDR: u8 = 4;
const DST_PORT: u8 = 8;

#[derive(Clone, Copy, Default, Debug)]
struct Groups {
    required: u8,
    satisfied: u8,
}

impl Groups {
    fn done(self) -> bool {
        self.required & !self.satisfied == 0
    }
    fn merge(self, o: Groups) -> Groups {
        Groups {
            required: self.required | o.required,
            satisfied: self.satisfied | o.satisfied,
        }
    }
}

#[derive(Debug)]
pub struct RuleSetRef {
    pub slots: Vec<Arc<Slot>>,
    pub match_source: bool,
}

#[derive(Debug, Default)]
pub struct DefaultRule {
    pub items: Vec<Item>,
    pub src_addr: Vec<Item>,
    pub src_port: Vec<Item>,
    pub dst_addr: Vec<Item>,
    pub dst_ipcidr: Vec<Item>,
    pub dst_port: Vec<Item>,
    pub rule_set: Option<RuleSetRef>,
    pub invert: bool,
}

impl DefaultRule {
    pub fn push_item(&mut self, i: Item) {
        self.items.push(i)
    }
    pub fn push_src_addr(&mut self, i: Item) {
        self.src_addr.push(i)
    }
    pub fn push_src_port(&mut self, i: Item) {
        self.src_port.push(i)
    }
    pub fn push_dst_addr(&mut self, i: Item) {
        self.dst_addr.push(i)
    }
    pub fn push_dst_ipcidr(&mut self, i: Item) {
        self.dst_ipcidr.push(i)
    }
    pub fn push_dst_port(&mut self, i: Item) {
        self.dst_port.push(i)
    }

    fn all_items(&self) -> impl Iterator<Item = &Item> {
        self.items
            .iter()
            .chain(&self.src_addr)
            .chain(&self.src_port)
            .chain(&self.dst_addr)
            .chain(&self.dst_ipcidr)
            .chain(&self.dst_port)
    }

    pub fn is_empty(&self) -> bool {
        self.all_items().next().is_none() && self.rule_set.is_none()
    }

    fn groups(&self, m: &Metadata, ctx: Ctx) -> Groups {
        let any = |items: &[Item]| items.iter().any(|i| i.matches(m, ctx));
        let mut g = Groups::default();
        if !self.src_addr.is_empty() {
            g.required |= SRC_ADDR;
            if any(&self.src_addr) {
                g.satisfied |= SRC_ADDR;
            }
        }
        if ctx.match_source && !self.dst_ipcidr.is_empty() {
            g.required |= SRC_ADDR;
            if g.satisfied & SRC_ADDR == 0 && any(&self.dst_ipcidr) {
                g.satisfied |= SRC_ADDR;
            }
        }
        if !self.src_port.is_empty() {
            g.required |= SRC_PORT;
            if any(&self.src_port) {
                g.satisfied |= SRC_PORT;
            }
        }
        if !self.dst_addr.is_empty() {
            g.required |= DST_ADDR;
            if any(&self.dst_addr) {
                g.satisfied |= DST_ADDR;
            }
        }
        if !ctx.match_source && !self.dst_ipcidr.is_empty() {
            g.required |= DST_ADDR;
            if g.satisfied & DST_ADDR == 0 && any(&self.dst_ipcidr) {
                g.satisfied |= DST_ADDR;
            }
        }
        if !self.dst_port.is_empty() {
            g.required |= DST_PORT;
            if any(&self.dst_port) {
                g.satisfied |= DST_PORT;
            }
        }
        g
    }

    fn evaluate_for_merge(&self, m: &Metadata, ctx: Ctx) -> Option<Groups> {
        let g = self.groups(m, ctx);
        if self.items.iter().all(|i| i.matches(m, ctx)) {
            Some(g)
        } else {
            None
        }
    }

    fn inner(&self, m: &Metadata, ctx: Ctx) -> bool {
        let groups = self.groups(m, ctx);
        if !self.items.iter().all(|i| i.matches(m, ctx)) {
            return false;
        }
        match &self.rule_set {
            Some(rs) => rule_set_match_with_outer(rs, m, groups),
            None => groups.done(),
        }
    }

    pub fn matches(&self, m: &Metadata, ctx: Ctx) -> bool {
        if self.is_empty() {
            return true;
        }
        let matched = self.inner(m, ctx);
        matched != self.invert
    }
}

fn rule_set_match_with_outer(rs: &RuleSetRef, m: &Metadata, outer: Groups) -> bool {
    let outer_done = outer.done();
    let ctx = Ctx {
        match_source: rs.match_source,
        accept_empty: false,
    };
    for slot in &rs.slots {
        let set = slot.current();
        if let Some(branch) = set.mergeable() {
            if let Some(g) = branch.evaluate_for_merge(m, ctx) {
                if outer.merge(g).done() {
                    return true;
                }
            }
            continue;
        }
        if outer_done && set.rules.iter().any(|r| r.matches(m, ctx)) {
            return true;
        }
    }
    false
}

#[derive(Debug)]
pub struct LogicalRule {
    pub and: bool,
    pub rules: Vec<Rule>,
    pub invert: bool,
}

#[derive(Debug)]
pub enum Rule {
    Default(DefaultRule),
    Logical(LogicalRule),
}

impl Rule {
    pub fn matches(&self, m: &Metadata, ctx: Ctx) -> bool {
        match self {
            Rule::Default(d) => d.matches(m, ctx),
            Rule::Logical(l) => {
                let matched = if l.and {
                    l.rules.iter().all(|r| r.matches(m, ctx))
                } else {
                    l.rules.iter().any(|r| r.matches(m, ctx))
                };
                matched != l.invert
            }
        }
    }

    fn visit(&self, f: &mut dyn FnMut(&Item)) {
        match self {
            Rule::Default(d) => {
                for i in d.all_items() {
                    f(i);
                }
                if let Some(rs) = &d.rule_set {
                    for s in &rs.slots {
                        for r in &s.current().rules {
                            r.visit(f);
                        }
                    }
                }
            }
            Rule::Logical(l) => {
                for r in &l.rules {
                    r.visit(f);
                }
            }
        }
    }

    /// Whether matching may read the client's process: the rule's own items, and the rule sets
    /// it names as they are now (each set keeps its answer, so a large one is not walked).
    pub fn needs_process(&self) -> bool {
        match self {
            Rule::Default(d) => {
                d.all_items().any(Item::needs_process)
                    || d.rule_set.as_ref().is_some_and(|rs| rs.slots.iter().any(|s| s.needs_process()))
            }
            Rule::Logical(l) => l.rules.iter().any(Rule::needs_process),
        }
    }

    pub fn needs_domain(&self) -> bool {
        let mut any = false;
        self.visit(&mut |i| any |= i.needs_domain() || matches!(i, Item::Protocol(_)));
        any
    }

    pub fn unsupported(&self, out: &mut Vec<&'static str>) {
        self.visit(&mut |i| {
            if let Item::Never(name) = i {
                if !out.contains(name) {
                    out.push(name);
                }
            }
        });
    }
}

// ---------------------------------------------------------------------------------------------
// json

/// A sing-box "listable": one value or an array of them.
pub fn listable(v: &Value) -> Vec<&Value> {
    match v {
        Value::Array(a) => a.iter().collect(),
        Value::Null => Vec::new(),
        other => vec![other],
    }
}

pub fn strings(key: &str, v: &Value) -> Result<Vec<String>, String> {
    listable(v)
        .into_iter()
        .map(|x| match x {
            Value::String(s) => Ok(s.clone()),
            Value::Number(n) => Ok(n.to_string()),
            _ => Err(format!("{key}: expected a string, found {x}")),
        })
        .collect()
}

fn ports(key: &str, v: &Value) -> Result<HashSet<u16>, String> {
    listable(v)
        .into_iter()
        .map(|x| {
            x.as_u64()
                .or_else(|| x.as_str().and_then(|s| s.trim().parse().ok()))
                .filter(|p| *p <= 65535)
                .map(|p| p as u16)
                .ok_or_else(|| format!("{key}: {x} is not a port"))
        })
        .collect()
}

/// `port_range` entries: `1000:2000`, `:3000`, `4000:`.
pub fn parse_port_ranges(values: &[String]) -> Result<Vec<(u16, u16)>, String> {
    let mut out = Vec::new();
    for v in values {
        let Some((a, b)) = v.split_once(':') else {
            return Err(format!("bad port range {v:?}: expected start:end"));
        };
        let start = if a.is_empty() {
            0
        } else {
            a.trim().parse::<u16>().map_err(|e| format!("bad port range {v:?}: {e}"))?
        };
        let end = if b.is_empty() {
            u16::MAX
        } else {
            b.trim().parse::<u16>().map_err(|e| format!("bad port range {v:?}: {e}"))?
        };
        out.push((start, end));
    }
    Ok(out)
}

fn ip_set(key: &str, v: &Value) -> Result<IpSet, String> {
    let mut b = IpSetBuilder::default();
    for (i, s) in strings(key, v)?.iter().enumerate() {
        b.add_text(s).map_err(|e| format!("{key}[{i}]: {e}"))?;
    }
    Ok(b.build())
}

fn bool_of(key: &str, v: &Value) -> Result<bool, String> {
    v.as_bool().ok_or_else(|| format!("{key}: expected true or false"))
}

/// Fields of a rule that are about its action, not its conditions.
pub const ACTION_KEYS: &[&str] = &[
    "action",
    "outbound",
    "override_address",
    "override_port",
    "network_strategy",
    "network_type",
    "fallback_network_type",
    "fallback_delay",
    "udp_disable_domain_unmapping",
    "udp_connect",
    "udp_timeout",
    "tls_fragment",
    "tls_fragment_fallback_delay",
    "tls_record_fragment",
    "tls_spoof",
    "tls_spoof_method",
    "method",
    "no_drop",
    "sniffer",
    "timeout",
    "server",
    "strategy",
    "disable_cache",
    "disable_optimistic_cache",
    "rewrite_ttl",
    "client_subnet",
    // direct action dial fields
    "bind_interface",
    "inet4_bind_address",
    "inet6_bind_address",
    "routing_mark",
    "reuse_addr",
    "connect_timeout",
    "tcp_fast_open",
    "tcp_multi_path",
    "udp_fragment",
    "domain_strategy",
];

/// Conditions sing-box has that cannot apply to Aether's socks/http proxies. They parse, warn
/// once, and never match.
pub const UNSUPPORTED_KEYS: &[&str] = &[
    "auth_user",
    "package_name",
    "package_name_regex",
    "user",
    "user_id",
    "clash_mode",
    "network_type",
    "network_is_expensive",
    "network_is_constrained",
    "wifi_ssid",
    "wifi_bssid",
    "interface_address",
    "network_interface_address",
    "default_interface_address",
    "source_mac_address",
    "source_hostname",
    "preferred_by",
    "query_type",
];

pub struct ParseEnv<'a> {
    pub headless: bool,
    pub lookup_set: &'a dyn Fn(&str) -> Option<Arc<Slot>>,
    pub warn: &'a mut dyn FnMut(String),
}

/// Parse one rule object (route rule, logical sub-rule, or headless rule-set rule). Action
/// fields are skipped here; the caller reads them.
pub fn parse_rule(v: &Value, env: &mut ParseEnv<'_>, path: &str) -> Result<Rule, String> {
    let obj = v
        .as_object()
        .ok_or_else(|| format!("{path}: a rule must be an object"))?;
    let kind = obj.get("type").and_then(|t| t.as_str()).unwrap_or("default");
    match kind {
        "" | "default" => parse_default(obj, env, path).map(Rule::Default),
        "logical" => {
            let mode = obj.get("mode").and_then(|m| m.as_str()).unwrap_or("");
            let and = match mode {
                "and" => true,
                "or" => false,
                other => return Err(format!("{path}: unknown logical mode {other:?}")),
            };
            let sub = obj
                .get("rules")
                .and_then(|r| r.as_array())
                .ok_or_else(|| format!("{path}: a logical rule needs rules"))?;
            if sub.is_empty() {
                return Err(format!("{path}: missing conditions"));
            }
            let mut rules = Vec::new();
            for (i, r) in sub.iter().enumerate() {
                let p = format!("{path}.rules[{i}]");
                if !env.headless {
                    if let Some(o) = r.as_object() {
                        if o.get("action").is_some_and(|a| a.as_str() != Some("route") && !a.is_null())
                            || o.get("outbound").is_some_and(|x| x.as_str().is_some_and(|s| !s.is_empty()))
                        {
                            return Err(format!("{p}: a nested rule cannot have an action"));
                        }
                    }
                }
                rules.push(parse_rule(r, env, &p)?);
            }
            let invert = obj.get("invert").and_then(|x| x.as_bool()).unwrap_or(false);
            for key in obj.keys() {
                if !matches!(key.as_str(), "type" | "mode" | "rules" | "invert")
                    && !(ACTION_KEYS.contains(&key.as_str()) && !env.headless)
                {
                    (env.warn)(format!("{path}: unknown field {key:?} ignored"));
                }
            }
            Ok(Rule::Logical(LogicalRule { and, rules, invert }))
        }
        other => Err(format!("{path}: unknown rule type {other:?}")),
    }
}

fn parse_default(
    obj: &serde_json::Map<String, Value>,
    env: &mut ParseEnv<'_>,
    path: &str,
) -> Result<DefaultRule, String> {
    let mut r = DefaultRule::default();
    let mut domains: Vec<String> = Vec::new();
    let mut suffixes: Vec<String> = Vec::new();
    let mut have_domain = false;
    let mut match_source = false;
    let mut rule_set_tags: Vec<String> = Vec::new();

    for (key, v) in obj {
        let k = key.as_str();
        let p = format!("{path}.{k}");
        match k {
            "type" => {}
            "invert" => r.invert = bool_of(&p, v)?,
            "inbound" if !env.headless => {
                r.push_item(Item::Inbound(strings(&p, v)?.into_iter().collect()))
            }
            "ip_version" if !env.headless => match v.as_u64() {
                Some(4) => r.push_item(Item::IpVersion6(false)),
                Some(6) => r.push_item(Item::IpVersion6(true)),
                Some(0) | None if v.is_null() => {}
                _ => return Err(format!("{p}: invalid ip version {v}")),
            },
            "network" => {
                let vals = strings(&p, v)?;
                for n in &vals {
                    if !matches!(n.as_str(), "tcp" | "udp" | "icmp") {
                        return Err(format!("{p}: unknown network {n:?}"));
                    }
                }
                if !vals.is_empty() {
                    r.push_item(Item::network(&vals));
                }
            }
            "protocol" if !env.headless => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_item(Item::Protocol(vals.into_iter().collect()))
                }
            }
            "client" if !env.headless => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_item(Item::Client(vals.into_iter().collect()))
                }
            }
            "domain" => {
                let vals = strings(&p, v)?;
                if vals.iter().any(|s| s.is_empty()) {
                    return Err(format!("{p}: empty item is not allowed"));
                }
                have_domain |= !vals.is_empty();
                domains.extend(vals.into_iter().map(|s| s.to_lowercase()));
            }
            "domain_suffix" => {
                let vals = strings(&p, v)?;
                if vals.iter().any(|s| s.is_empty()) {
                    return Err(format!("{p}: empty item is not allowed"));
                }
                have_domain |= !vals.is_empty();
                suffixes.extend(vals.into_iter().map(|s| s.to_lowercase()));
            }
            "domain_keyword" => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_dst_addr(Item::DomainKeyword(
                        vals.into_iter().map(|s| s.to_lowercase()).collect(),
                    ));
                }
            }
            "domain_regex" => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_dst_addr(Item::domain_regex(&vals).map_err(|e| format!("{path}: {e}"))?);
                }
            }
            "geosite" | "geoip" | "source_geoip" => {
                return Err(format!(
                    "{p}: the geosite/geoip databases were removed in sing-box 1.12; use rule_set \
                     with geosite-*.srs / geoip-*.srs instead"
                ))
            }
            "source_ip_cidr" => {
                let set = ip_set(&p, v)?;
                r.push_src_addr(Item::SourceIpCidr(set));
            }
            "source_ip_is_private" if !env.headless => {
                if bool_of(&p, v)? {
                    r.push_src_addr(Item::SourceIpIsPrivate)
                }
            }
            "ip_cidr" => {
                let set = ip_set(&p, v)?;
                r.push_dst_ipcidr(Item::IpCidr(set));
            }
            "ip_is_private" if !env.headless => {
                if bool_of(&p, v)? {
                    r.push_dst_ipcidr(Item::IpIsPrivate)
                }
            }
            "source_port" => {
                let set = ports(&p, v)?;
                if !set.is_empty() {
                    r.push_src_port(Item::SourcePort(set))
                }
            }
            "source_port_range" => {
                let ranges = parse_port_ranges(&strings(&p, v)?)?;
                if !ranges.is_empty() {
                    r.push_src_port(Item::SourcePortRange(ranges))
                }
            }
            "port" => {
                let set = ports(&p, v)?;
                if !set.is_empty() {
                    r.push_dst_port(Item::Port(set))
                }
            }
            "port_range" => {
                let ranges = parse_port_ranges(&strings(&p, v)?)?;
                if !ranges.is_empty() {
                    r.push_dst_port(Item::PortRange(ranges))
                }
            }
            "process_name" => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_item(Item::ProcessName(vals.into_iter().collect()))
                }
            }
            "process_path" => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_item(Item::ProcessPath(vals.into_iter().collect()))
                }
            }
            "process_path_regex" => {
                let vals = strings(&p, v)?;
                if !vals.is_empty() {
                    r.push_item(Item::process_path_regex(&vals).map_err(|e| format!("{path}: {e}"))?)
                }
            }
            "rule_set" if !env.headless => rule_set_tags = strings(&p, v)?,
            "rule_set_ip_cidr_match_source" if !env.headless => match_source = bool_of(&p, v)?,
            "rule_set_ipcidr_match_source" => {
                return Err(format!(
                    "{p}: renamed to rule_set_ip_cidr_match_source in sing-box 1.10"
                ))
            }
            "rule_set_ip_cidr_accept_empty" => {
                (env.warn)(format!("{p}: only meaningful for DNS rules; ignored"));
            }
            _ if let Some(&name) = UNSUPPORTED_KEYS.iter().find(|x| **x == k) => {
                (env.warn)(format!(
                    "{p}: Aether cannot evaluate {k} on its socks/http proxies; this condition \
                     never matches"
                ));
                r.push_item(Item::Never(name));
            }
            _ if ACTION_KEYS.contains(&k) && !env.headless => {}
            _ => (env.warn)(format!("{p}: unknown field ignored")),
        }
    }
    if have_domain {
        r.push_dst_addr(Item::Domain(DomainMatcher::new(&domains, &suffixes)));
    }
    if !rule_set_tags.is_empty() {
        let mut slots = Vec::new();
        for tag in &rule_set_tags {
            match (env.lookup_set)(tag) {
                Some(slot) => slots.push(slot),
                None => return Err(format!("{path}: rule-set not found: {tag}")),
            }
        }
        r.rule_set = Some(RuleSetRef {
            slots,
            match_source,
        });
    }
    // A rule with no conditions matches everything (sing-box accepts it as long as the rule
    // object says anything at all, such as `{"action": "sniff"}`); `{}` is refused by the caller.
    Ok(r)
}

#[cfg(test)]
mod tests;
