//! sunnyquic authentication: the client opens a bidirectional stream and sends
//! `Authenticate(SHA-256("username:password"))`, the 32-byte digest zero-padded to 64 bytes.
//! There is no answer. The server matches the hash against its users; a miss closes the whole
//! connection with application error 263, a hit lets the connection's requests through.
//!
//! Ported from shadowquic (MIT, Copyright (c) 2025 spongebob888), see LICENSE-shadowquic.

use std::collections::HashMap;

use super::proto::{Credential, AUTH_LEN};

/// The close code of a failed authentication, what upstream sends (as a real HTTP/3 server
/// would answer a stranger, by its comment).
pub const AUTH_FAILED: u32 = 263;

pub fn credential(username: &str, password: &str) -> Credential {
    let digest = ring::digest::digest(&ring::digest::SHA256, format!("{username}:{password}").as_bytes());
    let mut out = [0u8; AUTH_LEN];
    let d = digest.as_ref();
    out[..d.len()].copy_from_slice(d);
    out
}

/// The server's users, by credential.
#[derive(Clone, Debug, Default)]
pub struct Users(HashMap<Credential, String>);

impl Users {
    pub fn new<'a>(users: impl IntoIterator<Item = (&'a str, &'a str)>) -> Users {
        Users(users.into_iter().map(|(u, p)| (credential(u, p), u.to_string())).collect())
    }

    /// The user this credential is, if any.
    pub fn check(&self, c: &Credential) -> Option<&str> {
        self.0.get(c).map(String::as_str)
    }

    #[cfg(test)]
    pub fn len(&self) -> usize {
        self.0.len()
    }

    #[cfg(test)]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_credential_is_sha256_of_user_colon_password_zero_padded() {
        let c = credential("87654321", "12345678");
        let want = ring::digest::digest(&ring::digest::SHA256, b"87654321:12345678");
        assert_eq!(&c[..32], want.as_ref());
        assert!(c[32..].iter().all(|b| *b == 0));
        // a known value, so a change of the hashing shows up
        assert_eq!(hex::encode(&credential("a", "b")[..4]), "6783a31e");
    }

    #[test]
    fn users_accept_their_own_credential_only() {
        let users = Users::new([("alice", "wonderland"), ("bob", "builder")]);
        assert_eq!(users.len(), 2);
        assert_eq!(users.check(&credential("alice", "wonderland")), Some("alice"));
        assert_eq!(users.check(&credential("bob", "builder")), Some("bob"));
        assert_eq!(users.check(&credential("alice", "builder")), None);
        assert_eq!(users.check(&credential("alice:", "wonderland")), None);
        assert!(Users::new([]).is_empty());
    }
}
