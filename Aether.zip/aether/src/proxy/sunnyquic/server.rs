//! The sunnyquic server: accepts clients, checks their credential, and hands each tcp stream
//! and udp association to a `Handler` (Aether's router, or a test's direct dialler).
//!
//! Ported from shadowquic (MIT, Copyright (c) 2025 spongebob888), see LICENSE-shadowquic.

use std::io;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use bytes::Bytes;
use tokio::sync::{mpsc, watch};

use super::auth::{Users, AUTH_FAILED};
use super::proto::{Address, ExtError, Extension, Request};
use super::quic::ServerConfig;
use super::tcp::QuicStream;
use super::udp;

/// How long a request waits for its connection's authentication, as upstream waits.
const AUTH_WAIT: Duration = Duration::from_millis(3200);

/// A client's udp association: its packets come on `rx` as (payload, destination); answers go
/// on `tx` as (payload, source). Dropping both ends it.
pub struct UdpSession {
    pub rx: mpsc::Receiver<(Bytes, Address)>,
    pub tx: mpsc::Sender<(Bytes, Address)>,
}

/// Where the server's accepted traffic goes. Called on the connection's task: start the work
/// and return.
pub trait Handler: Send + Sync + 'static {
    fn tcp(&self, stream: QuicStream, dst: Address, peer: SocketAddr, user: &str);
    fn udp(&self, session: UdpSession, peer: SocketAddr, user: &str);
}

pub struct SunnyServer {
    endpoint: noq::Endpoint,
    users: Arc<Users>,
    zero_rtt: bool,
}

/// Who the connection authenticated as: `None` while unknown.
type Authed = watch::Receiver<Option<String>>;

async fn wait_auth(mut authed: Authed, limit: Option<Duration>) -> Option<String> {
    let wait = authed.wait_for(|a| a.is_some());
    let got = match limit {
        Some(t) => tokio::time::timeout(t, wait).await.ok()?,
        None => wait.await,
    };
    got.ok().and_then(|a| a.clone())
}

impl SunnyServer {
    pub fn bind(cfg: &ServerConfig) -> io::Result<SunnyServer> {
        let endpoint = noq::Endpoint::server(cfg.quic()?, cfg.listen)?;
        let users = Users::new(cfg.users.iter().map(|(u, p)| (u.as_str(), p.as_str())));
        Ok(SunnyServer { endpoint, users: Arc::new(users), zero_rtt: cfg.zero_rtt })
    }

    #[cfg(test)]
    pub fn local_addr(&self) -> io::Result<SocketAddr> {
        self.endpoint.local_addr()
    }

    /// Accept clients until the endpoint closes.
    pub async fn run(self, handler: Arc<dyn Handler>) {
        while let Some(incoming) = self.endpoint.accept().await {
            let peer = incoming.remote_address();
            let (users, handler, zero_rtt) = (self.users.clone(), handler.clone(), self.zero_rtt);
            tokio::spawn(async move {
                if let Err(e) = serve(incoming, peer, users, handler, zero_rtt).await {
                    log::debug!("[sunnyquic] {peer}: {e}");
                }
            });
        }
    }
}

async fn serve(incoming: noq::Incoming, peer: SocketAddr, users: Arc<Users>, handler: Arc<dyn Handler>, zero_rtt: bool) -> io::Result<()> {
    let connecting = incoming.accept().map_err(io::Error::other)?;
    let conn = if zero_rtt {
        match connecting.into_0rtt() {
            Ok((conn, _accepted)) => conn,
            Err(connecting) => connecting.await.map_err(io::Error::other)?,
        }
    } else {
        connecting.await.map_err(io::Error::other)?
    };
    log::debug!("[sunnyquic] accepted a connection from {peer}");
    let (set_authed, authed) = watch::channel(None::<String>);
    let set_authed = Arc::new(set_authed);
    let state = Arc::new(udp::State::default());
    {
        // udp only for an authenticated connection; a failed one is closed and this ends
        let (conn, state, authed) = (conn.clone(), state.clone(), authed.clone());
        tokio::spawn(async move {
            if wait_auth(authed, None).await.is_some() {
                let _ = udp::receive(conn, state).await;
            }
        });
    }
    loop {
        let (send, recv) = match conn.accept_bi().await {
            Ok(s) => s,
            Err(e) => {
                log::debug!("[sunnyquic] {peer}: connection ended: {e}");
                return Ok(());
            }
        };
        let ctx = Stream {
            conn: conn.clone(),
            peer,
            users: users.clone(),
            handler: handler.clone(),
            set_authed: set_authed.clone(),
            authed: authed.clone(),
            state: state.clone(),
        };
        tokio::spawn(async move {
            if let Err(e) = ctx.handle(send, recv).await {
                log::debug!("[sunnyquic] {peer}: stream: {e}");
            }
        });
    }
}

struct Stream {
    conn: noq::Connection,
    peer: SocketAddr,
    users: Arc<Users>,
    handler: Arc<dyn Handler>,
    set_authed: Arc<watch::Sender<Option<String>>>,
    authed: Authed,
    state: Arc<udp::State>,
}

impl Stream {
    async fn user(&self) -> io::Result<String> {
        wait_auth(self.authed.clone(), Some(AUTH_WAIT))
            .await
            .ok_or_else(|| io::Error::new(io::ErrorKind::PermissionDenied, "not authenticated in time"))
    }

    async fn handle(self, mut send: noq::SendStream, mut recv: noq::RecvStream) -> io::Result<()> {
        match Request::decode(&mut recv).await? {
            Request::Authenticate(c) => match self.users.check(&c) {
                Some(name) => {
                    log::debug!("[sunnyquic] {}: authenticated as {name}", self.peer);
                    let name = name.to_string();
                    self.set_authed.send_if_modified(|a| {
                        if a.is_some() {
                            return false;
                        }
                        *a = Some(name);
                        true
                    });
                }
                None => {
                    log::warn!("[sunnyquic] {}: wrong user or password, closing the connection", self.peer);
                    self.conn.close(AUTH_FAILED.into(), &[]);
                }
            },
            Request::Connect(dst) => {
                let user = self.user().await?;
                log::debug!("[sunnyquic] {} ({user}): tcp to {dst}", self.peer);
                self.handler.tcp(QuicStream { send, recv }, dst, self.peer, &user);
            }
            req @ (Request::AssociateOverDatagram(_) | Request::AssociateOverStream(_)) => {
                let user = self.user().await?;
                let over_stream = matches!(req, Request::AssociateOverStream(_));
                log::debug!("[sunnyquic] {} ({user}): udp association over {}", self.peer, if over_stream { "stream" } else { "datagram" });
                let (to_handler, rx) = mpsc::channel(256);
                let (tx, from_handler) = mpsc::channel(256);
                self.handler.udp(UdpSession { rx, tx }, self.peer, &user);
                udp::associate(&self.conn, &self.state, send, recv, from_handler, to_handler, over_stream).await?;
            }
            Request::Extension(ext) => {
                let user = self.user().await?;
                // no connection stats from noq and no user manager here: the answers of an
                // upstream server built the same way
                let err = match ext {
                    Extension::GetConnStats => ExtError::NotAvailable,
                    Extension::User(_) if !user.starts_with("admin") => ExtError::PermissionDenied,
                    Extension::User(_) => ExtError::NotAvailable,
                };
                let mut answer = Vec::new();
                err.encode_as_answer(&mut answer);
                send.write_all(&answer).await?;
                let _ = send.finish();
            }
            Request::Bind(dst) => {
                log::debug!("[sunnyquic] {}: bind {dst} is not supported", self.peer);
            }
        }
        Ok(())
    }
}
