//! Client against server on loopback: tcp, udp over datagrams and over streams, and a wrong
//! password.

use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

use noq::Runtime;
use tokio::io::{AsyncReadExt, AsyncWriteExt};

use super::*;

/// Echoes every stream and every datagram, answering a datagram from where it was sent to.
struct Echo;

impl Handler for Echo {
    fn tcp(&self, mut stream: QuicStream, _dst: Address, _peer: SocketAddr, _user: &str) {
        tokio::spawn(async move {
            let _ = tokio::io::copy(&mut stream.recv, &mut stream.send).await;
            let _ = stream.send.finish();
        });
    }

    fn udp(&self, mut session: UdpSession, _peer: SocketAddr, _user: &str) {
        tokio::spawn(async move {
            while let Some((data, dst)) = session.rx.recv().await {
                if session.tx.send((data, dst)).await.is_err() {
                    return;
                }
            }
        });
    }
}

/// A server's plain way out: tcp and udp straight to the destination, as upstream's `direct`
/// outbound does. For tests that need a sunnyquic server without Aether's router.
pub(crate) struct Direct;

async fn resolve(a: &Address) -> std::io::Result<SocketAddr> {
    match a.socket_addr() {
        Some(s) => Ok(s),
        None => tokio::net::lookup_host(a.to_string())
            .await?
            .next()
            .ok_or_else(|| std::io::Error::other(format!("{a} did not resolve"))),
    }
}

impl Handler for Direct {
    fn tcp(&self, mut stream: QuicStream, dst: Address, _peer: SocketAddr, _user: &str) {
        tokio::spawn(async move {
            let Ok(to) = resolve(&dst).await else { return };
            let Ok(mut up) = tokio::net::TcpStream::connect(to).await else { return };
            let _ = tokio::io::copy_bidirectional(&mut stream, &mut up).await;
        });
    }

    fn udp(&self, mut session: UdpSession, _peer: SocketAddr, _user: &str) {
        tokio::spawn(async move {
            let Ok(sock) = tokio::net::UdpSocket::bind("0.0.0.0:0").await else { return };
            let mut b = vec![0u8; 65536];
            loop {
                tokio::select! {
                    m = session.rx.recv() => {
                        let Some((data, dst)) = m else { return };
                        if let Ok(to) = resolve(&dst).await {
                            let _ = sock.send_to(&data, to).await;
                        }
                    }
                    r = sock.recv_from(&mut b) => {
                        let Ok((n, from)) = r else { return };
                        if session.tx.send((bytes::Bytes::copy_from_slice(&b[..n]), Address::from(from))).await.is_err() {
                            return;
                        }
                    }
                }
            }
        });
    }
}

async fn server(tag: &str) -> (SocketAddr, PathBuf) {
    let dir = crate::test_util::scratch(&format!("sq-proto-{tag}"));
    let (cert, key) = crate::test_util::self_signed(&dir);
    let mut cfg = ServerConfig::new("127.0.0.1:0".parse().unwrap(), cert.clone(), key);
    cfg.users = vec![("alice".into(), "wonderland".into()), ("bob".into(), "builder".into())];
    let server = SunnyServer::bind(&cfg).unwrap();
    let addr = server.local_addr().unwrap();
    tokio::spawn(server.run(Arc::new(Echo)));
    (addr, cert)
}

fn client(server: SocketAddr, ca: &std::path::Path, password: &str, over_stream: bool) -> SunnyClient {
    let mut cfg = ClientConfig::new("alice", password, server, "localhost");
    cfg.ca = Some(ca.to_path_buf());
    cfg.over_stream = over_stream;
    let sock = std::net::UdpSocket::bind("127.0.0.1:0").unwrap();
    let sock = noq::TokioRuntime.wrap_udp_socket(sock).unwrap();
    SunnyClient::new(cfg, sock).unwrap()
}

const T: Duration = Duration::from_secs(20);

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn tcp_and_both_udp_modes_round_trip() {
    let (addr, ca) = server("rt").await;
    for over_stream in [false, true] {
        let c = client(addr, &ca, "wonderland", over_stream);

        let mut s = tokio::time::timeout(T, c.open_tcp(&Address::new("example.com", 80))).await.unwrap().unwrap();
        let sent: Vec<u8> = (0..300_000).map(|i| (i % 251) as u8).collect();
        let (mut r, mut w) = tokio::io::split(&mut s);
        let to_send = sent.clone();
        let (_, got) = tokio::join!(async move { w.write_all(&to_send).await.unwrap() }, async move {
            let mut got = vec![0u8; 300_000];
            tokio::time::timeout(T, r.read_exact(&mut got)).await.unwrap().unwrap();
            got
        });
        assert!(got == sent, "tcp came back changed (over_stream {over_stream})");

        let mut a = c.associate_udp().await.unwrap();
        let dsts = [Address::new("10.1.2.3", 53), Address::new("dns.example", 853), Address::new("2001:db8::9", 5353)];
        for round in 0..3u8 {
            for d in &dsts {
                let payload = bytes::Bytes::from(vec![round; 900]);
                a.tx.send((payload.clone(), d.clone())).await.unwrap();
                let (data, from) = tokio::time::timeout(T, a.rx.recv()).await.expect("no udp echo").unwrap();
                assert_eq!((data, &from), (payload, d), "over_stream {over_stream}");
            }
        }
        // a second association on the same connection keeps its own ids apart
        let mut b = c.associate_udp().await.unwrap();
        b.tx.send((bytes::Bytes::from_static(b"second"), dsts[0].clone())).await.unwrap();
        let (data, _) = tokio::time::timeout(T, b.rx.recv()).await.unwrap().unwrap();
        assert_eq!(&data[..], b"second");
        drop(a);
        b.tx.send((bytes::Bytes::from_static(b"again"), dsts[1].clone())).await.unwrap();
        let (data, from) = tokio::time::timeout(T, b.rx.recv()).await.unwrap().unwrap();
        assert_eq!((&data[..], from), (&b"again"[..], dsts[1].clone()));
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_wrong_password_closes_the_connection_with_263() {
    let (addr, ca) = server("auth").await;
    let c = client(addr, &ca, "not-it", false);
    let conn = tokio::time::timeout(T, c.connection()).await.unwrap().unwrap();
    let reason = tokio::time::timeout(T, conn.quic.closed()).await.expect("the server kept the connection");
    match reason {
        noq::ConnectionError::ApplicationClosed(close) => assert_eq!(close.error_code, noq::VarInt::from_u32(auth::AUTH_FAILED)),
        other => panic!("closed otherwise: {other}"),
    }
    // the right password, on a new client, goes through
    let ok = client(addr, &ca, "wonderland", false);
    let mut s = tokio::time::timeout(T, ok.open_tcp(&Address::new("127.0.0.1", 1))).await.unwrap().unwrap();
    s.write_all(b"ping").await.unwrap();
    let mut b = [0u8; 4];
    tokio::time::timeout(T, s.read_exact(&mut b)).await.unwrap().unwrap();
    assert_eq!(&b, b"ping");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn extension_requests_get_upstream_answers() {
    let (addr, ca) = server("ext").await;
    let c = client(addr, &ca, "wonderland", false);
    let conn = tokio::time::timeout(T, c.connection()).await.unwrap().unwrap();
    for (ext, want) in [
        (proto::Extension::GetConnStats, proto::ExtError::NotAvailable),
        (proto::Extension::User(proto::UserOp::ListUsers), proto::ExtError::PermissionDenied),
    ] {
        let (mut send, mut recv) = conn.quic.open_bi().await.unwrap();
        let mut b = Vec::new();
        proto::Request::Extension(ext).encode(&mut b).unwrap();
        send.write_all(&b).await.unwrap();
        let got = tokio::time::timeout(T, proto::ExtError::decode_answer(&mut recv)).await.unwrap().unwrap();
        assert_eq!(got, Some(want));
    }
}
