//! The sunnyquic wire format, byte for byte as shadowquic writes it (`msgs/` there, derived by
//! its `SEncode`/`SDecode` macros): integers big-endian, an enum is its `repr` discriminant
//! followed by its one field, a `String` is a u32 length and its bytes, an address is a socks5
//! address (type byte, address, u16 port).
//!
//! Ported from shadowquic (MIT, Copyright (c) 2025 spongebob888), see LICENSE-shadowquic.

use std::fmt;
use std::io;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};

use tokio::io::{AsyncRead, AsyncReadExt};

pub const AUTH_LEN: usize = 64;
pub type Credential = [u8; AUTH_LEN];

const ATYP_V4: u8 = 0x01;
const ATYP_DOMAIN: u8 = 0x03;
const ATYP_V6: u8 = 0x04;

const REQ_CONNECT: u8 = 0x01;
const REQ_BIND: u8 = 0x02;
const REQ_ASSOCIATE_DATAGRAM: u8 = 0x03;
const REQ_ASSOCIATE_STREAM: u8 = 0x04;
const REQ_AUTHENTICATE: u8 = 0x05;
const REQ_EXTENSION: u8 = 0xFF;

const EXT_CONN: u64 = 0x1;
const EXT_USER: u64 = 0x2;

/// Strings and lists longer than this are a broken or hostile peer, not a request.
const MAX_FIELD: u32 = 1 << 20;

fn violation(what: impl fmt::Display) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, format!("sunnyquic: {what}"))
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum Host {
    V4(Ipv4Addr),
    V6(Ipv6Addr),
    Domain(String),
}

/// A socks5 address: where a stream or datagram goes, or where an answer came from.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct Address {
    pub host: Host,
    pub port: u16,
}

impl Address {
    /// An IP literal becomes an address, anything else a name the server resolves.
    pub fn new(host: &str, port: u16) -> Address {
        let host = match host.parse::<IpAddr>() {
            Ok(IpAddr::V4(ip)) => Host::V4(ip),
            Ok(IpAddr::V6(ip)) => Host::V6(ip),
            Err(_) => Host::Domain(host.to_string()),
        };
        Address { host, port }
    }

    pub fn socket_addr(&self) -> Option<SocketAddr> {
        match &self.host {
            Host::V4(ip) => Some(SocketAddr::new(IpAddr::V4(*ip), self.port)),
            Host::V6(ip) => Some(SocketAddr::new(IpAddr::V6(*ip), self.port)),
            Host::Domain(_) => None,
        }
    }

    pub fn unspecified() -> Address {
        Address { host: Host::V4(Ipv4Addr::UNSPECIFIED), port: 0 }
    }

    pub fn encode(&self, out: &mut Vec<u8>) -> io::Result<()> {
        match &self.host {
            Host::V4(ip) => {
                out.push(ATYP_V4);
                out.extend_from_slice(&ip.octets());
            }
            Host::V6(ip) => {
                out.push(ATYP_V6);
                out.extend_from_slice(&ip.octets());
            }
            Host::Domain(name) => {
                let len = u8::try_from(name.len()).map_err(|_| violation(format!("domain longer than 255 bytes: {name}")))?;
                out.push(ATYP_DOMAIN);
                out.push(len);
                out.extend_from_slice(name.as_bytes());
            }
        }
        out.extend_from_slice(&self.port.to_be_bytes());
        Ok(())
    }

    pub async fn decode<R: AsyncRead + Unpin>(r: &mut R) -> io::Result<Address> {
        let host = match r.read_u8().await? {
            ATYP_V4 => {
                let mut b = [0u8; 4];
                r.read_exact(&mut b).await?;
                Host::V4(Ipv4Addr::from(b))
            }
            ATYP_V6 => {
                let mut b = [0u8; 16];
                r.read_exact(&mut b).await?;
                Host::V6(Ipv6Addr::from(b))
            }
            ATYP_DOMAIN => {
                let len = r.read_u8().await? as usize;
                let mut b = vec![0u8; len];
                r.read_exact(&mut b).await?;
                Host::Domain(String::from_utf8(b).map_err(|_| violation("domain is not utf-8"))?)
            }
            other => return Err(violation(format!("unknown address type {other:#x}"))),
        };
        let port = r.read_u16().await?;
        Ok(Address { host, port })
    }
}

impl From<SocketAddr> for Address {
    fn from(a: SocketAddr) -> Address {
        let host = match a.ip() {
            IpAddr::V4(ip) => Host::V4(ip),
            IpAddr::V6(ip) => Host::V6(ip),
        };
        Address { host, port: a.port() }
    }
}

impl fmt::Display for Address {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match &self.host {
            Host::V4(ip) => write!(f, "{ip}:{}", self.port),
            Host::V6(ip) => write!(f, "[{ip}]:{}", self.port),
            Host::Domain(d) => write!(f, "{d}:{}", self.port),
        }
    }
}

fn put_string(out: &mut Vec<u8>, s: &str) {
    out.extend_from_slice(&(s.len() as u32).to_be_bytes());
    out.extend_from_slice(s.as_bytes());
}

async fn read_string<R: AsyncRead + Unpin>(r: &mut R) -> io::Result<String> {
    let len = r.read_u32().await?;
    if len > MAX_FIELD {
        return Err(violation(format!("string of {len} bytes")));
    }
    let mut b = vec![0u8; len as usize];
    r.read_exact(&mut b).await?;
    String::from_utf8(b).map_err(|_| violation("string is not utf-8"))
}

/// The user-management opcodes of the extension request (`ExtOpcodeUser`). Aether's server
/// has no user manager; it decodes them only to answer as an upstream server without one does.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum UserOp {
    AddUser { username: String, password: String },
    RemoveUser(String),
    ListUsers,
    GetUserStats(String),
    KillUserConn(String),
    GetAllStats,
    ClearUserStats(String),
    ClearAllStats,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Extension {
    GetConnStats,
    User(UserOp),
}

/// The first thing on every bidirectional stream (`SQReq`).
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Request {
    Connect(Address),
    Bind(Address),
    AssociateOverDatagram(Address),
    AssociateOverStream(Address),
    Authenticate(Box<Credential>),
    Extension(Extension),
}

impl Request {
    pub fn encode(&self, out: &mut Vec<u8>) -> io::Result<()> {
        match self {
            Request::Connect(a) => {
                out.push(REQ_CONNECT);
                a.encode(out)?;
            }
            Request::Bind(a) => {
                out.push(REQ_BIND);
                a.encode(out)?;
            }
            Request::AssociateOverDatagram(a) => {
                out.push(REQ_ASSOCIATE_DATAGRAM);
                a.encode(out)?;
            }
            Request::AssociateOverStream(a) => {
                out.push(REQ_ASSOCIATE_STREAM);
                a.encode(out)?;
            }
            Request::Authenticate(c) => {
                out.push(REQ_AUTHENTICATE);
                out.extend_from_slice(&c[..]);
            }
            Request::Extension(ext) => {
                out.push(REQ_EXTENSION);
                match ext {
                    Extension::GetConnStats => {
                        out.extend_from_slice(&EXT_CONN.to_be_bytes());
                        out.push(0x0);
                    }
                    Extension::User(op) => {
                        out.extend_from_slice(&EXT_USER.to_be_bytes());
                        match op {
                            UserOp::AddUser { username, password } => {
                                out.push(0x0);
                                put_string(out, username);
                                put_string(out, password);
                            }
                            UserOp::RemoveUser(u) => {
                                out.push(0x1);
                                put_string(out, u);
                            }
                            UserOp::ListUsers => out.push(0x2),
                            UserOp::GetUserStats(u) => {
                                out.push(0x3);
                                put_string(out, u);
                            }
                            UserOp::KillUserConn(u) => {
                                out.push(0x4);
                                put_string(out, u);
                            }
                            UserOp::GetAllStats => out.push(0x5),
                            UserOp::ClearUserStats(u) => {
                                out.push(0x6);
                                put_string(out, u);
                            }
                            UserOp::ClearAllStats => out.push(0x7),
                        }
                    }
                }
            }
        }
        Ok(())
    }

    pub async fn decode<R: AsyncRead + Unpin>(r: &mut R) -> io::Result<Request> {
        Ok(match r.read_u8().await? {
            REQ_CONNECT => Request::Connect(Address::decode(r).await?),
            REQ_BIND => Request::Bind(Address::decode(r).await?),
            REQ_ASSOCIATE_DATAGRAM => Request::AssociateOverDatagram(Address::decode(r).await?),
            REQ_ASSOCIATE_STREAM => Request::AssociateOverStream(Address::decode(r).await?),
            REQ_AUTHENTICATE => {
                let mut c = Box::new([0u8; AUTH_LEN]);
                r.read_exact(&mut c[..]).await?;
                Request::Authenticate(c)
            }
            REQ_EXTENSION => Request::Extension(match r.read_u64().await? {
                EXT_CONN => match r.read_u8().await? {
                    0x0 => Extension::GetConnStats,
                    other => return Err(violation(format!("unknown connection opcode {other:#x}"))),
                },
                EXT_USER => Extension::User(match r.read_u8().await? {
                    0x0 => UserOp::AddUser { username: read_string(r).await?, password: read_string(r).await? },
                    0x1 => UserOp::RemoveUser(read_string(r).await?),
                    0x2 => UserOp::ListUsers,
                    0x3 => UserOp::GetUserStats(read_string(r).await?),
                    0x4 => UserOp::KillUserConn(read_string(r).await?),
                    0x5 => UserOp::GetAllStats,
                    0x6 => UserOp::ClearUserStats(read_string(r).await?),
                    0x7 => UserOp::ClearAllStats,
                    other => return Err(violation(format!("unknown user opcode {other:#x}"))),
                }),
                other => return Err(violation(format!("unknown extension opcode {other:#x}"))),
            }),
            other => return Err(violation(format!("unknown request {other:#x}"))),
        })
    }
}

/// `SQExtError`, the error half of an extension's `Result` answer.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ExtError {
    NotAvailable,
    PermissionDenied,
    #[cfg_attr(not(test), expect(dead_code, reason = "the protocol's error set, as upstream defines it"))]
    NotFound,
    #[cfg_attr(not(test), expect(dead_code, reason = "the protocol's error set, as upstream defines it"))]
    Other(String),
}

impl ExtError {
    /// The whole answer `Err(self)`: tag 1, then the error.
    pub fn encode_as_answer(&self, out: &mut Vec<u8>) {
        out.push(1);
        match self {
            ExtError::NotAvailable => out.push(0x0),
            ExtError::PermissionDenied => out.push(0x1),
            ExtError::NotFound => out.push(0x2),
            ExtError::Other(s) => {
                out.push(0xFF);
                put_string(out, s);
            }
        }
    }

    #[cfg(test)]
    pub async fn decode_answer<R: AsyncRead + Unpin>(r: &mut R) -> io::Result<Option<ExtError>> {
        match r.read_u8().await? {
            0 => Ok(None),
            1 => Ok(Some(match r.read_u8().await? {
                0x0 => ExtError::NotAvailable,
                0x1 => ExtError::PermissionDenied,
                0x2 => ExtError::NotFound,
                0xFF => ExtError::Other(read_string(r).await?),
                other => return Err(violation(format!("unknown extension error {other:#x}"))),
            })),
            other => Err(violation(format!("bad result tag {other}"))),
        }
    }
}

/// Opens a udp destination on the association's control stream (`SQUdpControlHeader`): from
/// here on, datagrams carrying `id` are for (or from) `dst`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct UdpControl {
    pub dst: Address,
    pub id: u16,
}

impl UdpControl {
    pub fn encode(&self, out: &mut Vec<u8>) -> io::Result<()> {
        self.dst.encode(out)?;
        out.extend_from_slice(&self.id.to_be_bytes());
        Ok(())
    }

    pub async fn decode<R: AsyncRead + Unpin>(r: &mut R) -> io::Result<UdpControl> {
        let dst = Address::decode(r).await?;
        let id = r.read_u16().await?;
        Ok(UdpControl { dst, id })
    }
}

/// A QUIC datagram of an association: the u16 id (`SQPacketDatagramHeader`), then the payload.
pub fn datagram(id: u16, payload: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(2 + payload.len());
    out.extend_from_slice(&id.to_be_bytes());
    out.extend_from_slice(payload);
    out
}

pub fn split_datagram(d: &[u8]) -> io::Result<(u16, &[u8])> {
    if d.len() < 2 {
        return Err(violation("datagram shorter than its id"));
    }
    Ok((u16::from_be_bytes([d[0], d[1]]), &d[2..]))
}

#[cfg(test)]
mod tests {
    use super::*;

    async fn round_trip(req: Request) -> Vec<u8> {
        let mut b = Vec::new();
        req.encode(&mut b).unwrap();
        let mut r = &b[..];
        assert_eq!(Request::decode(&mut r).await.unwrap(), req);
        assert!(r.is_empty(), "{req:?} left bytes behind");
        b
    }

    #[tokio::test]
    async fn requests_round_trip_with_shadowquic_bytes() {
        let v4 = Address::new("1.2.3.4", 0x1f90);
        assert_eq!(round_trip(Request::Connect(v4.clone())).await, [1, 1, 1, 2, 3, 4, 0x1f, 0x90]);
        let name = Address::new("example.com", 443);
        let b = round_trip(Request::AssociateOverDatagram(name)).await;
        assert_eq!(&b[..3], &[3, 3, 11]);
        assert_eq!(&b[3..14], b"example.com");
        assert_eq!(&b[14..], &443u16.to_be_bytes());
        let v6 = Address::new("2001:db8::1", 53);
        let b = round_trip(Request::AssociateOverStream(v6)).await;
        assert_eq!((b[0], b[1], b.len()), (4, 4, 1 + 1 + 16 + 2));
        assert_eq!(round_trip(Request::Bind(v4)).await[0], 2);
        let b = round_trip(Request::Authenticate(Box::new([7u8; AUTH_LEN]))).await;
        assert_eq!((b[0], b.len()), (5, 1 + AUTH_LEN));
        assert_eq!(
            round_trip(Request::Extension(Extension::GetConnStats)).await,
            [0xFF, 0, 0, 0, 0, 0, 0, 0, 1, 0]
        );
        let b = round_trip(Request::Extension(Extension::User(UserOp::AddUser {
            username: "ab".into(),
            password: "c".into(),
        })))
        .await;
        assert_eq!(b, [0xFF, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 2, b'a', b'b', 0, 0, 0, 1, b'c']);
        for op in [
            UserOp::RemoveUser("x".into()),
            UserOp::ListUsers,
            UserOp::GetUserStats("x".into()),
            UserOp::KillUserConn("x".into()),
            UserOp::GetAllStats,
            UserOp::ClearUserStats("x".into()),
            UserOp::ClearAllStats,
        ] {
            round_trip(Request::Extension(Extension::User(op))).await;
        }
    }

    #[tokio::test]
    async fn broken_input_is_an_error() {
        for bad in [&[0x09u8][..], &[1, 2, 0, 0][..], &[1, 3, 2, 0xff, 0xfe, 0, 1][..], &[0xFF, 0, 0, 0, 0, 0, 0, 0, 9][..], &[5, 1, 2][..]] {
            let mut r = bad;
            assert!(Request::decode(&mut r).await.is_err(), "{bad:?}");
        }
        let mut b = Vec::new();
        assert!(Address::new(&"a".repeat(256), 1).encode(&mut b).is_err());
    }

    #[tokio::test]
    async fn udp_headers_and_answers() {
        let c = UdpControl { dst: Address::new("10.0.0.1", 53), id: 0x0102 };
        let mut b = Vec::new();
        c.encode(&mut b).unwrap();
        assert_eq!(b, [1, 10, 0, 0, 1, 0, 53, 1, 2]);
        assert_eq!(UdpControl::decode(&mut &b[..]).await.unwrap(), c);

        let d = datagram(7, b"hi");
        assert_eq!(d, [0, 7, b'h', b'i']);
        assert_eq!(split_datagram(&d).unwrap(), (7, &b"hi"[..]));
        assert!(split_datagram(&[1]).is_err());

        for e in [ExtError::NotAvailable, ExtError::PermissionDenied, ExtError::NotFound, ExtError::Other("no".into())] {
            let mut b = Vec::new();
            e.encode_as_answer(&mut b);
            assert_eq!(ExtError::decode_answer(&mut &b[..]).await.unwrap(), Some(e));
        }
        let mut b = Vec::new();
        ExtError::NotAvailable.encode_as_answer(&mut b);
        assert_eq!(b, [1, 0]);
    }
}
