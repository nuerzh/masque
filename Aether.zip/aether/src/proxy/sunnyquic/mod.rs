//! The sunnyquic protocol, client and server, on noq. Wire-compatible with shadowquic's
//! sunnyquic (spongebob888/shadowquic 4406bb2), from which it is ported (MIT, see
//! LICENSE-shadowquic): an Aether client works with an upstream server and an upstream
//! client with Aether's server.
//!
//! - `proto`: the frames (requests, addresses, udp headers, extension answers);
//! - `auth`: the credential and the server's users;
//! - `quic`: TLS, ALPN, 0-RTT, congestion control (`brutal`), MTU and the transport limits;
//! - `tcp`, `udp`: a proxied tcp stream, and udp associations over datagrams or streams;
//! - `client`, `server`.
//!
//! The users of it are `proxy::outbound::sunnyquic` (every sunnyquic outbound) and
//! `proxy::inbound::sunnyquic` (the server inbound).

pub mod auth;
mod brutal;
pub mod client;
pub mod proto;
pub mod quic;
pub mod server;
pub mod tcp;
pub mod udp;

pub use client::SunnyClient;
pub use proto::{Address, Host};
pub use quic::{ClientConfig, CongestionControl, ServerConfig};
pub use server::{Handler, SunnyServer, UdpSession};
pub use tcp::QuicStream;

#[cfg(test)]
pub(crate) mod tests;
