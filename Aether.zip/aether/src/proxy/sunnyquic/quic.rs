//! The QUIC side of sunnyquic on noq: TLS 1.3 (rustls, ring), ALPN, 0-RTT, congestion control,
//! MTU, and the transport limits, set as shadowquic's noq wrapper sets them, so either end
//! behaves towards an upstream peer as an upstream one would.
//!
//! Ported from shadowquic (MIT, Copyright (c) 2025 spongebob888), see LICENSE-shadowquic.

use std::io;
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

use noq::congestion::{Bbr3Config, CubicConfig, NewRenoConfig};
use noq::crypto::rustls::{QuicClientConfig, QuicServerConfig};
use noq::{MtuDiscoveryConfig, TransportConfig};
use rustls::crypto::ring as provider;
use rustls::pki_types::pem::PemObject;
use rustls::pki_types::{CertificateDer, PrivateKeyDer};
use serde::{de, Deserialize, Deserializer};

use super::brutal::BrutalConfig;

// shadowquic's windows: 4x quinn's defaults, sized for 100 ms at 100 Mbit/s and more
const WINDOW_BASE: u64 = 4 * 12_500_000 * 100 / 1000;
const STREAM_WINDOW: u64 = WINDOW_BASE;
const SEND_WINDOW: u64 = WINDOW_BASE * 8;
const DATAGRAM_WINDOW: u64 = WINDOW_BASE * 2;

pub const DEFAULT_INITIAL_MTU: u16 = 1300;
pub const DEFAULT_MIN_MTU: u16 = 1290;
/// Paths a server lets an upstream client open (multipath); upstream's default.
pub const DEFAULT_SERVER_PATHS: u32 = 12;

/// `congestion-control`: `bbr` (noq has BBRv3 only, so it is that), `bbr3`, `cubic`,
/// `new-reno`, or `{ brutal = { bandwidth = "100M", ... } }`.
#[derive(Deserialize, Default, Debug, Clone, PartialEq)]
#[serde(rename_all = "kebab-case")]
pub enum CongestionControl {
    #[default]
    Bbr,
    Cubic,
    #[serde(alias = "new_reno", alias = "newreno")]
    NewReno,
    Brutal(BrutalParams),
    Bbr3,
}

#[derive(Debug, Clone, Deserialize, PartialEq)]
#[serde(default, rename_all = "kebab-case", deny_unknown_fields)]
pub struct BrutalParams {
    /// the sending rate, bits per second; "30M" and "1.5G" count in 1024s, as upstream's do
    #[serde(deserialize_with = "deserialize_bps")]
    pub bandwidth: u64,
    pub min_window: u64,
    pub cwnd_gain: f64,
    pub min_ack_rate: f64,
    pub min_sample_count: u64,
    pub ack_compensate: bool,
}

impl Default for BrutalParams {
    fn default() -> Self {
        BrutalParams {
            bandwidth: 10_000_000,
            min_window: 16 * 1024,
            cwnd_gain: 1.10,
            min_ack_rate: 0.8,
            min_sample_count: 50,
            ack_compensate: false,
        }
    }
}

pub fn parse_bps(input: &str) -> Result<u64, String> {
    let s = input.trim();
    let (num, mul) = match s.as_bytes().last() {
        None => return Err("empty bandwidth string".into()),
        Some(b'K' | b'k') => (&s[..s.len() - 1], 1024f64),
        Some(b'M' | b'm') => (&s[..s.len() - 1], 1024f64 * 1024f64),
        Some(b'G' | b'g') => (&s[..s.len() - 1], 1024f64 * 1024f64 * 1024f64),
        Some(b'0'..=b'9') => (s, 1f64),
        _ => return Err(format!("invalid bandwidth suffix: {input}")),
    };
    let value: f64 = num.trim().parse().map_err(|_| format!("invalid bandwidth number: {input}"))?;
    if !value.is_finite() || value < 0.0 {
        return Err(format!("invalid bandwidth number: {input}"));
    }
    let bps = value * mul;
    if bps > u64::MAX as f64 {
        return Err(format!("bandwidth value overflow: {input}"));
    }
    Ok(bps.round() as u64)
}

fn deserialize_bps<'de, D: Deserializer<'de>>(d: D) -> Result<u64, D::Error> {
    struct Bps;
    impl de::Visitor<'_> for Bps {
        type Value = u64;
        fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
            f.write_str("an integer bps value or a string like \"30M\" or \"1.5G\"")
        }
        fn visit_u64<E: de::Error>(self, v: u64) -> Result<u64, E> {
            Ok(v)
        }
        fn visit_i64<E: de::Error>(self, v: i64) -> Result<u64, E> {
            u64::try_from(v).map_err(|_| E::custom("bandwidth must be non-negative"))
        }
        fn visit_f64<E: de::Error>(self, v: f64) -> Result<u64, E> {
            if !v.is_finite() || v < 0.0 {
                return Err(E::custom("bandwidth must be finite and non-negative"));
            }
            Ok(v.round() as u64)
        }
        fn visit_str<E: de::Error>(self, v: &str) -> Result<u64, E> {
            parse_bps(v).map_err(E::custom)
        }
    }
    d.deserialize_any(Bps)
}

/// `cipher-suite-preference`: TLS 1.3 suites in order. aes128-gcm is always added at the end
/// when missing: QUIC's Initial packets need it.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum CipherSuite {
    Aes128Gcm,
    Chacha20Poly1305,
    Aes256Gcm,
}

fn cipher_suites(prefs: &[CipherSuite]) -> Vec<rustls::SupportedCipherSuite> {
    let mut seen = Vec::new();
    for p in prefs {
        if !seen.contains(p) {
            seen.push(*p);
        }
    }
    if !seen.contains(&CipherSuite::Aes128Gcm) {
        log::warn!("[sunnyquic] cipher-suite-preference does not include aes128-gcm; appending it");
        seen.push(CipherSuite::Aes128Gcm);
    }
    seen.into_iter()
        .map(|s| match s {
            CipherSuite::Aes128Gcm => provider::cipher_suite::TLS13_AES_128_GCM_SHA256,
            CipherSuite::Chacha20Poly1305 => provider::cipher_suite::TLS13_CHACHA20_POLY1305_SHA256,
            CipherSuite::Aes256Gcm => provider::cipher_suite::TLS13_AES_256_GCM_SHA384,
        })
        .collect()
}

fn congestion(tp: &mut TransportConfig, cc: &CongestionControl) {
    match cc {
        CongestionControl::Cubic => tp.congestion_controller_factory(Arc::new(CubicConfig::default())),
        CongestionControl::NewReno => tp.congestion_controller_factory(Arc::new(NewRenoConfig::default())),
        CongestionControl::Bbr | CongestionControl::Bbr3 => tp.congestion_controller_factory(Arc::new(Bbr3Config::default())),
        CongestionControl::Brutal(b) => tp.congestion_controller_factory(Arc::new(BrutalConfig::new(
            b.bandwidth,
            b.min_window,
            b.cwnd_gain,
            b.min_ack_rate,
            b.min_sample_count,
            b.ack_compensate,
        ))),
    };
}

fn mtu_discovery(on: bool) -> Option<MtuDiscoveryConfig> {
    on.then(|| {
        let mut m = MtuDiscoveryConfig::default();
        m.black_hole_cooldown(Duration::from_secs(120));
        m.interval(Duration::from_secs(90));
        m
    })
}

fn tls_error(e: impl std::fmt::Display) -> io::Error {
    io::Error::other(format!("tls: {e}"))
}

/// A sunnyquic client: who it is, where the server is, and how its QUIC behaves.
#[derive(Debug, Clone)]
pub struct ClientConfig {
    pub username: String,
    pub password: String,
    pub server: SocketAddr,
    pub server_name: String,
    pub alpn: Vec<String>,
    /// trusted besides the system's roots
    pub ca: Option<PathBuf>,
    pub initial_mtu: u16,
    pub min_mtu: u16,
    pub congestion: CongestionControl,
    pub zero_rtt: bool,
    /// udp over unidirectional streams instead of datagrams
    pub over_stream: bool,
    /// 0: no keep-alive
    pub keep_alive_ms: u32,
    pub gso: bool,
    pub mtu_discovery: bool,
    pub cipher_suites: Option<Vec<CipherSuite>>,
}

impl ClientConfig {
    #[cfg(test)]
    pub fn new(username: &str, password: &str, server: SocketAddr, server_name: &str) -> ClientConfig {
        ClientConfig {
            username: username.into(),
            password: password.into(),
            server,
            server_name: server_name.into(),
            alpn: vec!["h3".into()],
            ca: None,
            initial_mtu: DEFAULT_INITIAL_MTU,
            min_mtu: DEFAULT_MIN_MTU,
            congestion: CongestionControl::Bbr,
            zero_rtt: true,
            over_stream: false,
            keep_alive_ms: 0,
            gso: true,
            mtu_discovery: true,
            cipher_suites: None,
        }
    }

    pub(super) fn quic(&self) -> io::Result<noq::ClientConfig> {
        let mut roots = rustls::RootCertStore::empty();
        let native = rustls_native_certs::load_native_certs();
        roots.add_parsable_certificates(native.certs);
        if let Some(path) = &self.ca {
            let certs: Vec<_> = CertificateDer::pem_file_iter(path)
                .map_err(|e| io::Error::other(format!("ca {}: {e}", path.display())))?
                .filter_map(|c| c.ok())
                .collect();
            let (added, _) = roots.add_parsable_certificates(certs);
            if added == 0 {
                return Err(io::Error::other(format!("ca {}: no certificate in it", path.display())));
            }
        }
        let mut p = provider::default_provider();
        if let Some(prefs) = &self.cipher_suites {
            p.cipher_suites = cipher_suites(prefs);
        }
        let mut tls = rustls::ClientConfig::builder_with_provider(Arc::new(p))
            .with_protocol_versions(&[&rustls::version::TLS13])
            .map_err(tls_error)?
            .with_root_certificates(roots)
            .with_no_client_auth();
        tls.alpn_protocols = self.alpn.iter().map(|a| a.as_bytes().to_vec()).collect();
        tls.enable_early_data = self.zero_rtt;

        let mut tp = TransportConfig::default();
        tp.max_concurrent_bidi_streams(500u32.into())
            .max_concurrent_uni_streams(500u32.into())
            .mtu_discovery_config(mtu_discovery(self.mtu_discovery))
            .min_mtu(self.min_mtu)
            .enable_segmentation_offload(self.gso)
            .initial_mtu(self.initial_mtu);
        // only the receive side is widened, for download speed, as upstream does
        tp.stream_receive_window(noq::VarInt::from_u64(STREAM_WINDOW).expect("a small window"));
        tp.datagram_receive_buffer_size(Some(DATAGRAM_WINDOW as usize));
        tp.keep_alive_interval((self.keep_alive_ms > 0).then(|| Duration::from_millis(self.keep_alive_ms as u64)));
        congestion(&mut tp, &self.congestion);

        let mut cfg = noq::ClientConfig::new(Arc::new(QuicClientConfig::try_from(tls).map_err(tls_error)?));
        cfg.transport_config(Arc::new(tp));
        Ok(cfg)
    }
}

/// A sunnyquic server.
#[derive(Debug, Clone)]
pub struct ServerConfig {
    pub listen: SocketAddr,
    /// (username, password)
    pub users: Vec<(String, String)>,
    pub cert_path: PathBuf,
    pub key_path: PathBuf,
    pub alpn: Vec<String>,
    pub zero_rtt: bool,
    pub congestion: CongestionControl,
    pub initial_mtu: u16,
    pub min_mtu: u16,
    pub gso: bool,
    pub mtu_discovery: bool,
    pub max_paths: u32,
}

impl ServerConfig {
    pub fn new(listen: SocketAddr, cert_path: PathBuf, key_path: PathBuf) -> ServerConfig {
        ServerConfig {
            listen,
            users: Vec::new(),
            cert_path,
            key_path,
            alpn: vec!["h3".into()],
            zero_rtt: true,
            congestion: CongestionControl::Bbr,
            initial_mtu: DEFAULT_INITIAL_MTU,
            min_mtu: DEFAULT_MIN_MTU,
            gso: true,
            mtu_discovery: true,
            max_paths: DEFAULT_SERVER_PATHS,
        }
    }

    pub(super) fn quic(&self) -> io::Result<noq::ServerConfig> {
        let certs: Vec<CertificateDer<'static>> = CertificateDer::pem_file_iter(&self.cert_path)
            .map_err(|e| io::Error::other(format!("certificate {}: {e}", self.cert_path.display())))?
            .filter_map(|c| c.ok())
            .collect();
        if certs.is_empty() {
            return Err(io::Error::other(format!("certificate {}: no certificate in it", self.cert_path.display())));
        }
        let key = PrivateKeyDer::from_pem_file(&self.key_path)
            .map_err(|e| io::Error::other(format!("key {}: {e}", self.key_path.display())))?;
        let mut tls = rustls::ServerConfig::builder_with_provider(Arc::new(provider::default_provider()))
            .with_protocol_versions(&[&rustls::version::TLS13])
            .map_err(tls_error)?
            .with_no_client_auth()
            .with_single_cert(certs, key)
            .map_err(tls_error)?;
        tls.alpn_protocols = self.alpn.iter().map(|a| a.as_bytes().to_vec()).collect();
        tls.max_early_data_size = if self.zero_rtt { u32::MAX } else { 0 };
        tls.send_half_rtt_data = self.zero_rtt;

        let mut tp = TransportConfig::default();
        tp.max_concurrent_bidi_streams(1000u32.into())
            .max_concurrent_uni_streams(1000u32.into())
            .mtu_discovery_config(mtu_discovery(self.mtu_discovery))
            .min_mtu(self.min_mtu)
            .enable_segmentation_offload(self.gso)
            .initial_mtu(self.initial_mtu);
        congestion(&mut tp, &self.congestion);
        tp.send_window(SEND_WINDOW);
        tp.stream_receive_window(noq::VarInt::from_u64(STREAM_WINDOW).expect("a small window"));
        tp.datagram_send_buffer_size(DATAGRAM_WINDOW as usize);
        tp.datagram_receive_buffer_size(Some(DATAGRAM_WINDOW as usize));
        tp.max_concurrent_multipath_paths(self.max_paths);

        let mut cfg = noq::ServerConfig::with_crypto(Arc::new(QuicServerConfig::try_from(tls).map_err(tls_error)?));
        cfg.transport_config(Arc::new(tp));
        Ok(cfg)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn congestion_names_and_brutal_read_as_upstream_writes_them() {
        let cc = |v: serde_json::Value| serde_json::from_value::<CongestionControl>(v);
        assert_eq!(cc("bbr".into()).unwrap(), CongestionControl::Bbr);
        assert_eq!(cc("cubic".into()).unwrap(), CongestionControl::Cubic);
        assert_eq!(cc("new-reno".into()).unwrap(), CongestionControl::NewReno);
        assert_eq!(cc("new_reno".into()).unwrap(), CongestionControl::NewReno);
        assert_eq!(cc("bbr3".into()).unwrap(), CongestionControl::Bbr3);
        assert!(cc("vegas".into()).is_err());
        match cc(serde_json::json!({"brutal": {"bandwidth": "1.5G", "cwnd-gain": 2.0}})).unwrap() {
            CongestionControl::Brutal(b) => {
                assert_eq!(b.bandwidth, (1.5 * 1024.0 * 1024.0 * 1024.0) as u64);
                assert_eq!(b.cwnd_gain, 2.0);
                assert_eq!(b.min_window, 16 * 1024);
            }
            other => panic!("{other:?}"),
        }
        assert!(cc(serde_json::json!({"brutal": {"bandwith": 1}})).is_err());
        assert_eq!(parse_bps("30M"), Ok(30 * 1024 * 1024));
        assert_eq!(parse_bps("1000"), Ok(1000));
        assert!(parse_bps("-1").is_err() && parse_bps("10x").is_err() && parse_bps("").is_err());
    }

    #[test]
    fn aes128_gcm_is_always_offered() {
        let s = cipher_suites(&[CipherSuite::Chacha20Poly1305, CipherSuite::Aes256Gcm, CipherSuite::Chacha20Poly1305]);
        assert_eq!(s.len(), 3);
        assert_eq!(s[2], provider::cipher_suite::TLS13_AES_128_GCM_SHA256);
        assert_eq!(cipher_suites(&[CipherSuite::Aes128Gcm]).len(), 1);
    }

    #[test]
    fn configs_build_and_a_missing_certificate_is_named() {
        let mut c = ClientConfig::new("u", "p", "127.0.0.1:1".parse().unwrap(), "localhost");
        c.cipher_suites = Some(vec![CipherSuite::Chacha20Poly1305]);
        c.congestion = CongestionControl::Brutal(BrutalParams::default());
        c.quic().unwrap();
        c.ca = Some("/nonexistent/ca.pem".into());
        assert!(c.quic().unwrap_err().to_string().contains("/nonexistent/ca.pem"));
        let s = ServerConfig::new("127.0.0.1:0".parse().unwrap(), "/nonexistent/c.pem".into(), "/nonexistent/k.pem".into());
        assert!(s.quic().unwrap_err().to_string().contains("/nonexistent/c.pem"));
    }
}
