//! The sunnyquic client: one QUIC connection to the server at a time, on a socket the caller
//! hands over (an OS udp socket, or Aether's `TunnelSocket` inside the WARP tunnel), dialled on
//! first use and again once it has closed.
//!
//! Ported from shadowquic (MIT, Copyright (c) 2025 spongebob888), see LICENSE-shadowquic.

use std::io;
use std::sync::Arc;

use bytes::Bytes;
use tokio::sync::mpsc;

use super::auth::credential;
use super::proto::{Address, Request};
use super::quic::ClientConfig;
use super::tcp::QuicStream;
use super::udp;

/// One connection to the server, authenticated (the request is sent; the server answers a
/// wrong one by closing the connection).
#[derive(Clone)]
pub struct Conn {
    pub quic: noq::Connection,
    udp: Arc<udp::State>,
}

impl Conn {
    pub fn is_closed(&self) -> bool {
        self.quic.close_reason().is_some()
    }
}

/// A udp association through the server: send (payload, destination) on `tx`, answers come on
/// `rx` as (payload, source). Dropping it ends the association.
pub struct Association {
    pub tx: mpsc::Sender<(Bytes, Address)>,
    pub rx: mpsc::Receiver<(Bytes, Address)>,
    task: tokio::task::AbortHandle,
}

impl Drop for Association {
    fn drop(&mut self) {
        self.task.abort();
    }
}

pub struct SunnyClient {
    cfg: ClientConfig,
    quic: noq::ClientConfig,
    socket: parking_lot::Mutex<Option<Box<dyn noq::AsyncUdpSocket>>>,
    endpoint: tokio::sync::OnceCell<noq::Endpoint>,
    conn: tokio::sync::Mutex<Option<Conn>>,
}

fn other(e: impl std::fmt::Display) -> io::Error {
    io::Error::other(e.to_string())
}

impl SunnyClient {
    /// The TLS and transport settings are made here, so a bad CA file or cipher list fails now.
    pub fn new(cfg: ClientConfig, socket: Box<dyn noq::AsyncUdpSocket>) -> io::Result<SunnyClient> {
        Ok(SunnyClient {
            quic: cfg.quic()?,
            cfg,
            socket: parking_lot::Mutex::new(Some(socket)),
            endpoint: tokio::sync::OnceCell::new(),
            conn: tokio::sync::Mutex::new(None),
        })
    }

    async fn endpoint(&self) -> io::Result<&noq::Endpoint> {
        self.endpoint
            .get_or_try_init(|| async {
                let socket = self.socket.lock().take().ok_or_else(|| other("sunnyquic: the endpoint's socket is gone"))?;
                let runtime = noq::default_runtime().ok_or_else(|| other("sunnyquic: no async runtime"))?;
                let ep = noq::Endpoint::new_with_abstract_socket(noq::EndpointConfig::default(), None, socket, runtime)?;
                ep.set_default_client_config(self.quic.clone());
                Ok::<_, io::Error>(ep)
            })
            .await
    }

    /// The connection, dialled now when there is none or the last one closed. Concurrent
    /// callers share one dial.
    pub async fn connection(&self) -> io::Result<Conn> {
        let mut current = self.conn.lock().await;
        if let Some(c) = current.as_ref() {
            if !c.is_closed() {
                return Ok(c.clone());
            }
            log::info!("[sunnyquic] connection to {} closed: {}", self.cfg.server, c.quic.close_reason().map(|r| r.to_string()).unwrap_or_default());
        }
        let c = self.dial().await?;
        *current = Some(c.clone());
        Ok(c)
    }

    async fn dial(&self) -> io::Result<Conn> {
        let ep = self.endpoint().await?;
        let connecting = ep.connect(self.cfg.server, &self.cfg.server_name).map_err(other)?;
        let quic = if self.cfg.zero_rtt {
            match connecting.into_0rtt() {
                Ok((conn, accepted)) => {
                    tokio::spawn(async move { log::debug!("[sunnyquic] 0-rtt accepted: {}", accepted.await) });
                    conn
                }
                Err(connecting) => connecting.await.map_err(other)?,
            }
        } else {
            connecting.await.map_err(other)?
        };
        let (mut send, _recv) = quic.open_bi().await.map_err(other)?;
        let mut head = Vec::new();
        Request::Authenticate(Box::new(credential(&self.cfg.username, &self.cfg.password))).encode(&mut head)?;
        send.write_all(&head).await?;
        let _ = send.finish();
        let conn = Conn { quic, udp: Arc::default() };
        let (q, state) = (conn.quic.clone(), conn.udp.clone());
        tokio::spawn(async move {
            if let Err(e) = udp::receive(q, state).await {
                log::debug!("[sunnyquic] incoming udp ended: {e}");
            }
        });
        Ok(conn)
    }

    /// A tcp connection to `dst` through the server.
    pub async fn open_tcp(&self, dst: &Address) -> io::Result<QuicStream> {
        let conn = self.connection().await?;
        let (mut send, recv) = conn.quic.open_bi().await.map_err(other)?;
        let mut head = Vec::new();
        Request::Connect(dst.clone()).encode(&mut head)?;
        send.write_all(&head).await?;
        Ok(QuicStream { send, recv })
    }

    /// A udp association, over datagrams or streams as the config says.
    pub async fn associate_udp(&self) -> io::Result<Association> {
        let conn = self.connection().await?;
        let (mut send, recv) = conn.quic.open_bi().await.map_err(other)?;
        let over_stream = self.cfg.over_stream;
        let bind = Address::unspecified();
        let req = if over_stream { Request::AssociateOverStream(bind) } else { Request::AssociateOverDatagram(bind) };
        let mut head = Vec::new();
        req.encode(&mut head)?;
        send.write_all(&head).await?;
        let (tx, local) = mpsc::channel(256);
        let (sink, rx) = mpsc::channel(256);
        let task = tokio::spawn(async move {
            if let Err(e) = udp::associate(&conn.quic, &conn.udp, send, recv, local, sink, over_stream).await {
                log::debug!("[sunnyquic] udp association ended: {e}");
            }
        });
        Ok(Association { tx, rx, task: task.abort_handle() })
    }
}
