//! UDP over a sunnyquic connection, the same at both ends.
//!
//! An association is a bidirectional stream opened by the client with `AssociateOverDatagram`
//! or `AssociateOverStream`. Each side, for each new peer address it sends to (the client) or
//! answers from (the server), takes a u16 id unique on the connection and writes
//! `UdpControl { dst, id }` on its half of that stream. The packets then go
//!
//! - over datagram: one QUIC datagram each, `id ++ payload`;
//! - over stream: one unidirectional stream per address, `id`, then `len (u16) ++ payload`
//!   for every packet.
//!
//! Ids are per direction: what a side sends uses its own ids, what it receives is named by the
//! peer's. A datagram whose control header has not arrived yet waits for it.
//!
//! Ported from shadowquic (MIT, Copyright (c) 2025 spongebob888), see LICENSE-shadowquic.

use std::collections::{HashMap, HashSet};
use std::io;
use std::sync::atomic::{AtomicU16, Ordering};
use std::sync::Arc;

use bytes::Bytes;
use parking_lot::Mutex;
use tokio::io::AsyncReadExt;
use tokio::sync::{mpsc, watch};

use super::proto::{self, Address, UdpControl};

/// Where received packets of an association go: (payload, the address it is from or for).
pub type Sink = mpsc::Sender<(Bytes, Address)>;

/// Packets held for an id whose control header is still on its way.
const PENDING_LIMIT: usize = 64;

enum Slot {
    Ready(Sink, Address),
    Pending { buffer: Vec<Bytes>, ready: watch::Sender<()> },
}

/// The udp state of one connection.
#[derive(Default)]
pub struct State {
    next_id: AtomicU16,
    sending: Mutex<HashSet<u16>>,
    receiving: Mutex<HashMap<u16, Slot>>,
}

impl State {
    fn take_id(&self) -> u16 {
        let mut ids = self.sending.lock();
        loop {
            let id = self.next_id.fetch_add(1, Ordering::Relaxed);
            if ids.insert(id) {
                return id;
            }
        }
    }

    async fn feed(&self, id: u16, packet: Bytes) {
        let ready = {
            let mut slots = self.receiving.lock();
            match slots.get_mut(&id) {
                Some(Slot::Ready(sink, addr)) => Some((sink.clone(), addr.clone())),
                Some(Slot::Pending { buffer, .. }) => {
                    if buffer.len() < PENDING_LIMIT {
                        buffer.push(packet.clone());
                    }
                    None
                }
                None => {
                    let (ready, _) = watch::channel(());
                    slots.insert(id, Slot::Pending { buffer: vec![packet.clone()], ready });
                    None
                }
            }
        };
        if let Some((sink, addr)) = ready {
            let _ = sink.send((packet, addr)).await;
        }
    }

    async fn open(&self, id: u16, sink: Sink, dst: Address) {
        let held = {
            let mut slots = self.receiving.lock();
            match slots.insert(id, Slot::Ready(sink.clone(), dst.clone())) {
                Some(Slot::Pending { buffer, ready }) => {
                    let _ = ready.send(());
                    buffer
                }
                Some(old @ Slot::Ready(..)) => {
                    log::warn!("[sunnyquic] udp id {id} opened twice; the first stays");
                    slots.insert(id, old);
                    Vec::new()
                }
                None => Vec::new(),
            }
        };
        for p in held {
            let _ = sink.send((p, dst.clone())).await;
        }
    }

    /// The sink and address of `id`, once its control header is in. An error when the
    /// association it belonged to ended first.
    async fn wait(&self, id: u16) -> io::Result<(Sink, Address)> {
        let mut rx = {
            let mut slots = self.receiving.lock();
            match slots.get(&id) {
                Some(Slot::Ready(sink, addr)) => return Ok((sink.clone(), addr.clone())),
                Some(Slot::Pending { ready, .. }) => ready.subscribe(),
                None => {
                    let (ready, rx) = watch::channel(());
                    slots.insert(id, Slot::Pending { buffer: Vec::new(), ready });
                    rx
                }
            }
        };
        let closed = || io::Error::other(format!("udp id {id}: its association ended"));
        rx.changed().await.map_err(|_| closed())?;
        match self.receiving.lock().get(&id) {
            Some(Slot::Ready(sink, addr)) => Ok((sink.clone(), addr.clone())),
            _ => Err(closed()),
        }
    }
}

/// Ids an association took, given back when it ends.
struct Taken<'a> {
    state: &'a State,
    sent: Vec<u16>,
    received: HashSet<u16>,
}

impl Drop for Taken<'_> {
    fn drop(&mut self) {
        let mut s = self.state.sending.lock();
        for id in &self.sent {
            s.remove(id);
        }
        drop(s);
        let mut r = self.state.receiving.lock();
        for id in &self.received {
            r.remove(id);
        }
    }
}

/// Run one association: packets from `local` go to the peer, packets from the peer (named by
/// the control headers on `ctrl_recv`) go to `sink`. Returns when the local side closes
/// `local` or the peer ends the stream.
pub async fn associate(
    conn: &noq::Connection,
    state: &State,
    ctrl_send: noq::SendStream,
    ctrl_recv: noq::RecvStream,
    local: mpsc::Receiver<(Bytes, Address)>,
    sink: Sink,
    over_stream: bool,
) -> io::Result<()> {
    // two loops side by side, never one select: a control header half read must not be dropped
    tokio::select! {
        r = send_side(conn, state, ctrl_send, local, over_stream) => r,
        r = receive_side(state, ctrl_recv, sink) => r,
    }
}

async fn send_side(
    conn: &noq::Connection,
    state: &State,
    mut ctrl_send: noq::SendStream,
    mut local: mpsc::Receiver<(Bytes, Address)>,
    over_stream: bool,
) -> io::Result<()> {
    let mut taken = Taken { state, sent: Vec::new(), received: HashSet::new() };
    let mut ids: HashMap<Address, u16> = HashMap::new();
    let mut unis: HashMap<Address, noq::SendStream> = HashMap::new();
    while let Some((data, dst)) = local.recv().await {
        let (id, new) = match ids.get(&dst) {
            Some(id) => (*id, false),
            None => {
                let id = state.take_id();
                taken.sent.push(id);
                ids.insert(dst.clone(), id);
                (id, true)
            }
        };
        if over_stream && !unis.contains_key(&dst) {
            unis.insert(dst.clone(), conn.open_uni().await.map_err(io::Error::other)?);
        }
        if new {
            // before any packet with the id, or the peer holds packets it cannot place
            let mut head = Vec::new();
            UdpControl { dst: dst.clone(), id }.encode(&mut head)?;
            ctrl_send.write_all(&head).await?;
        }
        if over_stream {
            let Ok(len) = u16::try_from(data.len()) else { continue };
            let uni = unis.get_mut(&dst).expect("opened above");
            let mut head = Vec::with_capacity(4);
            if new {
                head.extend_from_slice(&id.to_be_bytes());
            }
            head.extend_from_slice(&len.to_be_bytes());
            uni.write_all(&head).await?;
            uni.write_all(&data).await?;
        } else {
            match conn.send_datagram(Bytes::from(proto::datagram(id, &data))) {
                Ok(()) => {}
                Err(noq::SendDatagramError::TooLarge) => log::debug!(
                    "[sunnyquic] udp packet of {} bytes to {dst} is larger than a datagram ({:?}), dropped",
                    data.len(),
                    conn.max_datagram_size()
                ),
                Err(e) => return Err(io::Error::other(e)),
            }
        }
    }
    Ok(())
}

async fn receive_side(state: &State, mut ctrl_recv: noq::RecvStream, sink: Sink) -> io::Result<()> {
    let mut taken = Taken { state, sent: Vec::new(), received: HashSet::new() };
    loop {
        let c = match UdpControl::decode(&mut ctrl_recv).await {
            Ok(c) => c,
            Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => return Ok(()),
            Err(e) => return Err(e),
        };
        if taken.received.insert(c.id) {
            state.open(c.id, sink.clone(), c.dst).await;
        }
    }
}

/// The connection's incoming udp: datagrams, and the unidirectional streams of associations
/// over stream. Runs until the connection closes.
pub async fn receive(conn: noq::Connection, state: Arc<State>) -> io::Result<()> {
    loop {
        tokio::select! {
            d = conn.read_datagram() => {
                let d = d.map_err(io::Error::other)?;
                match proto::split_datagram(&d) {
                    Ok((id, _)) => state.feed(id, d.slice(2..)).await,
                    Err(e) => log::debug!("[sunnyquic] {e}"),
                }
            }
            u = conn.accept_uni() => {
                let mut uni = u.map_err(io::Error::other)?;
                let state = state.clone();
                tokio::spawn(async move {
                    let work = async {
                        let id = uni.read_u16().await?;
                        let (sink, addr) = state.wait(id).await?;
                        loop {
                            let len = uni.read_u16().await? as usize;
                            let mut b = vec![0u8; len];
                            AsyncReadExt::read_exact(&mut uni, &mut b).await?;
                            if sink.send((Bytes::from(b), addr.clone())).await.is_err() {
                                return Ok(());
                            }
                        }
                    };
                    let r: io::Result<()> = work.await;
                    if let Err(e) = r {
                        if e.kind() != io::ErrorKind::UnexpectedEof {
                            log::debug!("[sunnyquic] udp stream: {e}");
                        }
                    }
                });
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn packets_before_their_control_header_wait_for_it() {
        let state = State::default();
        let (sink, mut got) = mpsc::channel(8);
        state.feed(3, Bytes::from_static(b"early")).await;
        let dst = Address::new("10.0.0.1", 53);
        state.open(3, sink.clone(), dst.clone()).await;
        assert_eq!(got.recv().await.unwrap(), (Bytes::from_static(b"early"), dst.clone()));
        state.feed(3, Bytes::from_static(b"late")).await;
        assert_eq!(got.recv().await.unwrap(), (Bytes::from_static(b"late"), dst.clone()));
        assert_eq!(state.wait(3).await.unwrap().1, dst);
    }

    #[tokio::test]
    async fn a_waiting_stream_is_told_when_its_association_ends() {
        let state = Arc::new(State::default());
        let s = state.clone();
        let waiter = tokio::spawn(async move { s.wait(9).await.map(|(_, a)| a) });
        tokio::task::yield_now().await;
        {
            let taken = Taken { state: &state, sent: Vec::new(), received: HashSet::from([9]) };
            drop(taken);
        }
        assert!(waiter.await.unwrap().is_err());
    }

    #[test]
    fn ids_are_unique_while_taken_and_reused_after() {
        let state = State::default();
        let a = state.take_id();
        let b = state.take_id();
        assert_ne!(a, b);
        state.next_id.store(a, Ordering::Relaxed);
        assert_ne!(state.take_id(), a, "a taken id is skipped");
        drop(Taken { state: &state, sent: vec![a], received: HashSet::new() });
        state.next_id.store(a, Ordering::Relaxed);
        assert_eq!(state.take_id(), a);
    }
}
