//! One routed connection or flow, from whichever inbound: sniffing, the rules, resolving for
//! them, the verdict, and the relay to the chosen outbound.

use super::prelude::*;

pub(crate) fn target_host(t: &Target) -> String {
    match t {
        Target::Domain(d) => d.clone(),
        Target::Ip(ip) => ip.to_string(),
    }
}

/// Resolve a name for the `resolve` action.
pub(crate) async fn resolve_for_rules(name: &str, opts: &ResolveOpts, exit: &Exit) -> Vec<IpAddr> {
    let work = async {
        match opts.resolver {
            // Aether's resolver inside the WARP tunnel; with no WARP stack (off, or not up
            // yet) nothing is resolved rather than asking the local network instead
            Resolver::Tunnel => match exit.stack() {
                Some(stack) => resolve_in_tunnel(&stack, name, opts.strategy).await,
                None => {
                    log::debug!("[route] resolve {name}: no WARP tunnel to resolve through");
                    Vec::new()
                }
            },
            // this machine's resolver (in TUN mode: over the physical interface, never the TUN)
            Resolver::Local => lookup_egress(name, 0)
                .await
                .map(|it| it.into_iter().map(|a| a.ip()).collect::<Vec<_>>())
                .unwrap_or_default(),
        }
    };
    let found = tokio::time::timeout(opts.timeout, work).await.unwrap_or_default();
    opts.order(found)
}

pub(crate) async fn resolve_in_tunnel(stack: &StackHandle, name: &str, strategy: Strategy) -> Vec<IpAddr> {
    let Ok(udp) = stack.open_udp().await else {
        return Vec::new();
    };
    let (sender, mut rx) = udp.into_split();
    let order: &[u16] = match strategy {
        Strategy::Ipv4Only => &[QTYPE_A],
        Strategy::Ipv6Only => &[QTYPE_AAAA],
        Strategy::PreferIpv6 => &[QTYPE_AAAA, QTYPE_A],
        _ => &[QTYPE_A, QTYPE_AAAA],
    };
    let mut out = Vec::new();
    for qtype in order {
        match dns_exchange(&sender, &mut rx, name, *qtype).await {
            Ok(DnsAnswer::Found(ip)) => {
                out.push(ip);
                if !matches!(strategy, Strategy::AsIs) {
                    break;
                }
            }
            Ok(DnsAnswer::NoSuchName) => break,
            _ => {}
        }
        if !out.is_empty() {
            break;
        }
    }
    sender.close().await;
    out
}

pub(crate) const SNIFF_LIMIT: usize = 16 * 1024;

/// Read the client's first bytes (acknowledging the connection first when needed) and run
/// the sniffers on them.
pub(crate) async fn sniff_stream<S: RoutedClient>(
    meta: &mut Metadata,
    sock: &mut S,
    head: &mut Vec<u8>,
    inbound: Inbound,
    acked: &mut bool,
    opts: &SniffOpts,
) -> std::io::Result<()> {
    meta.sniffed = true;
    if sniffers::skip_port(meta.port) {
        log::trace!("[route] sniff skipped: port {} speaks first from the server", meta.port);
        return Ok(());
    }
    let list = opts.stream();
    if list.is_empty() {
        return Ok(());
    }
    let can_read = inbound != Inbound::HttpPlain;
    if head.is_empty() && can_read && !*acked {
        inbound.ack(sock).await?;
        *acked = true;
    }
    let deadline = tokio::time::Instant::now() + opts.timeout;
    loop {
        if !head.is_empty() {
            match sniffers::stream(head, &list) {
                Outcome::Found(f) => {
                    log::debug!(
                        "[route] {} sniffed protocol {}{}",
                        meta.describe(),
                        f.protocol,
                        f.domain.as_deref().map(|d| format!(", domain {d}")).unwrap_or_default()
                    );
                    meta.protocol = Some(f.protocol);
                    if f.domain.is_some() {
                        meta.domain = f.domain;
                    }
                    meta.client = f.client;
                    return Ok(());
                }
                Outcome::NotFound => return Ok(()),
                Outcome::NeedMore => {}
            }
        }
        if !can_read || head.len() >= SNIFF_LIMIT {
            return Ok(());
        }
        let mut buf = vec![0u8; 4096];
        match tokio::time::timeout_at(deadline, sock.read(&mut buf)).await {
            Ok(Ok(0)) => return Err(std::io::ErrorKind::UnexpectedEof.into()),
            Ok(Ok(n)) => head.extend_from_slice(&buf[..n]),
            Ok(Err(e)) => return Err(e),
            Err(_) => return Ok(()),
        }
    }
}

/// Evaluate the rules for a tcp connection, sniffing and resolving as the actions ask.
pub(crate) async fn decide<S: RoutedClient>(
    router: &Router,
    meta: &mut Metadata,
    sock: &mut S,
    head: &mut Vec<u8>,
    inbound: Inbound,
    acked: &mut bool,
    exit: &Exit,
) -> std::io::Result<(Verdict, RouteOpts)> {
    router.wait_ready().await;
    let mut opts = RouteOpts::default();
    let mut from = 0;
    loop {
        match router.step(meta, from, &mut opts) {
            Step::Done(v) => return Ok((v, opts)),
            Step::Sniff { next, opts: s } => {
                sniff_stream(meta, sock, head, inbound, acked, &s).await?;
                from = next;
            }
            Step::Process { next } => {
                meta.lookup_process().await;
                from = next;
            }
            Step::Resolve { next, opts: r } => {
                if let Some(name) = meta.fqdn.clone() {
                    meta.resolved = resolve_for_rules(&name, &r, exit).await;
                    meta.resolved_local = r.resolver == Resolver::Local;
                    log::debug!("[route] {} resolved to {:?}", meta.describe(), meta.resolved);
                }
                from = next;
            }
        }
    }
}

/// One tcp connection through the router.
pub(crate) async fn serve_tcp(
    router: &Router,
    sock: TcpStream,
    inbound: Inbound,
    target: Target,
    port: u16,
    head: Vec<u8>,
    exit: &Exit,
) -> Result<()> {
    let peer = sock.peer_addr()?;
    let local = sock.local_addr().ok();
    serve_stream(router, sock, inbound, target, port, head, exit, peer, local, None).await
}

/// One tcp connection through the router, from any client stream. `peer` is the client's
/// address and `local` the address it reached (the listener, or a TUN flow's destination);
/// `forced` decides the connection without the rules (the TUN inbound's own dns address).
#[allow(clippy::too_many_arguments)]
pub(crate) async fn serve_stream<S: RoutedClient>(
    router: &Router,
    mut sock: S,
    inbound: Inbound,
    target: Target,
    port: u16,
    mut head: Vec<u8>,
    exit: &Exit,
    peer: SocketAddr,
    local: Option<SocketAddr>,
    forced: Option<Verdict>,
) -> Result<()> {
    // A fake-ip address (a program that resolved through the TUN's dns and then used a proxy,
    // or a TUN flow): the name it stands for, so the router and the outbounds see the domain.
    let target = match target {
        Target::Ip(ip) if forced.is_none() => match crate::proxy::inbound::tun::fakeip::restore(ip) {
            crate::proxy::inbound::tun::fakeip::Restored::Real => Target::Ip(ip),
            crate::proxy::inbound::tun::fakeip::Restored::Name(n) => Target::Domain(n),
            crate::proxy::inbound::tun::fakeip::Restored::Stale => {
                log::debug!("[route] {ip}:{port}: a fake-ip address with no name behind it (stale); refused");
                inbound.refuse(&mut sock, true).await;
                return Ok(());
            }
        },
        t => t,
    };
    let mut meta = Metadata::new(&super::inbound::tag_of(inbound.tag()), Network::Tcp, peer, &target_host(&target), port);
    meta.local = local;
    let mut acked = false;

    let (verdict, opts) = match forced {
        Some(v) => (v, RouteOpts::default()),
        None => match decide(router, &mut meta, &mut sock, &mut head, inbound, &mut acked, exit).await {
            Ok(v) => v,
            Err(_) => return Ok(()),
        },
    };

    let mut host = target_host(&target);
    let mut port = port;
    let (kind, tag) = match verdict {
        Verdict::Reject { drop } => {
            log::info!("[route] {} rejected{}", meta.describe(), if drop { " (drop)" } else { "" });
            if !acked && !drop {
                inbound.refuse(&mut sock, true).await;
            }
            return Ok(());
        }
        Verdict::HijackDns => {
            // a TUN flow with fake-ip: A / AAAA are answered here, the rest goes on to the
            // resolver inside the tunnel
            if inbound == Inbound::Tun {
                if let Some(pool) = crate::proxy::inbound::tun::fakeip::pool() {
                    log::debug!("[route] {} hijacked to the fake-ip dns", meta.describe());
                    dns_tcp_session(sock, head, pool).await;
                    return Ok(());
                }
            }
            // DNS over tcp goes to Aether's resolver inside the tunnel.
            let resolver = resolver_addresses()[0];
            log::debug!("[route] {} hijacked to the dns resolver {resolver}", meta.describe());
            host = resolver.ip().to_string();
            port = resolver.port();
            meta.resolved.clear();
            (OutKind::Warp, "hijack-dns".to_string())
        }
        Verdict::Route { kind, tag } => (kind, tag),
    };
    let out = outbound_for(kind, exit);
    let via = out.via();
    if via == Via::Block {
        log::info!("[route] {} blocked ({tag})", meta.describe());
        if !acked {
            inbound.refuse(&mut sock, true).await;
        }
        return Ok(());
    }
    if let Some(a) = &opts.override_address {
        host = a.clone();
        meta.resolved.clear();
    }
    if let Some(p) = opts.override_port {
        port = p;
    }
    log::debug!("[route] {} => {tag} ({})", meta.describe(), via.label());

    // tls fragmentation only means something on the direct path
    let fragment = via == Via::Direct && (opts.tls_fragment || opts.tls_record_fragment);
    if fragment && head.is_empty() && inbound != Inbound::HttpPlain {
        if !acked {
            inbound.ack(&mut sock).await?;
            acked = true;
        }
        let mut buf = vec![0u8; SNIFF_LIMIT];
        if let Ok(Ok(n)) = tokio::time::timeout(Duration::from_millis(500), sock.read(&mut buf)).await {
            head.extend_from_slice(&buf[..n]);
        }
    }
    if via == Via::Direct && opts.tls_record_fragment {
        if let Some(split) = split_tls_records(&head) {
            head = split;
        }
    }

    // warp-local dials a `resolve` action's addresses only when they came from this machine's
    // resolver; addresses from the resolver inside the tunnel are for matching only there
    let resolved: &[IpAddr] = if via == Via::WarpLocal && !meta.resolved_local { &[] } else { &meta.resolved };
    let upstream = match out.connect_stream(StreamRequest { host: &host, port, resolved, client: peer.ip(), exit }).await {
        Ok(u) => u,
        Err(e) => {
            log::debug!("[route] {host}:{port} via {tag}: {e}");
            if !acked {
                let forbidden = matches!(&e, AetherError::Io(io) if io.kind() == std::io::ErrorKind::PermissionDenied);
                inbound.refuse(&mut sock, forbidden).await;
            }
            return Ok(());
        }
    };
    if !acked {
        inbound.ack(&mut sock).await?;
    }

    match upstream {
        Upstream::Tunnel(sender, rx, leftover) => {
            if !head.is_empty() && sender.send(head).await.is_err() {
                return Ok(());
            }
            if !leftover.is_empty() && sock.write_all(&leftover).await.is_err() {
                return Ok(());
            }
            sock.relay_tunnel(sender, rx, half_close_linger()).await;
        }
        Upstream::Tcp(mut up) => {
            if opts.tls_fragment && via == Via::Direct {
                let cfg = crate::utils::fragment::FragmentConfig {
                    enabled: true,
                    size_min: 1,
                    size_max: 8,
                    delay_min_ms: opts.tls_fragment_delay.map(|d| d.as_millis() as u64 / 50).unwrap_or(2),
                    delay_max_ms: opts.tls_fragment_delay.map(|d| d.as_millis() as u64 / 10).unwrap_or(10),
                    sni_split: true,
                };
                let mut wrapped = crate::utils::fragment::FragmentingStream::new(up, cfg);
                if !head.is_empty() && wrapped.write_all(&head).await.is_err() {
                    return Ok(());
                }
                relay_generic(sock, wrapped, half_close_linger()).await;
                return Ok(());
            }
            if !head.is_empty() && up.write_all(&head).await.is_err() {
                return Ok(());
            }
            sock.relay_tcp(up, half_close_linger()).await;
        }
        Upstream::Boxed(mut up) => {
            if !head.is_empty() && up.write_all(&head).await.is_err() {
                return Ok(());
            }
            relay_generic(sock, up, half_close_linger()).await;
        }
    }
    Ok(())
}

// ---------------------------------------------------------------------------------------------
// fake-ip dns over tcp

/// A hijacked dns-over-tcp connection of the TUN with fake-ip: each length-prefixed query is
/// answered here (A / AAAA / HTTPS / SVCB) or sent on to the resolver inside the tunnel over
/// one tcp connection, and the answer written back. `head` holds bytes already read (sniffing).
pub(crate) async fn dns_tcp_session<S: AsyncRead + AsyncWrite + Unpin>(
    mut sock: S,
    head: Vec<u8>,
    pool: &'static crate::proxy::inbound::tun::fakeip::FakePool,
) {
    use crate::proxy::inbound::tun::fakeip::{answer, servfail, DnsAction};
    let v6 = crate::proxy::inbound::tun::config().is_some_and(|c| c.v6.is_some());
    let mut buf = head;
    let mut upstream: Option<DnsTcpUpstream> = None;
    let idle = Duration::from_secs(30);
    loop {
        // one query: two length bytes, then the message
        let query = loop {
            if buf.len() >= 2 {
                let len = u16::from_be_bytes([buf[0], buf[1]]) as usize;
                if buf.len() >= 2 + len {
                    let q = buf[2..2 + len].to_vec();
                    buf.drain(..2 + len);
                    break q;
                }
            }
            let mut chunk = [0u8; 4096];
            match tokio::time::timeout(idle, sock.read(&mut chunk)).await {
                Ok(Ok(n)) if n > 0 => buf.extend_from_slice(&chunk[..n]),
                _ => {
                    if let Some((tx, _, _)) = upstream {
                        tx.close().await;
                    }
                    return;
                }
            }
        };
        let reply = match answer(pool, &query, v6) {
            DnsAction::Reply(r) => Some(r),
            DnsAction::Forward => match forward_dns_tcp(&mut upstream, &query).await {
                Some(r) => Some(r),
                None => {
                    upstream = None;
                    servfail(&query)
                }
            },
        };
        let Some(reply) = reply else { return };
        let mut framed = (reply.len() as u16).to_be_bytes().to_vec();
        framed.extend_from_slice(&reply);
        if sock.write_all(&framed).await.is_err() {
            return;
        }
    }
}

/// The tcp connection to the resolver inside the tunnel: its sender, the bytes it answers
/// with, and what of them is not yet a whole answer.
pub(crate) type DnsTcpUpstream = (TcpSender, tokio::sync::mpsc::Receiver<Vec<u8>>, Vec<u8>);

/// One query to the resolver inside the tunnel over tcp (opened on first use).
pub(crate) async fn forward_dns_tcp(
    upstream: &mut Option<DnsTcpUpstream>,
    query: &[u8],
) -> Option<Vec<u8>> {
    if upstream.is_none() {
        let stack = exits::stack()?;
        let resolver = resolver_addresses()[0];
        let conn = tokio::time::timeout(Duration::from_secs(5), stack.open_tcp(resolver)).await.ok()?.ok()?;
        let (tx, rx) = conn.into_split();
        *upstream = Some((tx, rx, Vec::new()));
    }
    let (tx, rx, pending) = upstream.as_mut()?;
    let mut framed = (query.len() as u16).to_be_bytes().to_vec();
    framed.extend_from_slice(query);
    crate::utils::stats::add_up(framed.len());
    tx.send(framed).await.ok()?;
    let deadline = tokio::time::Instant::now() + Duration::from_secs(5);
    loop {
        if pending.len() >= 2 {
            let len = u16::from_be_bytes([pending[0], pending[1]]) as usize;
            if pending.len() >= 2 + len {
                let r = pending[2..2 + len].to_vec();
                pending.drain(..2 + len);
                return Some(r);
            }
        }
        let chunk = tokio::time::timeout_at(deadline, rx.recv()).await.ok()??;
        crate::utils::stats::add_down(chunk.len());
        pending.extend_from_slice(&chunk);
    }
}

/// How a udp flow is carried, as its outbound decided (`AnyOutbound::connect_packet`).
#[derive(Clone, Debug)]
pub(crate) enum FlowRoute {
    Drop,
    Direct(Option<SocketAddr>),
    Warp(Option<SocketAddr>),
    /// `warp-local` for a flow addressed by name: resolved by `direct`'s resolver, then sent as
    /// `Warp(Some(address))`.
    WarpLocal,
    /// A udp session of the outbound with this registry index (`AnyOutbound::packet_exit`).
    Session(u16),
    Dns,
}

/// The address a flow goes to: an override, the flow's own address, or what a `resolve` action
/// found; `None` for a name, resolved when the flow is set up.
pub(crate) fn flow_addr(meta: &Metadata, ropts: &RouteOpts) -> Option<SocketAddr> {
    let port = ropts.override_port.unwrap_or(meta.port);
    match &ropts.override_address {
        Some(a) => a.parse::<IpAddr>().ok().map(|ip| SocketAddr::new(ip, port)),
        None => meta.ip.or(meta.resolved.first().copied()).map(|ip| SocketAddr::new(ip, port)),
    }
}

pub(crate) fn apply_packet_sniff(meta: &mut Metadata, outcome: Outcome) {
    meta.sniffed = true;
    if let Outcome::Found(f) = outcome {
        log::debug!(
            "[route] {} sniffed protocol {}{}",
            meta.describe(),
            f.protocol,
            f.domain.as_deref().map(|d| format!(", domain {d}")).unwrap_or_default()
        );
        meta.protocol = Some(f.protocol);
        if f.domain.is_some() {
            meta.domain = f.domain;
        }
    }
}

/// Run the rules until they decide or want a sniff; Err carries where to resume and how.
pub(crate) async fn first_udp_step(
    router: &Router,
    meta: &mut Metadata,
    ropts: &mut RouteOpts,
    exit: &Exit,
    _first: &[u8],
) -> std::result::Result<FlowRoute, (usize, SniffOpts)> {
    let mut from = 0;
    loop {
        match router.step(meta, from, ropts) {
            Step::Done(v) => return Ok(flow_of(v, meta, ropts, exit).await),
            Step::Sniff { next, opts } => {
                if opts.packet().is_empty() {
                    meta.sniffed = true;
                    from = next;
                    continue;
                }
                return Err((next, opts));
            }
            Step::Process { next } => {
                meta.lookup_process().await;
                from = next;
            }
            Step::Resolve { next, opts } => {
                if let Some(name) = meta.fqdn.clone() {
                    meta.resolved = resolve_for_rules(&name, &opts, exit).await;
                    meta.resolved_local = opts.resolver == Resolver::Local;
                }
                from = next;
            }
        }
    }
}

pub(crate) async fn finish_udp(router: &Router, meta: &mut Metadata, mut from: usize, ropts: &mut RouteOpts, exit: &Exit, key: &(String, u16)) -> FlowRoute {
    loop {
        match router.step(meta, from, ropts) {
            Step::Done(v) => {
                let r = flow_of(v, meta, ropts, exit).await;
                log::trace!("[route] udp flow {}:{} decided", key.0, key.1);
                return r;
            }
            Step::Sniff { next, .. } => {
                meta.sniffed = true;
                from = next;
            }
            Step::Process { next } => {
                meta.lookup_process().await;
                from = next;
            }
            Step::Resolve { next, opts } => {
                if let Some(name) = meta.fqdn.clone() {
                    meta.resolved = resolve_for_rules(&name, &opts, exit).await;
                    meta.resolved_local = opts.resolver == Resolver::Local;
                }
                from = next;
            }
        }
    }
}

pub(crate) async fn flow_of(v: Verdict, meta: &Metadata, ropts: &RouteOpts, exit: &Exit) -> FlowRoute {
    let (kind, tag) = match v {
        Verdict::Reject { .. } => {
            log::info!("[route] {} rejected", meta.describe());
            return FlowRoute::Drop;
        }
        Verdict::HijackDns => {
            log::debug!("[route] {} hijacked to the dns resolver", meta.describe());
            return FlowRoute::Dns;
        }
        Verdict::Route { kind, tag } => (kind, tag),
    };
    let out = outbound_for(kind, exit);
    log::debug!("[route] {} => {tag} ({})", meta.describe(), out.via().label());
    out.connect_packet(PacketRequest { meta, ropts })
}
