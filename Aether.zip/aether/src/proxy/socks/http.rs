//! HTTP proxy request parsing and tunnels opened for it.

use super::*;

pub(crate) const HTTP_HEAD_LIMIT: usize = 16 * 1024;

#[derive(Debug, PartialEq, Eq)]
pub struct HttpRequestLine {
    pub method: String,
    pub authority: String,
    pub port: u16,
    pub rewritten: Option<String>,
}

pub fn parse_authority(raw: &str, default_port: u16) -> Option<(String, u16)> {
    let raw = raw.trim();
    if raw.is_empty() {
        return None;
    }

    if let Some(rest) = raw.strip_prefix('[') {
        let (host, tail) = rest.split_once(']')?;
        if host.is_empty() {
            return None;
        }
        let port = match tail.strip_prefix(':') {
            Some(value) => value.parse().ok()?,
            None => default_port,
        };
        return Some((host.to_string(), port));
    }

    match raw.rsplit_once(':') {
        Some((host, port)) if !host.contains(':') => {
            if host.is_empty() {
                return None;
            }
            Some((host.to_string(), port.parse().ok()?))
        }
        _ => Some((raw.to_string(), default_port)),
    }
}

pub fn parse_request_line(line: &str) -> Option<HttpRequestLine> {
    let mut parts = line.split_whitespace();
    let method = parts.next()?.to_string();
    let target = parts.next()?;
    let version = parts.next().unwrap_or("HTTP/1.1");

    if method.eq_ignore_ascii_case("CONNECT") {
        let (authority, port) = parse_authority(target, 443)?;
        return Some(HttpRequestLine {
            method,
            authority,
            port,
            rewritten: None,
        });
    }

    let without_scheme = target
        .strip_prefix("http://")
        .or_else(|| target.strip_prefix("HTTP://"))?;
    let (authority_part, path) = match without_scheme.find('/') {
        Some(index) => (&without_scheme[..index], &without_scheme[index..]),
        None => (without_scheme, "/"),
    };
    let (authority, port) = parse_authority(authority_part, 80)?;

    Some(HttpRequestLine {
        method: method.clone(),
        authority,
        port,
        rewritten: Some(format!("{method} {path} {version}\r\n")),
    })
}

pub(crate) async fn read_head(sock: &mut TcpStream) -> Result<(Vec<u8>, Vec<u8>)> {
    let mut buf: Vec<u8> = Vec::with_capacity(1024);
    let mut chunk = [0u8; 2048];

    loop {
        let read = sock.read(&mut chunk).await?;
        if read == 0 {
            return Err(AetherError::Other(
                "the http client closed before sending a request".into(),
            ));
        }

        let search_from = buf.len().saturating_sub(3);
        buf.extend_from_slice(&chunk[..read]);

        if let Some(pos) = buf[search_from..].windows(4).position(|w| w == b"\r\n\r\n") {
            let early = buf.split_off(search_from + pos + 4);
            return Ok((buf, early));
        }

        if buf.len() > HTTP_HEAD_LIMIT {
            return Err(AetherError::Other("http request head too large".into()));
        }
    }
}

pub(crate) async fn open_tunneled(stack: &StackHandle, target: Target, port: u16) -> Result<GatewayChannel> {
    let via_gateway = gateway_proxy().filter(|_| should_use_gateway(port));

    if let Some(proxy) = via_gateway {
        let authority = match &target {
            Target::Domain(name) => name.clone(),
            Target::Ip(ip) => ip.to_string(),
        };
        match open_through_gateway(stack, proxy, &authority, port).await {
            Ok(conn) => return Ok(conn),
            Err(e) => retire_gateway(&e.to_string()),
        }
    }

    let ip = resolve(stack, target).await?;
    let conn = stack.open_tcp(SocketAddr::new(ip, port)).await?;
    let (sender, from_stack) = conn.into_split();
    Ok((sender, from_stack, Vec::new()))
}
