//! Listening sockets: binding, the client limit, the accept loop and its backoff, keepalive.

use super::*;

pub(crate) fn warn_if_world_reachable(kind: &str, listen: SocketAddr) {
    if listen.ip().is_loopback() {
        return;
    }
    log::warn!(
        "[socks] the {kind} listener is bound to {listen}, which is reachable from outside this machine. \
         It accepts every client without authentication, so anyone who can reach {listen} can send \
         traffic through your tunnel. Bind it to 127.0.0.1 unless you intend to share it."
    );
}

pub async fn bind_listener(kind: &str, listen: SocketAddr) -> Result<TcpListener> {
    TcpListener::bind(listen).await.map_err(|error| {
        AetherError::Other(format!(
            "the {kind} listener cannot use {listen}: {error}{}",
            bind_hint(&error)
        ))
    })
}

pub(crate) fn bind_hint(error: &std::io::Error) -> &'static str {
    match error.kind() {
        std::io::ErrorKind::AddrInUse => {
            "; another program already listens there, so stop it or choose another port with bind in the config file"
        }
        std::io::ErrorKind::PermissionDenied if cfg!(windows) => {
            "; Windows reserves some port ranges for Hyper-V and WSL (see `netsh interface ipv4 show \
             excludedportrange protocol=tcp`), so choose a port outside them with bind in the config file"
        }
        std::io::ErrorKind::PermissionDenied => {
            "; ports below 1024 need extra privileges, so choose a higher one with bind in the config file"
        }
        std::io::ErrorKind::AddrNotAvailable => {
            "; that address does not belong to this machine"
        }
        _ => "",
    }
}

pub(crate) const HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(10);

pub(crate) const ACCEPT_WARN_EVERY: Duration = Duration::from_secs(10);

pub(crate) fn client_limit() -> usize {
    if let Some(limit) = crate::config::settings::var("AETHER_MAX_CLIENTS")
        .ok()
        .and_then(|v| v.trim().parse::<usize>().ok())
        .filter(|&v| v > 0)
    {
        return limit;
    }

    let by_tier = match crate::utils::sysprofile::tuning().tier {
        crate::utils::sysprofile::Tier::Low => 512,
        crate::utils::sysprofile::Tier::Medium => 2048,
        crate::utils::sysprofile::Tier::High => 8192,
    };

    match crate::utils::sysprofile::open_file_limit() {
        Some(files) => by_tier.min((files.saturating_sub(64) / 2).max(32)),
        None => by_tier,
    }
}

pub(crate) async fn accept_clients<F, Fut>(
    listener: TcpListener,
    kind: &'static str,
    max: usize,
    serve_one: F,
) -> Result<()>
where
    F: Fn(TcpStream, SocketAddr) -> Fut,
    Fut: Future<Output = ()> + Send + 'static,
{
    let limit = Arc::new(Semaphore::new(max));
    let mut clients = tokio::task::JoinSet::new();
    let mut last_accept_warning: Option<std::time::Instant> = None;
    let mut last_limit_warning: Option<std::time::Instant> = None;

    loop {
        if limit.available_permits() == 0 && due(&mut last_limit_warning, ACCEPT_WARN_EVERY) {
            log::warn!(
                "[socks] {kind}: {max} clients are connected, the most served at once; new ones wait \
                 until one finishes (AETHER_MAX_CLIENTS raises the limit)"
            );
        }

        tokio::select! {
            Some(_) = clients.join_next(), if !clients.is_empty() => {}
            permit = Arc::clone(&limit).acquire_owned() => {
                let permit = permit.expect("the client limit is never closed");
                let (sock, peer) = match listener.accept().await {
                    Ok(accepted) => accepted,
                    Err(error) => {
                        if let Some(delay) = accept_backoff(&error) {
                            if due(&mut last_accept_warning, ACCEPT_WARN_EVERY) {
                                log::warn!(
                                    "[socks] {kind} accept failed: {error}; the listener stays open and retries"
                                );
                            }
                            tokio::time::sleep(delay).await;
                            continue;
                        }
                        log::error!("[socks] {kind} listener cannot continue: {error}");
                        return Err(error.into());
                    }
                };
                enable_keepalive(&sock);
                let client = serve_one(sock, peer);
                clients.spawn(async move {
                    client.await;
                    drop(permit);
                });
            }
        }
    }
}

pub(crate) fn due(last: &mut Option<std::time::Instant>, every: Duration) -> bool {
    let now = std::time::Instant::now();
    if last.is_some_and(|at| now.duration_since(at) < every) {
        return false;
    }
    *last = Some(now);
    true
}

pub(crate) fn enable_keepalive(sock: &TcpStream) {
    let idle = crate::transport::warp::netstack::tcp_keepalive();
    let probes = socket2::TcpKeepalive::new().with_time(idle);
    #[cfg(any(
        target_os = "linux",
        target_os = "android",
        target_os = "macos",
        target_os = "ios",
        target_os = "freebsd",
        target_os = "windows"
    ))]
    let probes =
        probes.with_interval((idle / 4).clamp(Duration::from_secs(5), Duration::from_secs(30)));
    #[cfg(any(
        target_os = "linux",
        target_os = "android",
        target_os = "macos",
        target_os = "ios",
        target_os = "freebsd"
    ))]
    let probes = probes.with_retries(4);

    if let Err(error) = socket2::SockRef::from(sock).set_tcp_keepalive(&probes) {
        log::debug!("[socks] could not enable keep-alive on a connection: {error}");
    }
}

pub fn accept_backoff(error: &std::io::Error) -> Option<std::time::Duration> {
    use std::io::ErrorKind;
    use std::time::Duration;

    if matches!(
        error.kind(),
        ErrorKind::ConnectionAborted
            | ErrorKind::ConnectionReset
            | ErrorKind::ConnectionRefused
            | ErrorKind::Interrupted
            | ErrorKind::WouldBlock
            | ErrorKind::TimedOut
            | ErrorKind::PermissionDenied
    ) {
        return Some(Duration::ZERO);
    }

    match error.raw_os_error() {
        Some(libc::EMFILE) | Some(libc::ENFILE) | Some(libc::ENOBUFS) | Some(libc::ENOMEM) => {
            Some(Duration::from_millis(100))
        }
        _ => None,
    }
}
