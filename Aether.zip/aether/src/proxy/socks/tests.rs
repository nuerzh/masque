use super::*;

fn parse_resolvers(raw: &str) -> Vec<SocketAddr> {
    let mut servers: Vec<SocketAddr> = Vec::new();
    for token in raw.split([',', ' ', ';']) {
        let entry = token.trim();
        if entry.is_empty() {
            continue;
        }
        let parsed = entry.parse::<SocketAddr>().ok().or_else(|| {
            entry
                .parse::<IpAddr>()
                .ok()
                .map(|ip| SocketAddr::new(ip, 53))
        });
        if let Some(server) = parsed {
            if !servers.contains(&server) {
                servers.push(server);
            }
        }
    }
    servers
}

#[test]
fn only_web_ports_are_sent_through_the_gateway() {
    assert!(should_use_gateway(80));
    assert!(should_use_gateway(443));
    assert!(!should_use_gateway(22));
    assert!(!should_use_gateway(853));
}

#[test]
fn the_proxy_request_carries_the_domain_so_the_gateway_can_filter_it() {
    let wire = String::from_utf8(build_proxy_connect("example.com", 443)).expect("utf8");
    assert!(wire.starts_with("CONNECT example.com:443 HTTP/1.1\r\n"));
    assert!(wire.contains("Host: example.com:443\r\n"));
    assert!(wire.ends_with("\r\n\r\n"));
}

#[test]
fn a_bare_ipv6_target_is_bracketed_for_the_proxy() {
    let wire = String::from_utf8(build_proxy_connect("2606:4700::1", 443)).expect("utf8");
    assert!(wire.starts_with("CONNECT [2606:4700::1]:443 HTTP/1.1\r\n"));
}

#[test]
fn an_already_bracketed_target_is_left_alone() {
    let wire = String::from_utf8(build_proxy_connect("[2606:4700::1]", 443)).expect("utf8");
    assert!(wire.starts_with("CONNECT [2606:4700::1]:443 HTTP/1.1\r\n"));
}

#[test]
fn the_gateway_verdict_is_read_from_the_status_line() {
    assert_eq!(
        proxy_connect_succeeded(b"HTTP/1.1 200 Connection established\r\n\r\n"),
        Some(true)
    );
    assert_eq!(
        proxy_connect_succeeded(b"HTTP/1.1 403 Forbidden\r\n\r\nblocked"),
        Some(false)
    );
    assert_eq!(
        proxy_connect_succeeded(b"HTTP/1.1 407 Proxy Authentication Required\r\n\r\n"),
        Some(false)
    );
    assert_eq!(proxy_connect_succeeded(b"garbage"), None);
    assert_eq!(proxy_connect_succeeded(b"HTTP/1.1\r\n\r\n"), None);
}

#[test]
fn the_end_of_the_proxy_response_head_is_located() {
    assert_eq!(find_head_end(b"HTTP/1.1 200 OK\r\n\r\n"), Some(19));
    assert_eq!(find_head_end(b"HTTP/1.1 200 OK\r\n\r\npayload"), Some(19));
    assert_eq!(find_head_end(b"HTTP/1.1 200 OK\r\n"), None);
}

#[test]
fn a_malformed_gateway_address_is_ignored_rather_than_fatal() {
    set_gateway_proxy("not an address");
    set_gateway_proxy("   ");
    assert!(gateway_proxy().is_none());
}

#[test]
fn the_first_datagram_must_come_from_the_control_connection_address() {
    let expected: IpAddr = "127.0.0.1".parse().unwrap();
    assert!(udp_source_allowed(
        expected,
        None,
        "127.0.0.1:51000".parse().unwrap()
    ));
    assert!(!udp_source_allowed(
        expected,
        None,
        "192.168.1.44:51000".parse().unwrap()
    ));
}

#[test]
fn a_latched_client_cannot_be_replaced_by_another_source() {
    let expected: IpAddr = "10.0.0.5".parse().unwrap();
    let latched: Option<SocketAddr> = Some("10.0.0.5:40000".parse().unwrap());
    assert!(udp_source_allowed(
        expected,
        latched,
        "10.0.0.5:40000".parse().unwrap()
    ));
    assert!(!udp_source_allowed(
        expected,
        latched,
        "10.0.0.5:40001".parse().unwrap()
    ));
    assert!(!udp_source_allowed(
        expected,
        latched,
        "10.0.0.9:40000".parse().unwrap()
    ));
}

#[test]
fn the_control_address_is_used_when_the_client_declares_a_wildcard() {
    let control: SocketAddr = "127.0.0.1:1080".parse().unwrap();
    let wildcard = Target::Ip("0.0.0.0".parse().unwrap());
    assert_eq!(
        expected_udp_source(control, &wildcard),
        "127.0.0.1".parse::<IpAddr>().unwrap()
    );
    let unset = Target::Domain(String::new());
    assert_eq!(
        expected_udp_source(control, &unset),
        "127.0.0.1".parse::<IpAddr>().unwrap()
    );
}

#[test]
fn an_explicit_client_address_in_the_request_is_honoured() {
    let control: SocketAddr = "192.168.1.10:1080".parse().unwrap();
    let declared = Target::Ip("192.168.1.77".parse().unwrap());
    assert_eq!(
        expected_udp_source(control, &declared),
        "192.168.1.77".parse::<IpAddr>().unwrap()
    );
}

#[test]
fn a_v4_mapped_control_address_matches_a_plain_v4_datagram() {
    let control: SocketAddr = "[::ffff:127.0.0.1]:1080".parse().unwrap();
    let expected = expected_udp_source(control, &Target::Domain(String::new()));
    assert_eq!(expected, "127.0.0.1".parse::<IpAddr>().unwrap());
    assert!(udp_source_allowed(
        expected,
        None,
        "127.0.0.1:9000".parse().unwrap()
    ));
}

#[test]
fn plain_resolver_addresses_get_the_dns_port() {
    let servers = parse_resolvers("9.9.9.9, 8.8.4.4");
    assert_eq!(servers.len(), 2);
    assert_eq!(servers[0].port(), 53);
    assert_eq!(servers[1].to_string(), "8.8.4.4:53");
}

#[test]
fn an_explicit_resolver_port_survives() {
    let servers = parse_resolvers("127.0.0.1:5353");
    assert_eq!(servers[0].port(), 5353);
}

#[test]
fn duplicate_and_malformed_resolvers_are_dropped() {
    let servers = parse_resolvers("1.1.1.1,1.1.1.1,not-an-ip,,1.0.0.1");
    assert_eq!(servers.len(), 2);
}

#[test]
fn an_empty_resolver_list_falls_back_to_cloudflare() {
    assert!(parse_resolvers("   ").is_empty());
    let defaults = resolver_addresses();
    assert!(defaults.len() >= 2);
    assert_eq!(defaults[0].port(), 53);
}

fn reply(id: u16, name: &str, qtype: u16, qr: bool) -> Vec<u8> {
    let mut msg = Vec::new();
    msg.extend_from_slice(&id.to_be_bytes());
    msg.push(if qr { 0x81 } else { 0x01 });
    msg.push(0x80);
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg.extend_from_slice(&[0, 0, 0, 0]);
    for label in name.split('.') {
        msg.push(label.len() as u8);
        msg.extend_from_slice(label.as_bytes());
    }
    msg.push(0);
    msg.extend_from_slice(&qtype.to_be_bytes());
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg
}

/// The answer to an A `query` (one record of `ip`), with the TC bit when `truncated`
/// (then without the record, as a server that ran out of room sends it).
fn a_answer(query: &[u8], ip: [u8; 4], truncated: bool) -> Vec<u8> {
    let mut r = query.to_vec();
    r[2] = 0x81 | if truncated { 0x02 } else { 0 };
    r[3] = 0x80;
    if !truncated {
        r[7] = 1;
        r.extend_from_slice(&[0xc0, 0x0c, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4]);
        r.extend_from_slice(&ip);
    }
    r
}

#[tokio::test]
async fn egress_dns_asks_again_over_tcp_when_the_udp_answer_is_truncated() {
    let udp = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
    let port = udp.local_addr().unwrap().port();
    let tcp = tokio::net::TcpListener::bind(("127.0.0.1", port)).await.unwrap();
    tokio::spawn(async move {
        let mut buf = [0u8; 512];
        loop {
            let Ok((n, from)) = udp.recv_from(&mut buf).await else { return };
            let _ = udp.send_to(&a_answer(&buf[..n], [0, 0, 0, 0], true), from).await;
        }
    });
    tokio::spawn(async move {
        while let Ok((mut c, _)) = tcp.accept().await {
            let mut len = [0u8; 2];
            if c.read_exact(&mut len).await.is_err() {
                continue;
            }
            let mut q = vec![0u8; u16::from_be_bytes(len) as usize];
            if c.read_exact(&mut q).await.is_err() {
                continue;
            }
            let r = a_answer(&q, [203, 0, 113, 7], false);
            let _ = c.write_all(&(r.len() as u16).to_be_bytes()).await;
            let _ = c.write_all(&r).await;
        }
    });
    let server: SocketAddr = format!("127.0.0.1:{port}").parse().unwrap();
    let got = egress_dns_lookup("big.example", &[server]).await;
    assert_eq!(got, vec!["203.0.113.7".parse::<IpAddr>().unwrap()]);
}

#[tokio::test]
async fn egress_dns_takes_a_plain_udp_answer() {
    let udp = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
    let server = udp.local_addr().unwrap();
    tokio::spawn(async move {
        let mut buf = [0u8; 512];
        loop {
            let Ok((n, from)) = udp.recv_from(&mut buf).await else { return };
            let _ = udp.send_to(&a_answer(&buf[..n], [198, 51, 100, 9], false), from).await;
        }
    });
    assert_eq!(egress_dns_lookup("small.example", &[server]).await, vec!["198.51.100.9".parse::<IpAddr>().unwrap()]);
}

#[test]
fn build_dns_query_reports_the_id_it_wrote() {
    let (query, id) = build_dns_query("example.com", QTYPE_A);
    assert_eq!(u16::from_be_bytes([query[0], query[1]]), id);
}

#[test]
fn accepts_the_matching_answer() {
    let msg = reply(0x4242, "example.com", QTYPE_A, true);
    assert!(dns_response_matches(&msg, 0x4242, "example.com", QTYPE_A));
}

#[test]
fn rejects_an_answer_with_a_forged_transaction_id() {
    let msg = reply(0x1111, "example.com", QTYPE_A, true);
    assert!(!dns_response_matches(&msg, 0x4242, "example.com", QTYPE_A));
}

#[test]
fn rejects_an_answer_for_another_domain() {
    let msg = reply(0x4242, "evil.example", QTYPE_A, true);
    assert!(!dns_response_matches(&msg, 0x4242, "example.com", QTYPE_A));
}

#[test]
fn rejects_a_query_shaped_message() {
    let msg = reply(0x4242, "example.com", QTYPE_A, false);
    assert!(!dns_response_matches(&msg, 0x4242, "example.com", QTYPE_A));
}

#[test]
fn rejects_truncated_input_without_panicking() {
    let msg = reply(0x4242, "example.com", QTYPE_A, true);
    for cut in 0..msg.len() {
        assert!(!dns_response_matches(
            &msg[..cut],
            0x4242,
            "example.com",
            QTYPE_A
        ));
    }
}

const V6_ONLY: &str = "2001:470:1:18::125";

fn answer(id: u16, name: &str, qtype: u16, rcode: u8, records: &[(u16, Vec<u8>)]) -> Vec<u8> {
    let mut msg = Vec::new();
    msg.extend_from_slice(&id.to_be_bytes());
    msg.push(0x81);
    msg.push(0x80 | rcode);
    msg.extend_from_slice(&1u16.to_be_bytes());
    msg.extend_from_slice(&(records.len() as u16).to_be_bytes());
    msg.extend_from_slice(&[0, 0, 0, 0]);
    for label in name.split('.') {
        msg.push(label.len() as u8);
        msg.extend_from_slice(label.as_bytes());
    }
    msg.push(0);
    msg.extend_from_slice(&qtype.to_be_bytes());
    msg.extend_from_slice(&1u16.to_be_bytes());
    for (rtype, data) in records {
        msg.extend_from_slice(&[0xc0, 0x0c]);
        msg.extend_from_slice(&rtype.to_be_bytes());
        msg.extend_from_slice(&1u16.to_be_bytes());
        msg.extend_from_slice(&300u32.to_be_bytes());
        msg.extend_from_slice(&(data.len() as u16).to_be_bytes());
        msg.extend_from_slice(data);
    }
    msg
}

#[test]
fn an_aaaa_answer_is_read_for_an_aaaa_question() {
    let v6: Ipv6Addr = V6_ONLY.parse().unwrap();
    let msg = answer(
        1,
        "ip6only.me",
        QTYPE_AAAA,
        0,
        &[(QTYPE_AAAA, v6.octets().to_vec())],
    );
    assert_eq!(parse_dns_answer(&msg, QTYPE_AAAA), Some(IpAddr::V6(v6)));
    assert_eq!(parse_dns_answer(&msg, QTYPE_A), None);
}

#[test]
fn an_alias_ahead_of_the_address_is_skipped() {
    let v6: Ipv6Addr = V6_ONLY.parse().unwrap();
    let alias = vec![3, b'w', b'w', b'w', 0xc0, 0x0c];
    let msg = answer(
        1,
        "ip6only.me",
        QTYPE_AAAA,
        0,
        &[(5, alias), (QTYPE_AAAA, v6.octets().to_vec())],
    );
    assert_eq!(parse_dns_answer(&msg, QTYPE_AAAA), Some(IpAddr::V6(v6)));
}

#[test]
fn a_name_that_does_not_exist_is_told_apart_from_a_missing_record() {
    let gone = answer(1, "nothing.example", QTYPE_A, RCODE_NXDOMAIN, &[]);
    let empty = answer(1, "ip6only.me", QTYPE_A, 0, &[]);
    assert_eq!(dns_rcode(&gone), Some(RCODE_NXDOMAIN));
    assert_eq!(dns_rcode(&empty), Some(0));
    assert_eq!(parse_dns_answer(&empty, QTYPE_A), None);
}

async fn fake_resolver(
    mut from_stack: mpsc::Receiver<Vec<u8>>,
    to_stack: mpsc::Sender<Vec<u8>>,
    asked: std::sync::Arc<std::sync::Mutex<Vec<(String, u16)>>>,
) {
    use smoltcp::phy::ChecksumCapabilities;
    use smoltcp::wire::{IpAddress, IpProtocol, Ipv4Packet, Ipv4Repr, UdpPacket, UdpRepr};

    let caps = ChecksumCapabilities::default();
    while let Some(pkt) = from_stack.recv().await {
        let Ok(ip) = Ipv4Packet::new_checked(&pkt[..]) else {
            continue;
        };
        let Ok(ip_repr) = Ipv4Repr::parse(&ip, &caps) else {
            continue;
        };
        if ip_repr.next_header != IpProtocol::Udp {
            continue;
        }
        let src = IpAddress::Ipv4(ip_repr.src_addr);
        let dst = IpAddress::Ipv4(ip_repr.dst_addr);
        let Ok(udp) = UdpPacket::new_checked(ip.payload()) else {
            continue;
        };
        let Ok(udp_repr) = UdpRepr::parse(&udp, &src, &dst, &caps) else {
            continue;
        };

        let query = udp.payload();
        let mut pos = 12;
        let mut labels = Vec::new();
        while pos < query.len() && query[pos] != 0 {
            let n = query[pos] as usize;
            labels.push(String::from_utf8_lossy(&query[pos + 1..pos + 1 + n]).to_string());
            pos += 1 + n;
        }
        let name = labels.join(".");
        let qtype = u16::from_be_bytes([query[pos + 1], query[pos + 2]]);
        let id = u16::from_be_bytes([query[0], query[1]]);
        asked.lock().unwrap().push((name.clone(), qtype));

        let v6: Ipv6Addr = V6_ONLY.parse().unwrap();
        let dual_v6: Ipv6Addr = "2606:2800:220:1::1".parse().unwrap();
        let reply = match (name.as_str(), qtype) {
            ("dualstack.example", QTYPE_A) => {
                answer(id, &name, qtype, 0, &[(QTYPE_A, vec![93, 184, 216, 34])])
            }
            ("dualstack.example", QTYPE_AAAA) => answer(
                id,
                &name,
                qtype,
                0,
                &[(QTYPE_AAAA, dual_v6.octets().to_vec())],
            ),
            ("ip6only.me", QTYPE_AAAA) => {
                answer(id, &name, qtype, 0, &[(QTYPE_AAAA, v6.octets().to_vec())])
            }
            ("ip6only.me", _) => answer(id, &name, qtype, 0, &[]),
            _ => answer(id, &name, qtype, RCODE_NXDOMAIN, &[]),
        };

        let out_udp = UdpRepr {
            src_port: 53,
            dst_port: udp_repr.src_port,
        };
        let out_ip = Ipv4Repr {
            src_addr: ip_repr.dst_addr,
            dst_addr: ip_repr.src_addr,
            next_header: IpProtocol::Udp,
            payload_len: 8 + reply.len(),
            hop_limit: 64,
        };
        let mut buf = vec![0u8; out_ip.buffer_len() + out_ip.payload_len];
        let mut packet = Ipv4Packet::new_unchecked(&mut buf[..]);
        out_ip.emit(&mut packet, &caps);
        let mut datagram = UdpPacket::new_unchecked(packet.payload_mut());
        out_udp.emit(
            &mut datagram,
            &dst,
            &src,
            reply.len(),
            |b| b.copy_from_slice(&reply),
            &caps,
        );
        let _ = to_stack.send(buf).await;
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_name_with_only_an_ipv6_address_resolves_through_the_tunnel() {
    let (to_stack, stack_in) = mpsc::channel(64);
    let (stack_out, from_stack) = mpsc::channel(64);
    let stack = crate::transport::warp::netstack::spawn(
        "172.16.0.2",
        "2606:4700:110:8a36::1",
        1280,
        stack_in,
        stack_out,
    )
    .unwrap();
    let asked = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
    tokio::spawn(fake_resolver(from_stack, to_stack, asked.clone()));

    assert_eq!(
        dns_resolve(&stack, "dualstack.example").await.unwrap(),
        IpAddr::V4(Ipv4Addr::new(93, 184, 216, 34))
    );
    assert_eq!(
        resolve(&stack, Target::Domain("ip6only.me".into()))
            .await
            .unwrap(),
        IpAddr::V6(V6_ONLY.parse().unwrap())
    );
    let missing = dns_resolve(&stack, "nothing.example")
        .await
        .unwrap_err()
        .to_string();
    assert!(missing.contains("does not exist"), "{missing}");

    let asked = asked.lock().unwrap().clone();
    assert_eq!(
        asked,
        vec![
            ("dualstack.example".to_string(), QTYPE_A),
            ("ip6only.me".to_string(), QTYPE_A),
            ("ip6only.me".to_string(), QTYPE_AAAA),
            ("nothing.example".to_string(), QTYPE_A),
        ]
    );
}

#[test]
fn one_decoder_reads_every_socks5_address_form() {
    let mut v4 = Vec::new();
    push_socket_addr(&mut v4, "1.2.3.4:80".parse().unwrap());
    let mut v6 = Vec::new();
    push_socket_addr(&mut v6, "[2001:db8::1]:443".parse().unwrap());
    let domain = [&[ATYP_DOMAIN, 7][..], b"a.test.", &[0, 53]].concat();
    for (bytes, want, port) in [(&v4, "1.2.3.4", 80), (&v6, "2001:db8::1", 443), (&domain, "a.test.", 53)] {
        let (target, p, used) = decode_addr(bytes[0], &bytes[1..]).expect("decoded");
        assert_eq!((target.to_string().as_str(), p, used), (want, port, bytes.len() - 1));
        for cut in 0..bytes.len() - 1 {
            assert!(decode_addr(bytes[0], &bytes[1..1 + cut]).is_none(), "short by {cut}");
        }
        let mut stream = &bytes[1..];
        let (target, p) = futures::executor::block_on(read_addr(&mut stream, bytes[0])).expect("read");
        assert_eq!((target.to_string().as_str(), p), (want, port));
        assert!(stream.is_empty(), "read exactly the address");
    }
    assert!(decode_addr(0x09, &[0; 32]).is_none());
    let mut stream: &[u8] = &[0; 32];
    assert!(futures::executor::block_on(read_addr(&mut stream, 0x09)).is_err());

    let mut packet = vec![0, 0, 0];
    packet.extend_from_slice(&domain);
    packet.extend_from_slice(b"payload");
    let (target, (port, data)) = parse_udp_request(&packet).expect("a udp request");
    assert_eq!((target.to_string(), port, data.as_slice()), ("a.test.".to_string(), 53, &b"payload"[..]));
}
