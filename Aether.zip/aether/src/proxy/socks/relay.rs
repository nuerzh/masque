//! Relaying a tcp connection both ways, with a linger once one side has finished.

use super::*;

pub(crate) async fn relay_generic<A, B>(client: A, remote: B, linger: Duration)
where
    A: AsyncRead + AsyncWrite + Send + Unpin,
    B: AsyncRead + AsyncWrite + Send + Unpin,
{
    let (client_rd, client_wr) = tokio::io::split(client);
    let (remote_rd, remote_wr) = tokio::io::split(remote);
    relay_split(client_rd, client_wr, remote_rd, remote_wr, linger).await;
}

/// Both ways between a client and the far end, given each one's read and write halves.
async fn relay_split<CR, CW, RR, RW>(mut client_rd: CR, mut client_wr: CW, mut remote_rd: RR, mut remote_wr: RW, linger: Duration)
where
    CR: AsyncRead + Unpin,
    CW: AsyncWrite + Unpin,
    RR: AsyncRead + Unpin,
    RW: AsyncWrite + Unpin,
{
    let activity = Activity::new();

    let upload = async {
        let _ = pump(&mut client_rd, &mut remote_wr, &activity, Way::Up).await;
        let _ = remote_wr.shutdown().await;
    };

    let download = async {
        if pump(&mut remote_rd, &mut client_wr, &activity, Way::Down)
            .await
            .is_ok()
        {
            let _ = client_wr.shutdown().await;
        }
    };

    relay_halves(upload, download, &activity, linger).await;
}

pub(crate) const RELAY_CHUNK: usize = 16384;

pub(crate) fn half_close_linger() -> Duration {
    let secs = crate::config::settings::var("AETHER_HALF_CLOSE_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(30);
    Duration::from_secs(secs)
}

pub(crate) struct Activity {
    started: tokio::time::Instant,
    last_ms: AtomicU64,
}

impl Activity {
    fn new() -> Self {
        Self {
            started: tokio::time::Instant::now(),
            last_ms: AtomicU64::new(0),
        }
    }

    fn touch(&self) {
        let elapsed = self.started.elapsed().as_millis().min(u64::MAX as u128) as u64;
        self.last_ms.store(elapsed, Ordering::Relaxed);
    }

    fn quiet_until(&self, idle: Duration) -> tokio::time::Instant {
        self.started + Duration::from_millis(self.last_ms.load(Ordering::Relaxed)) + idle
    }
}

pub(crate) async fn relay_halves<U, D>(upload: U, download: D, activity: &Activity, linger: Duration)
where
    U: Future<Output = ()>,
    D: Future<Output = ()>,
{
    tokio::pin!(upload);
    tokio::pin!(download);

    tokio::select! {
        _ = &mut download => return,
        _ = &mut upload => {}
    }

    activity.touch();
    loop {
        tokio::select! {
            _ = &mut download => return,
            _ = tokio::time::sleep_until(activity.quiet_until(linger)) => {
                if activity.quiet_until(linger) <= tokio::time::Instant::now() {
                    return;
                }
            }
        }
    }
}

pub(crate) async fn relay_tunneled(
    sock: TcpStream,
    sender: TcpSender,
    from_stack: mpsc::Receiver<Vec<u8>>,
    linger: Duration,
) {
    let (rd, wr) = sock.into_split();
    relay_tunneled_split(rd, wr, sender, from_stack, linger).await;
}

/// `relay_tunneled` for any client stream (the TUN inbound's flows).
pub(crate) async fn relay_tunneled_io<S: AsyncRead + AsyncWrite + Send + Unpin>(
    sock: S,
    sender: TcpSender,
    from_stack: mpsc::Receiver<Vec<u8>>,
    linger: Duration,
) {
    let (rd, wr) = tokio::io::split(sock);
    relay_tunneled_split(rd, wr, sender, from_stack, linger).await;
}

/// Both ways between a client's read and write halves and a tcp flow of the WARP stack.
async fn relay_tunneled_split<R: AsyncRead + Unpin, W: AsyncWrite + Unpin>(
    mut rd: R,
    mut wr: W,
    sender: TcpSender,
    mut from_stack: mpsc::Receiver<Vec<u8>>,
    linger: Duration,
) {
    let activity = Activity::new();

    let upload = async {
        let mut buf = vec![0u8; RELAY_CHUNK];
        loop {
            match rd.read(&mut buf).await {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if sender.send(buf[..n].to_vec()).await.is_err() {
                        return;
                    }
                    crate::utils::stats::add_up(n);
                    activity.touch();
                }
            }
        }
        sender.close().await;
    };

    let download = async {
        while let Some(chunk) = from_stack.recv().await {
            if wr.write_all(&chunk).await.is_err() {
                return;
            }
            crate::utils::stats::add_down(chunk.len());
            activity.touch();
        }
        let _ = wr.shutdown().await;
    };

    relay_halves(upload, download, &activity, linger).await;
}

pub(crate) async fn relay_direct(client: TcpStream, remote: TcpStream, linger: Duration) {
    let (client_rd, client_wr) = client.into_split();
    let (remote_rd, remote_wr) = remote.into_split();
    relay_split(client_rd, client_wr, remote_rd, remote_wr, linger).await;
}

#[derive(Clone, Copy)]
pub(crate) enum Way {
    Up,
    Down,
}

pub(crate) async fn pump<R, W>(from: &mut R, to: &mut W, activity: &Activity, way: Way) -> std::io::Result<()>
where
    R: AsyncRead + Unpin,
    W: AsyncWrite + Unpin,
{
    let mut buf = vec![0u8; RELAY_CHUNK];
    loop {
        let n = from.read(&mut buf).await?;
        if n == 0 {
            return Ok(());
        }
        to.write_all(&buf[..n]).await?;
        to.flush().await?;
        match way {
            Way::Up => crate::utils::stats::add_up(n),
            Way::Down => crate::utils::stats::add_down(n),
        }
        activity.touch();
    }
}
