use super::accept_backoff;
use std::io::{Error, ErrorKind};

#[test]
fn a_dropped_client_never_takes_the_listener_down() {
    for kind in [
        ErrorKind::ConnectionAborted,
        ErrorKind::ConnectionReset,
        ErrorKind::ConnectionRefused,
        ErrorKind::Interrupted,
        ErrorKind::WouldBlock,
        ErrorKind::TimedOut,
        ErrorKind::PermissionDenied,
    ] {
        assert!(
            accept_backoff(&Error::from(kind)).is_some(),
            "{kind:?} should keep the listener alive"
        );
    }
}

#[test]
fn running_out_of_descriptors_backs_off_instead_of_spinning() {
    for code in [libc::EMFILE, libc::ENFILE, libc::ENOBUFS, libc::ENOMEM] {
        let delay = accept_backoff(&Error::from_raw_os_error(code))
            .expect("resource exhaustion should be survivable");
        assert!(
            !delay.is_zero(),
            "os error {code} should pause before retrying"
        );
    }
}

#[test]
fn a_broken_listener_is_still_fatal() {
    for kind in [ErrorKind::InvalidInput, ErrorKind::AddrNotAvailable] {
        assert!(
            accept_backoff(&Error::from(kind)).is_none(),
            "{kind:?} should stop the listener"
        );
    }
}
