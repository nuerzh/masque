//! Name resolution through the WARP stack: queries, answers, and the resolvers asked.

use super::*;

pub(crate) async fn resolve(stack: &StackHandle, target: Target) -> Result<IpAddr> {
    match target {
        Target::Ip(ip) => Ok(ip),
        Target::Domain(name) => {
            if let Ok(ip) = name.parse::<IpAddr>() {
                return Ok(ip);
            }
            dns_resolve(stack, &name).await
        }
    }
}

pub(crate) async fn dns_resolve(stack: &StackHandle, name: &str) -> Result<IpAddr> {
    let udp = stack.open_udp().await?;
    let (sender, mut from_stack) = udp.into_split();
    let outcome = resolve_preferring_v4(&sender, &mut from_stack, name).await;
    sender.close().await;
    outcome
}

pub(crate) async fn resolve_preferring_v4(
    sender: &UdpSender,
    from_stack: &mut mpsc::Receiver<(SocketAddr, Vec<u8>)>,
    name: &str,
) -> Result<IpAddr> {
    match dns_exchange(sender, from_stack, name, QTYPE_A).await? {
        DnsAnswer::Found(ip) => Ok(ip),
        DnsAnswer::NoSuchName => Err(AetherError::Other(format!("{name} does not exist"))),
        DnsAnswer::NoRecord => match dns_exchange(sender, from_stack, name, QTYPE_AAAA).await? {
            DnsAnswer::Found(ip) => Ok(ip),
            _ => Err(AetherError::Other(format!(
                "no A or AAAA record for {name}"
            ))),
        },
    }
}

pub(crate) enum DnsAnswer {
    Found(IpAddr),
    NoRecord,
    NoSuchName,
}

pub(crate) fn resolver_addresses() -> Vec<SocketAddr> {
    let configured = crate::config::settings::var("AETHER_DNS").unwrap_or_default();
    let mut servers: Vec<SocketAddr> = Vec::new();

    for token in configured.split([',', ' ', ';']) {
        let entry = token.trim();
        if entry.is_empty() {
            continue;
        }
        let parsed = entry.parse::<SocketAddr>().ok().or_else(|| {
            entry
                .parse::<IpAddr>()
                .ok()
                .map(|ip| SocketAddr::new(ip, 53))
        });
        if let Some(server) = parsed {
            if !servers.contains(&server) {
                servers.push(server);
            }
        }
    }

    if servers.is_empty() {
        servers.push("1.1.1.1:53".parse().unwrap());
        servers.push("1.0.0.1:53".parse().unwrap());
    }
    servers
}

pub(crate) async fn dns_exchange(
    sender: &UdpSender,
    from_stack: &mut mpsc::Receiver<(SocketAddr, Vec<u8>)>,
    name: &str,
    qtype: u16,
) -> Result<DnsAnswer> {
    let mut last = AetherError::Other("dns timeout".into());

    for server in resolver_addresses() {
        let (query, id) = build_dns_query(name, qtype);
        if let Err(error) = sender.send_to(server, query).await {
            last = error;
            continue;
        }

        let deadline = tokio::time::Instant::now() + Duration::from_secs(5);

        loop {
            let resp = match tokio::time::timeout_at(deadline, from_stack.recv()).await {
                Ok(Some(resp)) => resp,
                Ok(None) => return Err(AetherError::Other("dns channel closed".into())),
                Err(_) => {
                    last = AetherError::Other(format!("dns timeout from {server}"));
                    break;
                }
            };

            if !dns_response_matches(&resp.1, id, name, qtype) {
                continue;
            }
            if let Some(ip) = parse_dns_answer(&resp.1, qtype) {
                return Ok(DnsAnswer::Found(ip));
            }
            if dns_rcode(&resp.1) == Some(RCODE_NXDOMAIN) {
                return Ok(DnsAnswer::NoSuchName);
            }
            return Ok(DnsAnswer::NoRecord);
        }
    }

    Err(last)
}

pub(crate) const QTYPE_A: u16 = 1;
pub(crate) const QTYPE_AAAA: u16 = 28;
pub(crate) const RCODE_NXDOMAIN: u8 = 3;

pub(crate) fn dns_rcode(resp: &[u8]) -> Option<u8> {
    resp.get(3).map(|flags| flags & 0x0f)
}

pub(crate) fn build_dns_query(name: &str, qtype: u16) -> (Vec<u8>, u16) {
    let mut q = Vec::with_capacity(32 + name.len());
    let id: u16 = rand::random();
    q.extend_from_slice(&id.to_be_bytes());
    q.extend_from_slice(&[0x01, 0x00]);
    q.extend_from_slice(&[0x00, 0x01]);
    q.extend_from_slice(&[0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    for label in name.split('.') {
        q.push(label.len() as u8);
        q.extend_from_slice(label.as_bytes());
    }
    q.push(0x00);
    q.extend_from_slice(&qtype.to_be_bytes());
    q.extend_from_slice(&[0x00, 0x01]);
    (q, id)
}

pub(crate) fn dns_response_matches(
    resp: &[u8],
    expected_id: u16,
    expected_name: &str,
    expected_qtype: u16,
) -> bool {
    if resp.len() < 12 {
        return false;
    }
    if u16::from_be_bytes([resp[0], resp[1]]) != expected_id {
        return false;
    }
    if resp[2] & 0x80 == 0 {
        return false;
    }
    if u16::from_be_bytes([resp[4], resp[5]]) != 1 {
        return false;
    }

    let mut pos = 12;
    for label in expected_name.split('.') {
        if label.is_empty() {
            continue;
        }
        let len = match resp.get(pos) {
            Some(value) => *value as usize,
            None => return false,
        };
        if len != label.len() {
            return false;
        }
        pos += 1;
        let end = match pos.checked_add(len) {
            Some(value) if value <= resp.len() => value,
            _ => return false,
        };
        if !resp[pos..end].eq_ignore_ascii_case(label.as_bytes()) {
            return false;
        }
        pos = end;
    }

    if resp.get(pos) != Some(&0) {
        return false;
    }
    pos += 1;

    if pos + 4 > resp.len() {
        return false;
    }
    u16::from_be_bytes([resp[pos], resp[pos + 1]]) == expected_qtype
}

pub(crate) fn parse_dns_answer(resp: &[u8], qtype: u16) -> Option<IpAddr> {
    if resp.len() < 12 {
        return None;
    }
    let qd = u16::from_be_bytes([resp[4], resp[5]]) as usize;
    let an = u16::from_be_bytes([resp[6], resp[7]]) as usize;
    let mut pos = 12;

    for _ in 0..qd {
        pos = skip_name(resp, pos)?;
        pos = pos.checked_add(4)?;
    }

    for _ in 0..an {
        pos = skip_name(resp, pos)?;
        if pos + 10 > resp.len() {
            return None;
        }
        let rtype = u16::from_be_bytes([resp[pos], resp[pos + 1]]);
        let rdlen = u16::from_be_bytes([resp[pos + 8], resp[pos + 9]]) as usize;
        pos += 10;
        if pos + rdlen > resp.len() {
            return None;
        }
        if rtype == qtype && qtype == QTYPE_A && rdlen == 4 {
            return Some(IpAddr::V4(Ipv4Addr::new(
                resp[pos],
                resp[pos + 1],
                resp[pos + 2],
                resp[pos + 3],
            )));
        }
        if rtype == qtype && qtype == QTYPE_AAAA && rdlen == 16 {
            let mut octets = [0u8; 16];
            octets.copy_from_slice(&resp[pos..pos + 16]);
            return Some(IpAddr::V6(Ipv6Addr::from(octets)));
        }
        pos += rdlen;
    }
    None
}

pub(crate) fn skip_name(buf: &[u8], mut pos: usize) -> Option<usize> {
    loop {
        let len = *buf.get(pos)?;
        if len & 0xc0 == 0xc0 {
            return Some(pos + 2);
        }
        if len == 0 {
            return Some(pos + 1);
        }
        pos += 1 + len as usize;
    }
}
