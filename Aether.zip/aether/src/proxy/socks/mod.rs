use std::future::Future;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{mpsc, Semaphore};

use crate::error::{AetherError, Result};
use crate::transport::warp::netstack::{StackHandle, TcpSender, UdpSender};

// The routed listeners moved to `crate::proxy`; these names stay for the callers.
pub use crate::proxy::outbound::BoxStream;
pub(crate) use crate::proxy::outbound::{detour_proxy, Exit};
#[cfg(test)]
pub(crate) use crate::proxy::outbound::SocksSunny;

mod direct;
mod dns;
mod gateway;
mod http;
mod listen;
mod relay;

pub use gateway::*;
pub use http::*;
pub use listen::*;
pub(crate) use direct::*;
pub(crate) use dns::*;
pub(crate) use relay::*;

#[cfg(test)]
mod accept_tests;
#[cfg(test)]
mod http_tests;
#[cfg(test)]
mod relay_tests;
#[cfg(test)]
mod tests;

pub(crate) const VER: u8 = 0x05;
pub(crate) const CMD_CONNECT: u8 = 0x01;
pub(crate) const CMD_UDP_ASSOCIATE: u8 = 0x03;
pub(crate) const ATYP_V4: u8 = 0x01;
pub(crate) const ATYP_DOMAIN: u8 = 0x03;
pub(crate) const ATYP_V6: u8 = 0x04;
pub(crate) const REP_OK: u8 = 0x00;
pub(crate) const REP_GENERAL: u8 = 0x01;
pub(crate) const REP_NOT_ALLOWED: u8 = 0x02;
pub(crate) const REP_NOT_SUPPORTED: u8 = 0x07;

#[derive(Debug, Clone)]
pub(crate) enum Target {
    Ip(IpAddr),
    Domain(String),
}

impl std::fmt::Display for Target {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Target::Ip(ip) => write!(f, "{ip}"),
            Target::Domain(name) => write!(f, "{name}"),
        }
    }
}

pub(crate) async fn read_request(sock: &mut TcpStream) -> Result<(u8, Target, u16)> {
    handshake(sock).await?;

    let mut head = [0u8; 4];
    sock.read_exact(&mut head).await?;
    if head[0] != VER {
        return Err(AetherError::Other("bad socks version".into()));
    }

    let (target, port) = read_target(sock, head[3]).await?;
    Ok((head[1], target, port))
}

pub(crate) async fn handshake(sock: &mut TcpStream) -> Result<()> {
    let mut prefix = [0u8; 2];
    sock.read_exact(&mut prefix).await?;
    if prefix[0] != VER {
        return Err(AetherError::Other("bad greeting version".into()));
    }
    let nmethods = prefix[1] as usize;
    let mut methods = vec![0u8; nmethods];
    sock.read_exact(&mut methods).await?;
    sock.write_all(&[VER, 0x00]).await?;
    Ok(())
}

/// The address after an ATYP byte (IPv4, IPv6 or a domain name, then the port) at the start of
/// `buf`, and how many bytes it took; `None` for a short buffer or an unknown ATYP.
pub(crate) fn decode_addr(atyp: u8, buf: &[u8]) -> Option<(Target, u16, usize)> {
    let (target, len) = match atyp {
        ATYP_V4 => {
            let b: [u8; 4] = buf.get(..4)?.try_into().ok()?;
            (Target::Ip(IpAddr::V4(Ipv4Addr::from(b))), 4)
        }
        ATYP_V6 => {
            let b: [u8; 16] = buf.get(..16)?.try_into().ok()?;
            (Target::Ip(IpAddr::V6(b.into())), 16)
        }
        ATYP_DOMAIN => {
            let n = *buf.first()? as usize;
            let name = buf.get(1..1 + n)?;
            (Target::Domain(String::from_utf8_lossy(name).to_string()), 1 + n)
        }
        _ => return None,
    };
    let port = buf.get(len..len + 2)?;
    Some((target, u16::from_be_bytes([port[0], port[1]]), len + 2))
}

/// `decode_addr` on a stream: reads exactly the address and its port.
pub(crate) async fn read_addr<R: AsyncRead + Unpin>(r: &mut R, atyp: u8) -> std::io::Result<(Target, u16)> {
    let bad = || std::io::Error::new(std::io::ErrorKind::InvalidData, "bad atyp");
    let mut buf = Vec::with_capacity(258);
    let need = match atyp {
        ATYP_V4 => 4 + 2,
        ATYP_V6 => 16 + 2,
        ATYP_DOMAIN => {
            buf.push(r.read_u8().await?);
            1 + buf[0] as usize + 2
        }
        _ => return Err(bad()),
    };
    let have = buf.len();
    buf.resize(need, 0);
    r.read_exact(&mut buf[have..]).await?;
    decode_addr(atyp, &buf).map(|(target, port, _)| (target, port)).ok_or_else(bad)
}

pub(crate) async fn read_target(sock: &mut TcpStream, atyp: u8) -> Result<(Target, u16)> {
    read_addr(sock, atyp).await.map_err(|e| match e.kind() {
        std::io::ErrorKind::InvalidData => AetherError::Other("bad atyp".into()),
        _ => e.into(),
    })
}

/// A socks5 reply with `code` and an all-zero IPv4 bound address.
pub(crate) const fn reply_bytes(code: u8) -> [u8; 10] {
    [VER, code, 0x00, ATYP_V4, 0, 0, 0, 0, 0, 0]
}

/// `address` as socks5 writes it: ATYP, the address, the port.
pub(crate) fn push_socket_addr(buf: &mut Vec<u8>, address: SocketAddr) {
    match address.ip() {
        IpAddr::V4(v4) => {
            buf.push(ATYP_V4);
            buf.extend_from_slice(&v4.octets());
        }
        IpAddr::V6(v6) => {
            buf.push(ATYP_V6);
            buf.extend_from_slice(&v6.octets());
        }
    }
    buf.extend_from_slice(&address.port().to_be_bytes());
}

pub(crate) async fn reply(sock: &mut TcpStream, code: u8) -> Result<()> {
    sock.write_all(&reply_bytes(code)).await?;
    Ok(())
}

pub(crate) async fn reply_bound(sock: &mut TcpStream, bound: SocketAddr) -> Result<()> {
    let mut buf = vec![VER, REP_OK, 0x00];
    push_socket_addr(&mut buf, bound);
    sock.write_all(&buf).await?;
    Ok(())
}

pub(crate) fn parse_udp_request(buf: &[u8]) -> Option<(Target, (u16, Vec<u8>))> {
    if buf.len() < 4 || buf[2] != 0 {
        return None;
    }
    let (target, port, used) = decode_addr(buf[3], &buf[4..])?;
    Some((target, (port, buf[4 + used..].to_vec())))
}

pub(crate) fn build_udp_reply(src: SocketAddr, data: &[u8]) -> Vec<u8> {
    let mut pkt = vec![0x00, 0x00, 0x00];
    push_socket_addr(&mut pkt, src);
    pkt.extend_from_slice(data);
    pkt
}
