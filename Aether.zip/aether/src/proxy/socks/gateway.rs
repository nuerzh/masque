//! The corporate gateway proxy (an HTTP CONNECT proxy some networks require) and tunnels opened through it.

use super::*;

pub(crate) static GATEWAY_PROXY: std::sync::OnceLock<SocketAddr> = std::sync::OnceLock::new();

pub fn set_gateway_proxy(address: &str) {
    let trimmed = address.trim();
    if trimmed.is_empty() {
        return;
    }
    match trimmed.parse::<SocketAddr>() {
        Ok(parsed) => {
            if GATEWAY_PROXY.set(parsed).is_ok() {
                log::info!(
                    "[socks] gateway filtering active: http and https will traverse {parsed} inside the tunnel"
                );
            }
        }
        Err(_) => log::warn!("[socks] ignoring malformed gateway proxy address {trimmed}"),
    }
}

pub(crate) static GATEWAY_HEALTHY: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(true);

pub(crate) fn gateway_proxy() -> Option<SocketAddr> {
    if !GATEWAY_HEALTHY.load(std::sync::atomic::Ordering::Relaxed) {
        return None;
    }
    GATEWAY_PROXY.get().copied()
}

pub(crate) fn retire_gateway(reason: &str) {
    if GATEWAY_HEALTHY.swap(false, std::sync::atomic::Ordering::Relaxed) {
        log::warn!(
            "[socks] the gateway proxy is not reachable ({reason}); sending traffic straight through \
             the tunnel instead. organization http filtering will not apply"
        );
    }
}

pub(crate) fn should_use_gateway(port: u16) -> bool {
    matches!(port, 80 | 443)
}

pub(crate) fn build_proxy_connect(target: &str, port: u16) -> Vec<u8> {
    let authority = if target.contains(':') && !target.starts_with('[') {
        format!("[{target}]:{port}")
    } else {
        format!("{target}:{port}")
    };

    format!(
        "CONNECT {authority} HTTP/1.1\r\nHost: {authority}\r\nUser-Agent: {}\r\n\r\n",
        crate::transport::warp::consts::UA_REGISTER
    )
    .into_bytes()
}

pub(crate) fn proxy_connect_succeeded(head: &[u8]) -> Option<bool> {
    let text = String::from_utf8_lossy(head);
    let line_end = text.find("\r\n")?;
    let status = text[..line_end]
        .split_whitespace()
        .nth(1)?
        .parse::<u16>()
        .ok()?;
    Some((200..300).contains(&status))
}

pub(crate) const GATEWAY_HEAD_LIMIT: usize = 8192;
pub(crate) const GATEWAY_PROBE_TIMEOUT: Duration = Duration::from_secs(5);

pub(crate) type GatewayChannel = (TcpSender, mpsc::Receiver<Vec<u8>>, Vec<u8>);

pub(crate) fn find_head_end(buffer: &[u8]) -> Option<usize> {
    buffer
        .windows(4)
        .position(|window| window == b"\r\n\r\n")
        .map(|at| at + 4)
}

pub(crate) async fn open_through_gateway(
    stack: &StackHandle,
    proxy: SocketAddr,
    authority: &str,
    port: u16,
) -> Result<GatewayChannel> {
    let conn = tokio::time::timeout(GATEWAY_PROBE_TIMEOUT, stack.open_tcp(proxy))
        .await
        .map_err(|_| {
            AetherError::Other(format!("gateway {proxy} did not accept a connection"))
        })??;
    let (sender, mut from_stack) = conn.into_split();

    sender.send(build_proxy_connect(authority, port)).await?;

    let mut head: Vec<u8> = Vec::new();
    loop {
        let chunk = tokio::time::timeout(GATEWAY_PROBE_TIMEOUT, from_stack.recv())
            .await
            .map_err(|_| AetherError::Other(format!("gateway {proxy} did not answer in time")))?
            .ok_or_else(|| AetherError::Other(format!("gateway {proxy} closed the connection")))?;

        head.extend_from_slice(&chunk);

        if let Some(at) = find_head_end(&head) {
            let accepted = proxy_connect_succeeded(&head).ok_or_else(|| {
                AetherError::Other(format!("gateway {proxy} sent a malformed response"))
            })?;

            if !accepted {
                let status = String::from_utf8_lossy(&head[..at])
                    .lines()
                    .next()
                    .unwrap_or("no status")
                    .trim()
                    .to_string();
                sender.close().await;
                return Err(AetherError::Other(format!(
                    "gateway refused {authority}:{port} ({status})"
                )));
            }

            return Ok((sender, from_stack, head[at..].to_vec()));
        }

        if head.len() > GATEWAY_HEAD_LIMIT {
            sender.close().await;
            return Err(AetherError::Other(format!(
                "gateway {proxy} sent an oversized response head"
            )));
        }
    }
}
