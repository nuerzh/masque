//! Direct connections from this machine: the safety checks, egress lookups, and dialing.

use super::*;

pub(crate) fn normalize_ip(ip: IpAddr) -> IpAddr {
    match ip {
        IpAddr::V6(v6) => match v6.to_ipv4_mapped() {
            Some(v4) => IpAddr::V4(v4),
            None => IpAddr::V6(v6),
        },
        other => other,
    }
}

pub(crate) fn expected_udp_source(control_peer: SocketAddr, requested: &Target) -> IpAddr {
    match requested {
        Target::Ip(ip) if !ip.is_unspecified() => normalize_ip(*ip),
        _ => normalize_ip(control_peer.ip()),
    }
}

pub(crate) fn udp_source_allowed(expected_ip: IpAddr, latched: Option<SocketAddr>, from: SocketAddr) -> bool {
    match latched {
        Some(known) => known == from,
        None => normalize_ip(from.ip()) == normalize_ip(expected_ip),
    }
}

pub(crate) const DIRECT_CONNECT_TIMEOUT: Duration = Duration::from_secs(10);

pub(crate) fn direct_target_allowed(client: IpAddr, address: IpAddr) -> bool {
    let address = normalize_ip(address);
    if address.is_loopback() || address.is_unspecified() {
        return normalize_ip(client).is_loopback();
    }
    true
}

/// The addresses of `host` for a `direct` connection. Without the TUN this is the system
/// resolver. With the TUN the system resolver points at the TUN itself (and with fake-ip would
/// answer with fake addresses, a loop), so Aether resolves on its own: through the tunnel
/// by asking the system's own dns servers (--tun-direct-dns system, the default: read before
/// the TUN took over) or the --tun-direct-dns servers over the physical interface, or through
/// the tunnel (--tun-direct-dns tunnel; the same servers over the physical interface while the
/// tunnel is down).
/// A fake-ip address is never returned.
pub(crate) async fn lookup_direct(host: &str, port: u16) -> std::io::Result<Vec<SocketAddr>> {
    let host = host.trim_start_matches('[').trim_end_matches(']');
    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(vec![SocketAddr::new(ip, port)]);
    }
    let found: Vec<SocketAddr> = match crate::proxy::inbound::tun::direct_dns() {
        None => tokio::net::lookup_host((host, port)).await?.collect(),
        // `System` is turned into `Servers` (or `Tunnel`) when the TUN starts
        Some(crate::proxy::inbound::tun::DirectDns::Tunnel | crate::proxy::inbound::tun::DirectDns::System) => match crate::proxy::router::exits::stack() {
            Some(stack) => match dns_resolve(&stack, host).await {
                Ok(ip) => vec![SocketAddr::new(ip, port)],
                Err(e) => return Err(std::io::Error::new(std::io::ErrorKind::NotFound, e.to_string())),
            },
            None => egress_dns_lookup(host, &resolver_addresses())
                .await
                .into_iter()
                .map(|ip| SocketAddr::new(ip, port))
                .collect(),
        },
        Some(crate::proxy::inbound::tun::DirectDns::Servers(list)) => {
            egress_dns_lookup(host, list).await.into_iter().map(|ip| SocketAddr::new(ip, port)).collect()
        }
    };
    let found: Vec<SocketAddr> = found.into_iter().filter(|a| !crate::proxy::inbound::tun::fakeip::is_fake(a.ip())).collect();
    if found.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("{host} did not resolve to any address"),
        ));
    }
    Ok(found)
}

/// The addresses of `host` for Aether's own connections (the WARP API, an upstream proxy):
/// the system resolver without the TUN; with it, the --tun-direct-dns servers (the system's
/// own by default; with tunnel, --dns,
/// 1.1.1.1) asked over the physical interface, since the tunnel may be the thing being set up.
pub(crate) async fn lookup_egress(host: &str, port: u16) -> std::io::Result<Vec<SocketAddr>> {
    let host = host.trim_start_matches('[').trim_end_matches(']');
    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(vec![SocketAddr::new(ip, port)]);
    }
    let servers = match crate::proxy::inbound::tun::direct_dns() {
        None => return Ok(tokio::net::lookup_host((host, port)).await?.collect()),
        Some(crate::proxy::inbound::tun::DirectDns::Servers(list)) => list.clone(),
        Some(crate::proxy::inbound::tun::DirectDns::Tunnel | crate::proxy::inbound::tun::DirectDns::System) => resolver_addresses(),
    };
    let found: Vec<SocketAddr> = egress_dns_lookup(host, &servers)
        .await
        .into_iter()
        .filter(|ip| !crate::proxy::inbound::tun::fakeip::is_fake(*ip))
        .map(|ip| SocketAddr::new(ip, port))
        .collect();
    if found.is_empty() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("{host} did not resolve to any address"),
        ));
    }
    Ok(found)
}

/// A plain dns lookup (A, then AAAA) sent from an egress socket, which never enters the TUN.
pub(crate) async fn egress_dns_lookup(name: &str, servers: &[SocketAddr]) -> Vec<IpAddr> {
    for server in servers {
        let Ok(sock) = crate::utils::egress::udp_bind(crate::utils::egress::wildcard_for(*server)) else { continue };
        if sock.connect(server).await.is_err() {
            continue;
        }
        let mut out = Vec::new();
        let mut no_such_name = false;
        for qtype in [QTYPE_A, QTYPE_AAAA] {
            let (query, id) = build_dns_query(name, qtype);
            if sock.send(&query).await.is_err() {
                break;
            }
            let deadline = tokio::time::Instant::now() + Duration::from_secs(3);
            let mut buf = vec![0u8; 4096];
            loop {
                let n = match tokio::time::timeout_at(deadline, sock.recv(&mut buf)).await {
                    Ok(Ok(n)) => n,
                    _ => break,
                };
                if !dns_response_matches(&buf[..n], id, name, qtype) {
                    continue;
                }
                let mut resp = buf[..n].to_vec();
                if dns_truncated(&resp) {
                    // too big for udp: ask again over tcp, from an egress socket too
                    match egress_dns_tcp(*server, &query, id, name, qtype).await {
                        Some(full) => resp = full,
                        None => log::debug!("[dns] {name}: truncated answer from {server} and no tcp answer"),
                    }
                }
                if let Some(ip) = parse_dns_answer(&resp, qtype) {
                    log::debug!(
                        "[dns] {name} {} -> {ip} (from {server}, physical interface)",
                        if qtype == QTYPE_A { "A" } else { "AAAA" }
                    );
                    out.push(ip);
                } else if dns_rcode(&resp) == Some(RCODE_NXDOMAIN) {
                    no_such_name = true;
                }
                break;
            }
            if !out.is_empty() || no_such_name {
                break;
            }
        }
        if !out.is_empty() || no_such_name {
            return out;
        }
    }
    Vec::new()
}

pub(crate) fn dns_truncated(resp: &[u8]) -> bool {
    resp.get(2).map(|flags| flags & 0x02 != 0).unwrap_or(false)
}

/// `query` over tcp (2-byte length prefix) to `server`, from an egress socket; the answer
/// when it is the one asked for.
pub(crate) async fn egress_dns_tcp(server: SocketAddr, query: &[u8], id: u16, name: &str, qtype: u16) -> Option<Vec<u8>> {
    let exchange = async {
        let mut stream = crate::utils::egress::tcp_connect(server).await.ok()?;
        let mut framed = Vec::with_capacity(query.len() + 2);
        framed.extend_from_slice(&(query.len() as u16).to_be_bytes());
        framed.extend_from_slice(query);
        stream.write_all(&framed).await.ok()?;
        let mut len = [0u8; 2];
        stream.read_exact(&mut len).await.ok()?;
        let mut resp = vec![0u8; u16::from_be_bytes(len) as usize];
        stream.read_exact(&mut resp).await.ok()?;
        Some(resp)
    };
    let resp = tokio::time::timeout(Duration::from_secs(4), exchange).await.ok()??;
    dns_response_matches(&resp, id, name, qtype).then_some(resp)
}

pub(crate) async fn connect_direct(host: &str, port: u16, client: IpAddr) -> std::io::Result<TcpStream> {
    let mut last_error = None;
    for address in lookup_direct(host, port).await? {
        if !direct_target_allowed(client, address.ip()) {
            last_error = Some(std::io::Error::new(
                std::io::ErrorKind::PermissionDenied,
                format!(
                    "{address} is this machine's own loopback, which only local clients may reach"
                ),
            ));
            continue;
        }
        match crate::utils::egress::tcp_connect(address).await {
            Ok(stream) => {
                let _ = stream.set_nodelay(true);
                enable_keepalive(&stream);
                return Ok(stream);
            }
            Err(error) => last_error = Some(error),
        }
    }
    Err(last_error.unwrap_or_else(|| {
        std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("{host} did not resolve to any address"),
        )
    }))
}
