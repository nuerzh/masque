use super::{parse_authority, parse_request_line, read_head};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

async fn head_over_socket(chunks: &[&[u8]]) -> (Vec<u8>, Vec<u8>) {
    let listener = TcpListener::bind("127.0.0.1:0").await.expect("bind");
    let addr = listener.local_addr().expect("addr");

    let owned: Vec<Vec<u8>> = chunks.iter().map(|c| c.to_vec()).collect();
    let writer = tokio::spawn(async move {
        let mut client = TcpStream::connect(addr).await.expect("connect");
        for chunk in owned {
            client.write_all(&chunk).await.expect("write");
            tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        }
        client.flush().await.expect("flush");
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;
    });

    let (mut server, _) = listener.accept().await.expect("accept");
    let (head, mut leftover) = read_head(&mut server).await.expect("head");

    let mut more = vec![0u8; 64];
    let n = tokio::time::timeout(
        std::time::Duration::from_millis(100),
        server.read(&mut more),
    )
    .await
    .map(|r| r.unwrap_or(0))
    .unwrap_or(0);
    leftover.extend_from_slice(&more[..n]);

    writer.abort();
    (head, leftover)
}

#[tokio::test]
async fn a_head_arriving_in_one_piece_is_read_exactly() {
    let (head, leftover) =
        head_over_socket(&[b"CONNECT a:443 HTTP/1.1\r\nHost: a\r\n\r\n"]).await;
    assert_eq!(head, b"CONNECT a:443 HTTP/1.1\r\nHost: a\r\n\r\n");
    assert!(leftover.is_empty());
}

#[tokio::test]
async fn a_head_split_across_writes_is_still_assembled() {
    let (head, _) =
        head_over_socket(&[b"CONNECT a:443 HT", b"TP/1.1\r\nHos", b"t: a\r\n", b"\r\n"]).await;
    assert_eq!(head, b"CONNECT a:443 HTTP/1.1\r\nHost: a\r\n\r\n");
}

#[tokio::test]
async fn bytes_after_the_head_are_kept_for_the_far_end() {
    let (head, leftover) =
        head_over_socket(&[b"CONNECT a:443 HTTP/1.1\r\n\r\n\x16\x03\x01pipelined"]).await;
    assert_eq!(head, b"CONNECT a:443 HTTP/1.1\r\n\r\n");
    assert_eq!(leftover, b"\x16\x03\x01pipelined");
}

#[test]
fn a_connect_request_carries_the_host_and_port() {
    let parsed = parse_request_line("CONNECT ipwho.is:443 HTTP/1.1").expect("parsed");
    assert_eq!(parsed.method, "CONNECT");
    assert_eq!(parsed.authority, "ipwho.is");
    assert_eq!(parsed.port, 443);
    assert!(parsed.rewritten.is_none());
}

#[test]
fn a_connect_request_without_a_port_defaults_to_https() {
    let parsed = parse_request_line("CONNECT example.com HTTP/1.1").expect("parsed");
    assert_eq!(parsed.port, 443);
}

#[test]
fn an_absolute_get_is_rewritten_to_origin_form() {
    let parsed = parse_request_line("GET http://ip-api.com/json/?fields=query HTTP/1.1")
        .expect("parsed");
    assert_eq!(parsed.authority, "ip-api.com");
    assert_eq!(parsed.port, 80);
    assert_eq!(
        parsed.rewritten.as_deref(),
        Some("GET /json/?fields=query HTTP/1.1\r\n")
    );
}

#[test]
fn an_absolute_url_without_a_path_gets_a_root_path() {
    let parsed = parse_request_line("GET http://example.com HTTP/1.1").expect("parsed");
    assert_eq!(parsed.rewritten.as_deref(), Some("GET / HTTP/1.1\r\n"));
}

#[test]
fn an_explicit_port_in_an_absolute_url_is_honoured() {
    let parsed = parse_request_line("GET http://example.com:8080/x HTTP/1.1").expect("parsed");
    assert_eq!(parsed.port, 8080);
    assert_eq!(parsed.authority, "example.com");
}

#[test]
fn ipv6_authorities_are_understood() {
    let parsed = parse_request_line("CONNECT [2606:4700::1]:443 HTTP/1.1").expect("parsed");
    assert_eq!(parsed.authority, "2606:4700::1");
    assert_eq!(parsed.port, 443);

    let bare = parse_authority("[2606:4700::1]", 443).expect("parsed");
    assert_eq!(bare, ("2606:4700::1".to_string(), 443));
}

#[test]
fn origin_form_requests_are_refused_because_a_proxy_needs_the_host() {
    assert!(parse_request_line("GET /json HTTP/1.1").is_none());
}

#[test]
fn https_absolute_urls_are_refused_since_clients_must_use_connect() {
    assert!(parse_request_line("GET https://example.com/ HTTP/1.1").is_none());
}

#[test]
fn a_malformed_line_is_rejected() {
    assert!(parse_request_line("").is_none());
    assert!(parse_request_line("CONNECT").is_none());
}
