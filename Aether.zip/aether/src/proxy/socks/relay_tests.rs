use super::*;
use crate::test_util::tcp_pair as pair;

#[tokio::test]
async fn a_far_end_that_never_closes_does_not_pin_a_half_closed_client() {
    let (mut client, proxied) = pair().await;
    let (dialed, mut far_end) = pair().await;
    let relay = tokio::spawn(relay_direct(proxied, dialed, Duration::from_millis(200)));

    client.write_all(b"request").await.unwrap();
    client.shutdown().await.unwrap();

    let mut request = Vec::new();
    far_end.read_to_end(&mut request).await.unwrap();
    assert_eq!(request, b"request");

    tokio::time::timeout(Duration::from_secs(5), relay)
        .await
        .expect("the relay must let go once the answer stops coming")
        .unwrap();

    let mut rest = Vec::new();
    let read = tokio::time::timeout(Duration::from_secs(1), client.read_to_end(&mut rest))
        .await
        .expect("the client must see the connection end");
    assert_eq!(read.unwrap(), 0);
    drop(far_end);
}

#[tokio::test]
async fn the_answer_to_a_half_closed_request_still_arrives_whole() {
    let (mut client, proxied) = pair().await;
    let (dialed, mut far_end) = pair().await;
    let relay = tokio::spawn(relay_direct(proxied, dialed, Duration::from_secs(5)));

    client.write_all(b"GET").await.unwrap();
    client.shutdown().await.unwrap();

    let mut request = Vec::new();
    far_end.read_to_end(&mut request).await.unwrap();
    far_end.write_all(b"the answer").await.unwrap();
    drop(far_end);

    let mut answer = Vec::new();
    client.read_to_end(&mut answer).await.unwrap();
    assert_eq!(answer, b"the answer");
    tokio::time::timeout(Duration::from_secs(5), relay)
        .await
        .expect("the relay ends with the far end")
        .unwrap();
}

#[tokio::test]
async fn an_answer_that_keeps_moving_outlives_the_linger() {
    let (mut client, proxied) = pair().await;
    let (dialed, mut far_end) = pair().await;
    let relay = tokio::spawn(relay_direct(proxied, dialed, Duration::from_millis(500)));

    client.shutdown().await.unwrap();
    let mut request = Vec::new();
    far_end.read_to_end(&mut request).await.unwrap();

    for byte in 0..20u8 {
        far_end.write_all(&[byte]).await.unwrap();
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
    drop(far_end);

    let mut answer = Vec::new();
    client.read_to_end(&mut answer).await.unwrap();
    assert_eq!(answer, (0..20u8).collect::<Vec<_>>());
    relay.await.unwrap();
}

#[test]
fn only_local_clients_may_reach_this_machines_loopback_directly() {
    let local: IpAddr = "127.0.0.1".parse().unwrap();
    let lan: IpAddr = "192.168.1.20".parse().unwrap();
    assert!(direct_target_allowed(local, "127.0.0.1".parse().unwrap()));
    assert!(direct_target_allowed(
        "::1".parse().unwrap(),
        "127.0.0.1".parse().unwrap()
    ));
    assert!(!direct_target_allowed(lan, "127.0.0.1".parse().unwrap()));
    assert!(!direct_target_allowed(lan, "127.8.9.10".parse().unwrap()));
    assert!(!direct_target_allowed(lan, "::1".parse().unwrap()));
    assert!(!direct_target_allowed(
        lan,
        "::ffff:127.0.0.1".parse().unwrap()
    ));
    assert!(!direct_target_allowed(lan, "0.0.0.0".parse().unwrap()));
    assert!(direct_target_allowed(lan, "192.168.1.1".parse().unwrap()));
    assert!(direct_target_allowed(lan, "93.184.216.34".parse().unwrap()));
}

#[tokio::test]
async fn a_lan_client_is_refused_a_loopback_target() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();

    let refused = connect_direct("127.0.0.1", port, "192.168.1.20".parse().unwrap())
        .await
        .expect_err("a lan client must not reach this machine's loopback");
    assert_eq!(refused.kind(), std::io::ErrorKind::PermissionDenied);

    assert!(
        connect_direct("127.0.0.1", port, "127.0.0.1".parse().unwrap())
            .await
            .is_ok()
    );
}

#[tokio::test]
async fn clients_past_the_limit_wait_for_a_free_slot() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let (served_tx, mut served) = mpsc::unbounded_channel::<SocketAddr>();

    let server = tokio::spawn(accept_clients(
        listener,
        "test",
        1,
        move |mut sock, peer| {
            let served_tx = served_tx.clone();
            async move {
                let _ = served_tx.send(peer);
                let mut buf = [0u8; 16];
                while let Ok(read) = sock.read(&mut buf).await {
                    if read == 0 {
                        break;
                    }
                }
            }
        },
    ));

    let first = TcpStream::connect(address).await.unwrap();
    let first_served = tokio::time::timeout(Duration::from_secs(2), served.recv())
        .await
        .expect("the first client is served")
        .unwrap();
    assert_eq!(first_served, first.local_addr().unwrap());

    let second = TcpStream::connect(address).await.unwrap();
    assert!(
        tokio::time::timeout(Duration::from_millis(300), served.recv())
            .await
            .is_err(),
        "the second client must wait while the first holds the only slot"
    );

    drop(first);
    let second_served = tokio::time::timeout(Duration::from_secs(2), served.recv())
        .await
        .expect("the second client is served once the slot frees up")
        .unwrap();
    assert_eq!(second_served, second.local_addr().unwrap());
    server.abort();
}
