//! Tests of the outbounds and the session, moved with them from socks/routed.rs.

use crate::proxy::prelude::*;

#[test]
fn outbounds_mean_one_thing_each() {
    // sunny and warp are themselves on every listener; only the alias follows the mode
    assert_eq!(Via::of(OutKind::Sunny, &Exit::Current), Via::Sunny);
    assert_eq!(Via::of(OutKind::Warp, &Exit::Current), Via::Warp);
    if !crate::proxy::router::sunny_mode() {
        assert_eq!(Via::of(OutKind::Tunnel, &Exit::Current), Via::Warp);
    }
}

/// `warp` with no WARP stack fails rather than going anywhere else.
#[tokio::test]
async fn warp_without_a_warp_stack_fails() {
    if exits::stack().is_some() {
        return;
    }
    let r = dial(OutKind::Warp, "example.com", 443, &[], "127.0.0.1".parse().unwrap(), &Exit::Current).await;
    assert!(r.is_err());
}

#[test]
fn warp_local_is_its_own_outbound() {
    assert_eq!(Via::of(OutKind::WarpLocal, &Exit::Current), Via::WarpLocal);
    assert_eq!(Via::WarpLocal.label(), "warp-local");
    assert_eq!(OutKind::WarpLocal.label(), "warp-local");
    assert_eq!(OutKind::WarpLocal.effective(), OutKind::WarpLocal);
}

/// Like warp: no WARP stack, no connection (never direct).
#[tokio::test]
async fn warp_local_without_a_warp_stack_fails() {
    if exits::stack().is_some() {
        return;
    }
    let r = dial(OutKind::WarpLocal, "localhost", 443, &[], "127.0.0.1".parse().unwrap(), &Exit::Current).await;
    assert!(r.is_err());
    let r = dial(OutKind::WarpLocal, "192.0.2.1", 443, &[], "127.0.0.1".parse().unwrap(), &Exit::Current).await;
    assert!(r.is_err());
}

fn fake_pool() -> &'static crate::proxy::inbound::tun::fakeip::FakePool {
    use crate::proxy::inbound::tun::fakeip::{FakeIpConfig, DEFAULT_RANGE};
    crate::proxy::inbound::tun::fakeip::install(FakeIpConfig::parse(DEFAULT_RANGE).unwrap());
    crate::proxy::inbound::tun::fakeip::pool().unwrap()
}

/// An address target goes to WARP as it is, with no lookup.
#[tokio::test]
async fn warp_local_dials_an_address_target_as_it_is() {
    let mut asked = Vec::new();
    let r = warp_local_connect("203.0.113.7", 443, &[], |ip| {
        asked.push(ip);
        async move { Ok::<IpAddr, AetherError>(ip) }
    })
    .await
    .unwrap();
    assert_eq!(r, "203.0.113.7".parse::<IpAddr>().unwrap());
    assert_eq!(asked, vec!["203.0.113.7".parse::<IpAddr>().unwrap()]);
}

/// A name is resolved by direct's resolver (here, no TUN: the system resolver), and only
/// the addresses found are dialed through WARP, in turn until one connects.
#[tokio::test]
async fn warp_local_resolves_a_name_locally_and_dials_the_addresses_in_turn() {
    let want = lookup_direct("localhost", 443).await.unwrap();
    let mut asked = Vec::new();
    let r = warp_local_connect("localhost", 443, &[], |ip| {
        asked.push(ip);
        async move { Err::<(), AetherError>(AetherError::Other(format!("{ip} refused"))) }
    })
    .await;
    assert!(r.is_err());
    assert!(!asked.is_empty());
    assert!(asked.iter().all(|ip| ip.is_loopback()), "{asked:?}");
    for ip in &asked {
        assert!(want.iter().any(|a| a.ip() == *ip), "{ip} is not what the system resolver gave");
    }
    // the first address that connects wins
    let mut n = 0;
    let r = warp_local_connect("localhost", 443, &[], |ip| {
        n += 1;
        async move { Ok::<IpAddr, AetherError>(ip) }
    })
    .await
    .unwrap();
    assert!(r.is_loopback());
    assert_eq!(n, 1);
}

/// Fake-ip addresses are never dialed: not from a resolve result, not as the target.
#[tokio::test]
async fn warp_local_never_dials_a_fake_address() {
    let pool = fake_pool();
    let fake = IpAddr::V4(pool.v4_for("warp-local-fake.example").unwrap());
    assert!(crate::proxy::inbound::tun::fakeip::is_fake(fake));
    let real: IpAddr = "192.0.2.5".parse().unwrap();
    let mut asked = Vec::new();
    let r = warp_local_connect("warp-local-fake.example", 443, &[fake, real], |ip| {
        asked.push(ip);
        async move { Ok::<IpAddr, AetherError>(ip) }
    })
    .await
    .unwrap();
    assert_eq!(r, real);
    assert_eq!(asked, vec![real]);
    // only fake addresses from the rules: resolved again locally
    let (ips, from) = warp_local_addresses("localhost", 443, &[fake]).await.unwrap();
    assert!(ips.iter().all(|ip| ip.is_loopback() && !crate::proxy::inbound::tun::fakeip::is_fake(*ip)));
    assert_eq!(from, "system dns");
    // a fake address as the target (stale): refused, nothing dialed
    let mut called = false;
    let r = warp_local_connect(&fake.to_string(), 443, &[], |ip| {
        called = true;
        async move { Ok::<IpAddr, AetherError>(ip) }
    })
    .await;
    assert!(r.is_err());
    assert!(!called);
}

#[test]
fn warp_local_takes_the_two_families_in_turn() {
    let ips: Vec<IpAddr> = ["1.1.1.1", "1.0.0.1", "2606:4700::1111", "2606:4700::1001"].iter().map(|s| s.parse().unwrap()).collect();
    let got = interleave_families(ips);
    let want: Vec<IpAddr> = ["1.1.1.1", "2606:4700::1111", "1.0.0.1", "2606:4700::1001"].iter().map(|s| s.parse().unwrap()).collect();
    assert_eq!(got, want);
    let v6first: Vec<IpAddr> = ["2606:4700::1111", "1.1.1.1", "1.0.0.1"].iter().map(|s| s.parse().unwrap()).collect();
    let got = interleave_families(v6first);
    assert_eq!(got[0].to_string(), "2606:4700::1111");
    assert_eq!(got[1].to_string(), "1.1.1.1");
    assert_eq!(got[2].to_string(), "1.0.0.1");
}

/// UDP: an address goes as `Warp(address)`; a name waits for the local lookup; a `resolve`
/// result from the tunnel's resolver is not used, a local one is.
#[tokio::test]
async fn warp_local_udp_flows() {
    let verdict = || Verdict::Route { kind: OutKind::WarpLocal, tag: "warp-local".into() };
    let peer: SocketAddr = "127.0.0.1:40000".parse().unwrap();
    let ropts = RouteOpts::default();
    let m = Metadata::new("tun", Network::Udp, peer, "192.0.2.9", 3478);
    assert!(matches!(flow_of(verdict(), &m, &ropts, &Exit::Current).await, FlowRoute::Warp(Some(a)) if a == "192.0.2.9:3478".parse().unwrap()));
    let mut m = Metadata::new("tun", Network::Udp, peer, "stun.example", 3478);
    assert!(matches!(flow_of(verdict(), &m, &ropts, &Exit::Current).await, FlowRoute::WarpLocal));
    m.resolved = vec!["192.0.2.10".parse().unwrap()];
    m.resolved_local = false;
    assert!(matches!(flow_of(verdict(), &m, &ropts, &Exit::Current).await, FlowRoute::WarpLocal));
    m.resolved_local = true;
    assert!(matches!(flow_of(verdict(), &m, &ropts, &Exit::Current).await, FlowRoute::Warp(Some(a)) if a == "192.0.2.10:3478".parse().unwrap()));
    // a UDP flow by name resolves through direct's resolver
    let (ips, _) = warp_local_addresses("localhost", 3478, &[]).await.unwrap();
    assert!(ips.iter().all(|ip| ip.is_loopback()));
}

#[test]
fn a_client_hello_is_split_into_two_records_with_the_same_bytes() {
    let mut hs = vec![1, 0, 0, 40];
    hs.extend_from_slice(&[0x42; 40]);
    let mut rec = vec![0x16, 0x03, 0x01, 0, hs.len() as u8];
    rec.extend_from_slice(&hs);
    let split = split_tls_records(&rec).unwrap();
    assert_eq!(split.len(), rec.len() + 5);
    assert_eq!(split[0], 0x16);
    let l1 = u16::from_be_bytes([split[3], split[4]]) as usize;
    assert_eq!(split[5 + l1], 0x16);
    let mut joined = split[5..5 + l1].to_vec();
    joined.extend_from_slice(&split[10 + l1..]);
    assert_eq!(joined, hs);
    assert!(split_tls_records(b"GET / HTTP/1.1\r\n").is_none());
}
