//! Routed udp associations (many destinations over one client association).

use super::prelude::*;

/// A flow whose route is known, with the packets that waited for it.
type ReadyFlow = ((String, u16), FlowRoute, Vec<Vec<u8>>);

struct Pending {
    packets: Vec<Vec<u8>>,
    deadline: tokio::time::Instant,
    next: usize,
    opts: SniffOpts,
    meta: Metadata,
    route_opts: RouteOpts,
}

/// A datagram from the client: its destination, port, payload and the client address it came from.
pub(crate) type ClientDatagram = (Target, u16, Vec<u8>, SocketAddr);

/// The client side of a udp association: the datagrams it sends, each with its destination,
/// and where the answers go back. A socks5 UDP ASSOCIATE, or a sunnyquic server's udp session.
pub(crate) trait DatagramClient: Send + Sync {
    /// The next datagram: its destination, port, payload and the client address it came from.
    /// `None` ends the association.
    fn recv(&self) -> crate::proxy::router::exits::BoxFuture<'_, Option<ClientDatagram>>;
    /// An answer from `src` back to the client.
    fn send<'a>(&'a self, src: SocketAddr, data: &'a [u8]) -> crate::proxy::router::exits::BoxFuture<'a, ()>;
}

/// Answers from the udp sessions of outbounds that carry their own, by registry index; `None`
/// when a session ended.
type SessionAnswer = (u16, Option<(Option<SocketAddr>, Vec<u8>)>);

type WarpUdpRx = tokio::sync::mpsc::Receiver<(SocketAddr, Vec<u8>)>;

/// The state of one routed udp association.
struct Nat<'a> {
    router: &'a Router,
    exit: &'a Exit,
    tag: &'a str,
    local: Option<SocketAddr>,
    control_peer: SocketAddr,
    stack: Option<StackHandle>,
    warp_tx: Option<UdpSender>,
    direct: UdpSocket,
    // the udp sessions of outbounds that carry their own (sunnyquic), by registry index; their
    // answers come in on one channel, a `None` when a session ended
    sessions: HashMap<u16, SunnyUdp>,
    answers_tx: tokio::sync::mpsc::Sender<SessionAnswer>,
    flows: HashMap<(String, u16), FlowRoute>,
    pending: HashMap<(String, u16), Pending>,
    dns_ids: HashMap<u16, SocketAddr>,
    resolver: SocketAddr,
}

/// A udp association through the router: each destination is routed on its own (with packet
/// sniffing), and carried direct, through the WARP stack, to the dns resolver, or by sunny.
/// `tag` is the inbound's, `peer` the client's address (for the `direct` safety check) and
/// `local` the address the client reached.
pub(crate) async fn udp_nat(router: &Router, exit: &Exit, tag: &str, peer: SocketAddr, local: Option<SocketAddr>, client: &dyn DatagramClient) -> Result<()> {
    router.wait_ready().await;

    let stack = exit.stack();
    let (warp_tx, mut warp_rx) = open_warp_udp(&stack).await;
    let direct = crate::utils::egress::udp_bind(crate::utils::egress::WILDCARD_V4)?;
    let (answers_tx, mut answers_rx) = tokio::sync::mpsc::channel::<SessionAnswer>(256);
    let mut nat = Nat {
        router,
        exit,
        tag,
        local,
        control_peer: peer,
        stack,
        warp_tx,
        direct,
        sessions: HashMap::new(),
        answers_tx,
        flows: HashMap::new(),
        pending: HashMap::new(),
        dns_ids: HashMap::new(),
        resolver: resolver_addresses()[0],
    };
    let mut dbuf = vec![0u8; 65535];

    loop {
        let next_deadline = nat.pending.values().map(|p| p.deadline).min();
        let mut ready: Vec<ReadyFlow> = Vec::new();

        tokio::select! {
            r = client.recv() => {
                let Some((dst, dst_port, payload, from)) = r else { break };
                nat.on_datagram(dst, dst_port, payload, from, &mut ready).await;
            }

            _ = async { match next_deadline { Some(d) => tokio::time::sleep_until(d).await, None => std::future::pending().await } } => {
                nat.expire(&mut ready).await;
            }

            maybe = async { match warp_rx.as_mut() { Some(rx) => rx.recv().await, None => std::future::pending().await } } => {
                let Some((src, data)) = maybe else {
                    warp_rx = None;
                    nat.warp_tx = None;
                    continue;
                };
                let src = nat.answer_source(src, &data);
                client.send(src, &data).await;
            }

            r = nat.direct.recv_from(&mut dbuf) => {
                let Ok((n, from)) = r else { continue };
                client.send(from, &dbuf[..n]).await;
            }

            r = answers_rx.recv() => {
                let Some((index, answer)) = r else { continue };
                match answer {
                    Some((Some(src), data)) => client.send(src, &data).await,
                    Some((None, _)) => {}
                    None => {
                        nat.sessions.remove(&index);
                    }
                }
            }

        }

        if !ready.is_empty() {
            nat.follow_stack(&mut warp_rx).await;
        }
        for ((host, port), route, packets) in ready {
            let route = nat.resolve(&host, port, route).await;
            for payload in packets {
                nat.deliver(&host, port, &route, payload).await;
            }
        }
    }
    if let Some(tx) = nat.warp_tx {
        tx.close().await;
    }
    Ok(())
}

impl Nat<'_> {
    /// Routes a datagram from the client; a flow whose route became known lands in `ready`.
    async fn on_datagram(&mut self, dst: Target, dst_port: u16, payload: Vec<u8>, from: SocketAddr, ready: &mut Vec<ReadyFlow>) {
        // a fake-ip address stands for its name
        let dst = match dst {
            Target::Ip(ip) => match crate::proxy::inbound::tun::fakeip::restore(ip) {
                crate::proxy::inbound::tun::fakeip::Restored::Real => Target::Ip(ip),
                crate::proxy::inbound::tun::fakeip::Restored::Name(n) => Target::Domain(n),
                crate::proxy::inbound::tun::fakeip::Restored::Stale => return,
            },
            d => d,
        };
        let key = (target_host(&dst), dst_port);
        if let Some(route) = self.flows.get(&key) {
            ready.push((key, route.clone(), vec![payload]));
        } else if let Some(p) = self.pending.get_mut(&key) {
            p.packets.push(payload);
            match sniffers::packets(&p.packets, &p.opts.packet()) {
                Outcome::NeedMore if p.packets.len() < 4 => {}
                outcome => {
                    let Some(mut p) = self.pending.remove(&key) else { return };
                    apply_packet_sniff(&mut p.meta, outcome);
                    let route = finish_udp(self.router, &mut p.meta, p.next, &mut p.route_opts, self.exit, &key).await;
                    self.flows.insert(key.clone(), route.clone());
                    ready.push((key, route, p.packets));
                }
            }
        } else {
            let mut meta = Metadata::new(&super::inbound::tag_of(self.tag), Network::Udp, from, &key.0, dst_port);
            meta.local = self.local;
            let mut ropts = RouteOpts::default();
            match first_udp_step(self.router, &mut meta, &mut ropts, self.exit, &payload).await {
                Ok(route) => {
                    self.flows.insert(key.clone(), route.clone());
                    ready.push((key, route, vec![payload]));
                }
                Err((next, opts)) => {
                    let outcome = sniffers::packets(std::slice::from_ref(&payload), &opts.packet());
                    if outcome == Outcome::NeedMore {
                        self.pending.insert(key, Pending {
                            packets: vec![payload],
                            deadline: tokio::time::Instant::now() + opts.timeout,
                            next,
                            opts,
                            meta,
                            route_opts: ropts,
                        });
                    } else {
                        apply_packet_sniff(&mut meta, outcome);
                        let route = finish_udp(self.router, &mut meta, next, &mut ropts, self.exit, &key).await;
                        self.flows.insert(key.clone(), route.clone());
                        ready.push((key, route, vec![payload]));
                    }
                }
            }
        }
    }

    /// Routes the flows whose sniffing ran out of time with what they have.
    async fn expire(&mut self, ready: &mut Vec<ReadyFlow>) {
        let now = tokio::time::Instant::now();
        let expired: Vec<(String, u16)> = self.pending.iter().filter(|(_, p)| p.deadline <= now).map(|(k, _)| k.clone()).collect();
        for key in expired {
            let Some(mut p) = self.pending.remove(&key) else { continue };
            let outcome = sniffers::packets(&p.packets, &p.opts.packet());
            apply_packet_sniff(&mut p.meta, outcome);
            let route = finish_udp(self.router, &mut p.meta, p.next, &mut p.route_opts, self.exit, &key).await;
            self.flows.insert(key.clone(), route.clone());
            ready.push((key, route, p.packets));
        }
    }

    /// The address an answer through WARP goes back from: a dns answer from the resolver
    /// comes from the server the client asked.
    fn answer_source(&mut self, src: SocketAddr, data: &[u8]) -> SocketAddr {
        if src == self.resolver && data.len() >= 2 {
            let id = u16::from_be_bytes([data[0], data[1]]);
            self.dns_ids.remove(&id).unwrap_or(src)
        } else {
            src
        }
    }

    /// The WARP tunnel reconnected: this association's flows go on through the new stack.
    async fn follow_stack(&mut self, warp_rx: &mut Option<WarpUdpRx>) {
        if !matches!(self.exit, Exit::Current) {
            return;
        }
        let now = self.exit.stack();
        let moved = match (&self.stack, &now) {
            (Some(a), Some(b)) => !a.same(b),
            (None, Some(_)) => true,
            _ => false,
        };
        if moved || (self.warp_tx.is_none() && now.is_some()) {
            if let Some(tx) = self.warp_tx.take() {
                tx.close().await;
            }
            self.stack = now;
            (self.warp_tx, *warp_rx) = open_warp_udp(&self.stack).await;
        }
    }

    /// A flow addressed by name is resolved once, then remembered with its address.
    async fn resolve(&mut self, host: &str, port: u16, route: FlowRoute) -> FlowRoute {
        match &route {
            FlowRoute::Direct(None) => {
                if let Some(a) = lookup_direct(host, port).await.ok().and_then(|f| f.into_iter().next()) {
                    let route = FlowRoute::Direct(Some(a));
                    self.flows.insert((host.to_string(), port), route.clone());
                    return route;
                }
            }
            FlowRoute::Warp(None) => {
                if let Some(stack) = &self.stack {
                    if let Ok(ip) = dns_resolve(stack, host).await {
                        let route = FlowRoute::Warp(Some(SocketAddr::new(ip, port)));
                        self.flows.insert((host.to_string(), port), route.clone());
                        return route;
                    }
                }
            }
            FlowRoute::WarpLocal if self.warp_tx.is_some() => match warp_local_addresses(host, port, &[]).await {
                Ok((ips, from)) => {
                    log::debug!("[route] udp {host}:{port} => warp-local (resolved {host} -> {} via {from})", ips[0]);
                    let route = FlowRoute::Warp(Some(SocketAddr::new(ips[0], port)));
                    self.flows.insert((host.to_string(), port), route.clone());
                    return route;
                }
                Err(e) => log::debug!("[route] udp {host}:{port} via warp-local: {e}"),
            },
            _ => {}
        }
        route
    }

    /// Sends one datagram of a flow the way its route says.
    async fn deliver(&mut self, host: &str, port: u16, route: &FlowRoute, payload: Vec<u8>) {
        match route {
            // no WARP stack, or the name did not resolve: dropped (never direct instead)
            FlowRoute::Drop | FlowRoute::WarpLocal => {}
            FlowRoute::Direct(addr) => match addr {
                Some(a) if direct_target_allowed(self.control_peer.ip(), a.ip()) => {
                    let _ = self.direct.send_to(&payload, *a).await;
                }
                _ => {}
            },
            FlowRoute::Warp(addr) => {
                let (Some(tx), Some(a)) = (&self.warp_tx, addr) else { return };
                let _ = tx.send_to(*a, payload).await;
            }
            FlowRoute::Dns => {
                let Some(tx) = &self.warp_tx else { return };
                if payload.len() >= 2 {
                    let id = u16::from_be_bytes([payload[0], payload[1]]);
                    if let Ok(ip) = host.parse::<IpAddr>() {
                        self.dns_ids.insert(id, SocketAddr::new(ip, port));
                        if self.dns_ids.len() > 1024 {
                            self.dns_ids.clear();
                        }
                    }
                }
                let _ = tx.send_to(self.resolver, payload).await;
            }
            FlowRoute::Session(index) => self.via_session(*index, host, port, payload).await,
        }
    }

    /// Carries a datagram over the udp session of the outbound at `index`, opening it first.
    async fn via_session(&mut self, index: u16, host: &str, port: u16, payload: Vec<u8>) {
        if let std::collections::hash_map::Entry::Vacant(slot) = self.sessions.entry(index) {
            // never another outbound in its place
            let Some(carrier) = outbound_at(index).and_then(|o| o.packet_exit()) else { return };
            match carrier.open_udp().await {
                Ok(mut s) => {
                    let mut rx = std::mem::replace(&mut s.rx, tokio::sync::mpsc::channel(1).1);
                    let tx = self.answers_tx.clone();
                    let pump = tokio::spawn(async move {
                        while let Some(answer) = rx.recv().await {
                            if tx.send((index, Some(answer))).await.is_err() {
                                return;
                            }
                        }
                        let _ = tx.send((index, None)).await;
                    });
                    s.pumps.push(pump.abort_handle());
                    slot.insert(s);
                }
                Err(e) => {
                    log::debug!("[route] udp session of outbound {index}: {e}");
                    return;
                }
            }
        }
        let s = &self.sessions[&index];
        if !s.send(host, port, payload.to_vec()).await {
            self.sessions.remove(&index);
        }
    }
}

async fn open_warp_udp(stack: &Option<StackHandle>) -> (Option<UdpSender>, Option<tokio::sync::mpsc::Receiver<(SocketAddr, Vec<u8>)>>) {
    match stack {
        Some(s) => match s.open_udp().await {
            Ok(u) => {
                let (a, b) = u.into_split();
                (Some(a), Some(b))
            }
            Err(_) => (None, None),
        },
        None => (None, None),
    }
}
