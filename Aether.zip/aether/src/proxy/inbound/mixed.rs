//! The mixed inbound: socks5 and http on one port, told apart by the first byte.

use crate::proxy::prelude::*;

pub(crate) async fn serve_mixed(listener: TcpListener, exit: Exit, tag: Option<String>) -> Result<()> {
    let listen = listener.local_addr()?;
    log::info!("[inbound] mixed (socks5 + http) listening on {listen} (routed{})", tag.as_deref().map(|t| format!(", inbound {t}")).unwrap_or_default());
    warn_if_world_reachable("mixed", listen);
    let bind_ip = listen.ip();
    accept_clients(listener, "mixed", client_limit(), move |sock, peer| {
        let exit = exit.clone();
        let tag = tag.clone();
        async move {
            let Some(router) = crate::proxy::router::router() else { return };
            let mut first = [0u8; 1];
            let is_socks = match tokio::time::timeout(HANDSHAKE_TIMEOUT, sock.peek(&mut first)).await {
                Ok(Ok(1)) => first[0] == VER,
                _ => return,
            };
            let work = async {
                if is_socks {
                    super::socks5::serve_socks_client(&router, sock, &exit, bind_ip).await
                } else {
                    super::http::serve_http_client(&router, sock, &exit).await
                }
            };
            if let Err(e) = super::tagged(tag, work).await {
                log::debug!("[inbound] mixed client {peer} ended: {e}");
            }
        }
    })
    .await
}
