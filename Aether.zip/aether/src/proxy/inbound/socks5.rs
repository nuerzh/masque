//! The socks5 inbound (CONNECT and UDP ASSOCIATE), routed.

use crate::proxy::prelude::*;
use super::Inbound;

/// UDP ASSOCIATE with each destination routed on its own.
pub(crate) async fn udp_associate(router: &Router, mut sock: TcpStream, exit: &Exit, bind_ip: IpAddr, requested: Target) -> Result<()> {
    let control_peer = sock.peer_addr()?;
    let expected_ip = expected_udp_source(control_peer, &requested);
    let relay = UdpSocket::bind(SocketAddr::new(bind_ip, 0)).await?;
    let relay_addr = relay.local_addr()?;
    reply_bound(&mut sock, relay_addr).await?;
    let client = SocksDatagrams {
        relay,
        expected_ip,
        client: parking_lot::Mutex::new(None),
        control: tokio::sync::Mutex::new((sock, vec![0u8; 65535])),
    };
    udp_nat(router, exit, "socks", control_peer, Some(relay_addr), &client).await
}

/// The client of a socks5 UDP ASSOCIATE: datagrams with the socks5 udp header on the relay
/// socket, the association lasting as long as the control connection.
struct SocksDatagrams {
    relay: UdpSocket,
    expected_ip: IpAddr,
    client: parking_lot::Mutex<Option<SocketAddr>>,
    control: tokio::sync::Mutex<(TcpStream, Vec<u8>)>,
}

impl DatagramClient for SocksDatagrams {
    fn recv(&self) -> crate::proxy::router::exits::BoxFuture<'_, Option<crate::proxy::session_udp::ClientDatagram>> {
        Box::pin(async move {
            let mut guard = self.control.lock().await;
            let (control, buf) = &mut *guard;
            let mut ctrl = [0u8; 256];
            loop {
                tokio::select! {
                    r = self.relay.recv_from(buf) => {
                        let (n, from) = r.ok()?;
                        let latched = *self.client.lock();
                        if !udp_source_allowed(self.expected_ip, latched, from) {
                            continue;
                        }
                        self.client.lock().get_or_insert(from);
                        let Some((dst, (port, payload))) = parse_udp_request(&buf[..n]) else { continue };
                        return Some((dst, port, payload, from));
                    }
                    r = control.read(&mut ctrl) => match r {
                        Ok(0) | Err(_) => return None,
                        Ok(_) => {}
                    },
                }
            }
        })
    }

    fn send<'a>(&'a self, src: SocketAddr, data: &'a [u8]) -> crate::proxy::router::exits::BoxFuture<'a, ()> {
        Box::pin(async move {
            let to = *self.client.lock();
            if let Some(c) = to {
                let _ = self.relay.send_to(&build_udp_reply(src, data), c).await;
            }
        })
    }
}

/// A socks5 listener whose connections are all routed (the --sunny front, configured
/// `inbounds`; the stack modes' own listener goes through `socks::serve`).
pub(crate) async fn serve_socks(listener: TcpListener, exit: Exit) -> Result<()> {
    serve_socks_tagged(listener, exit, None).await
}

pub(crate) async fn serve_socks_tagged(listener: TcpListener, exit: Exit, tag: Option<String>) -> Result<()> {
    let listen = listener.local_addr()?;
    log::info!("[inbound] socks5 server listening on {listen} (routed{})", tag.as_deref().map(|t| format!(", inbound {t}")).unwrap_or_default());
    warn_if_world_reachable("socks5", listen);
    let bind_ip = listen.ip();
    accept_clients(listener, "socks5", client_limit(), move |sock, peer| {
        let exit = exit.clone();
        let tag = tag.clone();
        async move {
            let Some(router) = crate::proxy::router::router() else { return };
            if let Err(e) = super::tagged(tag, serve_socks_client(&router, sock, &exit, bind_ip)).await {
                log::debug!("[inbound] socks client {peer} ended: {e}");
            }
        }
    })
    .await
}

pub(crate) async fn serve_socks_client(router: &Router, mut sock: TcpStream, exit: &Exit, bind_ip: IpAddr) -> Result<()> {
    let (cmd, target, port) = tokio::time::timeout(HANDSHAKE_TIMEOUT, read_request(&mut sock))
        .await
        .map_err(|_| AetherError::Other("the client did not finish the socks5 handshake in time".into()))??;
    match cmd {
        CMD_CONNECT => serve_tcp(router, sock, Inbound::Socks, target, port, Vec::new(), exit).await,
        CMD_UDP_ASSOCIATE => udp_associate(router, sock, exit, bind_ip, target).await,
        _ => {
            reply(&mut sock, REP_NOT_SUPPORTED).await?;
            Err(AetherError::Other("unsupported socks command".into()))
        }
    }
}

/// A socks5 listener that goes by `router` rather than the process's own.
#[cfg(all(test, feature = "sunny"))]
pub(crate) async fn serve_socks_routed_by(listener: TcpListener, exit: Exit, router: &'static Router) -> Result<()> {
    let bind_ip = listener.local_addr()?.ip();
    accept_clients(listener, "socks5", client_limit(), move |sock, peer| {
        let exit = exit.clone();
        async move {
            if let Err(e) = serve_socks_client(router, sock, &exit, bind_ip).await {
                log::debug!("[inbound] socks client {peer} ended: {e}");
            }
        }
    })
    .await
}
