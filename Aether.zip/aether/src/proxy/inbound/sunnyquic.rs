//! The sunnyquic server inbound: Aether's sunnyquic server (`proxy::sunnyquic`, the same
//! protocol a user's own upstream server speaks) accepting clients here, with every stream and
//! udp session it accepts handed to Aether's router, so they can leave by any outbound:
//! direct, warp, warp-local, sunny (a chain to another sunnyquic server), or a declared
//! sunnyquic outbound.

use std::path::PathBuf;

use crate::proxy::sunnyquic::{self as sq, Address, Host, QuicStream, SunnyServer, UdpSession};

use super::config::SunnyQuicServer;
use crate::proxy::prelude::*;

impl RoutedClient for QuicStream {
    fn relay_tcp(self, up: TcpStream, linger: Duration) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        Box::pin(relay_generic(self, up, linger))
    }
    fn relay_tunnel(
        self,
        sender: TcpSender,
        rx: tokio::sync::mpsc::Receiver<Vec<u8>>,
        linger: Duration,
    ) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        Box::pin(relay_tunneled_io(self, sender, rx, linger))
    }
}

fn target_of(addr: &Address) -> (Target, u16) {
    let t = match &addr.host {
        Host::V4(ip) => Target::Ip(IpAddr::V4(*ip)),
        Host::V6(ip) => Target::Ip(IpAddr::V6(*ip)),
        Host::Domain(name) => match name.parse::<IpAddr>() {
            Ok(ip) => Target::Ip(ip),
            Err(_) => Target::Domain(name.clone()),
        },
    };
    (t, addr.port)
}

/// The router as the sunnyquic server's handler.
struct ToRouter {
    tag: String,
    local: SocketAddr,
}

impl sq::Handler for ToRouter {
    fn tcp(&self, stream: QuicStream, dst: Address, peer: SocketAddr, _user: &str) {
        let local = self.local;
        tokio::spawn(super::tagged(Some(self.tag.clone()), async move {
            let Some(router) = crate::proxy::router::router() else { return };
            let (target, port) = target_of(&dst);
            if let Err(e) = serve_stream(&router, stream, Inbound::SunnyQuic, target, port, Vec::new(), &Exit::Current, peer, Some(local), None).await {
                log::debug!("[sunnyquic-in] tcp from {peer}: {e}");
            }
        }));
    }

    fn udp(&self, session: UdpSession, peer: SocketAddr, _user: &str) {
        let local = self.local;
        tokio::spawn(super::tagged(Some(self.tag.clone()), async move {
            let Some(router) = crate::proxy::router::router() else { return };
            let client = Datagrams { recv: tokio::sync::Mutex::new(session.rx), send: session.tx, peer };
            if let Err(e) = udp_nat(&router, &Exit::Current, "sunnyquic", peer, Some(local), &client).await {
                log::debug!("[sunnyquic-in] udp from {peer}: {e}");
            }
        }));
    }
}

/// A sunnyquic client's udp session, as the router's udp association sees it.
struct Datagrams {
    recv: tokio::sync::Mutex<tokio::sync::mpsc::Receiver<(bytes::Bytes, Address)>>,
    send: tokio::sync::mpsc::Sender<(bytes::Bytes, Address)>,
    peer: SocketAddr,
}

impl DatagramClient for Datagrams {
    fn recv(&self) -> exits::BoxFuture<'_, Option<crate::proxy::session_udp::ClientDatagram>> {
        Box::pin(async move {
            let (data, dst) = self.recv.lock().await.recv().await?;
            let (t, port) = target_of(&dst);
            Some((t, port, data.to_vec(), self.peer))
        })
    }

    fn send<'a>(&'a self, src: SocketAddr, data: &'a [u8]) -> exits::BoxFuture<'a, ()> {
        Box::pin(async move {
            let _ = self.send.send((bytes::Bytes::copy_from_slice(data), Address::from(src))).await;
        })
    }
}

/// A self-signed certificate for `name`, made once and kept next to the rule-set cache, so
/// clients can pin it with --sunny-ca across restarts.
pub(crate) fn self_signed(name: &str) -> Result<(PathBuf, PathBuf)> {
    let dir = crate::proxy::router::ruleset::default_cache_dir().join("sunnyquic-server");
    std::fs::create_dir_all(&dir)?;
    let safe: String = name.chars().map(|c| if c.is_ascii_alphanumeric() || c == '.' || c == '-' { c } else { '_' }).collect();
    let (cert, key) = (dir.join(format!("{safe}.cert.pem")), dir.join(format!("{safe}.key.pem")));
    if cert.exists() && key.exists() {
        return Ok((cert, key));
    }
    let made = rcgen::generate_simple_self_signed(vec![name.to_string()])
        .map_err(|e| AetherError::Other(format!("sunnyquic inbound: self-signed certificate: {e}")))?;
    std::fs::write(&cert, made.cert.pem())?;
    std::fs::write(&key, made.signing_key.serialize_pem())?;
    Ok((cert, key))
}

pub(crate) async fn start(tag: String, listen: SocketAddr, s: &SunnyQuicServer) -> Result<()> {
    let (cert_path, key_path) = match &s.certificate {
        Some(pair) => pair.clone(),
        None => {
            let pair = self_signed(&s.server_name)?;
            log::warn!(
                "[inbound] {tag}: no certificate given; using a self-signed one for {} ({}): clients need it as sunny.ca",
                s.server_name,
                pair.0.display()
            );
            pair
        }
    };
    let mut cfg = sq::ServerConfig::new(listen, cert_path, key_path);
    cfg.users = s.users.clone();
    cfg.alpn = s.alpn.clone();
    cfg.zero_rtt = s.zero_rtt;
    if let Some(c) = &s.congestion {
        cfg.congestion = serde_json::from_value(c.clone()).map_err(|e| AetherError::Other(format!("inbound {tag}: congestion_control: {e}")))?;
    }
    if let Some(m) = s.initial_mtu {
        cfg.initial_mtu = m;
    }
    if let Some(m) = s.min_mtu {
        cfg.min_mtu = m;
    }
    if let Some(m) = s.mtu_discovery {
        cfg.mtu_discovery = m;
    }
    let server = SunnyServer::bind(&cfg).map_err(|e| AetherError::Other(format!("inbound {tag}: udp {listen}: {e}")))?;
    let out = Arc::new(ToRouter { tag: tag.clone(), local: listen });
    log::info!("[sunnyquic-in] sunnyquic server listening on udp {listen} (routed, inbound {tag}, {} users)", s.users.len());
    crate::proxy::router::spawn_updaters();
    crate::utils::shutdown::spawn(server.run(out));
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proxy::sunnyquic::{ClientConfig, SunnyClient};
    use noq::Runtime;

    /// A sunnyquic client (on an OS socket) through Aether's sunnyquic server inbound: tcp
    /// and udp reach echo servers by the router's `direct`, and a reject
    /// rule on the inbound's tag holds. The router is process-global, so this runs alone:
    /// `cargo test sunnyquic_inbound -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    #[ignore]
    async fn sunnyquic_inbound_routes_tcp_and_udp() {
        let _ = env_logger::builder().is_test(true).try_init();
        let tcp = crate::test_util::tcp_echo().await;
        let blocked = crate::test_util::tcp_echo().await;
        let udp = crate::test_util::udp_echo().await;
        let cfgfile = crate::test_util::scratch("sq-in.yaml");
        std::fs::write(
            &cfgfile,
            crate::config::yaml::yaml_of_toml(&format!(
                "[route]\nfinal = \"direct\"\n\n[[route.rules]]\ninbound = \"sq-in\"\nport = {}\naction = \"reject\"\n",
                blocked.port()
            )),
        )
        .unwrap();
        crate::config::settings::decide("AETHER_ROUTE_CONFIG", cfgfile.to_string_lossy());
        crate::proxy::router::init().unwrap();

        let port = std::net::UdpSocket::bind("127.0.0.1:0").unwrap().local_addr().unwrap().port();
        let listen: SocketAddr = format!("127.0.0.1:{port}").parse().unwrap();
        let server = SunnyQuicServer {
            users: vec![("alice".into(), "wonderland".into())],
            server_name: "localhost".into(),
            certificate: None,
            alpn: vec!["h3".into()],
            zero_rtt: true,
            congestion: None,
            initial_mtu: None,
            min_mtu: None,
            mtu_discovery: None,
        };
        start("sq-in".into(), listen, &server).await.unwrap();
        let (cert, _) = self_signed("localhost").unwrap();
        tokio::time::sleep(Duration::from_millis(200)).await;

        let mut cfg = ClientConfig::new("alice", "wonderland", listen, "localhost");
        cfg.ca = Some(cert);
        let sock = noq::TokioRuntime.wrap_udp_socket(std::net::UdpSocket::bind("127.0.0.1:0").unwrap()).unwrap();
        let client = SunnyClient::new(cfg, sock).unwrap();
        let t = Duration::from_secs(20);

        let mut s = tokio::time::timeout(t, client.open_tcp(&Address::from(tcp))).await.unwrap().unwrap();
        let sent: Vec<u8> = (0..200_000).map(|i| (i % 251) as u8).collect();
        let (mut r, mut w) = tokio::io::split(&mut s);
        let to_send = sent.clone();
        let (_, got) = tokio::join!(async move { w.write_all(&to_send).await.unwrap() }, async move {
            let mut got = vec![0u8; 200_000];
            tokio::time::timeout(t, r.read_exact(&mut got)).await.unwrap().unwrap();
            got
        });
        assert!(got == sent, "tcp echo through the sunnyquic inbound came back changed");

        // the reject rule matches the inbound's tag: the stream closes with nothing echoed
        let mut s = tokio::time::timeout(t, client.open_tcp(&Address::from(blocked))).await.unwrap().unwrap();
        let _ = s.write_all(b"ping").await;
        let mut b = [0u8; 4];
        let n = tokio::time::timeout(t, s.read(&mut b)).await.unwrap().unwrap_or(0);
        assert_eq!(n, 0, "the rejected port was let through");

        // udp
        let mut assoc = client.associate_udp().await.unwrap();
        for round in 0..3u8 {
            let payload = bytes::Bytes::from(vec![round; 700]);
            assoc.tx.send((payload.clone(), Address::from(udp))).await.unwrap();
            let (data, from) = tokio::time::timeout(t, assoc.rx.recv()).await.expect("no udp echo").unwrap();
            assert_eq!(data, payload);
            assert_eq!(target_of(&from).1, udp.port());
        }
    }
}
