//! The `inbounds` of the route config, sing-box style:
//!
//! ```json
//! "inbounds": [
//!   {"type": "socks", "tag": "socks-in", "listen": "127.0.0.1", "listen_port": 1080},
//!   {"type": "http", "tag": "http-in", "listen": "127.0.0.1", "listen_port": 8080},
//!   {"type": "mixed", "tag": "mixed-in", "listen": "127.0.0.1", "listen_port": 2080},
//!   {"type": "tun", "tag": "tun-in", "interface_name": "aether-tun", "address": ["172.19.0.1/30"]},
//!   {"type": "sunnyquic", "tag": "sq-in", "listen": "::", "listen_port": 443,
//!    "users": [{"name": "alice", "password": "..."}],
//!    "tls": {"server_name": "sq.example.com", "certificate_path": "cert.pem", "key_path": "key.pem"}}
//! ]
//! ```
//!
//! Each one is opened next to the mode's own listeners (--bind, --http-proxy, --tun), and every
//! connection on it goes through the router, its `tag` being what `inbound` rules match. `tun`
//! turns the TUN inbound on as --tun does (flags given on the command line win over its fields).

use std::net::{IpAddr, SocketAddr};
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

use serde_json::Value;

use crate::error::{AetherError, Result};

#[derive(Debug, Clone)]
pub enum Kind {
    Socks,
    Http,
    Mixed,
    Tun,
    #[cfg_attr(all(not(feature = "sunny"), not(test)), expect(dead_code, reason = "read and checked without the sunny feature too, used only with it"))]
    SunnyQuic(Box<SunnyQuicServer>),
}

/// A sunnyquic server inbound: clients of the user's own sunnyquic come in here.
#[derive(Debug, Clone)]
#[cfg_attr(not(feature = "sunny"), expect(dead_code, reason = "read and checked without the sunny feature too, used only with it"))]
pub struct SunnyQuicServer {
    pub users: Vec<(String, String)>,
    pub server_name: String,
    /// None: a self-signed certificate is made for `server_name` (clients need it as --sunny-ca)
    pub certificate: Option<(PathBuf, PathBuf)>,
    pub alpn: Vec<String>,
    pub zero_rtt: bool,
    pub congestion: Option<Value>,
    pub initial_mtu: Option<u16>,
    pub min_mtu: Option<u16>,
    pub mtu_discovery: Option<bool>,
}

#[derive(Debug, Clone)]
pub struct Spec {
    pub tag: String,
    pub listen: Option<SocketAddr>,
    pub kind: Kind,
}

static SPECS: OnceLock<Vec<Spec>> = OnceLock::new();
static TUN_TAG: OnceLock<String> = OnceLock::new();

pub(crate) fn tun_tag() -> Option<&'static str> {
    TUN_TAG.get().map(String::as_str)
}

fn str_of<'a>(o: &'a serde_json::Map<String, Value>, k: &str) -> Option<&'a str> {
    o.get(k).and_then(Value::as_str).filter(|s| !s.is_empty())
}

fn list_of(o: &serde_json::Map<String, Value>, k: &str) -> Vec<String> {
    match o.get(k) {
        Some(Value::String(s)) => vec![s.clone()],
        Some(Value::Array(a)) => a.iter().filter_map(|v| v.as_str().map(str::to_string)).collect(),
        _ => Vec::new(),
    }
}

fn path_of(p: &str, base: &Path) -> PathBuf {
    let p = PathBuf::from(p);
    if p.is_absolute() {
        p
    } else {
        base.join(p)
    }
}

/// Parse `inbounds`; unknown types are warned about (sing-box has many Aether does not open).
pub fn parse(config: &Value, base: &Path, warn: &mut dyn FnMut(String)) -> std::result::Result<Vec<Spec>, String> {
    let Some(list) = config.get("inbounds") else { return Ok(Vec::new()) };
    let list = list.as_array().ok_or("inbounds must be a list")?;
    let mut out = Vec::new();
    for (i, item) in list.iter().enumerate() {
        let o = item.as_object().ok_or(format!("inbounds[{i}] must be an object"))?;
        let ty = str_of(o, "type").ok_or(format!("inbounds[{i}] has no type"))?.to_ascii_lowercase();
        let tag = str_of(o, "tag").map(str::to_string).unwrap_or_else(|| ty.clone());
        let at = format!("inbounds[{i}] ({tag})");
        let listen = match o.get("listen_port").and_then(Value::as_u64) {
            Some(port) if port > 0 && port <= 65535 => {
                let ip: IpAddr = match str_of(o, "listen") {
                    Some(l) => l.trim_matches(|c| c == '[' || c == ']').parse().map_err(|_| format!("{at}: listen {l:?} is not an address"))?,
                    None => IpAddr::from([127, 0, 0, 1]),
                };
                Some(SocketAddr::new(ip, port as u16))
            }
            Some(_) => return Err(format!("{at}: listen_port must be 1-65535")),
            None => None,
        };
        let kind = match ty.as_str() {
            "socks" | "socks5" => Kind::Socks,
            "http" => Kind::Http,
            "mixed" => Kind::Mixed,
            "tun" => Kind::Tun,
            "sunnyquic" | "sunny" => {
                let users: Vec<(String, String)> = o
                    .get("users")
                    .and_then(Value::as_array)
                    .map(|a| {
                        a.iter()
                            .filter_map(|u| {
                                let name = u.get("name").or_else(|| u.get("username"))?.as_str()?;
                                let pass = u.get("password")?.as_str()?;
                                Some((name.to_string(), pass.to_string()))
                            })
                            .collect()
                    })
                    .unwrap_or_default();
                if users.is_empty() {
                    return Err(format!("{at}: a sunnyquic inbound needs users ([{{\"name\": ..., \"password\": ...}}])"));
                }
                let tls = o.get("tls").and_then(Value::as_object).unwrap_or(o);
                let server_name = str_of(tls, "server_name").or(str_of(o, "server_name")).unwrap_or("localhost").to_string();
                let cert = str_of(tls, "certificate_path").or(str_of(o, "certificate_path"));
                let key = str_of(tls, "key_path").or(str_of(o, "key_path"));
                let certificate = match (cert, key) {
                    (Some(c), Some(k)) => Some((path_of(c, base), path_of(k, base))),
                    (None, None) => None,
                    _ => return Err(format!("{at}: give both certificate_path and key_path, or neither")),
                };
                let mut alpn = list_of(tls, "alpn");
                if alpn.is_empty() {
                    alpn = list_of(o, "alpn");
                }
                if alpn.is_empty() {
                    alpn = vec!["h3".into()];
                }
                if listen.is_none() {
                    return Err(format!("{at}: a sunnyquic inbound needs listen_port"));
                }
                Kind::SunnyQuic(Box::new(SunnyQuicServer {
                    users,
                    server_name,
                    certificate,
                    alpn,
                    zero_rtt: o.get("zero_rtt").and_then(Value::as_bool).unwrap_or(true),
                    congestion: o.get("congestion_control").cloned(),
                    initial_mtu: o.get("initial_mtu").and_then(Value::as_u64).map(|v| v as u16),
                    min_mtu: o.get("min_mtu").and_then(Value::as_u64).map(|v| v as u16),
                    mtu_discovery: o.get("mtu_discovery").and_then(Value::as_bool),
                }))
            }
            other => {
                warn(format!("{at}: inbound type {other:?} is not opened by Aether (socks, http, mixed, tun, sunnyquic are)"));
                continue;
            }
        };
        if matches!(kind, Kind::Socks | Kind::Http | Kind::Mixed) && listen.is_none() {
            warn(format!("{at}: no listen_port, not opened"));
            continue;
        }
        out.push(Spec { tag, listen, kind });
    }
    Ok(out)
}

fn set_if_unset(var: &str, value: String) {
    crate::config::settings::decide_default(var, value);
}

/// The `tun` inbound's fields, as the --tun flags would set them (flags win).
fn apply_tun(o: &serde_json::Map<String, Value>) {
    set_if_unset("AETHER_TUN", "1".into());
    if let Some(n) = str_of(o, "interface_name") {
        set_if_unset("AETHER_TUN_NAME", n.to_string());
    }
    let addr = list_of(o, "address");
    if !addr.is_empty() {
        set_if_unset("AETHER_TUN_ADDRESS", addr.join(","));
    }
    if let Some(m) = o.get("mtu").and_then(Value::as_u64) {
        set_if_unset("AETHER_TUN_MTU", m.to_string());
    }
    for (key, var) in [("auto_route", "AETHER_TUN_AUTO_ROUTE"), ("strict_route", "AETHER_TUN_STRICT_ROUTE")] {
        if let Some(b) = o.get(key).and_then(Value::as_bool) {
            set_if_unset(var, if b { "1" } else { "0" }.into());
        }
    }
    let include = list_of(o, "route_address");
    if !include.is_empty() {
        set_if_unset("AETHER_TUN_INCLUDE", include.join(","));
    }
    let exclude = list_of(o, "route_exclude_address");
    if !exclude.is_empty() {
        set_if_unset("AETHER_TUN_EXCLUDE", exclude.join(","));
    }
}

/// Read `inbounds` from the route config; turn the TUN on if one is there. Call before
/// `tun::prepare` (a bad inbound stops Aether here, with its place in the config named).
pub fn configure() -> Result<()> {
    let (config, base) = crate::proxy::router::config_value().map_err(AetherError::Other)?;
    let Some(config) = config else {
        let _ = SPECS.set(Vec::new());
        return Ok(());
    };
    let specs = parse(&config, &base, &mut |w| log::warn!("[inbound] {w}")).map_err(AetherError::Other)?;
    if let (Some(list), Some(spec)) = (config.get("inbounds").and_then(Value::as_array), specs.iter().find(|s| matches!(s.kind, Kind::Tun))) {
        if let Some(o) = list.iter().filter_map(Value::as_object).find(|o| str_of(o, "type").is_some_and(|t| t.eq_ignore_ascii_case("tun"))) {
            apply_tun(o);
        }
        let _ = TUN_TAG.set(spec.tag.clone());
    }
    let _ = SPECS.set(specs);
    Ok(())
}

/// How many configured inbounds listen on a port (the TUN is not one).
pub fn count() -> usize {
    SPECS.get().map(|l| l.iter().filter(|s| s.listen.is_some() && !matches!(s.kind, Kind::Tun)).count()).unwrap_or(0)
}

/// Open the configured socks / http / mixed / sunnyquic inbounds. Their ports are bound here,
/// so a busy one stops Aether at start; the connections wait for the router and the tunnel.
pub async fn start() -> Result<()> {
    let Some(specs) = SPECS.get() else { return Ok(()) };
    for spec in specs {
        let Some(listen) = spec.listen else { continue };
        let tag = spec.tag.clone();
        match &spec.kind {
            Kind::Tun => {}
            Kind::Socks | Kind::Http | Kind::Mixed => {
                let what = match spec.kind {
                    Kind::Socks => "socks5",
                    Kind::Http => "http proxy",
                    _ => "mixed",
                };
                let listener = crate::proxy::socks::bind_listener(what, listen).await?;
                let kind = spec.kind.clone();
                crate::utils::shutdown::spawn(async move {
                    crate::proxy::router::spawn_updaters();
                    let exit = crate::proxy::socks::Exit::Current;
                    let t = Some(tag.clone());
                    let r = match kind {
                        Kind::Socks => super::socks5::serve_socks_tagged(listener, exit, t).await,
                        Kind::Http => super::http::serve_http_tagged(listener, exit, t).await,
                        _ => super::mixed::serve_mixed(listener, exit, t).await,
                    };
                    if let Err(e) = r {
                        log::error!("[inbound] inbound {tag}: {e}");
                    }
                });
            }
            #[cfg(feature = "sunny")]
            Kind::SunnyQuic(server) => {
                super::sunnyquic::start(tag, listen, server).await?;
            }
            #[cfg(not(feature = "sunny"))]
            Kind::SunnyQuic(_) => {
                return Err(AetherError::Other(format!(
                    "inbound {tag}: this aether was built without the sunny feature"
                )));
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::file::test_routing as cfg;

    #[test]
    fn inbounds_are_read_sing_box_style() {
        let mut warnings = Vec::new();
        let specs = parse(
            &cfg(r#"
                [[inbounds]]
                type = "socks"
                tag = "s"
                listen = "127.0.0.1"
                listen_port = 1080

                [[inbounds]]
                type = "mixed"
                listen_port = 2080

                [[inbounds]]
                type = "tun"
                tag = "t"

                [[inbounds]]
                type = "vless"
                tag = "v"
                listen_port = 3

                [[inbounds]]
                type = "sunnyquic"
                tag = "sq"
                listen = "::"
                listen_port = 443
                users = [{ name = "a", password = "b" }]
                tls = { server_name = "x.test", certificate_path = "c.pem", key_path = "k.pem" }
            "#),
            Path::new("/etc/aether"),
            &mut |w| warnings.push(w),
        )
        .unwrap();
        assert_eq!(specs.len(), 4);
        assert_eq!(specs[0].listen, Some("127.0.0.1:1080".parse().unwrap()));
        assert_eq!(specs[1].tag, "mixed");
        assert_eq!(specs[1].listen, Some("127.0.0.1:2080".parse().unwrap()));
        assert!(matches!(specs[2].kind, Kind::Tun));
        match &specs[3].kind {
            Kind::SunnyQuic(s) => {
                assert_eq!(s.users, vec![("a".to_string(), "b".to_string())]);
                assert_eq!(s.server_name, "x.test");
                assert_eq!(s.certificate, Some((PathBuf::from("/etc/aether/c.pem"), PathBuf::from("/etc/aether/k.pem"))));
                assert_eq!(s.alpn, vec!["h3".to_string()]);
            }
            k => panic!("{k:?}"),
        }
        assert_eq!(specs[3].listen, Some("[::]:443".parse().unwrap()));
        assert_eq!(warnings.len(), 1, "{warnings:?}");
    }

    #[test]
    fn a_sunnyquic_inbound_needs_users_and_a_port() {
        let e = parse(&cfg(r#"
            inbounds = [{ type = "sunnyquic", listen_port = 443 }]
        "#), Path::new("."), &mut |_| {});
        assert!(e.is_err());
        let e = parse(&cfg(r#"
            inbounds = [{ type = "sunnyquic", users = [{ name = "a", password = "b" }] }]
        "#), Path::new("."), &mut |_| {});
        assert!(e.is_err());
        let e = parse(&cfg(r#"
            [[inbounds]]
            type = "sunnyquic"
            listen_port = 1
            users = [{ name = "a", password = "b" }]
            certificate_path = "c"
        "#), Path::new("."), &mut |_| {});
        assert!(e.is_err());
    }
}
