//! The http proxy inbound (CONNECT and plain requests), routed.

use crate::proxy::prelude::*;
use super::{Inbound};

/// An http proxy client through the router.
pub(crate) async fn serve_http_client(router: &Router, mut sock: TcpStream, exit: &Exit) -> Result<()> {
    let (head, early) = tokio::time::timeout(HANDSHAKE_TIMEOUT, read_head(&mut sock))
        .await
        .map_err(|_| AetherError::Other("the client did not send a request head in time".into()))??;
    let text = String::from_utf8_lossy(&head).to_string();
    let first_line = text.lines().next().unwrap_or_default();
    let Some(request) = parse_request_line(first_line) else {
        let _ = sock.write_all(b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n").await;
        return Err(AetherError::Other(format!("unsupported http proxy request: {first_line}")));
    };
    let target = match request.authority.parse::<IpAddr>() {
        Ok(ip) => Target::Ip(ip),
        Err(_) => Target::Domain(request.authority.clone()),
    };
    match &request.rewritten {
        Some(line) => {
            let rest = text.split_once("\r\n").map(|(_, tail)| tail).unwrap_or("");
            let mut bytes = format!("{line}{rest}").into_bytes();
            bytes.extend_from_slice(&early);
            serve_tcp(router, sock, Inbound::HttpPlain, target, request.port, bytes, exit).await
        }
        None => serve_tcp(router, sock, Inbound::HttpConnect, target, request.port, early, exit).await,
    }
}

pub(crate) async fn serve_http(listener: TcpListener, exit: Exit) -> Result<()> {
    serve_http_tagged(listener, exit, None).await
}

pub(crate) async fn serve_http_tagged(listener: TcpListener, exit: Exit, tag: Option<String>) -> Result<()> {
    let listen = listener.local_addr()?;
    log::info!("[inbound] http proxy listening on {listen} (routed{})", tag.as_deref().map(|t| format!(", inbound {t}")).unwrap_or_default());
    warn_if_world_reachable("http proxy", listen);
    accept_clients(listener, "http proxy", client_limit(), move |sock, peer| {
        let exit = exit.clone();
        let tag = tag.clone();
        async move {
            let Some(router) = crate::proxy::router::router() else { return };
            if let Err(e) = super::tagged(tag, serve_http_client(&router, sock, &exit)).await {
                log::debug!("[inbound] http proxy client {peer} ended: {e}");
            }
        }
    })
    .await
}
