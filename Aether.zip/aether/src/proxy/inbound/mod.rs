//! Inbounds: where connections come in. socks5 and http listeners, the TUN device, and the
//! sunnyquic server; every one hands its tcp streams and udp flows to the router (`session`),
//! which picks the outbound.

pub mod config;
pub mod http;
pub mod mixed;
pub mod socks5;
#[cfg(feature = "sunny")]
pub mod sunnyquic;
pub mod tun;

pub use config::{configure, start};

/// The mode's own listeners (--bind, --http-proxy), routed, kept across every tunnel; dropping
/// this stops them.
pub struct Listeners(Vec<tokio::task::AbortHandle>);

impl Drop for Listeners {
    fn drop(&mut self) {
        for t in &self.0 {
            t.abort();
        }
    }
}

/// Open --bind (socks5) and --http-proxy. A port in use is an error here, at start.
pub(crate) async fn serve_listeners(socks: SocketAddr, http: Option<SocketAddr>) -> Result<Listeners> {
    let socks_listener = bind_listener("socks5", socks).await?;
    let http_listener = match http {
        Some(a) => Some(bind_listener("http proxy", a).await?),
        None => None,
    };
    crate::proxy::router::spawn_updaters();
    let mut tasks = vec![tokio::spawn(async move {
        if let Err(e) = socks5::serve_socks(socks_listener, Exit::Current).await {
            log::error!("[inbound] the socks5 listener stopped: {e}");
        }
    })
    .abort_handle()];
    if let Some(l) = http_listener {
        tasks.push(
            tokio::spawn(async move {
                if let Err(e) = http::serve_http(l, Exit::Current).await {
                    log::error!("[inbound] the http listener stopped: {e}");
                }
            })
            .abort_handle(),
        );
    }
    Ok(Listeners(tasks))
}

use super::prelude::*;

tokio::task_local! {
    /// The tag of the configured inbound a connection came in on (sing-box `inbound` rules
    /// match it); unset for the mode's own listeners, which go by their kind.
    pub(crate) static INBOUND_TAG: String;
}

/// Run `fut` as a connection of the configured inbound `tag` (none: the mode's own listener).
pub(crate) async fn tagged<F: Future>(tag: Option<String>, fut: F) -> F::Output {
    match tag {
        Some(t) => INBOUND_TAG.scope(t, fut).await,
        None => fut.await,
    }
}

/// The inbound tag the rules see for `kind`: the configured inbound's own tag, if any.
pub(crate) fn tag_of(kind: &str) -> String {
    if let Ok(t) = INBOUND_TAG.try_with(|t| t.clone()) {
        return t;
    }
    if kind == "tun" {
        if let Some(t) = config::tun_tag() {
            return t.to_string();
        }
    }
    kind.to_string()
}

/// How the inbound acknowledges a connection and refuses one.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Inbound {
    Socks,
    HttpConnect,
    /// A plain http request: the client already sent everything the far end needs to see.
    HttpPlain,
    /// A tcp flow taken off the TUN device (--tun): the userspace stack already completed the
    /// handshake, so there is nothing to acknowledge, and a refusal is a reset.
    Tun,
    /// A tcp stream of a sunnyquic client (the sunnyquic server inbound): the client already
    /// asked for its target and waits for no answer; a refusal closes the stream.
    #[cfg(feature = "sunny")]
    SunnyQuic,
}

/// The client side of a routed tcp connection: a socket accepted by a listener, or a flow of
/// the TUN inbound. Each relays the way that suits it.
pub(crate) trait RoutedClient: AsyncRead + AsyncWrite + Send + Unpin + Sized + 'static {
    fn relay_tcp(self, up: TcpStream, linger: Duration) -> Pin<Box<dyn Future<Output = ()> + Send>>;
    fn relay_tunnel(
        self,
        sender: TcpSender,
        rx: tokio::sync::mpsc::Receiver<Vec<u8>>,
        linger: Duration,
    ) -> Pin<Box<dyn Future<Output = ()> + Send>>;
    /// Abort the connection (a TUN flow answers with a reset).
    fn abort(&mut self) {}
}

impl RoutedClient for TcpStream {
    fn relay_tcp(self, up: TcpStream, linger: Duration) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        Box::pin(relay_direct(self, up, linger))
    }
    fn relay_tunnel(
        self,
        sender: TcpSender,
        rx: tokio::sync::mpsc::Receiver<Vec<u8>>,
        linger: Duration,
    ) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        Box::pin(relay_tunneled(self, sender, rx, linger))
    }
}

impl Inbound {
    pub(crate) fn tag(self) -> &'static str {
        match self {
            Inbound::Socks => "socks",
            Inbound::HttpConnect | Inbound::HttpPlain => "http",
            Inbound::Tun => "tun",
            #[cfg(feature = "sunny")]
            Inbound::SunnyQuic => "sunnyquic",
        }
    }

    pub(crate) async fn ack<S: RoutedClient>(self, sock: &mut S) -> std::io::Result<()> {
        match self {
            Inbound::Socks => sock.write_all(&reply_bytes(REP_OK)).await,
            Inbound::HttpConnect => sock.write_all(b"HTTP/1.1 200 Connection established\r\n\r\n").await,
            Inbound::HttpPlain | Inbound::Tun => Ok(()),
            #[cfg(feature = "sunny")]
            Inbound::SunnyQuic => Ok(()),
        }
    }

    pub(crate) async fn refuse<S: RoutedClient>(self, sock: &mut S, forbidden: bool) {
        let _ = match self {
            // a refusal by the rules is a reset ("connection refused"); a failed dial leaves the
            // SYN unanswered (the stack never sent a SYN-ACK), so the program's Happy Eyeballs
            // can try another address
            Inbound::Tun => {
                if forbidden {
                    sock.abort();
                }
                Ok(())
            }
            #[cfg(feature = "sunny")]
            Inbound::SunnyQuic => Ok(()),
            Inbound::Socks => {
                let code = if forbidden { REP_NOT_ALLOWED } else { REP_GENERAL };
                sock.write_all(&reply_bytes(code)).await
            }
            _ => {
                let answer: &[u8] = if forbidden {
                    b"HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n"
                } else {
                    b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n"
                };
                sock.write_all(answer).await
            }
        };
    }
}
