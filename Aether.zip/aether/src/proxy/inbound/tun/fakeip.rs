//! Fake-ip for the TUN inbound (--tun-fakeip, on by default).
//!
//! A program's A / AAAA query that the TUN hijacks is answered here, at once and without any
//! lookup, with an address from a reserved pool (198.18.0.0/15 and fc00::/18 by default). When
//! the program then connects to that address, the TUN flow is turned back into the name, so the
//! router sees a domain (as with socks5h) and every outbound gets the name itself:
//!
//! * `sunny`: the name goes to the sunnyquic server in the socks5 request (ATYP domain), and the
//!   server resolves it; nothing on this machine looks the name up;
//! * `warp`: the name is resolved inside the WARP tunnel (Aether's resolver, 1.1.1.1 by default)
//!   when the connection is made;
//! * `direct`: the name is resolved by Aether itself (by default the system's own dns servers,
//!   read before the TUN took over, or the --tun-direct-dns servers, asked over the physical
//!   interface; or through the tunnel with --tun-direct-dns tunnel), never by the system
//!   resolver, which points at the TUN.
//!
//! The pool is a bounded map with least-recently-used reuse: a name keeps its address for as
//! long as it is in use, the same name always gets the same address while it is mapped, and when
//! the pool is full the address that went unused the longest is given to the new name.

use std::collections::{BTreeMap, HashMap};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::OnceLock;

use ipnet::{IpNet, Ipv4Net, Ipv6Net};
use parking_lot::Mutex;

/// The default pools (sing-box's defaults).
pub const DEFAULT_RANGE: &str = "198.18.0.0/15,fc00::/18";
/// The TTL of a fake answer, in seconds. Short, so programs come back soon after Aether stops
/// (their cached fake addresses lead nowhere then), long enough not to re-ask for every
/// connection.
pub const TTL: u32 = 10;
/// How many names the pool holds at most (the oldest unused one is reused beyond that).
pub const MAX_ENTRIES: u32 = 65536;

pub const QTYPE_A: u16 = 1;
pub const QTYPE_PTR: u16 = 12;
pub const QTYPE_AAAA: u16 = 28;
pub const QTYPE_SVCB: u16 = 64;
pub const QTYPE_HTTPS: u16 = 65;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FakeIpConfig {
    pub v4: Option<Ipv4Net>,
    pub v6: Option<Ipv6Net>,
}

impl FakeIpConfig {
    /// `198.18.0.0/15,fc00::/18`: at most one IPv4 and one IPv6 range.
    pub fn parse(text: &str) -> Result<FakeIpConfig, String> {
        let mut cfg = FakeIpConfig { v4: None, v6: None };
        for item in text.split([',', ' ', ';']).map(str::trim).filter(|s| !s.is_empty()) {
            let net: IpNet = item
                .parse()
                .map_err(|_| format!("tun.fakeip-range '{item}': give a CIDR such as 198.18.0.0/15"))?;
            match net.trunc() {
                IpNet::V4(n) => {
                    if cfg.v4.is_some() {
                        return Err("tun.fakeip-range: give at most one IPv4 range".into());
                    }
                    if n.prefix_len() > 24 {
                        return Err(format!("tun.fakeip-range '{item}': use /24 or wider"));
                    }
                    cfg.v4 = Some(n);
                }
                IpNet::V6(n) => {
                    if cfg.v6.is_some() {
                        return Err("tun.fakeip-range: give at most one IPv6 range".into());
                    }
                    if n.prefix_len() > 120 {
                        return Err(format!("tun.fakeip-range '{item}': use /120 or wider"));
                    }
                    cfg.v6 = Some(n);
                }
            }
        }
        if cfg.v4.is_none() && cfg.v6.is_none() {
            return Err("tun.fakeip-range: give at least one range".into());
        }
        Ok(cfg)
    }

    pub fn contains(&self, ip: IpAddr) -> bool {
        match crate::proxy::router::ipset::unmap(ip) {
            IpAddr::V4(a) => self.v4.is_some_and(|n| n.contains(&a)),
            IpAddr::V6(a) => self.v6.is_some_and(|n| n.contains(&a)),
        }
    }

    pub fn nets(&self) -> Vec<IpNet> {
        self.v4.map(IpNet::V4).into_iter().chain(self.v6.map(IpNet::V6)).collect()
    }

    /// Usable addresses: the network address and the last one are left out.
    fn capacity(&self) -> u32 {
        let hosts4 = self.v4.map(|n| (1u64 << (32 - n.prefix_len())) - 2);
        let hosts6 = self.v6.map(|n| {
            let bits = 128 - n.prefix_len() as u32;
            if bits >= 63 {
                u64::MAX
            } else {
                (1u64 << bits) - 2
            }
        });
        let hosts = match (hosts4, hosts6) {
            (Some(a), Some(b)) => a.min(b),
            (Some(a), None) | (None, Some(a)) => a,
            (None, None) => 0,
        };
        hosts.min(MAX_ENTRIES as u64) as u32
    }
}

#[derive(Default)]
struct Inner {
    by_name: HashMap<String, u32>,
    by_slot: HashMap<u32, (String, u64)>,
    lru: BTreeMap<u64, u32>,
    tick: u64,
    cursor: u32,
}

impl Inner {
    fn touch(&mut self, slot: u32) {
        self.tick += 1;
        let tick = self.tick;
        if let Some((_, used)) = self.by_slot.get_mut(&slot) {
            self.lru.remove(used);
            *used = tick;
            self.lru.insert(tick, slot);
        }
    }
}

/// The domain <-> fake address map.
pub struct FakePool {
    cfg: FakeIpConfig,
    cap: u32,
    inner: Mutex<Inner>,
}

/// A name as the pool keys it: lowercase, no trailing dot.
pub fn normalize(name: &str) -> String {
    name.trim().trim_end_matches('.').to_ascii_lowercase()
}

impl FakePool {
    pub fn new(cfg: FakeIpConfig) -> FakePool {
        Self::with_capacity(cfg.clone(), cfg.capacity())
    }

    /// A pool that holds at most `cap` names (the tests use a small one).
    pub fn with_capacity(cfg: FakeIpConfig, cap: u32) -> FakePool {
        let cap = cap.min(cfg.capacity()).max(1);
        FakePool { cfg, cap, inner: Mutex::new(Inner::default()) }
    }

    pub fn contains(&self, ip: IpAddr) -> bool {
        self.cfg.contains(ip)
    }

    #[cfg(test)]
    pub fn len(&self) -> usize {
        self.inner.lock().by_name.len()
    }

    #[cfg(test)]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// The slot of `name`, given out now if it has none.
    fn slot(&self, name: &str) -> u32 {
        let name = normalize(name);
        let mut g = self.inner.lock();
        if let Some(&slot) = g.by_name.get(&name) {
            g.touch(slot);
            return slot;
        }
        let slot = if (g.by_slot.len() as u32) < self.cap {
            loop {
                let s = g.cursor;
                g.cursor = (g.cursor + 1) % self.cap;
                if !g.by_slot.contains_key(&s) {
                    break s;
                }
            }
        } else {
            // full: the address unused the longest goes to the new name
            let (_, s) = g.lru.pop_first().expect("a full pool has entries");
            if let Some((old, _)) = g.by_slot.remove(&s) {
                log::trace!("[tun] fake-ip: {old} gives up its address to {name}");
                g.by_name.remove(&old);
            }
            s
        };
        g.by_name.insert(name.clone(), slot);
        g.by_slot.insert(slot, (name, 0));
        g.touch(slot);
        slot
    }

    pub fn v4_for(&self, name: &str) -> Option<Ipv4Addr> {
        let net = self.cfg.v4?;
        let slot = self.slot(name);
        Some(Ipv4Addr::from(u32::from(net.network()) + 1 + slot))
    }

    pub fn v6_for(&self, name: &str) -> Option<Ipv6Addr> {
        let net = self.cfg.v6?;
        let slot = self.slot(name);
        Some(Ipv6Addr::from(u128::from(net.network()) + 1 + slot as u128))
    }

    fn slot_of(&self, ip: IpAddr) -> Option<u32> {
        let off: u128 = match crate::proxy::router::ipset::unmap(ip) {
            IpAddr::V4(a) => {
                let net = self.cfg.v4.filter(|n| n.contains(&a))?;
                (u32::from(a) - u32::from(net.network())) as u128
            }
            IpAddr::V6(a) => {
                let net = self.cfg.v6.filter(|n| n.contains(&a))?;
                u128::from(a) - u128::from(net.network())
            }
        };
        let slot = off.checked_sub(1)?;
        (slot < self.cap as u128).then_some(slot as u32)
    }

    /// The name a fake address stands for (None: not a fake address, or no longer mapped).
    pub fn lookup(&self, ip: IpAddr) -> Option<String> {
        let slot = self.slot_of(ip)?;
        let mut g = self.inner.lock();
        let name = g.by_slot.get(&slot).map(|(n, _)| n.clone())?;
        g.touch(slot);
        Some(name)
    }
}

static POOL: OnceLock<FakePool> = OnceLock::new();

/// Turn fake-ip on for this run (tun::prepare).
pub fn install(cfg: FakeIpConfig) {
    let _ = POOL.set(FakePool::new(cfg));
}

/// The pool of this run, when the TUN runs with fake-ip.
pub fn pool() -> Option<&'static FakePool> {
    POOL.get()
}

/// Whether `ip` is one of this run's fake addresses (never a real destination).
pub fn is_fake(ip: IpAddr) -> bool {
    pool().is_some_and(|p| p.contains(ip))
}

/// What became of a target that may be a fake address.
#[derive(Debug, PartialEq, Eq)]
pub enum Restored {
    /// Not a fake address: use as it is.
    Real,
    /// A fake address: this is the name it stands for.
    Name(String),
    /// A fake address no name is mapped to any more (from before a restart, or evicted).
    Stale,
}

pub fn restore_in(pool: Option<&FakePool>, ip: IpAddr) -> Restored {
    match pool {
        Some(p) if p.contains(ip) => match p.lookup(ip) {
            Some(n) => Restored::Name(n),
            None => Restored::Stale,
        },
        _ => Restored::Real,
    }
}

pub fn restore(ip: IpAddr) -> Restored {
    restore_in(pool(), ip)
}

// ---------------------------------------------------------------------------------------------
// dns

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Question {
    pub id: u16,
    /// The second header word of the query (opcode, RD, ...).
    pub flags: u16,
    pub name: String,
    pub qtype: u16,
    pub qclass: u16,
    /// Where the question ends in the query.
    pub end: usize,
}

/// The single question of a standard query, or None for anything else.
pub fn parse_question(q: &[u8]) -> Option<Question> {
    if q.len() < 12 {
        return None;
    }
    let flags = u16::from_be_bytes([q[2], q[3]]);
    // a response, or an opcode other than QUERY
    if flags & 0x8000 != 0 || flags & 0x7800 != 0 {
        return None;
    }
    if u16::from_be_bytes([q[4], q[5]]) != 1 {
        return None;
    }
    let mut pos = 12;
    let mut labels: Vec<String> = Vec::new();
    loop {
        let len = *q.get(pos)? as usize;
        if len == 0 {
            pos += 1;
            break;
        }
        if len & 0xc0 != 0 {
            return None;
        }
        let label = q.get(pos + 1..pos + 1 + len)?;
        if !label.iter().all(|b| b.is_ascii_alphanumeric() || *b == b'-' || *b == b'_') {
            return None;
        }
        labels.push(String::from_utf8_lossy(label).to_ascii_lowercase());
        pos += 1 + len;
    }
    let qtype = u16::from_be_bytes([*q.get(pos)?, *q.get(pos + 1)?]);
    let qclass = u16::from_be_bytes([*q.get(pos + 2)?, *q.get(pos + 3)?]);
    Some(Question {
        id: u16::from_be_bytes([q[0], q[1]]),
        flags,
        name: labels.join("."),
        qtype,
        qclass,
        end: pos + 4,
    })
}

/// Names that keep their real answers (the query goes on to the resolver as before).
fn keeps_real_answer(name: &str) -> bool {
    name.is_empty()
        || !name.contains('.')
        || name == "localhost"
        || name.ends_with(".localhost")
        || name.ends_with(".local")
        || name.ends_with(".arpa")
}

/// A reply to `query`'s question with `answers` (type, rdata), and `rcode`.
pub fn build_reply(query: &[u8], q: &Question, rcode: u8, answers: &[(u16, Vec<u8>)]) -> Vec<u8> {
    let mut out = Vec::with_capacity(q.end + answers.len() * 32);
    out.extend_from_slice(&q.id.to_be_bytes());
    // QR, the query's opcode and RD; RA
    let hi = 0x80 | ((q.flags >> 8) as u8 & 0x79);
    out.push(hi);
    out.push(0x80 | (rcode & 0x0f));
    out.extend_from_slice(&1u16.to_be_bytes());
    out.extend_from_slice(&(answers.len() as u16).to_be_bytes());
    out.extend_from_slice(&[0, 0, 0, 0]);
    out.extend_from_slice(&query[12..q.end]);
    for (rtype, rdata) in answers {
        out.extend_from_slice(&[0xc0, 0x0c]);
        out.extend_from_slice(&rtype.to_be_bytes());
        out.extend_from_slice(&1u16.to_be_bytes());
        out.extend_from_slice(&TTL.to_be_bytes());
        out.extend_from_slice(&(rdata.len() as u16).to_be_bytes());
        out.extend_from_slice(rdata);
    }
    out
}

/// What to do with a hijacked dns query.
#[derive(Debug, PartialEq, Eq)]
pub enum DnsAction {
    /// Answered here (fake address, or an empty answer).
    Reply(Vec<u8>),
    /// Send it on to the resolver through the tunnel, as without fake-ip.
    Forward,
}

/// The fake-ip answer to `query`. `v6` says whether the TUN carries IPv6: without it an AAAA
/// query gets an empty answer, so programs do not try addresses that lead nowhere.
pub fn answer(pool: &FakePool, query: &[u8], v6: bool) -> DnsAction {
    let Some(q) = parse_question(query) else { return DnsAction::Forward };
    if q.qclass != 1 {
        return DnsAction::Forward;
    }
    if q.qtype == QTYPE_PTR {
        return match ptr_target(&q.name) {
            Some(ip) if pool.contains(ip) => match pool.lookup(ip) {
                Some(name) => DnsAction::Reply(build_reply(query, &q, 0, &[(QTYPE_PTR, encode_name(&name))])),
                None => DnsAction::Reply(build_reply(query, &q, 3, &[])),
            },
            _ => DnsAction::Forward,
        };
    }
    if keeps_real_answer(&q.name) {
        return DnsAction::Forward;
    }
    match q.qtype {
        QTYPE_A => {
            let answers: Vec<(u16, Vec<u8>)> =
                pool.v4_for(&q.name).map(|a| (QTYPE_A, a.octets().to_vec())).into_iter().collect();
            DnsAction::Reply(build_reply(query, &q, 0, &answers))
        }
        QTYPE_AAAA => {
            let answers: Vec<(u16, Vec<u8>)> = if v6 {
                pool.v6_for(&q.name).map(|a| (QTYPE_AAAA, a.octets().to_vec())).into_iter().collect()
            } else {
                Vec::new()
            };
            DnsAction::Reply(build_reply(query, &q, 0, &answers))
        }
        // An HTTPS / SVCB record carries real address hints (ipv4hint, ipv6hint, ECH) a browser
        // would connect to instead of the fake address: answer that there is none.
        QTYPE_HTTPS | QTYPE_SVCB => DnsAction::Reply(build_reply(query, &q, 0, &[])),
        _ => DnsAction::Forward,
    }
}

/// A SERVFAIL reply to `query`, when it can be parsed.
pub fn servfail(query: &[u8]) -> Option<Vec<u8>> {
    let q = parse_question(query)?;
    Some(build_reply(query, &q, 2, &[]))
}

fn encode_name(name: &str) -> Vec<u8> {
    let mut out = Vec::with_capacity(name.len() + 2);
    for label in name.split('.').filter(|l| !l.is_empty()) {
        let l = &label.as_bytes()[..label.len().min(63)];
        out.push(l.len() as u8);
        out.extend_from_slice(l);
    }
    out.push(0);
    out
}

/// The address a reverse name (`4.3.2.1.in-addr.arpa`, nibbles `.ip6.arpa`) asks about.
pub fn ptr_target(name: &str) -> Option<IpAddr> {
    if let Some(rest) = name.strip_suffix(".in-addr.arpa") {
        let parts: Vec<u8> = rest.split('.').map(|p| p.parse::<u8>().ok()).collect::<Option<_>>()?;
        if parts.len() != 4 {
            return None;
        }
        return Some(IpAddr::V4(Ipv4Addr::new(parts[3], parts[2], parts[1], parts[0])));
    }
    if let Some(rest) = name.strip_suffix(".ip6.arpa") {
        let nibbles: Vec<u8> = rest
            .split('.')
            .map(|p| if p.len() == 1 { u8::from_str_radix(p, 16).ok() } else { None })
            .collect::<Option<_>>()?;
        if nibbles.len() != 32 {
            return None;
        }
        let mut v: u128 = 0;
        for n in nibbles.iter().rev() {
            v = (v << 4) | *n as u128;
        }
        return Some(IpAddr::V6(Ipv6Addr::from(v)));
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg() -> FakeIpConfig {
        FakeIpConfig::parse(DEFAULT_RANGE).unwrap()
    }

    fn query(name: &str, qtype: u16) -> Vec<u8> {
        let mut q = vec![0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0];
        q.extend_from_slice(&encode_name(name));
        q.extend_from_slice(&qtype.to_be_bytes());
        q.extend_from_slice(&1u16.to_be_bytes());
        q
    }

    /// (rcode, answers as (type, rdata)) of a reply built here.
    fn read_reply(r: &[u8], qlen: usize) -> (u8, Vec<(u16, u32, Vec<u8>)>) {
        assert_eq!(&r[0..2], &[0x12, 0x34]);
        assert!(r[2] & 0x80 != 0, "QR set");
        assert!(r[2] & 0x01 != 0, "RD copied");
        let an = u16::from_be_bytes([r[6], r[7]]) as usize;
        let mut pos = qlen;
        let mut out = Vec::new();
        for _ in 0..an {
            assert_eq!(&r[pos..pos + 2], &[0xc0, 0x0c]);
            let t = u16::from_be_bytes([r[pos + 2], r[pos + 3]]);
            let ttl = u32::from_be_bytes([r[pos + 6], r[pos + 7], r[pos + 8], r[pos + 9]]);
            let l = u16::from_be_bytes([r[pos + 10], r[pos + 11]]) as usize;
            out.push((t, ttl, r[pos + 12..pos + 12 + l].to_vec()));
            pos += 12 + l;
        }
        assert_eq!(pos, r.len());
        (r[3] & 0x0f, out)
    }

    #[test]
    fn ranges_are_parsed_and_checked() {
        let c = cfg();
        assert_eq!(c.v4, Some("198.18.0.0/15".parse().unwrap()));
        assert_eq!(c.v6, Some("fc00::/18".parse().unwrap()));
        assert!(c.contains("198.19.255.1".parse().unwrap()));
        assert!(c.contains("::ffff:198.18.0.9".parse().unwrap()));
        assert!(!c.contains("198.20.0.1".parse().unwrap()));
        assert!(c.contains("fc00:1::5".parse().unwrap()));
        assert!(!c.contains("fd00::1".parse().unwrap()));
        assert_eq!(c.capacity(), MAX_ENTRIES);
        assert!(FakeIpConfig::parse("10.0.0.0/8,10.1.0.0/16").is_err());
        assert!(FakeIpConfig::parse("1.2.3.4/30").is_err());
        assert!(FakeIpConfig::parse("nonsense").is_err());
        assert!(FakeIpConfig::parse("").is_err());
        let v4only = FakeIpConfig::parse("100.64.0.0/24").unwrap();
        assert_eq!((v4only.v6, v4only.capacity()), (None, 254));
    }

    #[test]
    fn a_name_keeps_its_address_and_maps_back() {
        let p = FakePool::new(cfg());
        let a = p.v4_for("Example.COM.").unwrap();
        assert_eq!(a, Ipv4Addr::new(198, 18, 0, 1));
        assert_eq!(p.v4_for("example.com"), Some(a), "stable reuse");
        let b = p.v4_for("other.test").unwrap();
        assert_ne!(a, b);
        let a6 = p.v6_for("example.com").unwrap();
        assert_eq!(a6, "fc00::1".parse::<Ipv6Addr>().unwrap(), "same slot in both families");
        assert_eq!(p.lookup(IpAddr::V4(a)).as_deref(), Some("example.com"));
        assert_eq!(p.lookup(IpAddr::V6(a6)).as_deref(), Some("example.com"));
        assert_eq!(p.lookup(IpAddr::V4(b)).as_deref(), Some("other.test"));
        assert_eq!(p.lookup("198.18.0.200".parse().unwrap()), None, "never given out");
        assert_eq!(p.lookup("8.8.8.8".parse().unwrap()), None);
        assert_eq!(p.len(), 2);
    }

    #[test]
    fn a_full_pool_reuses_the_address_unused_the_longest() {
        let p = FakePool::with_capacity(cfg(), 3);
        let a = p.v4_for("a.test").unwrap();
        let b = p.v4_for("b.test").unwrap();
        let c = p.v4_for("c.test").unwrap();
        // a is used again, so b is now the oldest
        assert_eq!(p.lookup(IpAddr::V4(a)).as_deref(), Some("a.test"));
        let d = p.v4_for("d.test").unwrap();
        assert_eq!(d, b, "b's address went to d");
        assert_eq!(p.lookup(IpAddr::V4(b)).as_deref(), Some("d.test"));
        assert_eq!(p.len(), 3);
        // b asks again: it gets the oldest address now, c's
        let b2 = p.v4_for("b.test").unwrap();
        assert_eq!(b2, c);
        assert_eq!(restore_in(Some(&p), IpAddr::V4(a)), Restored::Name("a.test".into()));
        assert_eq!(restore_in(Some(&p), "198.18.0.99".parse().unwrap()), Restored::Stale);
        assert_eq!(restore_in(Some(&p), "1.1.1.1".parse().unwrap()), Restored::Real);
        assert_eq!(restore_in(None, IpAddr::V4(a)), Restored::Real);
    }

    #[test]
    fn a_and_aaaa_queries_get_fake_answers() {
        let p = FakePool::new(cfg());
        let q = query("www.example.com", QTYPE_A);
        let DnsAction::Reply(r) = answer(&p, &q, true) else { panic!("not answered") };
        let (rcode, ans) = read_reply(&r, q.len());
        assert_eq!(rcode, 0);
        assert_eq!(ans, vec![(QTYPE_A, TTL, vec![198, 18, 0, 1])]);
        assert_eq!(&r[12..q.len()], &q[12..], "the question is echoed");

        let q6 = query("www.example.com", QTYPE_AAAA);
        let DnsAction::Reply(r6) = answer(&p, &q6, true) else { panic!() };
        let (_, ans6) = read_reply(&r6, q6.len());
        assert_eq!(ans6[0].0, QTYPE_AAAA);
        assert_eq!(ans6[0].2, "fc00::1".parse::<Ipv6Addr>().unwrap().octets().to_vec());

        // no IPv6 on the TUN: an empty answer
        let DnsAction::Reply(r6) = answer(&p, &q6, false) else { panic!() };
        assert_eq!(read_reply(&r6, q6.len()), (0, vec![]));
    }

    #[test]
    fn https_records_are_empty_and_other_types_go_on() {
        let p = FakePool::new(cfg());
        for t in [QTYPE_HTTPS, QTYPE_SVCB] {
            let q = query("www.example.com", t);
            let DnsAction::Reply(r) = answer(&p, &q, true) else { panic!("HTTPS/SVCB not answered") };
            assert_eq!(read_reply(&r, q.len()), (0, vec![]));
        }
        for t in [15u16, 16, 33, 2] {
            assert_eq!(answer(&p, &query("example.com", t), true), DnsAction::Forward);
        }
        // names that keep real answers
        for n in ["localhost", "printer.local", "wpad", "x.localhost"] {
            assert_eq!(answer(&p, &query(n, QTYPE_A), true), DnsAction::Forward, "{n}");
        }
        assert!(p.is_empty(), "nothing was mapped");
        // not a query
        let mut resp = query("example.com", QTYPE_A);
        resp[2] |= 0x80;
        assert_eq!(answer(&p, &resp, true), DnsAction::Forward);
        assert_eq!(answer(&p, &[1, 2, 3], true), DnsAction::Forward);
    }

    #[test]
    fn reverse_lookups_of_fake_addresses_give_the_name() {
        let p = FakePool::new(cfg());
        let a = p.v4_for("example.com").unwrap();
        let o = a.octets();
        let q = query(&format!("{}.{}.{}.{}.in-addr.arpa", o[3], o[2], o[1], o[0]), QTYPE_PTR);
        let DnsAction::Reply(r) = answer(&p, &q, true) else { panic!() };
        let (_, ans) = read_reply(&r, q.len());
        assert_eq!(ans[0].2, encode_name("example.com"));
        let q = query("200.0.18.198.in-addr.arpa", QTYPE_PTR);
        let DnsAction::Reply(r) = answer(&p, &q, true) else { panic!() };
        assert_eq!(read_reply(&r, q.len()).0, 3, "NXDOMAIN for an unmapped fake address");
        assert_eq!(answer(&p, &query("8.8.8.8.in-addr.arpa", QTYPE_PTR), true), DnsAction::Forward);
        let v6: Ipv6Addr = "fc00::1".parse().unwrap();
        let nib: Vec<String> = format!("{:032x}", u128::from(v6)).chars().rev().map(|c| c.to_string()).collect();
        assert_eq!(ptr_target(&format!("{}.ip6.arpa", nib.join("."))), Some(IpAddr::V6(v6)));
    }

    #[test]
    fn servfail_keeps_the_question() {
        let q = query("example.com", QTYPE_A);
        let r = servfail(&q).unwrap();
        assert_eq!(read_reply(&r, q.len()), (2, vec![]));
    }
}
