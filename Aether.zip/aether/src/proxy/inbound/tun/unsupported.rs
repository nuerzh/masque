//! --tun is only implemented for Linux and Windows.

use bytes::Bytes;

use super::TunConfig;

pub(super) struct Device;

pub(super) fn preflight(_cfg: &TunConfig) -> Result<(), String> {
    Err("TUN mode is only available on Linux and Windows".into())
}

pub(super) fn host_has_ipv6() -> bool {
    false
}

pub(super) fn cleanup_stale(_cfg: &TunConfig) {}

pub(super) fn system_dns(_cfg: &TunConfig) -> (Vec<std::net::IpAddr>, String) {
    (Vec::new(), "no system dns reader on this platform".into())
}

impl Device {
    pub(super) fn open(
        _cfg: &TunConfig,
        _to_stack: async_channel::Sender<Bytes>,
        _from_stack: async_channel::Receiver<Bytes>,
    ) -> Result<Device, String> {
        Err("TUN mode is only available on Linux and Windows".into())
    }
}
