// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
//
// Adapted for Aether from geph5 (https://github.com/geph-official/geph5),
// binaries/geph5-app/src/vpn/linux.rs, Copyright (c) the Geph developers,
// licensed under MPL-2.0 (see LICENSE-geph5-MPL-2.0). Taken: the TUNSETIFF
// device creation, the `ip` command runner, the replace-rule-by-priority idiom,
// the "own traffic to main, guard with unreachable, everything else to the TUN
// table" policy-routing ladder and the nftables kill switch. Changed: Aether
// is one process, so its own traffic is told apart by a socket mark (SO_MARK,
// set on every egress socket) instead of a dedicated uid; the device name,
// addresses, table, priorities and include/exclude routes are configurable; a
// `suppress_prefixlength 0` rule keeps LAN routes direct unless strict; the
// kill switch is only installed in strict mode; DNS is handed to
// systemd-resolved when it runs.

//! Linux side of the TUN inbound: the device, its addresses, the policy routing that sends
//! everything but Aether's own (marked) sockets into it, DNS and the optional kill switch.

use std::io::Write;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::process::{Command, Stdio};

use bytes::Bytes;
use tokio::io::unix::AsyncFd;

use super::TunConfig;

// From <linux/if_tun.h>: TUNSETIFF = _IOW('T', 202, int). Kept as a plain integer and cast
// with `as _` at the call site, because `libc::ioctl`'s request argument is `c_ulong` on glibc
// but `c_int` on musl.
const TUNSETIFF: u64 = 0x4004_54ca;
const IFF_TUN: libc::c_short = 0x0001;
const IFF_NO_PI: libc::c_short = 0x1000;

const NFT_TABLE: &str = "aether_tun";

/// The running device. Dropping it stops the packet pumps, removes the rules, the table, the
/// firewall and the device itself.
pub(super) struct Device {
    cfg: TunConfig,
    tasks: Vec<tokio::task::JoinHandle<()>>,
}

impl Drop for Device {
    fn drop(&mut self) {
        for t in self.tasks.drain(..) {
            t.abort();
        }
        cleanup_stale(&self.cfg);
    }
}

/// Whether the host has an IPv6 default route of its own.
pub(super) fn host_has_ipv6() -> bool {
    Command::new("ip")
        .args(["-6", "route", "show", "default"])
        .output()
        .map(|o| o.status.success() && !String::from_utf8_lossy(&o.stdout).trim().is_empty())
        .unwrap_or(false)
}

/// The system's dns servers as resolv.conf has them (systemd-resolved's upstream list when
/// /etc/resolv.conf only names its 127.0.0.53 stub), read before the TUN takes over.
pub(super) fn system_dns(_cfg: &TunConfig) -> (Vec<std::net::IpAddr>, String) {
    const ETC: &str = "/etc/resolv.conf";
    const RESOLVED: &str = "/run/systemd/resolve/resolv.conf";
    let etc = std::fs::read_to_string(ETC).ok();
    let upstream = std::fs::read_to_string(RESOLVED).ok();
    let main = etc.as_deref().map(super::parse_resolv_conf).unwrap_or_default();
    let found = super::pick_resolv_servers(etc.as_deref(), upstream.as_deref());
    let from = if upstream.is_some() && found != main { RESOLVED } else { ETC };
    (found, from.to_string())
}

pub(super) fn preflight(cfg: &TunConfig) -> Result<(), String> {
    if unsafe { libc::geteuid() } != 0 {
        log::warn!("[tun] not running as root: TUN mode needs CAP_NET_ADMIN (and the `ip` command)");
    }
    if Command::new("ip").arg("-V").stdout(Stdio::null()).stderr(Stdio::null()).status().is_err() {
        return Err("TUN mode needs the `ip` command (iproute2)".into());
    }
    if crate::utils::egress::mark() == 0 {
        return Err("TUN mode needs a socket mark for Aether's own sockets; mark: 0 turned it off".into());
    }
    if cfg.strict_route && !nft_present() {
        log::warn!("[tun] tun.strict-route: `nft` (nftables) is missing, so the leak firewall is not installed; LAN routes are still taken into the TUN");
    }
    Ok(())
}

impl Device {
    pub(super) fn open(
        cfg: &TunConfig,
        to_stack: async_channel::Sender<Bytes>,
        from_stack: async_channel::Receiver<Bytes>,
    ) -> Result<Device, String> {
        let fd = create_tun(&cfg.name).map_err(|e| {
            let hint = if e.raw_os_error() == Some(libc::EPERM) || e.raw_os_error() == Some(libc::EACCES) {
                "; run Aether as root (sudo) or give it CAP_NET_ADMIN"
            } else {
                ""
            };
            format!("creating the TUN device {}: {e}{hint}", cfg.name)
        })?;
        // From here on a failure undoes what was done.
        let mut device = Device { cfg: cfg.clone(), tasks: Vec::new() };
        for cmd in plan_setup(cfg, crate::utils::egress::mark()) {
            let optional = cmd.optional;
            if let Err(e) = run(&cmd.args) {
                if optional {
                    log::debug!("[tun] {e}");
                } else {
                    return Err(e);
                }
            }
        }
        if cfg.strict_route && cfg.auto_route && nft_present() {
            if let Err(e) = nft_apply(&killswitch(cfg, crate::utils::egress::mark())) {
                log::warn!("[tun] leak firewall not installed: {e}");
            } else {
                log::info!("[tun] leak firewall installed (nft table inet {NFT_TABLE})");
            }
        }
        if let Some(dns) = cfg.dns {
            set_resolved_dns(&cfg.name, dns);
        }
        let afd = AsyncFd::new(fd).map_err(|e| format!("tun fd: {e}"))?;
        let afd = std::sync::Arc::new(afd);
        let mtu = cfg.mtu as usize;
        let reader = afd.clone();
        device.tasks.push(tokio::spawn(async move {
            let mut buf = vec![0u8; mtu.max(1500) + 64];
            loop {
                let Ok(mut guard) = reader.readable().await else { return };
                match guard.try_io(|inner| {
                    let n = unsafe { libc::read(inner.as_raw_fd(), buf.as_mut_ptr().cast(), buf.len()) };
                    if n < 0 {
                        Err(std::io::Error::last_os_error())
                    } else {
                        Ok(n as usize)
                    }
                }) {
                    Ok(Ok(0)) => return,
                    Ok(Ok(n)) => {
                        if to_stack.send(Bytes::copy_from_slice(&buf[..n])).await.is_err() {
                            return;
                        }
                    }
                    Ok(Err(e)) => {
                        log::debug!("[tun] read: {e}");
                        if e.raw_os_error() == Some(libc::EBADF) {
                            return;
                        }
                    }
                    Err(_would_block) => continue,
                }
            }
        }));
        let writer = afd;
        device.tasks.push(tokio::spawn(async move {
            while let Ok(pkt) = from_stack.recv().await {
                loop {
                    let Ok(mut guard) = writer.writable().await else { return };
                    match guard.try_io(|inner| {
                        let n = unsafe { libc::write(inner.as_raw_fd(), pkt.as_ptr().cast(), pkt.len()) };
                        if n < 0 {
                            Err(std::io::Error::last_os_error())
                        } else {
                            Ok(())
                        }
                    }) {
                        Ok(Ok(())) => break,
                        Ok(Err(e)) => {
                            log::trace!("[tun] write: {e}");
                            break;
                        }
                        Err(_would_block) => continue,
                    }
                }
            }
        }));
        Ok(device)
    }
}

fn create_tun(name: &str) -> std::io::Result<OwnedFd> {
    let fd = unsafe { libc::open(c"/dev/net/tun".as_ptr(), libc::O_RDWR | libc::O_CLOEXEC | libc::O_NONBLOCK) };
    if fd < 0 {
        return Err(std::io::Error::last_os_error());
    }
    let owned = unsafe { OwnedFd::from_raw_fd(fd) };

    #[repr(C)]
    struct IfReq {
        name: [libc::c_char; 16],
        flags: libc::c_short,
        _pad: [u8; 22],
    }
    let mut req = IfReq { name: [0; 16], flags: IFF_TUN | IFF_NO_PI, _pad: [0; 22] };
    for (i, b) in name.bytes().take(15).enumerate() {
        req.name[i] = b as libc::c_char;
    }
    let rc = unsafe { libc::ioctl(owned.as_raw_fd(), TUNSETIFF as _, &mut req as *mut IfReq) };
    if rc < 0 {
        return Err(std::io::Error::last_os_error());
    }
    Ok(owned)
}

/// One `ip` invocation of the setup; `optional` ones (IPv6 on a host without it) may fail.
#[derive(Debug, Clone, PartialEq)]
pub(super) struct Cmd {
    pub args: Vec<String>,
    pub optional: bool,
}

fn cmd(optional: bool, args: &[&str]) -> Cmd {
    Cmd { args: args.iter().map(|s| s.to_string()).collect(), optional }
}

/// Every command that brings the device, its addresses and (with auto-route) the policy
/// routing up, in order. Pure, so the tests can read it.
///
///   prio P   : fwmark M -> main           (Aether's own sockets leave by the real interface)
///   prio P+1 : fwmark M -> unreachable    (guard: never fall through into the TUN)
///   prio P+2 : main, suppress_prefixlength 0  (LAN and other specific routes stay direct;
///              left out with strict route)
///   prio P+3 : -> table T                 (everything else; T has the TUN default or the
///              include routes, and `throw` routes for the excludes)
pub(super) fn plan_setup(cfg: &TunConfig, mark: u32) -> Vec<Cmd> {
    let dev = cfg.name.as_str();
    let mtu = cfg.mtu.to_string();
    let mut out = vec![cmd(false, &["link", "set", dev, "mtu", &mtu]), cmd(false, &["link", "set", dev, "up"])];
    if let Some((a, p)) = cfg.v4 {
        out.push(cmd(false, &["-4", "addr", "replace", &format!("{a}/{p}"), "dev", dev]));
    }
    if let Some((a, p)) = cfg.v6 {
        out.push(cmd(true, &["-6", "addr", "replace", &format!("{a}/{p}"), "dev", dev, "nodad"]));
    }
    if !cfg.auto_route {
        return out;
    }
    let table = cfg.table.to_string();
    let mark = format!("{mark:#x}");
    let prio = |i: u32| (cfg.priority + i).to_string();
    for (fam, v6) in [("-4", false), ("-6", true)] {
        if !v6 && cfg.v4.is_none() || v6 && cfg.v6.is_none() {
            continue;
        }
        let optional = v6;
        let any = if v6 { "::/0" } else { "0.0.0.0/0" };
        let includes: Vec<String> = cfg
            .include
            .iter()
            .filter(|n| matches!(n, ipnet::IpNet::V6(_)) == v6)
            .map(|n| n.to_string())
            .collect();
        if includes.is_empty() {
            out.push(cmd(optional, &[fam, "route", "replace", any, "dev", dev, "table", &table]));
        } else {
            for n in &includes {
                out.push(cmd(optional, &[fam, "route", "replace", n, "dev", dev, "table", &table]));
            }
        }
        for n in cfg.exclude.iter().filter(|n| matches!(n, ipnet::IpNet::V6(_)) == v6) {
            out.push(cmd(optional, &[fam, "route", "replace", "throw", &n.to_string(), "table", &table]));
        }
        out.push(cmd(optional, &[fam, "rule", "add", "fwmark", &mark, "lookup", "main", "priority", &prio(0)]));
        out.push(cmd(optional, &[fam, "rule", "add", "fwmark", &mark, "unreachable", "priority", &prio(1)]));
        if !cfg.strict_route {
            out.push(cmd(optional, &[fam, "rule", "add", "lookup", "main", "suppress_prefixlength", "0", "priority", &prio(2)]));
        }
        out.push(cmd(optional, &[fam, "rule", "add", "lookup", &table, "priority", &prio(3)]));
    }
    out
}

/// The commands that undo `plan_setup` (all may fail: nothing to remove).
pub(super) fn plan_cleanup(cfg: &TunConfig) -> Vec<Vec<String>> {
    let mut out = Vec::new();
    for fam in ["-4", "-6"] {
        for i in 0..4 {
            out.push(vec![fam.to_string(), "rule".into(), "del".into(), "priority".into(), (cfg.priority + i).to_string()]);
        }
        out.push(vec![fam.to_string(), "route".into(), "flush".into(), "table".into(), cfg.table.to_string()]);
    }
    out
}

/// Remove rules, table, firewall and device of this or an earlier run. Idempotent.
pub(super) fn cleanup_stale(cfg: &TunConfig) {
    for args in plan_cleanup(cfg) {
        // a priority can hold more than one rule if a run was killed between add and del
        let is_rule_del = args.get(1).map(|s| s == "rule").unwrap_or(false);
        let mut guard = 0;
        while run(&args).is_ok() && is_rule_del && guard < 16 {
            guard += 1;
        }
    }
    if nft_present() {
        let _ = nft_apply(&format!("table inet {NFT_TABLE}\ndelete table inet {NFT_TABLE}\n"));
    }
    // Only delete the interface when it is a TUN device (never a real NIC of the same name).
    if std::path::Path::new(&format!("/sys/class/net/{}/tun_flags", cfg.name)).exists() {
        let _ = run(&["link".into(), "del".into(), cfg.name.clone()]);
    }
}

/// The kill switch of strict route: anything leaving by an interface other than the TUN and
/// loopback that is not Aether's own (marked) traffic or DHCP is dropped.
pub(super) fn killswitch(cfg: &TunConfig, mark: u32) -> String {
    format!(
        "table inet {t}
delete table inet {t}
table inet {t} {{
\tchain killswitch {{
\t\ttype filter hook output priority filter; policy accept;
\t\toifname \"lo\" accept
\t\toifname \"{iface}\" accept
\t\tmeta mark {mark:#x} accept
\t\tudp dport {{ 67, 68, 546, 547 }} accept
\t\ticmpv6 type {{ nd-router-solicit, nd-neighbor-solicit, nd-neighbor-advert }} accept
\t\tcounter drop
\t}}
}}
",
        t = NFT_TABLE,
        iface = cfg.name,
    )
}

/// Point systemd-resolved at the TUN dns address for every domain. Undone by the kernel when
/// the link goes away. Without systemd-resolved nothing is changed here: port-53 traffic that
/// enters the TUN is hijacked anyway (see --tun-dns-hijack).
fn set_resolved_dns(dev: &str, dns: std::net::IpAddr) {
    let ok = Command::new("resolvectl")
        .args(["dns", dev, &dns.to_string()])
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false);
    if ok {
        let _ = Command::new("resolvectl").args(["domain", dev, "~."]).stdout(Stdio::null()).stderr(Stdio::null()).status();
        let _ = Command::new("resolvectl").args(["default-route", dev, "yes"]).stdout(Stdio::null()).stderr(Stdio::null()).status();
        log::info!("[tun] systemd-resolved now asks {dns} through {dev}");
    } else {
        log::debug!("[tun] resolvectl not available; system dns left as it is (port 53 is hijacked in the TUN)");
    }
}

fn nft_present() -> bool {
    Command::new("nft")
        .arg("list")
        .arg("tables")
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

fn nft_apply(ruleset: &str) -> Result<(), String> {
    let mut child = Command::new("nft")
        .arg("-f")
        .arg("-")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| format!("spawning nft: {e}"))?;
    child
        .stdin
        .take()
        .ok_or("nft stdin")?
        .write_all(ruleset.as_bytes())
        .map_err(|e| e.to_string())?;
    let out = child.wait_with_output().map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(format!("nft failed: {}", String::from_utf8_lossy(&out.stderr).trim()));
    }
    Ok(())
}

fn run(args: &[String]) -> Result<(), String> {
    let out = Command::new("ip").args(args).output().map_err(|e| format!("spawning ip: {e}"))?;
    if !out.status.success() {
        return Err(format!("`ip {}` failed: {}", args.join(" "), String::from_utf8_lossy(&out.stderr).trim()));
    }
    log::debug!("[tun] ip {}", args.join(" "));
    Ok(())
}
