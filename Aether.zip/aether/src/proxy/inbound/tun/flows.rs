//! The flows of the TUN inbound (--tun): each tcp and udp flow the userspace stack takes off
//! the device goes through the router as inbound `tun`, with the same outbounds, sniffing,
//! rule sets, process rules and dns hijacking as a socks5 connection.

use std::net::SocketAddr;
use std::pin::Pin;
use std::time::Duration;

use ipstack_geph::stream::{IpStackStream, IpStackTcpStream, IpStackUdpStream};
use tokio::net::TcpStream;

use crate::proxy::inbound::{Inbound, RoutedClient};
use crate::proxy::prelude::*;
use super::fakeip::{self, DnsAction, Restored};
use super::{classify, Class, TunConfig};

/// The udp socket to the resolver inside the tunnel and the answers it gets back.
type UdpUpstream = (UdpSender, tokio::sync::mpsc::Receiver<(SocketAddr, Vec<u8>)>);

impl RoutedClient for IpStackTcpStream {
    fn relay_tcp(self, up: TcpStream, linger: Duration) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        Box::pin(relay_generic(self, up, linger))
    }
    fn relay_tunnel(
        self,
        sender: TcpSender,
        rx: tokio::sync::mpsc::Receiver<Vec<u8>>,
        linger: Duration,
    ) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        Box::pin(relay_tunneled_io(self, sender, rx, linger))
    }
    fn abort(&mut self) {
        self.reset();
    }
}

/// Accept the stack's flows until it stops.
pub(crate) async fn serve(stack: ipstack_geph::IpStack, cfg: &'static TunConfig) {
    loop {
        let flow = match stack.accept().await {
            Ok(f) => f,
            Err(e) => {
                // the device closed its end: Aether is stopping
                log::debug!("[tun] the userspace stack stopped: {e}");
                return;
            }
        };
        match flow {
            IpStackStream::Tcp(s) => {
                tokio::spawn(tcp_flow(s, cfg));
            }
            IpStackStream::Udp(u) => {
                tokio::spawn(udp_flow(u, cfg));
            }
            IpStackStream::UnknownTransport(_) | IpStackStream::UnknownNetwork(_) => {}
        }
    }
}

fn exit() -> Exit {
    Exit::Current
}

/// The target of a flow to `dst`: the name behind a fake address (fake-ip), or the address.
/// None for a fake address that no name is mapped to any more (a program kept it past its TTL
/// across a restart, or the pool reused it): such a flow is refused rather than sent anywhere.
pub(crate) fn flow_target(dst: std::net::IpAddr) -> Option<Target> {
    match fakeip::restore(dst) {
        Restored::Real => Some(Target::Ip(dst)),
        Restored::Name(name) => Some(Target::Domain(name)),
        Restored::Stale => None,
    }
}

async fn tcp_flow(mut s: IpStackTcpStream, cfg: &'static TunConfig) {
    let src = s.local_addr();
    let dst = s.peer_addr();
    let forced = match classify(cfg, dst) {
        Class::Drop => {
            s.reset();
            return;
        }
        Class::Dns => Some(Verdict::HijackDns),
        Class::Route => None,
    };
    let Some(router) = crate::proxy::router::router() else {
        s.reset();
        return;
    };
    let target = match forced {
        Some(_) => Target::Ip(dst.ip()),
        None => match flow_target(dst.ip()) {
            Some(t) => t,
            None => {
                log::debug!("[tun] tcp {src} -> {dst}: a fake address with no name behind it (stale); reset");
                s.reset();
                return;
            }
        },
    };
    if let Err(e) = serve_stream(&router, s, Inbound::Tun, target, dst.port(), Vec::new(), &exit(), src, Some(dst), forced).await {
        log::debug!("[tun] tcp {src} -> {dst}: {e}");
    }
}

/// How long a udp flow lives without a packet either way.
fn udp_idle(dst: SocketAddr) -> Duration {
    if dst.port() == 53 {
        Duration::from_secs(20)
    } else {
        Duration::from_secs(120)
    }
}

async fn udp_flow(u: IpStackUdpStream, cfg: &'static TunConfig) {
    let src = u.local_addr();
    let dst = u.peer_addr();
    let idle = udp_idle(dst);
    let Ok(Ok(first)) = tokio::time::timeout(idle, u.recv()).await else { return };
    let mut queued: Vec<Vec<u8>> = vec![first.to_vec()];

    // the name behind a fake address (fake-ip), else the address
    let mut host = dst.ip().to_string();
    let route = match classify(cfg, dst) {
        Class::Drop => return,
        Class::Dns => FlowRoute::Dns,
        Class::Route => {
            match flow_target(dst.ip()) {
                Some(t) => host = target_host(&t),
                None => {
                    log::debug!("[tun] udp {src} -> {dst}: a fake address with no name behind it (stale); dropped");
                    return;
                }
            }
            let Some(router) = crate::proxy::router::router() else { return };
            router.wait_ready().await;
            let exit = exit();
            let mut meta = Metadata::new("tun", Network::Udp, src, &host, dst.port());
            meta.local = Some(dst);
            let mut ropts = RouteOpts::default();
            match first_udp_step(&router, &mut meta, &mut ropts, &exit, &queued[0]).await {
                Ok(r) => r,
                Err((next, opts)) => {
                    let deadline = tokio::time::Instant::now() + opts.timeout;
                    let list = opts.packet();
                    let outcome = loop {
                        match sniffers::packets(&queued, &list) {
                            Outcome::NeedMore if queued.len() < 4 => {}
                            o => break o,
                        }
                        match tokio::time::timeout_at(deadline, u.recv()).await {
                            Ok(Ok(p)) => queued.push(p.to_vec()),
                            Ok(Err(_)) => return,
                            Err(_) => break sniffers::packets(&queued, &list),
                        }
                    };
                    apply_packet_sniff(&mut meta, outcome);
                    let key = (host.clone(), dst.port());
                    finish_udp(&router, &mut meta, next, &mut ropts, &exit, &key).await
                }
            }
        }
    };
    log::trace!("[tun] udp {src} -> {dst}: {route:?}");
    if let Err(e) = forward_udp(&u, src, dst, &host, route, queued, idle).await {
        log::debug!("[tun] udp {src} -> {dst}: {e}");
    }
}

/// `host` is what the flow is for: the name behind a fake address, or the address itself.
async fn forward_udp(
    u: &IpStackUdpStream,
    src: SocketAddr,
    dst: SocketAddr,
    host: &str,
    route: FlowRoute,
    queued: Vec<Vec<u8>>,
    idle: Duration,
) -> std::io::Result<()> {
    // a flow addressed by name: `direct` resolves with Aether's own resolver (never the system's,
    // which points at the TUN), `warp` inside the WARP tunnel
    let route = match route {
        FlowRoute::Direct(None) => match lookup_direct(host, dst.port()).await {
            Ok(list) => match list.into_iter().find(|a| direct_target_allowed(src.ip(), a.ip())) {
                Some(a) => FlowRoute::Direct(Some(a)),
                None => return Ok(()),
            },
            Err(e) => {
                log::debug!("[tun] udp {host}:{} via direct: {e}", dst.port());
                return Ok(());
            }
        },
        // warp-local: resolved like direct (never the system resolver behind the TUN, never a
        // fake address), sent through the WARP stack; no stack -> dropped
        FlowRoute::WarpLocal => {
            if let Err(e) = exits::warp_stack("tun udp via warp-local").await {
                log::debug!("[tun] udp {host}:{}: {e}; dropped", dst.port());
                return Ok(());
            }
            match warp_local_addresses(host, dst.port(), &[]).await {
                Ok((ips, from)) => {
                    log::debug!("[route] udp {host}:{} => warp-local (resolved {host} -> {} via {from})", dst.port(), ips[0]);
                    FlowRoute::Warp(Some(SocketAddr::new(ips[0], dst.port())))
                }
                Err(e) => {
                    log::debug!("[tun] udp {host}:{} via warp-local: {e}", dst.port());
                    return Ok(());
                }
            }
        }
        FlowRoute::Warp(None) => {
            let stack = match exits::warp_stack("tun udp via warp").await {
                Ok(s) => s,
                Err(e) => {
                    log::debug!("[tun] udp {host}:{}: {e}; dropped", dst.port());
                    return Ok(());
                }
            };
            match dns_resolve(&stack, host).await {
                Ok(ip) => FlowRoute::Warp(Some(SocketAddr::new(ip, dst.port()))),
                Err(e) => {
                    log::debug!("[tun] udp {host}:{} via warp: {e}", dst.port());
                    return Ok(());
                }
            }
        }
        r => r,
    };
    match route {
        FlowRoute::Drop => Ok(()),
        FlowRoute::Direct(None) | FlowRoute::Warp(None) | FlowRoute::WarpLocal => Ok(()),
        FlowRoute::Direct(Some(to)) => {
            if !direct_target_allowed(src.ip(), to.ip()) || fakeip::is_fake(to.ip()) {
                return Ok(());
            }
            let sock = crate::utils::egress::udp_bind(crate::utils::egress::wildcard_for(to))?;
            sock.connect(to).await?;
            for p in &queued {
                let _ = sock.send(p).await;
            }
            let mut buf = vec![0u8; 65535];
            loop {
                tokio::select! {
                    r = u.recv() => match r {
                        Ok(p) => { let _ = sock.send(&p).await; crate::utils::stats::add_up(p.len()); }
                        Err(_) => return Ok(()),
                    },
                    r = sock.recv(&mut buf) => match r {
                        Ok(n) => { if u.send(&buf[..n]).await.is_err() { return Ok(()); } crate::utils::stats::add_down(n); }
                        Err(_) => continue,
                    },
                    _ = tokio::time::sleep(idle) => return Ok(()),
                }
            }
        }
        FlowRoute::Warp(Some(to)) => tunnel_udp(u, to, queued, idle).await,
        FlowRoute::Dns => {
            let resolver = resolver_addresses()[0];
            match fakeip::pool() {
                Some(pool) => {
                    log::debug!("[tun] dns {src} -> {dst}: fake-ip (other queries go to {resolver} through the tunnel)");
                    fake_dns_udp(u, pool, resolver, queued, idle).await
                }
                None => {
                    log::debug!("[tun] dns {src} -> {dst} answered by {resolver} through the tunnel");
                    tunnel_udp(u, resolver, queued, idle).await
                }
            }
        }
        FlowRoute::Session(index) => {
            // the name itself (ATYP domain) when the flow has one: the sunnyquic server resolves
            let out = crate::proxy::outbound::outbound_at(index);
            let exit = match out.as_ref().and_then(|o| o.packet_exit()) {
                Some(e) => Some(e),
                // the --sunny client: over WARP waited for as the tunnel is, direct while it is made
                None if out.as_ref().is_some_and(|o| o.via() == crate::proxy::outbound::Via::Sunny) => {
                    exits::sunny_exit("tun udp via sunny").await.ok()
                }
                None => None,
            };
            let Some(exit) = exit else {
                let tag = out.as_ref().map(|o| o.tag().to_string()).unwrap_or_default();
                log::debug!("[tun] udp {host}:{} via {tag}: its client is not up; dropped", dst.port());
                return Ok(());
            };
            let mut s = exit.open_udp().await?;
            for p in queued {
                let _ = s.send(host, dst.port(), p).await;
            }
            loop {
                tokio::select! {
                    r = u.recv() => match r {
                        Ok(p) => { if !s.send(host, dst.port(), p.to_vec()).await { return Ok(()); } }
                        Err(_) => return Ok(()),
                    },
                    r = s.recv() => match r {
                        Some((_, data)) => {
                            if u.send(&data).await.is_err() { return Ok(()); }
                        }
                        None => return Ok(()),
                    },
                    _ = tokio::time::sleep(idle) => return Ok(()),
                }
            }
        }
    }
}

/// A udp flow through the tunnel stack to `to`; replies come back as from the flow's
/// destination, whatever address answered.
async fn tunnel_udp(u: &IpStackUdpStream, to: SocketAddr, queued: Vec<Vec<u8>>, idle: Duration) -> std::io::Result<()> {
    let stack = match exits::warp_stack("tun udp via warp").await {
        Ok(s) => s,
        Err(e) => {
            log::debug!("[tun] udp to {to}: {e}; dropped");
            return Ok(());
        }
    };
    let conn = stack.open_udp().await.map_err(|e| std::io::Error::other(e.to_string()))?;
    let (tx, mut rx) = conn.into_split();
    let result = async {
        for p in queued {
            crate::utils::stats::add_up(p.len());
            if tx.send_to(to, p).await.is_err() {
                return;
            }
        }
        loop {
            tokio::select! {
                r = u.recv() => match r {
                    Ok(p) => {
                        crate::utils::stats::add_up(p.len());
                        if tx.send_to(to, p.to_vec()).await.is_err() { return; }
                    }
                    Err(_) => return,
                },
                r = rx.recv() => match r {
                    Some((_from, data)) => {
                        crate::utils::stats::add_down(data.len());
                        if u.send(&data).await.is_err() { return; }
                    }
                    None => return,
                },
                _ = tokio::time::sleep(idle) => return,
            }
        }
    };
    result.await;
    tx.close().await;
    Ok(())
}

/// Whether the TUN carries IPv6 (else AAAA queries get empty fake-ip answers).
fn tun_has_v6() -> bool {
    super::config().is_some_and(|c| c.v6.is_some())
}

/// A hijacked udp dns flow with fake-ip: A / AAAA (and HTTPS / SVCB) are answered here, every
/// other query goes on to the resolver through the tunnel as before.
async fn fake_dns_udp(
    u: &IpStackUdpStream,
    pool: &'static fakeip::FakePool,
    resolver: SocketAddr,
    queued: Vec<Vec<u8>>,
    idle: Duration,
) -> std::io::Result<()> {
    let v6 = tun_has_v6();
    let mut upstream: Option<UdpUpstream> = None;
    let mut pending: std::collections::VecDeque<Vec<u8>> = queued.into();
    let result = async {
        loop {
            while let Some(q) = pending.pop_front() {
                match fakeip::answer(pool, &q, v6) {
                    DnsAction::Reply(r) => {
                        if u.send(&r).await.is_err() {
                            return;
                        }
                    }
                    DnsAction::Forward => {
                        if upstream.is_none() {
                            let Some(stack) = exits::stack() else {
                                if let Some(r) = fakeip::servfail(&q) {
                                    let _ = u.send(&r).await;
                                }
                                continue;
                            };
                            match stack.open_udp().await {
                                Ok(c) => upstream = Some(c.into_split()),
                                Err(_) => continue,
                            }
                        }
                        if let Some((tx, _)) = &upstream {
                            crate::utils::stats::add_up(q.len());
                            let _ = tx.send_to(resolver, q).await;
                        }
                    }
                }
            }
            tokio::select! {
                r = u.recv() => match r {
                    Ok(p) => pending.push_back(p.to_vec()),
                    Err(_) => return,
                },
                r = async { match upstream.as_mut() { Some((_, rx)) => rx.recv().await, None => std::future::pending().await } } => match r {
                    Some((_from, data)) => {
                        crate::utils::stats::add_down(data.len());
                        if u.send(&data).await.is_err() { return; }
                    }
                    None => upstream = None,
                },
                _ = tokio::time::sleep(idle) => return,
            }
        }
    };
    result.await;
    if let Some((tx, _)) = upstream {
        tx.close().await;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proxy::inbound::tun::fakeip::{FakeIpConfig, DEFAULT_RANGE};
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    fn pool() -> &'static fakeip::FakePool {
        fakeip::install(FakeIpConfig::parse(DEFAULT_RANGE).unwrap());
        fakeip::pool().unwrap()
    }

    /// What a mock "sunnyquic client" socks5 listener was asked for.
    #[derive(Debug, Clone, PartialEq)]
    enum Asked {
        Connect { atyp: u8, host: String, port: u16 },
        Udp { atyp: u8, host: String, port: u16, payload: Vec<u8> },
    }

    fn read_addr(b: &[u8]) -> Option<(u8, String, u16, usize)> {
        let atyp = *b.first()?;
        let (host, used) = match atyp {
            1 => (std::net::Ipv4Addr::new(b[1], b[2], b[3], b[4]).to_string(), 5),
            3 => {
                let l = b[1] as usize;
                (String::from_utf8_lossy(&b[2..2 + l]).to_string(), 2 + l)
            }
            4 => {
                let mut o = [0u8; 16];
                o.copy_from_slice(&b[1..17]);
                (std::net::Ipv6Addr::from(o).to_string(), 17)
            }
            _ => return None,
        };
        let port = u16::from_be_bytes([b[used], b[used + 1]]);
        Some((atyp, host, port, used + 2))
    }

    /// A socks5 listener standing in for a sunnyquic client: records each request, echoes tcp.
    async fn mock_sunny() -> (SocketAddr, tokio::sync::mpsc::UnboundedReceiver<Asked>) {
        let lis = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = lis.local_addr().unwrap();
        let (tx, rx) = tokio::sync::mpsc::unbounded_channel();
        tokio::spawn(async move {
            while let Ok((mut s, _)) = lis.accept().await {
                let tx = tx.clone();
                tokio::spawn(async move {
                    let mut g = [0u8; 3];
                    s.read_exact(&mut g).await.unwrap();
                    s.write_all(&[5, 0]).await.unwrap();
                    let mut buf = vec![0u8; 512];
                    let n = s.read(&mut buf).await.unwrap();
                    let cmd = buf[1];
                    let (atyp, host, port, _) = read_addr(&buf[3..n]).unwrap();
                    if cmd == 1 {
                        tx.send(Asked::Connect { atyp, host, port }).unwrap();
                        s.write_all(&[5, 0, 0, 1, 0, 0, 0, 0, 0, 0]).await.unwrap();
                        let (mut r, mut w) = s.split();
                        let _ = tokio::io::copy(&mut r, &mut w).await;
                    } else {
                        let relay = tokio::net::UdpSocket::bind("127.0.0.1:0").await.unwrap();
                        let ra = relay.local_addr().unwrap();
                        let mut rep = vec![5, 0, 0, 1, 127, 0, 0, 1];
                        rep.extend_from_slice(&ra.port().to_be_bytes());
                        s.write_all(&rep).await.unwrap();
                        let mut d = vec![0u8; 2048];
                        while let Ok((n, _)) = relay.recv_from(&mut d).await {
                            let (atyp, host, port, used) = read_addr(&d[3..n]).unwrap();
                            tx.send(Asked::Udp { atyp, host, port, payload: d[3 + used..n].to_vec() }).unwrap();
                        }
                    }
                });
            }
        });
        (addr, rx)
    }

    fn router_with(config: serde_json::Value) -> crate::proxy::router::Router {
        crate::proxy::router::build(
            &config,
            crate::proxy::router::LoadOptions {
                base_dir: ".".into(),
                cache_dir: std::env::temp_dir(),
                caps: crate::proxy::router::Caps::ALL,
            },
        )
        .unwrap()
        .router
    }

    /// A TUN tcp flow to a fake address, routed to sunny: the socks5 request carries the name
    /// (ATYP domain), so the sunnyquic server resolves it. The route has a `resolve` action
    /// with no tunnel to resolve through, which shows its result never replaces the name.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn a_fake_ip_tcp_flow_reaches_sunny_as_its_domain() {
        let pool = pool();
        let fake = pool.v4_for("sunny-dest.example").unwrap();
        let (sunny, mut asked) = mock_sunny().await;
        crate::proxy::router::exits::set_sunny(std::sync::Arc::new(crate::proxy::socks::SocksSunny(sunny)));
        let router = router_with(crate::config::file::test_routing(
            r#"
            [route]
            final = "sunny"

            [[route.rules]]
            action = "resolve"

            [[route.rules]]
            ip_cidr = ["198.18.0.0/15", "fc00::/7"]
            action = "reject"

            [[route.rules]]
            ip_is_private = true
            outbound = "direct"
            "#,
        ));

        let lis = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(lis.local_addr().unwrap()).await.unwrap();
        let (server_side, peer) = lis.accept().await.unwrap();
        let dst = SocketAddr::new(IpAddr::V4(fake), 443);
        let flow = tokio::spawn(async move {
            serve_stream(&router, server_side, Inbound::Tun, Target::Ip(dst.ip()), 443, Vec::new(), &Exit::Current, peer, Some(dst), None)
                .await
                .unwrap();
        });
        let got = tokio::time::timeout(Duration::from_secs(5), asked.recv()).await.unwrap().unwrap();
        assert_eq!(got, Asked::Connect { atyp: 3, host: "sunny-dest.example".into(), port: 443 });
        client.write_all(b"ping").await.unwrap();
        let mut b = [0u8; 4];
        tokio::time::timeout(Duration::from_secs(5), client.read_exact(&mut b)).await.unwrap().unwrap();
        assert_eq!(&b, b"ping");
        drop(client);
        let _ = tokio::time::timeout(Duration::from_secs(5), flow).await;

        // a fake address nothing is mapped to: refused, nothing reaches sunny
        let lis = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let mut client = tokio::net::TcpStream::connect(lis.local_addr().unwrap()).await.unwrap();
        let (server_side, peer) = lis.accept().await.unwrap();
        let stale: IpAddr = "198.19.200.200".parse().unwrap();
        let router = router_with(crate::config::file::test_routing("[route]\nfinal = \"sunny\"\n"));
        serve_stream(&router, server_side, Inbound::Tun, Target::Ip(stale), 443, Vec::new(), &Exit::Current, peer, None, None)
            .await
            .unwrap();
        let mut b = [0u8; 1];
        let n = tokio::time::timeout(Duration::from_secs(2), client.read(&mut b)).await.unwrap().unwrap_or(0);
        assert_eq!(n, 0);
        assert!(asked.try_recv().is_err(), "a stale fake address went to sunny");
    }

    /// The whole TUN path for udp: a dns query on the device gets a fake address, a datagram to
    /// that address is routed by name to sunny, whose socks5 udp header carries the domain.
    /// The router is process-global, so this runs alone:
    /// `cargo test fake_ip_udp_end_to_end -- --ignored`.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    #[ignore]
    async fn fake_ip_udp_end_to_end() {
        use etherparse::{PacketBuilder, SlicedPacket, TransportSlice};
        let pool = pool();
        let (sunny, mut asked) = mock_sunny().await;
        crate::proxy::router::exits::set_sunny(std::sync::Arc::new(crate::proxy::socks::SocksSunny(sunny)));
        let cfgfile = crate::test_util::scratch_file("fakeip-e2e.yaml", "route:\n  final: sunny\n  rules:\n    - ip_is_private: true\n      outbound: direct\n");
        crate::config::settings::decide("AETHER_ROUTE_CONFIG", cfgfile.to_string_lossy());
        crate::config::settings::decide("AETHER_PROTOCOL", "sunny");
        crate::proxy::router::init().unwrap();

        let cfg: &'static TunConfig = Box::leak(Box::new(crate::proxy::inbound::tun::parse_config_with(&|_: &str| None).unwrap()));
        let (to_stack, rx) = async_channel::bounded::<bytes::Bytes>(64);
        let (tx, from_stack) = async_channel::bounded::<bytes::Bytes>(64);
        let stack = ipstack_geph::IpStack::new(
            ipstack_geph::IpStackConfig { mtu: 1500, tcp_timeout: Duration::from_secs(30), udp_timeout: Duration::from_secs(30) },
            rx,
            tx,
        );
        tokio::spawn(serve(stack, cfg));
        let udp = |dst: [u8; 4], dport: u16, payload: &[u8]| {
            let b = PacketBuilder::ipv4([172, 19, 0, 1], dst, 64).udp(40000, dport);
            let mut out = Vec::new();
            b.write(&mut out, payload).unwrap();
            bytes::Bytes::from(out)
        };
        // dns: A query for e2e.example to the TUN's dns address
        let mut q = vec![0xab, 0xcd, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0];
        for l in ["e2e", "example"] {
            q.push(l.len() as u8);
            q.extend_from_slice(l.as_bytes());
        }
        q.extend_from_slice(&[0, 0, 1, 0, 1]);
        to_stack.send(udp([172, 19, 0, 2], 53, &q)).await.unwrap();
        let out = tokio::time::timeout(Duration::from_secs(5), from_stack.recv()).await.unwrap().unwrap();
        let p = SlicedPacket::from_ip(&out).unwrap();
        let Some(TransportSlice::Udp(u)) = p.transport else { panic!("no udp answer") };
        let r = u.payload();
        assert_eq!(&r[0..2], &[0xab, 0xcd]);
        let ip = std::net::Ipv4Addr::new(r[r.len() - 4], r[r.len() - 3], r[r.len() - 2], r[r.len() - 1]);
        assert!(pool.contains(IpAddr::V4(ip)), "{ip} is not a fake address");
        assert_eq!(pool.lookup(IpAddr::V4(ip)).as_deref(), Some("e2e.example"));
        // a datagram to the fake address goes to sunny by name
        to_stack.send(udp(ip.octets(), 3478, b"hello")).await.unwrap();
        let got = tokio::time::timeout(Duration::from_secs(5), asked.recv()).await.unwrap().unwrap();
        assert_eq!(got, Asked::Udp { atyp: 3, host: "e2e.example".into(), port: 3478, payload: b"hello".to_vec() });
    }
}
