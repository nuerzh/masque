// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
//
// Adapted for Aether from geph5 (https://github.com/geph-official/geph5),
// binaries/geph5-app/src/vpn/windows.rs, Copyright (c) the Geph developers,
// licensed under MPL-2.0 (see LICENSE-geph5-MPL-2.0). Taken: the WinTUN
// adapter handling, the in-process IP Helper calls (unicast address, on-link
// routes, the `/1` split default routes, SetInterfaceDnsSettings with the
// correct field order), the default-route interface discovery and the
// blocking WinTUN packet pump threads. Changed: the pump feeds Aether's
// in-process userspace stack through channels instead of a child's stdio;
// the physical interface is handed to Aether's egress so every own socket is
// pinned with IP_UNICAST_IF; addresses, name, include/exclude routes and DNS
// are configurable; exclude routes are added via the physical gateway and
// remembered in a state file for --tun-cleanup; the WFP leak firewall
// (windows_firewall.rs) is only installed with --tun-strict-route.

//! Windows side of the TUN inbound: a WinTUN adapter (wintun.dll next to aether.exe), its
//! addresses, split default routes, DNS, and the optional WFP leak firewall.

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread::JoinHandle;

use bytes::Bytes;
use ipnet::IpNet;
use windows_sys::Win32::Foundation::{ERROR_NOT_FOUND, ERROR_OBJECT_ALREADY_EXISTS, NO_ERROR};
use windows_sys::Win32::NetworkManagement::IpHelper::{
    CreateIpForwardEntry2, CreateUnicastIpAddressEntry, DeleteIpForwardEntry2, FreeMibTable, GetIpForwardTable2,
    InitializeIpForwardEntry, InitializeUnicastIpAddressEntry, SetInterfaceDnsSettings, DNS_INTERFACE_SETTINGS,
    DNS_INTERFACE_SETTINGS_VERSION1, DNS_SETTING_IPV6, DNS_SETTING_NAMESERVER, MIB_IPFORWARD_ROW2,
    MIB_IPFORWARD_TABLE2, MIB_UNICASTIPADDRESS_ROW,
};
use windows_sys::Win32::Networking::WinSock::{
    ADDRESS_FAMILY, AF_INET, AF_INET6, IN6_ADDR, IN6_ADDR_0, IN_ADDR, IN_ADDR_0, SOCKADDR_IN, SOCKADDR_IN6,
    SOCKADDR_INET,
};
use wintun::{Adapter, Session, Wintun};

use super::windows_firewall::Firewall;
use super::TunConfig;

/// Fixed adapter GUID so Aether recognises its own adapter across runs ("Aether" + 1).
const TUN_GUID: u128 = 0x4165_7468_6572_0000_0000_0000_0000_0001;
/// Ring-buffer capacity of the WinTUN session (4 MiB).
const RING_CAPACITY: u32 = 0x40_0000;
/// Metric of the routes Aether adds.
const ROUTE_METRIC: u32 = 0;

const V4_SPLIT: [(Ipv4Addr, u8); 2] = [(Ipv4Addr::new(0, 0, 0, 0), 1), (Ipv4Addr::new(128, 0, 0, 0), 1)];
const V6_SPLIT: [(Ipv6Addr, u8); 2] = [
    (Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0), 1),
    (Ipv6Addr::new(0x8000, 0, 0, 0, 0, 0, 0, 0), 1),
];

/// The physical default route of one family: interface index, LUID and gateway.
#[derive(Clone, Copy, Debug)]
struct PhysRoute {
    index: u32,
    luid: u64,
    gateway: IpAddr,
}

pub(super) struct Device {
    // `wintun` must outlive `adapter` (the adapter holds the loaded DLL).
    #[allow(dead_code)]
    wintun: Wintun,
    adapter: Arc<Adapter>,
    session: Arc<Session>,
    stop: Arc<AtomicBool>,
    threads: Vec<JoinHandle<()>>,
    routes: Vec<(u64, IpAddr, u8, IpAddr)>,
    firewall: Option<Firewall>,
    dns_set: bool,
}

impl Drop for Device {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        let _ = self.session.shutdown();
        if let Some(mut fw) = self.firewall.take() {
            fw.remove();
        }
        if self.dns_set {
            let _ = set_tun_dns(self.adapter.get_guid(), &[]);
        }
        for (luid, dest, prefix, hop) in self.routes.drain(..) {
            let _ = delete_route(luid, dest, prefix, hop);
        }
        let _ = std::fs::remove_file(state_file());
        // The pump threads only hold Arcs; they end on the shutdown event / closed channel.
        for t in self.threads.drain(..) {
            let _ = t.join();
        }
    }
}

fn is_elevated() -> bool {
    use windows_sys::Win32::Foundation::{CloseHandle, HANDLE};
    use windows_sys::Win32::Security::{GetTokenInformation, TokenElevation, TOKEN_ELEVATION, TOKEN_QUERY};
    use windows_sys::Win32::System::Threading::{GetCurrentProcess, OpenProcessToken};
    unsafe {
        let mut token: HANDLE = std::ptr::null_mut();
        if OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &mut token) == 0 {
            return false;
        }
        let mut elevation: TOKEN_ELEVATION = std::mem::zeroed();
        let mut len = 0u32;
        let ok = GetTokenInformation(
            token,
            TokenElevation,
            &mut elevation as *mut TOKEN_ELEVATION as *mut _,
            std::mem::size_of::<TOKEN_ELEVATION>() as u32,
            &mut len,
        );
        CloseHandle(token);
        ok != 0 && elevation.TokenIsElevated != 0
    }
}

/// Whether the host has an IPv6 default route of its own.
pub(super) fn host_has_ipv6() -> bool {
    default_route(AF_INET6).is_some()
}

fn dll_path() -> std::path::PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.join("wintun.dll")))
        .unwrap_or_else(|| "wintun.dll".into())
}

/// Administrator, wintun.dll, the physical interface; pins Aether's own sockets to it before
/// the outer tunnel connects.
pub(super) fn preflight(_cfg: &TunConfig) -> Result<(), String> {
    if !is_elevated() {
        return Err("TUN mode needs Administrator rights: start aether.exe (or run-aether-tun.bat) as Administrator".into());
    }
    let dll = dll_path();
    if !dll.exists() {
        return Err(format!("TUN mode needs wintun.dll next to aether.exe ({} is missing)", dll.display()));
    }
    let v4 = default_route(AF_INET);
    let v6 = default_route(AF_INET6);
    let Some(p4) = v4.or(v6) else {
        return Err("TUN mode: no default route found, so there is no physical interface to keep Aether's own traffic on".into());
    };
    let index6 = v6.map(|r| r.index).unwrap_or(p4.index);
    crate::utils::egress::set_bind_interface(p4.index, index6);
    let _ = PHYS_IF.set((v4.map(|r| r.index).unwrap_or(0), v6.map(|r| r.index).unwrap_or(0)));
    log::info!("[tun] Aether's own sockets are pinned to interface {} (IPv4) / {} (IPv6)", p4.index, index6);
    Ok(())
}

/// The IPv4 and IPv6 default-route interface indexes preflight found (0: none).
static PHYS_IF: std::sync::OnceLock<(u32, u32)> = std::sync::OnceLock::new();

/// The dns servers of the physical default-route adapter(s), read with GetAdaptersAddresses
/// before the TUN takes over (never those of Aether's own WinTUN adapter).
pub(super) fn system_dns(cfg: &TunConfig) -> (Vec<IpAddr>, String) {
    use windows_sys::Win32::NetworkManagement::IpHelper::{
        GetAdaptersAddresses, GAA_FLAG_SKIP_ANYCAST, GAA_FLAG_SKIP_MULTICAST, GAA_FLAG_SKIP_UNICAST,
        IP_ADAPTER_ADDRESSES_LH,
    };
    use windows_sys::Win32::Networking::WinSock::{AF_UNSPEC, SOCKADDR};
    let (if4, if6) = PHYS_IF.get().copied().unwrap_or((0, 0));
    if if4 == 0 && if6 == 0 {
        return (Vec::new(), "no physical default-route adapter".into());
    }
    let flags = GAA_FLAG_SKIP_UNICAST | GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST;
    let mut size: u32 = 32 * 1024;
    let mut buf: Vec<u64> = Vec::new();
    let mut code = 0u32;
    for _ in 0..4 {
        buf = vec![0u64; (size as usize).div_ceil(8)];
        code = unsafe {
            GetAdaptersAddresses(AF_UNSPEC as u32, flags, std::ptr::null(), buf.as_mut_ptr() as *mut IP_ADAPTER_ADDRESSES_LH, &mut size)
        };
        if code != 111 {
            // 111 = ERROR_BUFFER_OVERFLOW: `size` now holds what is needed
            break;
        }
    }
    if code != NO_ERROR {
        return (Vec::new(), format!("GetAdaptersAddresses failed: {code}"));
    }
    let tun_guid = format!("{{{}}}", guid_string(TUN_GUID)).to_ascii_uppercase();
    let mut out: Vec<IpAddr> = Vec::new();
    let mut names: Vec<String> = Vec::new();
    unsafe {
        let mut a = buf.as_ptr() as *const IP_ADAPTER_ADDRESSES_LH;
        while !a.is_null() {
            let ad = &*a;
            a = ad.Next;
            let index = ad.Anonymous1.Anonymous.IfIndex;
            let ours = (index != 0 && index == if4) || (ad.Ipv6IfIndex != 0 && ad.Ipv6IfIndex == if6);
            if !ours {
                continue;
            }
            let friendly = pwstr(ad.FriendlyName);
            let adapter_name = if ad.AdapterName.is_null() {
                String::new()
            } else {
                std::ffi::CStr::from_ptr(ad.AdapterName as *const std::ffi::c_char).to_string_lossy().into_owned()
            };
            // never Aether's own adapter (a stale one from an earlier run included)
            if friendly.eq_ignore_ascii_case(&cfg.name) || adapter_name.to_ascii_uppercase() == tun_guid {
                continue;
            }
            let mut d = ad.FirstDnsServerAddress;
            while !d.is_null() {
                let sa = (*d).Address.lpSockaddr as *const SOCKADDR;
                d = (*d).Next;
                if sa.is_null() {
                    continue;
                }
                let ip = match (*sa).sa_family {
                    AF_INET => {
                        let v4 = &*(sa as *const SOCKADDR_IN);
                        Some(IpAddr::V4(Ipv4Addr::from(v4.sin_addr.S_un.S_addr.to_ne_bytes())))
                    }
                    AF_INET6 => {
                        let v6 = &*(sa as *const SOCKADDR_IN6);
                        Some(IpAddr::V6(Ipv6Addr::from(v6.sin6_addr.u.Byte)))
                    }
                    _ => None,
                };
                if let Some(ip) = ip {
                    if !out.contains(&ip) {
                        out.push(ip);
                    }
                }
            }
            names.push(if friendly.is_empty() { format!("interface {index}") } else { format!("adapter \"{friendly}\"") });
        }
    }
    let from = if names.is_empty() { format!("no adapter for interface {if4}/{if6}") } else { names.join(", ") };
    (out, from)
}

fn pwstr(p: windows_sys::core::PWSTR) -> String {
    if p.is_null() {
        return String::new();
    }
    unsafe {
        let mut n = 0usize;
        while *p.add(n) != 0 {
            n += 1;
        }
        String::from_utf16_lossy(std::slice::from_raw_parts(p, n))
    }
}

/// `TUN_GUID` as the registry writes it (without braces).
fn guid_string(g: u128) -> String {
    let b = g.to_be_bytes();
    format!(
        "{:02X}{:02X}{:02X}{:02X}-{:02X}{:02X}-{:02X}{:02X}-{:02X}{:02X}-{:02X}{:02X}{:02X}{:02X}{:02X}{:02X}",
        b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]
    )
}

/// Whether an interface with this alias (the WinTUN adapter's name) exists already, asked
/// without WinTUN, whose open of a missing adapter logs an error ("Failed to find matching
/// adapter name", 0x490) for what is the normal first start.
fn alias_exists(name: &str) -> bool {
    use windows_sys::Win32::NetworkManagement::IpHelper::ConvertInterfaceAliasToLuid;
    use windows_sys::Win32::NetworkManagement::Ndis::NET_LUID_LH;
    let wide: Vec<u16> = name.encode_utf16().chain(std::iter::once(0)).collect();
    let mut luid: NET_LUID_LH = unsafe { std::mem::zeroed() };
    unsafe { ConvertInterfaceAliasToLuid(wide.as_ptr(), &mut luid) == NO_ERROR }
}

/// WinTUN's log, through Aether's: its "no adapter of that name" message (0x490,
/// ERROR_NOT_FOUND) is expected when an adapter is created and goes to debug; everything
/// else keeps WinTUN's level.
// the wintun crate's callback type is `extern "stdcall"` (C on x86_64)
#[allow(unsupported_calling_conventions)]
unsafe extern "stdcall" fn wintun_logger(level: i32, _timestamp: u64, message: *const u16) {
    let text = pwstr(message as windows_sys::core::PWSTR);
    if wintun_message_is_benign(&text) {
        log::debug!("[tun] WinTun: {text}");
        return;
    }
    match level {
        0 => log::info!("[tun] WinTun: {text}"),
        1 => log::warn!("[tun] WinTun: {text}"),
        _ => log::error!("[tun] WinTun: {text}"),
    }
}

fn wintun_message_is_benign(text: &str) -> bool {
    text.contains("Failed to find matching adapter") || text.contains("0x00000490")
}

impl Device {
    pub(super) fn open(
        cfg: &TunConfig,
        to_stack: async_channel::Sender<Bytes>,
        from_stack: async_channel::Receiver<Bytes>,
    ) -> Result<Device, String> {
        let wintun = unsafe { wintun::load_from_path(dll_path()) }.map_err(|e| format!("loading wintun.dll: {e}"))?;
        // the wintun crate installs its own logger on its first call; Aether's replaces it
        // right away (and again after that first call, which would overwrite it)
        wintun::set_logger(&wintun, Some(wintun_logger));
        let existing = if alias_exists(&cfg.name) { Adapter::open(&wintun, &cfg.name).ok() } else { None };
        let adapter = match existing {
            Some(a) => a,
            None => {
                let created = Adapter::create(&wintun, &cfg.name, "Aether", Some(TUN_GUID));
                wintun::set_logger(&wintun, Some(wintun_logger));
                created.map_err(|e| format!("creating the WinTUN adapter {}: {e}", cfg.name))?
            }
        };
        wintun::set_logger(&wintun, Some(wintun_logger));
        let luid = unsafe { adapter.get_luid().Value };
        let session = Arc::new(
            adapter
                .start_session(RING_CAPACITY)
                .map_err(|e| format!("starting the WinTUN session: {e}"))?,
        );
        let mut device = Device {
            wintun,
            adapter: adapter.clone(),
            session: session.clone(),
            stop: Arc::new(AtomicBool::new(false)),
            threads: Vec::new(),
            routes: Vec::new(),
            firewall: None,
            dns_set: false,
        };
        if let Some((a, p)) = cfg.v4 {
            set_unicast_address(luid, IpAddr::V4(a), p)?;
        }
        if let Some((a, p)) = cfg.v6 {
            if let Err(e) = set_unicast_address(luid, IpAddr::V6(a), p) {
                log::warn!("[tun] {e}");
            }
        }
        let _ = adapter.set_mtu(cfg.mtu as usize);
        if let Some(dns) = cfg.dns {
            set_tun_dns(adapter.get_guid(), &[dns])?;
            device.dns_set = true;
        }

        // Packet pumps first, so nothing routed into the adapter is lost.
        let up = {
            let session = session.clone();
            let stop = device.stop.clone();
            std::thread::Builder::new()
                .name("aether-tun-up".into())
                .spawn(move || {
                    while !stop.load(Ordering::SeqCst) {
                        let packet = match session.receive_blocking() {
                            Ok(p) => p,
                            Err(_) => break,
                        };
                        if to_stack.send_blocking(Bytes::copy_from_slice(packet.bytes())).is_err() {
                            break;
                        }
                    }
                })
                .map_err(|e| e.to_string())?
        };
        let down = {
            let session = session.clone();
            let stop = device.stop.clone();
            std::thread::Builder::new()
                .name("aether-tun-down".into())
                .spawn(move || {
                    while !stop.load(Ordering::SeqCst) {
                        let Ok(buf) = from_stack.recv_blocking() else { break };
                        if buf.is_empty() || buf.len() > u16::MAX as usize {
                            continue;
                        }
                        match session.allocate_send_packet(buf.len() as u16) {
                            Ok(mut packet) => {
                                packet.bytes_mut().copy_from_slice(&buf);
                                session.send_packet(packet);
                            }
                            Err(_) => continue,
                        }
                    }
                })
                .map_err(|e| e.to_string())?
        };
        device.threads.push(up);
        device.threads.push(down);

        if !cfg.auto_route {
            return Ok(device);
        }
        if cfg.strict_route {
            let mut fw = Firewall::new();
            fw.install(luid, cfg.allow_lan).map_err(|e| format!("installing the WFP leak firewall: {e}"))?;
            log::info!("[tun] WFP leak firewall installed (removed when Aether exits)");
            device.firewall = Some(fw);
        }
        // Capture routes into the adapter.
        let mut capture: Vec<(IpAddr, u8)> = Vec::new();
        let (inc4, inc6): (Vec<&IpNet>, Vec<&IpNet>) = cfg.include.iter().partition(|n| matches!(n, IpNet::V4(_)));
        if cfg.v4.is_some() {
            if inc4.is_empty() {
                capture.extend(V4_SPLIT.iter().map(|(a, p)| (IpAddr::V4(*a), *p)));
            } else {
                capture.extend(inc4.iter().map(|n| (n.addr(), n.prefix_len())));
            }
        }
        if cfg.v6.is_some() {
            if inc6.is_empty() {
                capture.extend(V6_SPLIT.iter().map(|(a, p)| (IpAddr::V6(*a), *p)));
            } else {
                capture.extend(inc6.iter().map(|n| (n.addr(), n.prefix_len())));
            }
        }
        for (dest, prefix) in capture {
            let hop = unspecified_like(dest);
            match add_route(luid, dest, prefix, hop) {
                Ok(()) => device.routes.push((luid, dest, prefix, hop)),
                Err(e) if dest.is_ipv6() => log::warn!("[tun] {e}"),
                Err(e) => return Err(e),
            }
        }
        // Exclusions leave by the physical gateway.
        for net in &cfg.exclude {
            let family = if net.addr().is_ipv4() { AF_INET } else { AF_INET6 };
            let Some(phys) = default_route(family) else {
                log::warn!("[tun] no physical {} default route to exclude {net} by", if net.addr().is_ipv4() { "IPv4" } else { "IPv6" });
                continue;
            };
            match add_route(phys.luid, net.addr(), net.prefix_len(), phys.gateway) {
                Ok(()) => device.routes.push((phys.luid, net.addr(), net.prefix_len(), phys.gateway)),
                Err(e) => log::warn!("[tun] exclude {net}: {e}"),
            }
        }
        save_state(&device.routes);
        Ok(device)
    }
}

fn state_file() -> std::path::PathBuf {
    std::env::temp_dir().join("aether-tun-routes.txt")
}

fn save_state(routes: &[(u64, IpAddr, u8, IpAddr)]) {
    let text: String = routes.iter().map(|(l, d, p, h)| format!("{l}\t{d}\t{p}\t{h}\n")).collect();
    let _ = std::fs::write(state_file(), text);
}

/// Remove the routes, DNS and firewall a killed run left behind (the adapter itself goes away
/// with the process that created it, or is reused by the next run).
pub(super) fn cleanup_stale(cfg: &TunConfig) {
    if let Ok(text) = std::fs::read_to_string(state_file()) {
        for line in text.lines() {
            let f: Vec<&str> = line.split('\t').collect();
            if f.len() != 4 {
                continue;
            }
            if let (Ok(l), Ok(d), Ok(p), Ok(h)) = (f[0].parse::<u64>(), f[1].parse::<IpAddr>(), f[2].parse::<u8>(), f[3].parse::<IpAddr>()) {
                let _ = delete_route(l, d, p, h);
            }
        }
        let _ = std::fs::remove_file(state_file());
    }
    let _ = super::windows_firewall::purge_stale();
    let _ = cfg;
}

// ---- IP Helper (iphlpapi), keyed by interface LUID ----

/// Set (or clear, with an empty list) the adapter's DNS servers with a correctly formed
/// `SetInterfaceDnsSettings` call (wintun's own binding swaps NameServer and Domain).
fn set_tun_dns(guid: u128, servers: &[IpAddr]) -> Result<(), String> {
    let guid = windows_sys::core::GUID::from_u128(guid);
    let v4: Vec<String> = servers.iter().filter(|ip| ip.is_ipv4()).map(|ip| ip.to_string()).collect();
    let v6: Vec<String> = servers.iter().filter(|ip| ip.is_ipv6()).map(|ip| ip.to_string()).collect();
    for (list, v6_flag) in [(v4, 0u64), (v6, DNS_SETTING_IPV6 as u64)] {
        let joined: Vec<u16> = list.join(",").encode_utf16().chain(std::iter::once(0)).collect();
        let settings = DNS_INTERFACE_SETTINGS {
            Version: DNS_INTERFACE_SETTINGS_VERSION1,
            Flags: DNS_SETTING_NAMESERVER as u64 | v6_flag,
            Domain: std::ptr::null_mut(),
            NameServer: joined.as_ptr() as *mut u16,
            SearchList: std::ptr::null_mut(),
            RegistrationEnabled: 0,
            RegisterAdapterName: 0,
            EnableLLMNR: 0,
            QueryAdapterName: 0,
            ProfileNameServer: std::ptr::null_mut(),
        };
        let code = unsafe { SetInterfaceDnsSettings(guid, &settings) };
        if code != NO_ERROR {
            return Err(format!("SetInterfaceDnsSettings(ipv6={}) failed: 0x{code:08X}", v6_flag != 0));
        }
    }
    Ok(())
}

fn write_sockaddr_inet(dst: &mut SOCKADDR_INET, ip: IpAddr) {
    match ip {
        IpAddr::V4(v4) => {
            let mut sa: SOCKADDR_IN = unsafe { std::mem::zeroed() };
            sa.sin_family = AF_INET;
            sa.sin_addr = IN_ADDR { S_un: IN_ADDR_0 { S_addr: u32::from_ne_bytes(v4.octets()) } };
            dst.Ipv4 = sa;
        }
        IpAddr::V6(v6) => {
            let mut sa: SOCKADDR_IN6 = unsafe { std::mem::zeroed() };
            sa.sin6_family = AF_INET6;
            sa.sin6_addr = IN6_ADDR { u: IN6_ADDR_0 { Byte: v6.octets() } };
            dst.Ipv6 = sa;
        }
    }
}

fn read_sockaddr_inet(src: &SOCKADDR_INET) -> Option<IpAddr> {
    unsafe {
        match src.si_family {
            AF_INET => Some(IpAddr::V4(Ipv4Addr::from(src.Ipv4.sin_addr.S_un.S_addr.to_ne_bytes()))),
            AF_INET6 => Some(IpAddr::V6(Ipv6Addr::from(src.Ipv6.sin6_addr.u.Byte))),
            _ => None,
        }
    }
}

fn unspecified_like(ip: IpAddr) -> IpAddr {
    match ip {
        IpAddr::V4(_) => IpAddr::V4(Ipv4Addr::UNSPECIFIED),
        IpAddr::V6(_) => IpAddr::V6(Ipv6Addr::UNSPECIFIED),
    }
}

fn set_unicast_address(luid: u64, ip: IpAddr, prefix: u8) -> Result<(), String> {
    let mut row: MIB_UNICASTIPADDRESS_ROW = unsafe { std::mem::zeroed() };
    unsafe { InitializeUnicastIpAddressEntry(&mut row) };
    row.InterfaceLuid.Value = luid;
    write_sockaddr_inet(&mut row.Address, ip);
    row.OnLinkPrefixLength = prefix;
    let code = unsafe { CreateUnicastIpAddressEntry(&row) };
    if code == NO_ERROR || code == ERROR_OBJECT_ALREADY_EXISTS {
        Ok(())
    } else {
        Err(format!("CreateUnicastIpAddressEntry({ip}/{prefix}) failed: 0x{code:08X}"))
    }
}

fn add_route(luid: u64, dest: IpAddr, prefix: u8, next_hop: IpAddr) -> Result<(), String> {
    let mut row: MIB_IPFORWARD_ROW2 = unsafe { std::mem::zeroed() };
    unsafe { InitializeIpForwardEntry(&mut row) };
    row.InterfaceLuid.Value = luid;
    write_sockaddr_inet(&mut row.DestinationPrefix.Prefix, dest);
    row.DestinationPrefix.PrefixLength = prefix;
    write_sockaddr_inet(&mut row.NextHop, next_hop);
    row.Metric = ROUTE_METRIC;
    let code = unsafe { CreateIpForwardEntry2(&row) };
    if code == NO_ERROR || code == ERROR_OBJECT_ALREADY_EXISTS {
        Ok(())
    } else {
        Err(format!("CreateIpForwardEntry2({dest}/{prefix}) failed: 0x{code:08X}"))
    }
}

fn delete_route(luid: u64, dest: IpAddr, prefix: u8, next_hop: IpAddr) -> Result<(), String> {
    let mut row: MIB_IPFORWARD_ROW2 = unsafe { std::mem::zeroed() };
    row.InterfaceLuid.Value = luid;
    write_sockaddr_inet(&mut row.DestinationPrefix.Prefix, dest);
    row.DestinationPrefix.PrefixLength = prefix;
    write_sockaddr_inet(&mut row.NextHop, next_hop);
    let code = unsafe { DeleteIpForwardEntry2(&row) };
    if code == NO_ERROR || code == ERROR_NOT_FOUND {
        Ok(())
    } else {
        Err(format!("DeleteIpForwardEntry2({dest}/{prefix}) failed: 0x{code:08X}"))
    }
}

/// The lowest-metric non-loopback `/0` route of `family` (Aether's own routes are `/1`, so
/// they are never mistaken for it).
fn default_route(family: ADDRESS_FAMILY) -> Option<PhysRoute> {
    let mut table: *mut MIB_IPFORWARD_TABLE2 = std::ptr::null_mut();
    let code = unsafe { GetIpForwardTable2(family, &mut table) };
    if code != NO_ERROR || table.is_null() {
        return None;
    }
    let mut best: Option<(u32, PhysRoute)> = None;
    unsafe {
        let count = (*table).NumEntries as usize;
        let rows = std::ptr::addr_of!((*table).Table) as *const MIB_IPFORWARD_ROW2;
        for i in 0..count {
            let row = &*rows.add(i);
            if row.DestinationPrefix.PrefixLength != 0 || row.DestinationPrefix.Prefix.si_family != family {
                continue;
            }
            if row.Loopback as u8 != 0 {
                continue;
            }
            let Some(gateway) = read_sockaddr_inet(&row.NextHop) else { continue };
            if best.map(|(m, _)| row.Metric < m).unwrap_or(true) {
                best = Some((row.Metric, PhysRoute { index: row.InterfaceIndex, luid: row.InterfaceLuid.Value, gateway }));
            }
        }
        FreeMibTable(table as *const core::ffi::c_void);
    }
    best.map(|(_, r)| r)
}
