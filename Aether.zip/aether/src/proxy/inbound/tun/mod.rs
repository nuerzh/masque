//! The system-wide TUN inbound (`--tun`): a TUN device (Linux) or a WinTUN adapter (Windows)
//! takes the machine's traffic, a userspace TCP/IP stack (ipstack-geph, the stack geph5 uses
//! for its VPN mode) turns its packets back into tcp and udp flows, and every flow goes through
//! the sing-box compatible router as inbound `tun`, like a socks5 connection would.
//!
//! Loop avoidance: every socket Aether opens itself for the outer tunnel, `direct` outbounds and
//! rule-set downloads is made through `egress`, which marks it on Linux (SO_MARK, with policy
//! rules that send marked packets to the main table) and pins it to the physical interface on
//! Windows (IP_UNICAST_IF / IPV6_UNICAST_IF), so it never enters the TUN device. Traffic of
//! the userspace WARP stack never touches a socket of its own.
//!
//! The OS side (device, addresses, routes, policy rules, DNS, the optional leak firewall) is in
//! `linux.rs` and `windows.rs`, adapted from geph5 (MPL-2.0); this file and the flow handling
//! in `flows.rs` are Aether's own.

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::OnceLock;

use ipnet::IpNet;
use parking_lot::Mutex;

use crate::error::{AetherError, Result};

pub mod fakeip;
pub(crate) mod flows;

#[cfg(target_os = "linux")]
mod linux;
#[cfg(target_os = "linux")]
use linux as os;
#[cfg(windows)]
mod windows;
#[cfg(windows)]
use self::windows as os;
#[cfg(windows)]
mod windows_firewall;
#[cfg(not(any(target_os = "linux", windows)))]
mod unsupported;
#[cfg(not(any(target_os = "linux", windows)))]
use unsupported as os;

/// The firewall mark Aether's own sockets carry in TUN mode on Linux when --mark is not given.
#[cfg(target_os = "linux")]
pub const DEFAULT_MARK: u32 = 0x6165;
/// The policy-routing table that holds the TUN routes (Linux).
pub const DEFAULT_TABLE: u32 = 1819;
/// The first of the four `ip rule` priorities the TUN mode owns (Linux).
pub const DEFAULT_PRIORITY: u32 = 9180;

#[derive(Debug, Clone, PartialEq)]
pub struct TunConfig {
    pub name: String,
    pub v4: Option<(Ipv4Addr, u8)>,
    pub v6: Option<(Ipv6Addr, u8)>,
    pub mtu: u16,
    /// The address the system is told to use as its DNS server; queries to it are answered by
    /// Aether's resolver through the tunnel whatever the rules say.
    pub dns: Option<IpAddr>,
    pub auto_route: bool,
    pub strict_route: bool,
    /// Route only these into the TUN (default: everything).
    pub include: Vec<IpNet>,
    /// Keep these out of the TUN.
    pub exclude: Vec<IpNet>,
    /// Hijack every port-53 flow the TUN takes, not only those to `dns`.
    pub hijack_all_dns: bool,
    /// Strict route on Windows lets LAN destinations through the leak firewall.
    pub allow_lan: bool,
    pub table: u32,
    pub priority: u32,
    /// Fake-ip for hijacked A / AAAA queries (None: answered through the tunnel, real addresses).
    pub fakeip: Option<fakeip::FakeIpConfig>,
    /// How `direct` connections and Aether's own lookups resolve names while the TUN is up.
    pub direct_dns: DirectDns,
}

/// How names are resolved for `direct` while the TUN runs: the system resolver points at the
/// TUN (and would hand out fake addresses), so Aether never asks it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DirectDns {
    /// The default: the dns servers the physical network gave the system (read before the TUN
    /// takes over: the egress adapter's servers on Windows, resolv.conf on Linux), asked over
    /// the physical interface. A `direct` site then gets the answer the local network would
    /// give (an ISP / mainland CDN address, not one picked for the tunnel's exit). `start`
    /// turns it into `Servers`, or into `Tunnel` when no usable server is found.
    System,
    /// Aether's resolver inside the tunnel (--dns, 1.1.1.1 by default): what the system got
    /// before fake-ip. When the tunnel is down, the same servers over the physical interface.
    Tunnel,
    /// These servers, asked over the physical interface (never through the TUN).
    Servers(Vec<std::net::SocketAddr>),
}

fn env(key: &str) -> Option<String> {
    crate::config::settings::var(key).ok().map(|v| v.trim().to_string()).filter(|v| !v.is_empty())
}

fn env_bool(key: &str, default: bool) -> bool {
    bool_of(env(key), default)
}

fn bool_of(v: Option<String>, default: bool) -> bool {
    match v.as_deref().map(str::to_ascii_lowercase).as_deref() {
        Some("1" | "true" | "yes" | "on") => true,
        Some("0" | "false" | "no" | "off") => false,
        _ => default,
    }
}

/// Whether --tun / AETHER_TUN asks for the TUN inbound.
pub fn enabled() -> bool {
    env_bool("AETHER_TUN", false)
}

fn default_name() -> &'static str {
    if cfg!(windows) {
        "Aether"
    } else {
        "aether-tun"
    }
}

fn cidrs(key: &str, text: &str) -> std::result::Result<Vec<IpNet>, String> {
    let mut out = Vec::new();
    for item in text.split([',', ' ', ';']).map(str::trim).filter(|s| !s.is_empty()) {
        let net = match item.parse::<IpNet>() {
            Ok(n) => n.trunc(),
            Err(_) => match item.parse::<IpAddr>() {
                Ok(ip) => IpNet::from(ip),
                Err(_) => return Err(format!("{key}: '{item}' is not an address or a CIDR")),
            },
        };
        out.push(net);
    }
    Ok(out)
}

/// Read the TUN options from the environment (the flags set them).
pub fn parse_config() -> std::result::Result<TunConfig, String> {
    parse_config_with(&env)
}

/// `parse_config` over any source of settings (the tests give a map).
pub fn parse_config_with(env: &dyn Fn(&str) -> Option<String>) -> std::result::Result<TunConfig, String> {
    let env_bool = |k: &str, d: bool| bool_of(env(k), d);
    let name = env("AETHER_TUN_NAME").unwrap_or_else(|| default_name().to_string());
    if name.len() > 15 || name.chars().any(|c| c.is_whitespace() || c == '/') {
        return Err(format!("tun.name '{name}': give at most 15 characters, no spaces or slashes"));
    }
    let mut v4 = None;
    let mut v6 = None;
    let addresses = env("AETHER_TUN_ADDRESS").unwrap_or_else(|| "172.19.0.1/30,fdfe:dcba:9876::1/126".to_string());
    for item in addresses.split([',', ' ', ';']).map(str::trim).filter(|s| !s.is_empty()) {
        if item.eq_ignore_ascii_case("none") {
            continue;
        }
        let net: IpNet = item
            .parse()
            .map_err(|_| format!("tun.address '{item}': give an address with its prefix, such as 172.19.0.1/30"))?;
        match net {
            IpNet::V4(n) if n.prefix_len() <= 30 => v4 = Some((n.addr(), n.prefix_len())),
            IpNet::V6(n) if n.prefix_len() <= 126 => v6 = Some((n.addr(), n.prefix_len())),
            _ => return Err(format!("tun.address '{item}': the prefix leaves no room for the dns address; use /30 (/126) or wider")),
        }
    }
    if v4.is_none() && v6.is_none() {
        return Err("tun.address: give at least one address".into());
    }
    let mtu = match env("AETHER_TUN_MTU") {
        None => 9000,
        Some(t) => t
            .parse::<u16>()
            .ok()
            .filter(|m| (1280..=65535).contains(m))
            .ok_or_else(|| format!("tun.mtu '{t}': give a number from 1280 to 65535"))?,
    };
    let dns = match env("AETHER_TUN_DNS").as_deref() {
        Some(t) if t.eq_ignore_ascii_case("off") || t.eq_ignore_ascii_case("none") => None,
        Some(t) => Some(t.parse::<IpAddr>().map_err(|_| format!("tun.dns '{t}': give an IP address, or off"))?),
        None => match (v4, v6) {
            (Some((a, _)), _) => Some(IpAddr::V4(next_v4(a))),
            (None, Some((a, _))) => Some(IpAddr::V6(next_v6(a))),
            _ => None,
        },
    };
    let include = cidrs("tun.include", &env("AETHER_TUN_INCLUDE").unwrap_or_default())?;
    let exclude = cidrs("tun.exclude", &env("AETHER_TUN_EXCLUDE").unwrap_or_default())?;
    let fake = if env_bool("AETHER_TUN_FAKEIP", true) {
        let f = fakeip::FakeIpConfig::parse(&env("AETHER_TUN_FAKEIP_RANGE").unwrap_or_else(|| fakeip::DEFAULT_RANGE.to_string()))?;
        let own: Vec<IpAddr> = v4
            .map(|(a, _)| IpAddr::V4(a))
            .into_iter()
            .chain(v6.map(|(a, _)| IpAddr::V6(a)))
            .chain(dns)
            .collect();
        if let Some(ip) = own.iter().find(|ip| f.contains(**ip)) {
            return Err(format!("tun.fakeip-range: {ip} (the TUN's own address or dns) is inside the fake-ip range"));
        }
        if let Some(n) = exclude.iter().find(|n| f.nets().iter().any(|p| p.contains(&n.network()) || n.contains(&p.network()))) {
            return Err(format!("tun.exclude {n} overlaps the fake-ip range; fake addresses must reach the TUN"));
        }
        Some(f)
    } else {
        None
    };
    let direct_dns = parse_direct_dns(env("AETHER_TUN_DIRECT_DNS").as_deref())?;
    let num = |key: &str, default: u32| -> std::result::Result<u32, String> {
        match env(key) {
            None => Ok(default),
            Some(t) => t.parse::<u32>().ok().filter(|v| *v > 0).ok_or_else(|| format!("{key} '{t}' is not a positive number")),
        }
    };
    Ok(TunConfig {
        name,
        v4,
        v6,
        mtu,
        dns,
        auto_route: env_bool("AETHER_TUN_AUTO_ROUTE", true),
        strict_route: env_bool("AETHER_TUN_STRICT_ROUTE", false),
        include,
        exclude,
        hijack_all_dns: env_bool("AETHER_TUN_DNS_HIJACK", true),
        allow_lan: env_bool("AETHER_TUN_ALLOW_LAN", true),
        table: num("AETHER_TUN_TABLE", DEFAULT_TABLE)?,
        priority: num("AETHER_TUN_RULE_PRIORITY", DEFAULT_PRIORITY)?,
        fakeip: fake,
        direct_dns,
    })
}

/// --tun-direct-dns: `system` (the default), `tunnel`, or dns server addresses.
pub fn parse_direct_dns(text: Option<&str>) -> std::result::Result<DirectDns, String> {
    let Some(t) = text.map(str::trim).filter(|t| !t.is_empty()) else { return Ok(DirectDns::System) };
    if t.eq_ignore_ascii_case("system") {
        return Ok(DirectDns::System);
    }
    if t.eq_ignore_ascii_case("tunnel") {
        return Ok(DirectDns::Tunnel);
    }
    let mut list = Vec::new();
    for item in t.split([',', ' ', ';']).map(str::trim).filter(|s| !s.is_empty()) {
        let sa = item
            .parse::<std::net::SocketAddr>()
            .ok()
            .or_else(|| item.parse::<IpAddr>().ok().map(|ip| std::net::SocketAddr::new(ip, 53)))
            .ok_or_else(|| {
                format!("tun.direct-dns '{item}': give system, tunnel, or dns server addresses such as 223.5.5.5")
            })?;
        if !list.contains(&sa) {
            list.push(sa);
        }
    }
    if list.is_empty() {
        return Err("tun.direct-dns: give system, tunnel, or dns server addresses such as 223.5.5.5".into());
    }
    Ok(DirectDns::Servers(list))
}

/// The nameservers of a resolv.conf (`nameserver` lines; comments and other lines ignored;
/// an address with a `%scope` is kept as written without its scope, the filter drops it).
#[cfg(any(target_os = "linux", test))]
pub fn parse_resolv_conf(text: &str) -> Vec<IpAddr> {
    let mut out = Vec::new();
    for line in text.lines() {
        let line = line.split(['#', ';']).next().unwrap_or("").trim();
        let mut words = line.split_whitespace();
        if words.next() != Some("nameserver") {
            continue;
        }
        let Some(addr) = words.next() else { continue };
        let addr = addr.split('%').next().unwrap_or(addr);
        if let Ok(ip) = addr.parse::<IpAddr>() {
            if !out.contains(&ip) {
                out.push(ip);
            }
        }
    }
    out
}

/// Which resolv.conf holds the network's own servers: /etc/resolv.conf, unless it only names
/// a loopback stub (systemd-resolved's 127.0.0.53, or a local cache) and systemd-resolved's
/// upstream list (/run/systemd/resolve/resolv.conf) is there.
#[cfg(any(target_os = "linux", test))]
pub fn pick_resolv_servers(etc: Option<&str>, systemd_upstream: Option<&str>) -> Vec<IpAddr> {
    let main = etc.map(parse_resolv_conf).unwrap_or_default();
    let only_loopback = main.iter().all(|ip| crate::proxy::router::ipset::unmap(*ip).is_loopback());
    if only_loopback || main.contains(&IpAddr::V4(Ipv4Addr::new(127, 0, 0, 53))) {
        if let Some(up) = systemd_upstream {
            let up = parse_resolv_conf(up);
            if !up.is_empty() {
                return up;
            }
        }
    }
    main
}

/// The system's dns servers that can be asked over the physical interface while the TUN is
/// up: no loopback stub (it would forward into the TUN and get fake addresses back), no
/// link-local or site-local address (fe80::/10 needs a scope Aether does not keep; fec0::/10
/// is the Windows placeholder), nothing of the TUN's own (its addresses, its dns, the fake-ip
/// pools), no unspecified / multicast / broadcast.
pub fn usable_system_servers(cfg: &TunConfig, candidates: &[IpAddr]) -> Vec<std::net::SocketAddr> {
    let tun_nets: Vec<IpNet> = cfg
        .v4
        .and_then(|(a, p)| ipnet::Ipv4Net::new(a, p).ok().map(IpNet::V4))
        .into_iter()
        .chain(cfg.v6.and_then(|(a, p)| ipnet::Ipv6Net::new(a, p).ok().map(IpNet::V6)))
        .map(|n| n.trunc())
        .collect();
    let mut out = Vec::new();
    for ip in candidates {
        let ip = crate::proxy::router::ipset::unmap(*ip);
        let bad = match ip {
            IpAddr::V4(v4) => {
                v4.is_loopback() || v4.is_unspecified() || v4.is_multicast() || v4.is_broadcast() || v4.is_link_local()
            }
            IpAddr::V6(v6) => {
                let seg0 = v6.segments()[0];
                v6.is_loopback() || v6.is_unspecified() || v6.is_multicast() || (seg0 & 0xffc0) == 0xfe80 || (seg0 & 0xffc0) == 0xfec0
            }
        };
        let tun_own = Some(ip) == cfg.dns
            || tun_nets.iter().any(|n| n.contains(&ip))
            || cfg.fakeip.as_ref().map(|f| f.contains(ip)).unwrap_or(false);
        let sa = std::net::SocketAddr::new(ip, 53);
        if !bad && !tun_own && !out.contains(&sa) {
            out.push(sa);
        }
    }
    out
}

/// Turn `DirectDns::System` into the servers read from the system now (before the TUN takes
/// over its dns), or into `Tunnel` with a warning when none is usable.
fn resolve_system_dns(cfg: &mut TunConfig) {
    if cfg.direct_dns != DirectDns::System {
        if let DirectDns::Servers(list) = &cfg.direct_dns {
            log::info!(
                "[tun] direct dns: {} (over the physical interface)",
                list.iter().map(|s| s.to_string()).collect::<Vec<_>>().join(", ")
            );
        } else {
            log::info!("[tun] direct dns: tunnel (dns through the tunnel; direct sites get answers for the tunnel's exit)");
        }
        return;
    }
    let (found, from) = os::system_dns(cfg);
    let usable = usable_system_servers(cfg, &found);
    if usable.is_empty() {
        log::warn!(
            "[tun] direct dns: no usable system dns server found{} ({}); falling back to tunnel (dns through the tunnel). \
             Give tun.direct-dns: <ips> (e.g. your router or ISP dns) if direct sites get far-away addresses",
            if found.is_empty() { String::new() } else { format!(" among {}", found.iter().map(|i| i.to_string()).collect::<Vec<_>>().join(", ")) },
            from
        );
        cfg.direct_dns = DirectDns::Tunnel;
    } else {
        log::info!(
            "[tun] direct dns: system servers {} (from {from}), asked over the physical interface",
            usable.iter().map(|s| s.ip().to_string()).collect::<Vec<_>>().join(", ")
        );
        cfg.direct_dns = DirectDns::Servers(usable);
    }
}

/// With --tun-include, only the listed ranges reach the TUN: the fake-ip ranges are added so
/// connections to fake addresses still do.
pub fn add_fakeip_routes(cfg: &mut TunConfig) {
    let Some(f) = cfg.fakeip.clone() else { return };
    if cfg.include.is_empty() {
        return;
    }
    for n in f.nets() {
        let family_on = if n.addr().is_ipv4() { cfg.v4.is_some() } else { cfg.v6.is_some() };
        if family_on && !cfg.include.iter().any(|i| i.contains(&n)) {
            cfg.include.push(n);
        }
    }
}

/// Whether the TUN device is up and has the system's routes and dns.
static ACTIVE: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// How `direct` and Aether's own lookups resolve while the TUN device is up (None: no TUN, or
/// not up yet: the system resolver still answers for real then).
pub fn direct_dns() -> Option<&'static DirectDns> {
    if !ACTIVE.load(std::sync::atomic::Ordering::Relaxed) {
        return None;
    }
    config().map(|c| &c.direct_dns)
}

/// The address after `a` (the default dns address sits right after the device's own).
fn next_v4(a: Ipv4Addr) -> Ipv4Addr {
    Ipv4Addr::from(u32::from(a).wrapping_add(1))
}

fn next_v6(a: Ipv6Addr) -> Ipv6Addr {
    Ipv6Addr::from(u128::from(a).wrapping_add(1))
}

static CONFIG: OnceLock<TunConfig> = OnceLock::new();

/// The TUN options of this run (only meaningful once `start` accepted them).
pub fn config() -> Option<&'static TunConfig> {
    CONFIG.get()
}

/// Before `egress::init`: on Linux, TUN mode needs Aether's own sockets marked, so a mark is
/// chosen when --mark did not give one.
pub fn prepare_env() {
    if !enabled() {
        return;
    }
    #[cfg(target_os = "linux")]
    if env("AETHER_MARK").is_none() {
        crate::config::settings::decide("AETHER_MARK", format!("{DEFAULT_MARK:#x}"));
    }
}

/// What a flow taken off the TUN is, before the rules see it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Class {
    /// A dns query to answer with Aether's resolver.
    Dns,
    /// Nothing to forward: multicast, broadcast, unspecified, or the device's own addresses.
    Drop,
    /// An ordinary flow for the router.
    Route,
}

pub fn classify(cfg: &TunConfig, dst: std::net::SocketAddr) -> Class {
    let ip = crate::proxy::router::ipset::unmap(dst.ip());
    if dst.port() == 53 && (Some(ip) == cfg.dns || cfg.hijack_all_dns) {
        return Class::Dns;
    }
    let own = cfg.v4.map(|(a, _)| IpAddr::V4(a)) == Some(ip) || cfg.v6.map(|(a, _)| IpAddr::V6(a)) == Some(ip);
    let silent = match ip {
        IpAddr::V4(v4) => v4.is_multicast() || v4.is_broadcast() || v4.is_unspecified() || is_tun_broadcast(cfg, v4),
        IpAddr::V6(v6) => v6.is_multicast() || v6.is_unspecified(),
    };
    if own || silent || Some(ip) == cfg.dns {
        return Class::Drop;
    }
    Class::Route
}

fn is_tun_broadcast(cfg: &TunConfig, ip: Ipv4Addr) -> bool {
    match cfg.v4 {
        Some((a, p)) => ipnet::Ipv4Net::new(a, p).map(|n| n.broadcast() == ip).unwrap_or(false),
        None => false,
    }
}

/// The OS state of a running TUN inbound; dropping it restores routes, DNS and firewall.
static DEVICE: Mutex<Option<os::Device>> = Mutex::new(None);

/// Undo everything a running TUN inbound changed. Safe to call more than once.
pub fn shutdown() {
    ACTIVE.store(false, std::sync::atomic::Ordering::Relaxed);
    if let Some(device) = DEVICE.lock().take() {
        log::info!("[tun] restoring routes, dns and firewall");
        drop(device);
    }
}

/// --tun-cleanup: remove what a TUN run that was killed may have left behind.
pub fn cleanup_command() -> Result<()> {
    let cfg = parse_config().map_err(AetherError::Other)?;
    os::cleanup_stale(&cfg);
    println!("aether: removed the TUN device, routes, rules and firewall entries of an earlier TUN run (if any)");
    Ok(())
}

/// After `route::init`: check the options and the privileges, and prepare the OS side that must
/// exist before the outer tunnel connects. `spawn` then brings the TUN inbound up.
pub fn prepare() -> Result<()> {
    if !enabled() {
        return Ok(());
    }
    let mut cfg = parse_config().map_err(AetherError::Other)?;
    // Without IPv6 on the host, an IPv6 address on the TUN makes programs prefer IPv6 and
    // every `direct` IPv6 connection then fails; keep the TUN IPv4-only unless asked.
    if cfg.v6.is_some() && env("AETHER_TUN_ADDRESS").is_none() && !os::host_has_ipv6() {
        log::info!("[tun] the host has no IPv6 default route: the TUN takes IPv4 only (give tun.address with an IPv6 address to force it)");
        cfg.v6 = None;
    }
    add_fakeip_routes(&mut cfg);
    os::preflight(&cfg).map_err(AetherError::Other)?;
    os::cleanup_stale(&cfg);
    // the system's own dns servers, read while they are still the physical network's
    resolve_system_dns(&mut cfg);
    if let Some(f) = &cfg.fakeip {
        fakeip::install(f.clone());
    }
    let _ = CONFIG.set(cfg);
    Ok(())
}

/// Bring the prepared TUN inbound up in the background, without waiting for the WARP tunnel:
/// flows to outbounds that need no WARP go at once, and those to WARP's wait for it (Aether's
/// own sockets, the scan's included, are bound to the physical interface and never enter the
/// TUN).
pub fn spawn() {
    if !enabled() || config().is_none() {
        return;
    }
    install_signal_handlers();
    crate::utils::shutdown::spawn(async {
        if let Err(e) = run().await {
            // --tun was asked for: carrying on as a plain proxy would leave the user thinking
            // the whole system is covered
            log::error!("[tun] {e}");
            shutdown();
            std::process::exit(1);
        }
    });
}

async fn run() -> std::result::Result<(), String> {
    let cfg = config().ok_or("no tun config")?;

    let (to_stack_tx, to_stack_rx) = async_channel::bounded::<bytes::Bytes>(1024);
    let (from_stack_tx, from_stack_rx) = async_channel::bounded::<bytes::Bytes>(1024);
    let stack = ipstack_geph::IpStack::new(
        ipstack_geph::IpStackConfig {
            mtu: cfg.mtu,
            tcp_timeout: std::time::Duration::from_secs(3600),
            udp_timeout: std::time::Duration::from_secs(300),
        },
        to_stack_rx,
        from_stack_tx,
    );
    // from here on the system resolver points at the TUN: Aether resolves on its own
    ACTIVE.store(true, std::sync::atomic::Ordering::Relaxed);
    let device = os::Device::open(cfg, to_stack_tx, from_stack_rx)?;
    log::info!(
        "[tun] tun inbound up: device {}{}{}, mtu {}, dns {}{}, auto-route {}{}",
        cfg.name,
        cfg.v4.map(|(a, p)| format!(", {a}/{p}")).unwrap_or_default(),
        cfg.v6.map(|(a, p)| format!(", {a}/{p}")).unwrap_or_default(),
        cfg.mtu,
        cfg.dns.map(|d| d.to_string()).unwrap_or_else(|| "off".into()),
        match &cfg.fakeip {
            Some(f) => format!(
                " (fake-ip {}, ttl {}s)",
                f.nets().iter().map(|n| n.to_string()).collect::<Vec<_>>().join(","),
                fakeip::TTL
            ),
            None => " (fake-ip off: real answers through the tunnel)".into(),
        },
        if cfg.auto_route { "on" } else { "off" },
        if cfg.strict_route { ", strict" } else { "" },
    );
    *DEVICE.lock() = Some(device);
    crate::proxy::router::spawn_updaters();
    flows::serve(stack, cfg).await;
    Ok(())
}

fn install_signal_handlers() {
    crate::utils::shutdown::spawn(async {
        #[cfg(unix)]
        {
            use tokio::signal::unix::{signal, SignalKind};
            let (Ok(mut term), Ok(mut int), Ok(mut hup)) =
                (signal(SignalKind::terminate()), signal(SignalKind::interrupt()), signal(SignalKind::hangup()))
            else {
                return;
            };
            tokio::select! {
                _ = term.recv() => {}
                _ = int.recv() => {}
                _ = hup.recv() => {}
            }
        }
        #[cfg(windows)]
        {
            use tokio::signal::windows;
            let (Ok(mut c), Ok(mut brk), Ok(mut close), Ok(mut shut)) =
                (windows::ctrl_c(), windows::ctrl_break(), windows::ctrl_close(), windows::ctrl_shutdown())
            else {
                return;
            };
            tokio::select! {
                _ = c.recv() => {}
                _ = brk.recv() => {}
                _ = close.recv() => {}
                _ = shut.recv() => {}
            }
        }
        log::info!("[tun] stopping");
        shutdown();
        std::process::exit(130);
    });
}

#[cfg(test)]
mod tests;
