use std::collections::HashMap;
use std::net::SocketAddr;
use std::time::Duration;

use bytes::Bytes;
use etherparse::{PacketBuilder, SlicedPacket, TransportSlice};

use super::*;

fn cfg_of(pairs: &[(&str, &str)]) -> std::result::Result<TunConfig, String> {
    let map: HashMap<String, String> = pairs.iter().map(|(k, v)| (k.to_string(), v.to_string())).collect();
    parse_config_with(&move |k| map.get(k).cloned())
}

fn sa(s: &str) -> SocketAddr {
    s.parse().unwrap()
}

#[test]
fn defaults_follow_sing_box() {
    let c = cfg_of(&[]).unwrap();
    assert_eq!(c.v4, Some(("172.19.0.1".parse().unwrap(), 30)));
    assert_eq!(c.v6, Some(("fdfe:dcba:9876::1".parse().unwrap(), 126)));
    assert_eq!(c.dns, Some("172.19.0.2".parse().unwrap()));
    assert_eq!(c.mtu, 9000);
    assert!(c.auto_route && !c.strict_route && c.hijack_all_dns);
    assert_eq!((c.table, c.priority), (DEFAULT_TABLE, DEFAULT_PRIORITY));
}

#[test]
fn options_are_read_and_checked() {
    let c = cfg_of(&[
        ("AETHER_TUN_ADDRESS", "10.66.0.1/24"),
        ("AETHER_TUN_MTU", "1500"),
        ("AETHER_TUN_DNS", "off"),
        ("AETHER_TUN_INCLUDE", "1.1.1.1, 8.8.0.0/16"),
        ("AETHER_TUN_EXCLUDE", "192.168.9.7/24;2001:db8::/32"),
        ("AETHER_TUN_STRICT_ROUTE", "1"),
        ("AETHER_TUN_AUTO_ROUTE", "false"),
    ])
    .unwrap();
    assert_eq!(c.v4, Some(("10.66.0.1".parse().unwrap(), 24)));
    assert_eq!(c.v6, None);
    assert_eq!(c.dns, None);
    assert_eq!(c.mtu, 1500);
    assert_eq!(c.include, vec!["1.1.1.1/32".parse::<IpNet>().unwrap(), "8.8.0.0/16".parse().unwrap()]);
    // host bits are dropped
    assert_eq!(c.exclude[0], "192.168.9.0/24".parse::<IpNet>().unwrap());
    assert!(c.strict_route && !c.auto_route);
    assert!(cfg_of(&[("AETHER_TUN_MTU", "100")]).is_err());
    assert!(cfg_of(&[("AETHER_TUN_ADDRESS", "10.0.0.1/31")]).is_err());
    assert!(cfg_of(&[("AETHER_TUN_ADDRESS", "nonsense")]).is_err());
    assert!(cfg_of(&[("AETHER_TUN_INCLUDE", "1.2.3")]).is_err());
    assert!(cfg_of(&[("AETHER_TUN_NAME", "a name that is far too long")]).is_err());
    assert_eq!(cfg_of(&[("AETHER_TUN_ADDRESS", "fd00::1/64")]).unwrap().dns, Some("fd00::2".parse().unwrap()));
}

#[test]
fn flows_are_classified_before_the_rules() {
    let c = cfg_of(&[]).unwrap();
    assert_eq!(classify(&c, sa("172.19.0.2:53")), Class::Dns);
    assert_eq!(classify(&c, sa("8.8.8.8:53")), Class::Dns);
    assert_eq!(classify(&c, sa("[::ffff:8.8.8.8]:53")), Class::Dns);
    assert_eq!(classify(&c, sa("8.8.8.8:443")), Class::Route);
    assert_eq!(classify(&c, sa("172.19.0.2:80")), Class::Drop);
    assert_eq!(classify(&c, sa("172.19.0.1:80")), Class::Drop);
    assert_eq!(classify(&c, sa("172.19.0.3:9")), Class::Drop);
    assert_eq!(classify(&c, sa("224.0.0.251:5353")), Class::Drop);
    assert_eq!(classify(&c, sa("255.255.255.255:67")), Class::Drop);
    assert_eq!(classify(&c, sa("[ff02::fb]:5353")), Class::Drop);
    let only = cfg_of(&[("AETHER_TUN_DNS_HIJACK", "0")]).unwrap();
    assert_eq!(classify(&only, sa("8.8.8.8:53")), Class::Route);
    assert_eq!(classify(&only, sa("172.19.0.2:53")), Class::Dns);
}

#[test]
fn fakeip_is_on_by_default_and_configurable() {
    let c = cfg_of(&[]).unwrap();
    let f = c.fakeip.clone().expect("fake-ip on by default");
    assert_eq!(f.v4, Some("198.18.0.0/15".parse().unwrap()));
    assert_eq!(f.v6, Some("fc00::/18".parse().unwrap()));
    assert_eq!(c.direct_dns, DirectDns::System);
    assert_eq!(cfg_of(&[("AETHER_TUN_FAKEIP", "0")]).unwrap().fakeip, None);
    let c = cfg_of(&[("AETHER_TUN_FAKEIP_RANGE", "100.80.0.0/16"), ("AETHER_TUN_DIRECT_DNS", "223.5.5.5, 119.29.29.29:53")]).unwrap();
    assert_eq!(c.fakeip.as_ref().unwrap().v6, None);
    assert_eq!(c.direct_dns, DirectDns::Servers(vec![sa("223.5.5.5:53"), sa("119.29.29.29:53")]));
    assert!(cfg_of(&[("AETHER_TUN_DIRECT_DNS", "dns.example")]).is_err());
    // the TUN's own address inside the pool, or an exclude over it
    assert!(cfg_of(&[("AETHER_TUN_FAKEIP_RANGE", "172.19.0.0/16")]).is_err());
    assert!(cfg_of(&[("AETHER_TUN_EXCLUDE", "198.18.5.0/24")]).is_err());
    assert!(cfg_of(&[("AETHER_TUN_EXCLUDE", "198.18.5.0/24"), ("AETHER_TUN_FAKEIP", "off")]).is_ok());
}

#[test]
fn fake_addresses_are_routed_not_dropped() {
    let c = cfg_of(&[]).unwrap();
    assert_eq!(classify(&c, sa("198.18.0.1:443")), Class::Route);
    assert_eq!(classify(&c, sa("198.19.255.254:80")), Class::Route);
    assert_eq!(classify(&c, sa("[fc00::1]:443")), Class::Route);
    // dns to a fake address is still dns
    assert_eq!(classify(&c, sa("198.18.0.1:53")), Class::Dns);
}

#[test]
fn include_lists_get_the_fakeip_ranges() {
    let mut c = cfg_of(&[("AETHER_TUN_INCLUDE", "8.8.0.0/16")]).unwrap();
    add_fakeip_routes(&mut c);
    assert!(c.include.contains(&"198.18.0.0/15".parse().unwrap()));
    assert!(c.include.contains(&"fc00::/18".parse().unwrap()));
    // no include list: everything goes to the TUN already
    let mut all = cfg_of(&[]).unwrap();
    add_fakeip_routes(&mut all);
    assert!(all.include.is_empty());
    // the IPv6 pool only when the TUN has IPv6
    let mut v4 = cfg_of(&[("AETHER_TUN_INCLUDE", "8.8.0.0/16"), ("AETHER_TUN_ADDRESS", "172.19.0.1/30")]).unwrap();
    add_fakeip_routes(&mut v4);
    assert_eq!(v4.include.len(), 2);
}

#[cfg(target_os = "linux")]
#[test]
fn linux_policy_routing_keeps_marked_sockets_out() {
    let c = cfg_of(&[("AETHER_TUN_EXCLUDE", "203.0.113.0/24")]).unwrap();
    let plan: Vec<String> = linux::plan_setup(&c, 0x6165).into_iter().map(|c| c.args.join(" ")).collect();
    let pos = |needle: &str| plan.iter().position(|l| l == needle).unwrap_or_else(|| panic!("missing: {needle}\n{plan:#?}"));
    let route = pos("-4 route replace 0.0.0.0/0 dev aether-tun table 1819");
    let throw = pos("-4 route replace throw 203.0.113.0/24 table 1819");
    let own = pos("-4 rule add fwmark 0x6165 lookup main priority 9180");
    let guard = pos("-4 rule add fwmark 0x6165 unreachable priority 9181");
    let lan = pos("-4 rule add lookup main suppress_prefixlength 0 priority 9182");
    let all = pos("-4 rule add lookup 1819 priority 9183");
    // the catch-all comes last, after Aether's own traffic is excluded above it
    assert!(route < own && throw < own && own < guard && guard < lan && lan < all);
    assert!(plan.iter().any(|l| l == "-6 rule add lookup 1819 priority 9183"));

    let strict = cfg_of(&[("AETHER_TUN_STRICT_ROUTE", "1"), ("AETHER_TUN_INCLUDE", "1.1.1.0/24"), ("AETHER_TUN_ADDRESS", "10.1.0.1/30")]).unwrap();
    let plan: Vec<String> = linux::plan_setup(&strict, 7).into_iter().map(|c| c.args.join(" ")).collect();
    assert!(!plan.iter().any(|l| l.contains("suppress_prefixlength")));
    assert!(plan.iter().any(|l| l == "-4 route replace 1.1.1.0/24 dev aether-tun table 1819"));
    assert!(!plan.iter().any(|l| l.contains("0.0.0.0/0")));
    assert!(!plan.iter().any(|l| l.starts_with("-6")));

    let manual = cfg_of(&[("AETHER_TUN_AUTO_ROUTE", "0")]).unwrap();
    assert!(!linux::plan_setup(&manual, 7).iter().any(|c| c.args.iter().any(|a| a == "rule")));

    let clean: Vec<String> = linux::plan_cleanup(&c).into_iter().map(|a| a.join(" ")).collect();
    for p in 9180..9184 {
        assert!(clean.contains(&format!("-4 rule del priority {p}")));
        assert!(clean.contains(&format!("-6 rule del priority {p}")));
    }
    assert!(clean.contains(&"-4 route flush table 1819".to_string()));
    let ks = linux::killswitch(&c, 0x6165);
    assert!(ks.contains("meta mark 0x6165 accept") && ks.contains("oifname \"aether-tun\" accept") && ks.contains("drop"));
}

// ---- the userspace stack with synthetic packets ----

struct Wire {
    to_stack: async_channel::Sender<Bytes>,
    from_stack: async_channel::Receiver<Bytes>,
    stack: ipstack_geph::IpStack,
}

fn wire() -> Wire {
    let (to_stack, rx) = async_channel::bounded(64);
    let (tx, from_stack) = async_channel::bounded(64);
    let stack = ipstack_geph::IpStack::new(
        ipstack_geph::IpStackConfig { mtu: 1500, tcp_timeout: Duration::from_secs(30), udp_timeout: Duration::from_secs(30) },
        rx,
        tx,
    );
    Wire { to_stack, from_stack, stack }
}

fn udp_packet(src: [u8; 4], sport: u16, dst: [u8; 4], dport: u16, payload: &[u8]) -> Bytes {
    let b = PacketBuilder::ipv4(src, dst, 64).udp(sport, dport);
    let mut out = Vec::with_capacity(b.size(payload.len()));
    b.write(&mut out, payload).unwrap();
    Bytes::from(out)
}

fn syn(src: [u8; 4], sport: u16, dst: [u8; 4], dport: u16) -> Bytes {
    let b = PacketBuilder::ipv4(src, dst, 64).tcp(sport, dport, 1000, 65535).syn();
    let mut out = Vec::with_capacity(b.size(0));
    b.write(&mut out, &[]).unwrap();
    Bytes::from(out)
}

async fn next_out(w: &Wire) -> Bytes {
    tokio::time::timeout(Duration::from_secs(5), w.from_stack.recv()).await.expect("a packet out").unwrap()
}

#[tokio::test]
async fn a_udp_packet_becomes_a_flow_and_the_answer_a_packet_back() {
    let w = wire();
    w.to_stack.send(udp_packet([172, 19, 0, 1], 40000, [1, 1, 1, 1], 53, b"query")).await.unwrap();
    let flow = tokio::time::timeout(Duration::from_secs(5), w.stack.accept()).await.unwrap().unwrap();
    let ipstack_geph::stream::IpStackStream::Udp(u) = flow else { panic!("not udp") };
    assert_eq!(u.local_addr(), sa("172.19.0.1:40000"));
    assert_eq!(u.peer_addr(), sa("1.1.1.1:53"));
    assert_eq!(&u.recv().await.unwrap()[..], b"query");
    u.send(b"answer").await.unwrap();
    let out = next_out(&w).await;
    let p = SlicedPacket::from_ip(&out).unwrap();
    let Some(TransportSlice::Udp(udp)) = p.transport else { panic!("not udp out") };
    assert_eq!((udp.source_port(), udp.destination_port()), (53, 40000));
    assert_eq!(udp.payload(), b"answer");
    // the same 5-tuple stays one flow
    w.to_stack.send(udp_packet([172, 19, 0, 1], 40000, [1, 1, 1, 1], 53, b"again")).await.unwrap();
    assert_eq!(&u.recv().await.unwrap()[..], b"again");
}

#[tokio::test]
async fn a_syn_is_answered_and_handed_over_as_a_tcp_flow() {
    let w = wire();
    w.to_stack.send(syn([172, 19, 0, 1], 41000, [93, 184, 216, 34], 443)).await.unwrap();
    let flow = tokio::time::timeout(Duration::from_secs(5), w.stack.accept()).await.unwrap().unwrap();
    let ipstack_geph::stream::IpStackStream::Tcp(mut t) = flow else { panic!("not tcp") };
    assert_eq!(t.local_addr(), sa("172.19.0.1:41000"));
    assert_eq!(t.peer_addr(), sa("93.184.216.34:443"));
    // nothing is answered before the flow is read: a dial that fails leaves the SYN unanswered
    assert!(tokio::time::timeout(Duration::from_millis(300), w.from_stack.recv()).await.is_err());
    let reader = tokio::spawn(async move {
        use tokio::io::AsyncReadExt;
        let mut b = [0u8; 16];
        let _ = tokio::time::timeout(Duration::from_secs(2), t.read(&mut b)).await;
        t
    });
    let out = next_out(&w).await;
    let p = SlicedPacket::from_ip(&out).unwrap();
    let Some(TransportSlice::Tcp(tcp)) = p.transport else { panic!("not tcp out") };
    assert!(tcp.syn() && tcp.ack(), "a SYN-ACK");
    assert_eq!(tcp.acknowledgment_number(), 1001);
    assert_eq!((tcp.source_port(), tcp.destination_port()), (443, 41000));
    let mut t = reader.await.unwrap();
    // a reset (a refusal by the rules) is a RST to the program
    t.reset();
    let out = next_out(&w).await;
    let p = SlicedPacket::from_ip(&out).unwrap();
    let Some(TransportSlice::Tcp(tcp)) = p.transport else { panic!("not tcp out") };
    assert!(tcp.rst());
}

#[test]
fn signals_and_shutdown_are_harmless_without_a_device() {
    shutdown();
    shutdown();
}

#[test]
fn direct_dns_defaults_to_system_and_takes_tunnel_or_servers() {
    assert_eq!(parse_direct_dns(None), Ok(DirectDns::System));
    assert_eq!(parse_direct_dns(Some("  ")), Ok(DirectDns::System));
    assert_eq!(parse_direct_dns(Some("System")), Ok(DirectDns::System));
    assert_eq!(parse_direct_dns(Some("tunnel")), Ok(DirectDns::Tunnel));
    assert_eq!(parse_direct_dns(Some("TUNNEL")), Ok(DirectDns::Tunnel));
    assert_eq!(
        parse_direct_dns(Some("223.5.5.5;223.5.5.5 [2400:3200::1]:5353")),
        Ok(DirectDns::Servers(vec![sa("223.5.5.5:53"), sa("[2400:3200::1]:5353")]))
    );
    assert!(parse_direct_dns(Some("system,223.5.5.5")).is_err());
    assert!(parse_direct_dns(Some(",")).is_err());
    assert!(parse_direct_dns(Some("dns.example")).is_err());
    assert_eq!(cfg_of(&[("AETHER_TUN_DIRECT_DNS", "tunnel")]).unwrap().direct_dns, DirectDns::Tunnel);
    assert_eq!(cfg_of(&[("AETHER_TUN_DIRECT_DNS", "system")]).unwrap().direct_dns, DirectDns::System);
}

#[test]
fn resolv_conf_nameservers_are_read() {
    let text = "# generated\nsearch lan\nnameserver 192.168.1.1 # router\n  nameserver\t2001:db8::53\n\
                ; nameserver 9.9.9.9\nnameserver fe80::1%eth0\nnameserver bogus\noptions edns0\nnameserver 192.168.1.1\n";
    let got = parse_resolv_conf(text);
    let want: Vec<IpAddr> = ["192.168.1.1", "2001:db8::53", "fe80::1"].iter().map(|s| s.parse().unwrap()).collect();
    assert_eq!(got, want);
    assert!(parse_resolv_conf("").is_empty());
}

#[test]
fn the_systemd_resolved_stub_is_replaced_by_its_upstream_list() {
    let stub = "nameserver 127.0.0.53\noptions edns0 trust-ad\n";
    let upstream = "nameserver 10.0.0.1\nnameserver 223.5.5.5\n";
    let ip = |s: &str| s.parse::<IpAddr>().unwrap();
    assert_eq!(pick_resolv_servers(Some(stub), Some(upstream)), vec![ip("10.0.0.1"), ip("223.5.5.5")]);
    // no upstream file: the stub stays (and is filtered out later)
    assert_eq!(pick_resolv_servers(Some(stub), None), vec![ip("127.0.0.53")]);
    // a real resolv.conf is used as it is
    assert_eq!(pick_resolv_servers(Some("nameserver 114.114.114.114\n"), Some(upstream)), vec![ip("114.114.114.114")]);
    // another loopback cache (dnsmasq) with resolved's list there: the list
    assert_eq!(pick_resolv_servers(Some("nameserver 127.0.0.1\n"), Some(upstream)), vec![ip("10.0.0.1"), ip("223.5.5.5")]);
    // nothing at all
    assert!(pick_resolv_servers(None, None).is_empty());
    assert_eq!(pick_resolv_servers(None, Some(upstream)).len(), 2);
}

#[test]
fn system_servers_that_would_loop_or_cannot_be_reached_are_dropped() {
    let c = cfg_of(&[]).unwrap();
    let ips: Vec<IpAddr> = [
        "127.0.0.53",
        "::1",
        "0.0.0.0",
        "169.254.1.1",
        "fe80::1",
        "fec0:0:0:ffff::1",
        "ff02::1",
        "172.19.0.2",
        "172.19.0.1",
        "198.18.0.5",
        "fc00::5",
        "fdfe:dcba:9876::2",
        "192.168.1.1",
        "::ffff:223.5.5.5",
        "2001:db8::53",
        "192.168.1.1",
    ]
    .iter()
    .map(|s| s.parse().unwrap())
    .collect();
    assert_eq!(usable_system_servers(&c, &ips), vec![sa("192.168.1.1:53"), sa("223.5.5.5:53"), sa("[2001:db8::53]:53")]);
    // with fake-ip off the pool is an ordinary range
    let off = cfg_of(&[("AETHER_TUN_FAKEIP", "0")]).unwrap();
    assert_eq!(usable_system_servers(&off, &["198.18.0.5".parse().unwrap()]), vec![sa("198.18.0.5:53")]);
    assert!(usable_system_servers(&c, &[]).is_empty());
}
