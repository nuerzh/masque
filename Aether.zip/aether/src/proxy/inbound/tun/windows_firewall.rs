// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
//
// Adapted for Aether from geph5 (https://github.com/geph-official/geph5),
// binaries/geph5-app/src/vpn/windows/firewall.rs, Copyright (c) the Geph
// developers, licensed under MPL-2.0 (see LICENSE-geph5-MPL-2.0). Taken: the
// WFP filter ladder at ALE_AUTH_CONNECT v4/v6 (permit loopback, permit the
// app id, permit on the WinTUN interface, permit DHCP, block port 53, permit
// LAN, default block), the condition builders and the app-id lookup.
// Changed: Aether opens a DYNAMIC WFP session and keeps it for the life of
// the TUN inbound, so the filters disappear with the process even when it is
// killed (fail-open rather than a blackholed machine); there is a single app
// id (aether.exe); errors are plain strings.

//! The --tun-strict-route leak firewall on Windows (Windows Filtering Platform).

use std::os::windows::ffi::OsStrExt;
use std::path::Path;

use windows_sys::core::GUID;
use windows_sys::Win32::Foundation::HANDLE;
use windows_sys::Win32::NetworkManagement::WindowsFilteringPlatform::*;
use windows_sys::Win32::System::Rpc::RPC_C_AUTHN_WINNT;

type Result<T> = std::result::Result<T, String>;

/// Aether's sublayer ("Aether" + 2); everything the firewall adds lives under it.
const SUBLAYER_KEY: GUID = GUID::from_u128(0x4165_7468_6572_0000_0000_0000_0000_0002);

/// `IPPROTO_UDP`, the protocol number used in the DHCP permit condition.
const IPPROTO_UDP: u8 = 17;

/// The installed firewall: the dynamic WFP session that owns the filters.
pub(super) struct Firewall {
    engine: HANDLE,
}

// The engine handle is only used from the thread that drops the device, one at a time.
unsafe impl Send for Firewall {}

impl Firewall {
    pub(super) fn new() -> Self {
        Firewall { engine: std::ptr::null_mut() }
    }

    pub(super) fn install(&mut self, wintun_luid: u64, allow_lan: bool) -> Result<()> {
        let engine = open_engine(true)?;
        if let Err(e) = check(unsafe { FwpmTransactionBegin0(engine, 0) }, "FwpmTransactionBegin0") {
            unsafe { FwpmEngineClose0(engine) };
            return Err(e);
        }
        let exe = std::env::current_exe().map_err(|e| e.to_string())?;
        let result = build_filters(engine, &[exe], wintun_luid, allow_lan)
            .and_then(|()| check(unsafe { FwpmTransactionCommit0(engine) }, "FwpmTransactionCommit0"));
        if let Err(e) = result {
            unsafe {
                let _ = FwpmTransactionAbort0(engine);
                FwpmEngineClose0(engine);
            }
            return Err(e);
        }
        self.engine = engine;
        Ok(())
    }

    /// Closing the dynamic session deletes every filter it added.
    pub(super) fn remove(&mut self) {
        if !self.engine.is_null() {
            unsafe { FwpmEngineClose0(self.engine) };
            self.engine = std::ptr::null_mut();
        }
    }
}

impl Drop for Firewall {
    fn drop(&mut self) {
        self.remove();
    }
}

/// Delete Aether's sublayer and its filters if a non-dynamic leftover exists (there should be
/// none: the filters are dynamic). Used by --tun-cleanup.
pub(super) fn purge_stale() -> Result<()> {
    let engine = open_engine(false)?;
    let ids = owned_filter_ids(engine);
    if let Ok(ids) = &ids {
        for id in ids {
            unsafe {
                let _ = FwpmFilterDeleteById0(engine, *id);
            }
        }
    }
    unsafe {
        let _ = FwpmSubLayerDeleteByKey0(engine, &SUBLAYER_KEY);
        FwpmEngineClose0(engine);
    }
    ids.map(|_| ())
}

fn owned_filter_ids(engine: HANDLE) -> Result<Vec<u64>> {
    let mut ids = Vec::new();
    for layer in [FWPM_LAYER_ALE_AUTH_CONNECT_V4, FWPM_LAYER_ALE_AUTH_CONNECT_V6] {
        let mut template: FWPM_FILTER_ENUM_TEMPLATE0 = unsafe { std::mem::zeroed() };
        template.layerKey = layer;
        template.enumType = FWP_FILTER_ENUM_FULLY_CONTAINED;
        template.actionMask = 0xFFFF_FFFF;
        let mut enum_handle: HANDLE = std::ptr::null_mut();
        check(
            unsafe { FwpmFilterCreateEnumHandle0(engine, &template, &mut enum_handle) },
            "FwpmFilterCreateEnumHandle0",
        )?;
        loop {
            let mut entries: *mut *mut FWPM_FILTER0 = std::ptr::null_mut();
            let mut count = 0u32;
            let code = unsafe { FwpmFilterEnum0(engine, enum_handle, 64, &mut entries, &mut count) };
            if let Err(error) = check(code, "FwpmFilterEnum0") {
                unsafe {
                    let _ = FwpmFilterDestroyEnumHandle0(engine, enum_handle);
                }
                return Err(error);
            }
            if count == 0 {
                break;
            }
            for index in 0..count as usize {
                let filter = unsafe { *entries.add(index) };
                if !filter.is_null() && unsafe { guid_eq(&(*filter).subLayerKey, &SUBLAYER_KEY) } {
                    ids.push(unsafe { (*filter).filterId });
                }
            }
            unsafe {
                FwpmFreeMemory0(&mut (entries as *mut core::ffi::c_void));
            }
        }
        unsafe {
            let _ = FwpmFilterDestroyEnumHandle0(engine, enum_handle);
        }
    }
    Ok(ids)
}

fn guid_eq(left: &GUID, right: &GUID) -> bool {
    left.data1 == right.data1 && left.data2 == right.data2 && left.data3 == right.data3 && left.data4 == right.data4
}

fn open_engine(dynamic: bool) -> Result<HANDLE> {
    let mut name = wide("Aether TUN leak firewall");
    let mut engine: HANDLE = std::ptr::null_mut();
    let code = unsafe {
        let mut session: FWPM_SESSION0 = std::mem::zeroed();
        session.displayData = FWPM_DISPLAY_DATA0 { name: name.as_mut_ptr(), description: std::ptr::null_mut() };
        if dynamic {
            session.flags = FWPM_SESSION_FLAG_DYNAMIC;
        }
        FwpmEngineOpen0(std::ptr::null(), RPC_C_AUTHN_WINNT, std::ptr::null(), &session, &mut engine)
    };
    check(code, "FwpmEngineOpen0")?;
    Ok(engine)
}

fn build_filters(engine: HANDLE, app_ids: &[std::path::PathBuf], wintun_luid: u64, allow_lan: bool) -> Result<()> {
    let mut sl_name = wide("Aether TUN leak firewall");
    let code = unsafe {
        let mut sublayer: FWPM_SUBLAYER0 = std::mem::zeroed();
        sublayer.subLayerKey = SUBLAYER_KEY;
        sublayer.displayData = FWPM_DISPLAY_DATA0 { name: sl_name.as_mut_ptr(), description: std::ptr::null_mut() };
        sublayer.weight = 0xFFFF;
        FwpmSubLayerAdd0(engine, &sublayer, std::ptr::null_mut())
    };
    check(code, "FwpmSubLayerAdd0")?;

    let mut app_blobs: Vec<*mut FWP_BYTE_BLOB> = Vec::new();
    for path in app_ids {
        match app_id_blob(path) {
            Ok(blob) => app_blobs.push(blob),
            Err(e) => {
                for blob in app_blobs {
                    unsafe { FwpmFreeMemory0(&mut (blob as *mut core::ffi::c_void)) };
                }
                return Err(format!("could not resolve the WFP app id of {}: {e}", path.display()));
            }
        }
    }
    let r = (|| {
        install_family(engine, false, &app_blobs, wintun_luid, allow_lan)?;
        install_family(engine, true, &app_blobs, wintun_luid, allow_lan)?;
        Ok(())
    })();
    for blob in app_blobs {
        unsafe { FwpmFreeMemory0(&mut (blob as *mut core::ffi::c_void)) };
    }
    r
}

// Filter weights (`FWP_UINT8`, higher = evaluated first among terminating
// filters). The DNS-leak block sits *above* the LAN permit on purpose.
const W_LOOPBACK: u8 = 15;
const W_APPID: u8 = 14;
const W_WINTUN: u8 = 13;
const W_DHCP: u8 = 12;
const W_DNS_BLOCK: u8 = 11;
const W_LAN: u8 = 10;
const W_DEFAULT_BLOCK: u8 = 0;

/// Install the whole ladder of filters for one address family.
fn install_family(
    engine: HANDLE,
    v6: bool,
    app_blobs: &[*mut FWP_BYTE_BLOB],
    wintun_luid: u64,
    allow_lan: bool,
) -> Result<()> {
    let layer = if v6 {
        FWPM_LAYER_ALE_AUTH_CONNECT_V6
    } else {
        FWPM_LAYER_ALE_AUTH_CONNECT_V4
    };
    // Backing storage for pointer-typed condition values; must outlive every add.
    let mut back = Backing::default();

    // permit loopback (by remote address).
    {
        let c = if v6 {
            vec![cond_v6(
                &mut back,
                &FWPM_CONDITION_IP_REMOTE_ADDRESS,
                V6_LOOPBACK,
                128,
            )]
        } else {
            vec![cond_v4(
                &mut back,
                &FWPM_CONDITION_IP_REMOTE_ADDRESS,
                0x7F00_0000,
                0xFF00_0000,
            )]
        };
        add_filter(engine, layer, FWP_ACTION_PERMIT, W_LOOPBACK, &c, "loopback")?;
    }

    // permit Aether itself by app-id (its own sockets: the outer tunnel, direct outbounds).
    for &blob in app_blobs {
        let c = vec![cond_blob(&FWPM_CONDITION_ALE_APP_ID, blob)];
        add_filter(engine, layer, FWP_ACTION_PERMIT, W_APPID, &c, "aether-app")?;
    }

    // permit everything leaving on the WinTUN interface (normal tunneled traffic).
    {
        let c = vec![cond_u64(
            &mut back,
            &FWPM_CONDITION_IP_LOCAL_INTERFACE,
            wintun_luid,
        )];
        add_filter(engine, layer, FWP_ACTION_PERMIT, W_WINTUN, &c, "on-wintun")?;
    }

    // permit DHCP (v4: UDP→:67; v6: DHCPv6 UDP→:547) so leases can renew.
    {
        let dhcp_port: u16 = if v6 { 547 } else { 67 };
        let c = vec![
            cond_u8(&FWPM_CONDITION_IP_PROTOCOL, IPPROTO_UDP),
            cond_u16(&FWPM_CONDITION_IP_REMOTE_PORT, dhcp_port),
        ];
        add_filter(engine, layer, FWP_ACTION_PERMIT, W_DHCP, &c, "dhcp")?;
    }

    // block :53 to anything not permitted above (DNS-leak guard).
    {
        let c = vec![cond_u16(&FWPM_CONDITION_IP_REMOTE_PORT, 53)];
        add_filter(
            engine,
            layer,
            FWP_ACTION_BLOCK,
            W_DNS_BLOCK,
            &c,
            "dns-leak-guard",
        )?;
    }

    // permit LAN destinations if requested (RFC1918 / link-local / ULA).
    if allow_lan {
        if v6 {
            for (addr, prefix) in [(V6_ULA, 7u8), (V6_LINK_LOCAL, 10u8)] {
                let c = vec![cond_v6(
                    &mut back,
                    &FWPM_CONDITION_IP_REMOTE_ADDRESS,
                    addr,
                    prefix,
                )];
                add_filter(engine, layer, FWP_ACTION_PERMIT, W_LAN, &c, "lan")?;
            }
        } else {
            for (addr, mask) in [
                (0x0A00_0000u32, 0xFF00_0000u32), // 10.0.0.0/8
                (0xAC10_0000, 0xFFF0_0000),       // 172.16.0.0/12
                (0xC0A8_0000, 0xFFFF_0000),       // 192.168.0.0/16
                (0xA9FE_0000, 0xFFFF_0000),       // 169.254.0.0/16 link-local
            ] {
                let c = vec![cond_v4(
                    &mut back,
                    &FWPM_CONDITION_IP_REMOTE_ADDRESS,
                    addr,
                    mask,
                )];
                add_filter(engine, layer, FWP_ACTION_PERMIT, W_LAN, &c, "lan")?;
            }
        }
    }

    // default block → fail-closed (no conditions, lowest weight).
    add_filter(
        engine,
        layer,
        FWP_ACTION_BLOCK,
        W_DEFAULT_BLOCK,
        &[],
        "default-block",
    )?;

    drop(back);
    Ok(())
}

const V6_LOOPBACK: [u8; 16] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];
const V6_ULA: [u8; 16] = [0xfc, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; // fc00::/7
const V6_LINK_LOCAL: [u8; 16] = [0xfe, 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; // fe80::/10

/// Stable heap storage for pointer-typed condition values (`FWP_UINT64`,
/// `FWP_V4_ADDR_AND_MASK`, `FWP_V6_ADDR_AND_MASK`). Conditions hold raw pointers
/// into these boxes, so this must outlive the `FwpmFilterAdd0` calls that use them.
#[derive(Default)]
struct Backing {
    u64s: Vec<Box<u64>>,
    v4s: Vec<Box<FWP_V4_ADDR_AND_MASK>>,
    v6s: Vec<Box<FWP_V6_ADDR_AND_MASK>>,
}

impl Backing {
    fn u64_ptr(&mut self, v: u64) -> *mut u64 {
        let b = Box::new(v);
        let p = b.as_ref() as *const u64 as *mut u64;
        self.u64s.push(b);
        p
    }
    fn v4_ptr(&mut self, addr: u32, mask: u32) -> *mut FWP_V4_ADDR_AND_MASK {
        let b = Box::new(FWP_V4_ADDR_AND_MASK { addr, mask });
        let p = b.as_ref() as *const FWP_V4_ADDR_AND_MASK as *mut FWP_V4_ADDR_AND_MASK;
        self.v4s.push(b);
        p
    }
    fn v6_ptr(&mut self, addr: [u8; 16], prefix: u8) -> *mut FWP_V6_ADDR_AND_MASK {
        let b = Box::new(FWP_V6_ADDR_AND_MASK {
            addr,
            prefixLength: prefix,
        });
        let p = b.as_ref() as *const FWP_V6_ADDR_AND_MASK as *mut FWP_V6_ADDR_AND_MASK;
        self.v6s.push(b);
        p
    }
}

// ---- condition constructors (matchType EQUAL) ----

fn cond(field: &GUID, ty: FWP_DATA_TYPE, val: FWP_CONDITION_VALUE0_0) -> FWPM_FILTER_CONDITION0 {
    FWPM_FILTER_CONDITION0 {
        fieldKey: *field,
        matchType: FWP_MATCH_EQUAL,
        conditionValue: FWP_CONDITION_VALUE0 {
            r#type: ty,
            Anonymous: val,
        },
    }
}

fn cond_u8(field: &GUID, v: u8) -> FWPM_FILTER_CONDITION0 {
    cond(field, FWP_UINT8, FWP_CONDITION_VALUE0_0 { uint8: v })
}
fn cond_u16(field: &GUID, v: u16) -> FWPM_FILTER_CONDITION0 {
    cond(field, FWP_UINT16, FWP_CONDITION_VALUE0_0 { uint16: v })
}
fn cond_u64(back: &mut Backing, field: &GUID, v: u64) -> FWPM_FILTER_CONDITION0 {
    cond(
        field,
        FWP_UINT64,
        FWP_CONDITION_VALUE0_0 {
            uint64: back.u64_ptr(v),
        },
    )
}
fn cond_v4(back: &mut Backing, field: &GUID, addr: u32, mask: u32) -> FWPM_FILTER_CONDITION0 {
    cond(
        field,
        FWP_V4_ADDR_MASK,
        FWP_CONDITION_VALUE0_0 {
            v4AddrMask: back.v4_ptr(addr, mask),
        },
    )
}
fn cond_v6(back: &mut Backing, field: &GUID, addr: [u8; 16], prefix: u8) -> FWPM_FILTER_CONDITION0 {
    cond(
        field,
        FWP_V6_ADDR_MASK,
        FWP_CONDITION_VALUE0_0 {
            v6AddrMask: back.v6_ptr(addr, prefix),
        },
    )
}
fn cond_blob(field: &GUID, blob: *mut FWP_BYTE_BLOB) -> FWPM_FILTER_CONDITION0 {
    cond(
        field,
        FWP_BYTE_BLOB_TYPE,
        FWP_CONDITION_VALUE0_0 { byteBlob: blob },
    )
}

/// Add a single terminating filter under our sublayer at `layer`.
fn add_filter(
    engine: HANDLE,
    layer: GUID,
    action: FWP_ACTION_TYPE,
    weight: u8,
    conditions: &[FWPM_FILTER_CONDITION0],
    label: &str,
) -> Result<()> {
    let mut name = wide(&format!("Aether TUN: {label}"));
    let mut id: u64 = 0;
    let code = unsafe {
        let mut filter: FWPM_FILTER0 = std::mem::zeroed();
        filter.displayData = FWPM_DISPLAY_DATA0 {
            name: name.as_mut_ptr(),
            description: std::ptr::null_mut(),
        };
        filter.layerKey = layer;
        filter.subLayerKey = SUBLAYER_KEY;
        filter.flags = FWPM_FILTER_FLAG_NONE;
        filter.weight = FWP_VALUE0 {
            r#type: FWP_UINT8,
            Anonymous: FWP_VALUE0_0 { uint8: weight },
        };
        filter.action.r#type = action;
        filter.numFilterConditions = conditions.len() as u32;
        filter.filterCondition = if conditions.is_empty() {
            std::ptr::null_mut()
        } else {
            conditions.as_ptr() as *mut FWPM_FILTER_CONDITION0
        };
        FwpmFilterAdd0(engine, &filter, std::ptr::null_mut(), &mut id)
    };
    check(code, "FwpmFilterAdd0").map_err(|e| format!("{e} (filter: {label})"))
}

/// Resolve a file path to the WFP app-id blob WFP expects in an `ALE_APP_ID`
/// condition. The returned blob must be freed with `FwpmFreeMemory0`.
fn app_id_blob(path: &Path) -> Result<*mut FWP_BYTE_BLOB> {
    let wpath = wide(&path.to_string_lossy());
    let mut blob: *mut FWP_BYTE_BLOB = std::ptr::null_mut();
    let code = unsafe { FwpmGetAppIdFromFileName0(wpath.as_ptr(), &mut blob) };
    check(code, "FwpmGetAppIdFromFileName0")?;
    Ok(blob)
}

/// Map a nonzero WFP/Win32 return code to an error.
fn check(code: u32, what: &str) -> Result<()> {
    if code == 0 {
        Ok(())
    } else {
        return Err(format!("{what} failed: 0x{code:08X}"))
    }
}

/// UTF-16, NUL-terminated, for the wide-string WFP/Win32 APIs.
fn wide(s: &str) -> Vec<u16> {
    std::ffi::OsStr::new(s)
        .encode_wide()
        .chain(std::iter::once(0))
        .collect()
}
