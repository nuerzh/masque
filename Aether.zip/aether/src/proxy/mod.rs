//! Aether's proxy core, laid out the way QuicProxy lays out its own: inbounds, a router, and
//! outbounds.
//!
//! ```text
//!   inbound  (socks5 | http | tun | sunnyquic server)
//!      |  tcp streams and udp flows, with their target
//!      v
//!   session  (sniff -> router rules -> verdict)            router = sing-box route config
//!      |
//!      v
//!   outbound (direct | block | warp | warp-local | sunny | sunny-direct | sunnyquic)
//!      |
//!      v
//!   transports underneath: the WARP MASQUE tunnel stack (netstack), and the sunnyquic
//!   client on it or on a local udp socket.
//! ```
//!
//! `sunnyquic` is the protocol itself (client and server), shared by the sunnyquic outbounds
//! and the sunnyquic server inbound.
//!
//! `inbound::start` opens the listeners a config's `inbounds` names; with none, the mode's own
//! (--bind, --http-proxy, --tun) stay as before.

pub mod inbound;
pub mod outbound;
pub mod router;
pub mod socks;
#[cfg(feature = "sunny")]
pub mod sunnyquic;
pub(crate) mod session;
pub(crate) mod session_udp;

#[cfg(test)]
mod tests;

/// What every file of the proxy core works with.
pub(crate) mod prelude {
    pub(crate) use std::collections::HashMap;
    pub(crate) use std::future::Future;
    pub(crate) use std::net::{IpAddr, SocketAddr};
    pub(crate) use std::pin::Pin;
    pub(crate) use std::sync::Arc;
    pub(crate) use std::time::Duration;

    pub(crate) use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
    pub(crate) use tokio::net::{TcpListener, TcpStream, UdpSocket};

    pub(crate) use crate::error::{AetherError, Result};
    pub(crate) use crate::transport::warp::netstack::{StackHandle, TcpSender, UdpSender};
    pub(crate) use crate::proxy::socks::*;
    pub(crate) use super::inbound::{Inbound, RoutedClient};
    pub(crate) use super::outbound::*;
    pub(crate) use super::router::rule::{Metadata, Network};
    pub(crate) use super::router::sniff::{self as sniffers, Outcome};
    pub(crate) use super::router::{exits, OutKind, ResolveOpts, Resolver, RouteOpts, Router, SniffOpts, Step, Strategy, Verdict};
    pub(crate) use super::session::*;
    pub(crate) use super::session_udp::*;
}
