# aether scan changes (this round)

Config and decisions
- prober/config.rs: ScanConfig, read once per scan (ScanConfig::from_env), passed down.
  No scan code reads AETHER_SCAN_* itself any more. API requests override max_rtt/rounds/switch.
- prober/carrier.rs: Carrier (Http2 | Quic) replaces the scan's bool and its own enum.
- prober/plan.rs: pure decisions (IP family fallback, prefilter, quick-pass fallback, deeper round).

Scan algorithm
- Verification feedback: prober/memory.rs records each full check per (range, port); the next
  quick pass starts its Thompson scheduler from those counts (the prior).
- Cross-run memory: AETHER_SCAN_MEMORY=<file> keeps the counts between runs (halved on load).
  Off when unset.
- Pacing: the pipelined sender backs off (AIMD, multiplicative decrease) on failed sends and
  recovers slowly. Only local send failures are seen; path loss shows as silence.
- QUIC replies must look like QUIC (looks_like_quic) before they count as answers.
- Retry timeout: 2 x p95 of recent RTTs (was 3 x median), clamped to [min, max].
- IPv4 and IPv6 quick passes run at once; IPv4 answers hint the IPv6 candidates via a channel.

Not done
- Pipelined verification (verify while the quick pass still runs): needs run_rounds and the
  Picker restructured.
- Carrier as a trait: judged not worth it for two carriers.
- Catalog and sysprofile globals: immutable data loaded once; kept as is.

Options (this step)
- The scan knobs are configuration-file options (aether.yaml), not environment variables:
  scan.pps, scan.retries (0-5), scan.pipeline (on/off), scan.memory (file, relative to the config).
  The core reads its settings from the file only; AETHER_SCAN_* in the environment is not read.
- ScanConfig::from_env renamed to ScanConfig::from_settings.
