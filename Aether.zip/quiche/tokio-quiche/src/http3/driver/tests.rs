use crate::http3::driver::client::ClientHooks;
use crate::http3::driver::server::ServerHooks;
use assert_matches::assert_matches;

use super::test_utils::*;
use super::*;

/// Tests for connection close error metrics recorded by
/// [`H3Driver::on_conn_close`].
mod conn_close_metrics {
    use crate::ApplicationOverQuic as _;

    use super::*;

    /// Peer sends a QUIC-level CONNECTION_CLOSE and the work loop
    /// completes with Ok. Verifies the peer QUIC error counter is
    /// incremented.
    #[test]
    fn peer_quic_error_on_ok_result() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();

        // Peer (client) closes with a QUIC-level error
        helper
            .pipe
            .client
            .close(false, 0x1, b"internal error")
            .unwrap();
        helper.pipe.advance().unwrap();

        let metrics = TestMetrics::default();
        helper
            .driver
            .on_conn_close(&mut helper.pipe.server, &metrics, &Ok(()));

        assert_eq!(metrics.peer_quic.get(), 1);
        assert_eq!(metrics.peer_h3.get(), 0);
        assert_eq!(metrics.local_quic.get(), 0);
        assert_eq!(metrics.local_h3.get(), 0);
    }

    /// Peer sends an APPLICATION_CLOSE (H3-level) and the work loop
    /// completes with Ok. Verifies the peer H3 error counter is
    /// incremented.
    #[test]
    fn peer_h3_error_on_ok_result() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();

        // Peer (client) closes with an H3-level error (is_app = true)
        helper.pipe.client.close(true, 0x100, b"no error").unwrap();
        helper.pipe.advance().unwrap();

        let metrics = TestMetrics::default();
        helper
            .driver
            .on_conn_close(&mut helper.pipe.server, &metrics, &Ok(()));

        assert_eq!(metrics.peer_h3.get(), 1);
        assert_eq!(metrics.peer_quic.get(), 0);
        assert_eq!(metrics.local_quic.get(), 0);
        assert_eq!(metrics.local_h3.get(), 0);
    }

    /// Work loop returns an error and the local side has a QUIC-level
    /// error set. Verifies the local QUIC error counter is incremented.
    #[test]
    fn local_quic_error_on_err_result() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();

        // Local side (server) closes with a QUIC-level error
        helper
            .pipe
            .server
            .close(false, 0x1, b"internal error")
            .unwrap();

        let err: crate::QuicResult<()> =
            Err(H3ConnectionError::PostAcceptTimeout.into());
        let metrics = TestMetrics::default();
        helper
            .driver
            .on_conn_close(&mut helper.pipe.server, &metrics, &err);

        assert_eq!(metrics.local_quic.get(), 1);
        assert_eq!(metrics.local_h3.get(), 0);
        assert_eq!(metrics.peer_quic.get(), 0);
        assert_eq!(metrics.peer_h3.get(), 0);
    }
}

/// Tests that use an H3Driver for the client side. We mostly focus on testing
/// the driver's handling of stream state, and data, rather than H3 semantics.
/// Note that most of these tests could have just as easily been written for
/// the server side.
mod client_side_driver {
    use super::*;

    #[test]
    fn client_fin_before_server_body() {
        let mut helper = DriverTestHelper::<ClientHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, false).unwrap();

        helper.advance_and_run_loop().unwrap();

        // Client receives response headers
        let resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(!resp.read_fin);
        let to_server = resp.send.get_ref().unwrap().clone();
        let mut from_server = resp.recv;
        // client sends body
        to_server
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[1; 5]), false))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // server receives client body
        assert_eq!(helper.peer_server_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_server_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_server_recv_body_vec(0, 1024), Ok(vec![1; 5]));

        // client sends fin, server sends body and fin
        to_server
            .try_send(OutboundFrame::Body(Default::default(), true))
            .unwrap();
        helper.peer_server_send_body(0, &[2; 10], true).unwrap();

        // Server reads fin
        helper.advance_and_run_loop().unwrap();
        // TODO: the server sees an h3::Event::Data, but it's for an empty buffer.
        // Ideally, it wouldn't do that.
        assert_eq!(helper.peer_server_poll(), Ok((0, h3::Event::Data)));
        // No data to be read
        assert_eq!(
            helper.peer_server_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_server_poll(), Ok((0, h3::Event::Finished)));
        assert_eq!(helper.peer_server_poll(), Err(h3::Error::Done));
        helper.advance_and_run_loop().unwrap();

        // client receives the server body
        assert_matches!(from_server.try_recv(), Ok(InboundFrame::Body(buf, fin)) => {
            assert_eq!(buf.to_vec(), vec![2; 10]);
            // TODO: it would be nice if we could receive the fin here, but that's not
            // how quiche::h3 works. Instead we need another receive call on the channel
            assert!(!fin);
        });
        helper.work_loop_iter().unwrap();

        // FIXME: This is an edge case. We should not see a `Disconnected` error
        // here. The `from_server` / `InboudFrame` channel is set to 1 in tests.
        // What happens, is the driver reads the previous body frame, then it
        // sees an `Event::Finished` and calls `process_h3_fin`, which sets
        // `ctx.fin_recv`. Then it processes the pending write that sends the fin
        // from client to server. The driver now sees both ctx.fin_read &&
        // ctx.fin_sent and drops the context and thus the channel. Application
        // code (H3Body) is not affected by -- it treats a disconnected channel
        // like receiving a fin. It's a different question if it should treat it
        // as such

        // assert_matches!(from_server.try_recv(), Ok(InboundFrame::Body(buf,
        // fin)) => {
        //    assert_eq!(buf.into_inner().into_vec().len(), 0);
        //    assert!(fin);
        //});
        assert_matches!(from_server.try_recv(), Err(TryRecvError::Disconnected));
        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    #[test]
    fn client_body_recv_buf() {
        let mut helper = DriverTestHelper::<ClientHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request with fin
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), true)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, false).unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client receives response headers
        let resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(!resp.read_fin);
        let mut from_server = resp.recv;

        // Set the buffer size
        helper.driver_set_body_buf_size(30);
        // Server sends an initial 10 byte body.
        helper.peer_server_send_body(0, &[2; 10], false).unwrap();
        helper.advance_and_run_loop().unwrap();
        // client receives the server body
        assert_eq!(helper.driver_try_recv_body(&mut from_server).0, vec![2; 10]);
        // another 10 bytes
        helper.peer_server_send_body(0, &[3; 10], false).unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.driver_try_recv_body(&mut from_server).0, vec![3; 10]);
        // another 10 bytes. That should have used the initial buffer.
        helper.peer_server_send_body(0, &[4; 10], false).unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.driver_try_recv_body(&mut from_server).0, vec![4; 10]);
        // another 10 bytes. Should transparently use a new buffer
        helper.peer_server_send_body(0, &[5; 10], true).unwrap();
        helper.advance_and_run_loop().unwrap();

        let (body, fin, _) = helper.driver_try_recv_body(&mut from_server);
        assert_eq!(body, vec![5; 10]);
        // client receives the server FIN
        assert!(fin);
        // client should have cleaned up the stream as both directions have closed
        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    /// Test that dropping the OutboundFrame channel causes the driver to
    /// send a RESET_STREAM frame to the peer.
    #[test]
    fn client_send_reset_stream_when_outbound_frame_channel_drops() {
        let mut helper = DriverTestHelper::<ClientHooks>::new().unwrap();
        const REQUEST_CANCELED_ERR: u64 =
            h3::WireErrorCode::RequestCancelled as u64;
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // The client uses H3Driver
        // client sends a request
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, false).unwrap();

        helper.advance_and_run_loop().unwrap();

        // Client receives response headers
        let resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(!resp.read_fin);
        // the stream is waiting on writes
        assert_eq!(helper.driver.waiting_streams.len(), 1);
        // take the InboundFrame receiver and stats
        let mut from_server = resp.recv;
        let audit_stats = resp.h3_audit_stats.clone();
        // ... and drop the outbound frame
        drop(resp.send);

        helper.advance_and_run_loop().unwrap();

        // server receives the reset
        assert_eq!(
            helper.peer_server_poll(),
            Ok((0, h3::Event::Reset(REQUEST_CANCELED_ERR)))
        );
        assert_eq!(helper.peer_server_poll(), Err(h3::Error::Done));

        helper.peer_server_send_body(0, &[2; 10], true).unwrap();
        helper.advance_and_run_loop().unwrap();

        // client receives the server body
        assert_matches!(from_server.try_recv(), Ok(InboundFrame::Body(buf, fin)) => {
            assert_eq!(buf.to_vec(), vec![2; 10]);
            // TODO: it would be nice if we could receive the fin here, but that's not
            // how quiche::h3 works. Instead we need another receive call on the channel
            assert!(!fin);
        });
        helper.work_loop_iter().unwrap();
        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(
            audit_stats.sent_reset_stream_error_code(),
            REQUEST_CANCELED_ERR as i64
        );
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 10);
        assert_eq!(audit_stats.downstream_bytes_sent(), 0);
    }

    /// Test that dropping the OutboundFrame channel causes the driver to
    /// send a RESET_STREAM frame to the peer.
    #[test]
    fn client_send_reset_stream_when_outbound_frame_channel_drops_2() {
        let mut helper = DriverTestHelper::<ClientHooks>::new().unwrap();
        const REQUEST_CANCELED_ERR: u64 =
            h3::WireErrorCode::RequestCancelled as u64;
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // The client uses H3Driver
        // client sends a request
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers, body, and fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, false).unwrap();
        helper.peer_server_send_body(0, &[2; 10], true).unwrap();

        helper.advance_and_run_loop().unwrap();

        // Client receives response headers
        let mut resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(!resp.read_fin);
        // take the InboundFrame receiver and stats
        let mut from_server = resp.recv;
        let audit_stats = resp.h3_audit_stats.clone();
        let (body, fin, _) = helper.driver_try_recv_body(&mut from_server);
        assert_eq!(body, vec![2; 10]);
        assert!(fin);
        helper.advance_and_run_loop().unwrap();

        // clsoe the channel.
        resp.send.close();

        helper.advance_and_run_loop().unwrap();

        // server receives the reset
        assert_eq!(
            helper.peer_server_poll(),
            Ok((0, h3::Event::Reset(REQUEST_CANCELED_ERR)))
        );
        assert_eq!(helper.peer_server_poll(), Err(h3::Error::Done));

        helper.advance_and_run_loop().unwrap();

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(
            audit_stats.sent_reset_stream_error_code(),
            REQUEST_CANCELED_ERR as i64
        );
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 10);
        assert_eq!(audit_stats.downstream_bytes_sent(), 0);
    }

    /// Send data until the stream is no longer writable, then drop the
    /// OutboundFrame channel to trigger a RESET_STREAM
    #[test]
    fn client_send_reset_stream_with_full_stream() {
        let mut config = default_quiche_config();
        config.set_initial_max_stream_data_bidi_local(30);
        config.set_initial_max_stream_data_bidi_remote(30);
        let mut helper = DriverTestHelper::<ClientHooks>::with_pipe(
            quiche::test_utils::Pipe::with_config_and_buf(&mut config).unwrap(),
        )
        .unwrap();
        const REQUEST_CANCELED_ERR: u64 =
            h3::WireErrorCode::RequestCancelled as u64;
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // The client uses H3Driver
        // client sends a request
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers, and fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, true).unwrap();

        helper.advance_and_run_loop().unwrap();

        // Client receives response headers
        let resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(resp.read_fin);
        let audit_stats = resp.h3_audit_stats.clone();
        // send a body the to server, but not enough flow control for the full
        // body
        resp.send
            .get_ref()
            .unwrap()
            .try_send(OutboundFrame::Body(
                Bytes::copy_from_slice(&[23; 50]),
                false,
            ))
            .unwrap();
        assert_eq!(helper.driver.waiting_streams.len(), 1);
        // run `work_loop_iter()` to write the body into quiche
        helper.work_loop_iter().unwrap();
        // make sure we couldn't write the full body
        assert!(audit_stats.downstream_bytes_sent() < 50);
        let written = audit_stats.downstream_bytes_sent();
        // advance the pipe, the stream is writable again, but
        // don't advance the work_loop yet.
        helper.pipe.advance().unwrap();
        while helper.peer_server_poll().is_ok() {}
        assert_eq!(
            helper.peer_server_recv_body_vec(0, 1024).unwrap().len(),
            written as usize
        );
        helper.pipe.advance().unwrap();
        assert_eq!(helper.driver.waiting_streams.len(), 0);
        assert!(helper.driver.stream_map.get(&0).unwrap().recv.is_some());
        assert!(helper
            .driver
            .stream_map
            .get(&0)
            .unwrap()
            .queued_frame
            .is_some());

        // clsoe the channel.
        drop(resp.send);

        helper.work_loop_iter().unwrap();
        assert_eq!(
            audit_stats.sent_reset_stream_error_code(),
            REQUEST_CANCELED_ERR as i64
        );
        helper.advance_and_run_loop().unwrap();

        // server receives the reset
        assert_eq!(
            helper.peer_server_poll(),
            Ok((0, h3::Event::Reset(REQUEST_CANCELED_ERR)))
        );
        assert_eq!(helper.peer_server_poll(), Err(h3::Error::Done));

        helper.advance_and_run_loop().unwrap();

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(
            audit_stats.sent_reset_stream_error_code(),
            REQUEST_CANCELED_ERR as i64
        );
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::None);
    }

    /// Test that dropping the OutboundFrame channel after we've send a fin
    /// is a no-op.
    #[test]
    fn client_drop_outbound_frame_channel_after_fin_no_reset() {
        let mut helper = DriverTestHelper::<ClientHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // The client uses H3Driver
        // client sends a request
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers, body, and fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, false).unwrap();

        helper.advance_and_run_loop().unwrap();

        // Client receives response headers
        let mut resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(!resp.read_fin);
        // take the InboundFrame receiver and stats
        let mut from_server = resp.recv;
        let audit_stats = resp.h3_audit_stats.clone();
        helper.advance_and_run_loop().unwrap();
        resp.send
            .get_ref()
            .unwrap()
            .try_send(OutboundFrame::Body(Default::default(), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // clsoe the channel.
        resp.send.close();

        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_server_send_body(0, &[42], true), Ok(1));
        helper.advance_and_run_loop().unwrap();

        // server receives the fin
        assert_eq!(helper.peer_server_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(
            helper.peer_server_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_server_poll(), Ok((0, h3::Event::Finished)));
        assert_eq!(helper.peer_server_poll(), Err(h3::Error::Done));

        helper.advance_and_run_loop().unwrap();

        // client receives the body and fin
        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_server);
        assert_eq!(body, &[42]);
        assert!(fin);

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 1);
        assert_eq!(audit_stats.downstream_bytes_sent(), 0);
    }

    /// Verify that a GOAWAY received mid-stream does not kill in-flight
    /// request streams. The server sends GOAWAY with an ID above the
    /// active stream, indicating the stream was accepted. The client
    /// should continue receiving the remaining response body and
    /// complete the stream normally.
    #[test]
    fn client_receives_goaway_during_streaming_response() {
        let mut helper = DriverTestHelper::<ClientHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client sends a request with fin (GET, no body).
        let stream_id = helper
            .driver_send_request(make_request_headers("GET"), true)
            .unwrap();
        assert_eq!(stream_id, 0);

        // Server sees the request and starts a streaming response.
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_server_poll().unwrap(),
            (0, h3::Event::Headers { .. })
        );
        helper.peer_server_send_response(0, false).unwrap();
        helper.peer_server_send_body(0, &[1; 10], false).unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client receives response headers.
        let resp = assert_matches!(
            helper.driver_recv_core_event().unwrap(),
            H3Event::IncomingHeaders(headers) => { headers }
        );
        assert_eq!(resp.stream_id, stream_id);
        assert!(!resp.read_fin);
        let mut from_server = resp.recv;

        // Client receives first body chunk.
        assert_eq!(helper.driver_try_recv_body(&mut from_server).0, vec![1; 10]);

        // Server sends GOAWAY with id = stream_id + 4 (our stream was
        // accepted, but no future streams will be).
        helper
            .peer
            .send_goaway(&mut helper.pipe.server, stream_id + 4)
            .unwrap();
        // Server continues sending body data on the existing stream.
        helper.peer_server_send_body(0, &[2; 10], false).unwrap();

        // Advance — the driver handles GOAWAY gracefully and keeps
        // the connection alive.
        helper.advance_and_run_loop().unwrap();

        // Client should still receive the second body chunk.
        assert_eq!(helper.driver_try_recv_body(&mut from_server).0, vec![2; 10]);

        // Controller receives a GoAway event with the correct ID.
        // Drain any BodyBytesReceived notifications first — the
        // ordering between data and control stream events is not
        // guaranteed.
        loop {
            match helper.driver_recv_core_event().unwrap() {
                H3Event::GoAway { id } => {
                    assert_eq!(id, stream_id + 4);
                    break;
                },
                H3Event::BodyBytesReceived { .. } => continue,
                other => panic!("unexpected event: {other:?}"),
            }
        }

        // Server finishes the response.
        helper.peer_server_send_body(0, &[3; 10], true).unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client receives the final chunk.
        let (body, _fin, _err) = helper.driver_try_recv_body(&mut from_server);
        assert_eq!(body, vec![3; 10]);
    }
}

/// Tests that use an H3Driver for the server side. We mostly focus on testing
/// the driver's handling of stream state, and data, rather than H3 semantics.
/// Note that most of these tests could have just as easily been written for
/// the client side.
mod server_side_driver {

    use super::*;

    #[test]
    fn client_fin_before_server_body() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client reads response and sends body and fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 5], true), Ok(5));
        helper.advance_and_run_loop().unwrap();

        // server receives body
        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_client);
        assert_eq!(body, vec![1; 5]);
        assert!(fin);

        // server sends body and fin
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[42]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![42]));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    #[test]
    fn verify_pr_2162() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request but NO FIN.
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();
        helper.work_loop_iter().unwrap();
        // server sends body and fin. This caused an infinite loop before #2162
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[42]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends body and fin
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_client_send_body(0, &[1; 5], true), Ok(5));
        helper.advance_and_run_loop().unwrap();

        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_client);
        assert_eq!(body, &[1; 5]);
        assert!(fin);

        // Stream is done
        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    /// Test the case where the client sends a STOP_SENDING quiche frame.
    #[test]
    fn client_sends_stop_sending() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        let audit_stats = req.h3_audit_stats;

        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client sends a STOP_SENDING
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(
            helper
                .pipe
                .client
                .stream_shutdown(0, quiche::Shutdown::Read, 4242),
            Ok(())
        );
        helper.advance_and_run_loop().unwrap();

        // the client didn't send any additional data, a try_recv on the server
        // returns empty
        assert_matches!(from_client.try_recv(), Err(TryRecvError::Empty));
        // The way quiche is implemented, we need to attempt a write to the stream
        // to learn that it's closed. So we add an OutboundFrame to the
        // channel and let the driver write it. The driver gets a
        // StreamStopped back and closes the channel.
        to_client
            .try_send(OutboundFrame::Body(
                Bytes::copy_from_slice(&[23; 10]),
                false,
            ))
            .unwrap();
        helper.work_loop_iter().unwrap();
        assert!(to_client.is_closed());
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), 4242);
        helper.work_loop_iter().unwrap();

        // STOP_SENDING only closes one half of the stream. The client
        // can still send data and it MUST send a `fin` to close the
        // other half.
        helper.peer_client_send_body(0, &[1, 2, 3], true).unwrap();
        helper.advance_and_run_loop().unwrap();
        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_client);
        assert_eq!(body, &[1, 2, 3]);
        assert!(fin);

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), 4242);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        // technically quiche will automatically respond to a STOP_SENDING
        // frame with a STREAM_RESET echoing the error code, but the user
        // didn't *actively* send a STREAM_RESET.
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 3);
        assert_eq!(audit_stats.downstream_bytes_sent(), 0);
    }

    /// Test the case where the client sends a RESET_STREAM quiche frame.
    /// The peer sends its reset before we send a fin
    #[test]
    fn client_sends_reset_stream_before_server_fin() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client (peer) sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let from_client = req.recv;
        let audit_stats = req.h3_audit_stats;

        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client sends a RESET_STREAM frame
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(
            helper
                .pipe
                .client
                .stream_shutdown(0, quiche::Shutdown::Write, 4242),
            Ok(())
        );
        helper.advance_and_run_loop().unwrap();

        // The channel is closed because the peer send us the reset.
        assert!(from_client.is_closed());
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::ResetStream { stream_id: 0 })
        );

        // We can still write to the peer and in fact, we must eventually send a
        // fin.
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[5; 4]), false))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[6; 4]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Ok(vec![5, 5, 5, 5, 6, 6, 6, 6])
        );

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 0);
        assert_eq!(audit_stats.downstream_bytes_sent(), 8);
    }

    /// Test the case where the client sends a RESET_STREAM quiche frame.
    /// We send a fin before the client sends reset
    #[test]
    fn client_sends_reset_stream_after_server_fin() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client (peer) sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let from_client = req.recv;
        let audit_stats = req.h3_audit_stats;

        // Send response, body, and fin to client
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();
        helper.work_loop_iter().unwrap();
        to_client
            .try_send(OutboundFrame::Body(
                Bytes::copy_from_slice(b"foobar 42"),
                true,
            ))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a RESET_STREAM frame
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_matches!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        helper.peer_client_recv_body_vec(0, 1024).unwrap();
        assert_eq!(
            helper
                .pipe
                .client
                .stream_shutdown(0, quiche::Shutdown::Write, 4242),
            Ok(())
        );
        helper.advance_and_run_loop().unwrap();

        // The channel is closed because the peer send us the reset.
        assert!(from_client.is_closed());
        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::ResetStream { stream_id: 0 })
        );

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 0);
        assert_eq!(
            audit_stats.downstream_bytes_sent(),
            b"foobar 42".len() as u64
        );
    }

    /// Test the case where the client sends a RESET_STREAM quiche frame while
    /// we're in the middle of reading data. We want to excercise the
    /// code-path where `upstream_ready` is called before `process_reads`.
    /// If `process_reads()` is called first, it will get the Reset event.
    /// If `upstream_ready()` is called first, it will attempt to read from
    /// the h3::Connection and will get a
    /// `TransportError(StreamReset(code))`
    #[test]
    fn client_sends_reset_stream_while_reading_wait_for_data() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client (peer) sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers and some body bytes
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        let audit_stats = req.h3_audit_stats;

        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();
        helper.work_loop_iter().unwrap();
        to_client
            .try_send(OutboundFrame::Body(
                Bytes::copy_from_slice(&[1, 2, 3, 4]),
                false,
            ))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends data
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_matches!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 10], false), Ok(10));

        // Advance the pipe and let the driver read a part of the body and
        // put it into the `from_client` channel
        helper.pipe.advance().unwrap();
        // Limit the amount of data we read from the stream.
        helper.driver_set_body_buf_size(5);
        helper.work_loop_iter().unwrap();
        assert_matches!(from_client.try_recv(), Ok(InboundFrame::Body(buf, fin)) => {
            assert_eq!(buf.to_vec(), &[1; 5]);
            assert!(!fin);
        });
        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::BodyBytesReceived {
                stream_id: 0,
                num_bytes: 5,
                fin: false
            })
        );
        assert_matches!(
            helper.controller.event_receiver_mut().try_recv(),
            Err(TryRecvError::Empty)
        );

        // client sends a reset.
        // TODO: This is a bit finnicky to test properly. We don't want to
        // run a full `work_loop_iter()` because that would call `process_reads()`
        // first.
        helper.pipe.advance().unwrap();
        assert_eq!(
            helper
                .pipe
                .client
                .stream_shutdown(0, quiche::Shutdown::Write, 4242),
            Ok(())
        );
        helper.pipe.advance().unwrap();
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never()
        .unwrap_or(Ok(()))
        .unwrap();

        // The channel is closed because the peer send us the reset.
        assert!(from_client.is_closed());
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::ResetStream { stream_id: 0 })
        );

        // We can still write to the peer and in fact, we must eventually send a
        // fin.
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[6; 4]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Ok(vec![1, 2, 3, 4, 6, 6, 6, 6])
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 5);
        assert_eq!(audit_stats.downstream_bytes_sent(), 8);
    }

    /// Test the case where the client sends a RESET_STREAM quiche frame while
    /// we're in the middle of reading data. We want to excercise the
    /// code-path where where we call `process_reads` before
    /// `upstream_ready()`.
    #[test]
    fn server_sends_reset_stream_while_reading_process_reads() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client (peer) sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        let audit_stats = req.h3_audit_stats;

        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends data
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 10], false), Ok(10));

        // Advance the pipe and let the driver read a part of the body and
        // put it into the `from_client` channel
        helper.pipe.advance().unwrap();
        // Limit the amount of data we read from the stream.
        helper.driver_set_body_buf_size(5);
        helper.work_loop_iter().unwrap();
        assert_matches!(from_client.try_recv(), Ok(InboundFrame::Body(buf, fin)) => {
            assert_eq!(buf.to_vec(), &[1; 5]);
            assert!(!fin);
        });
        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::BodyBytesReceived {
                stream_id: 0,
                num_bytes: 5,
                fin: false
            })
        );

        // client sends a reset.
        assert_eq!(
            helper
                .pipe
                .client
                .stream_shutdown(0, quiche::Shutdown::Write, 4242),
            Ok(())
        );
        helper.advance_and_run_loop().unwrap();

        // The channel is closed because the peer send us the reset.
        assert!(from_client.is_closed());
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::ResetStream { stream_id: 0 })
        );

        // send fin to client
        to_client
            .try_send(OutboundFrame::Body(Default::default(), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        assert_eq!(helper.driver.stream_map.len(), 0);
        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), 4242);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 5);
        assert_eq!(audit_stats.downstream_bytes_sent(), 0);
    }

    #[test]
    fn server_driver_send_stop_sending_after_channel_drop() {
        const REQUEST_CANCELED_ERR: u64 =
            h3::WireErrorCode::RequestCancelled as u64;
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        let audit_stats = req.h3_audit_stats.clone();
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client reads response and sends body without fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 5], false), Ok(5));
        helper.advance_and_run_loop().unwrap();

        // server receives body
        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_client);
        assert_eq!(body, vec![1; 5]);
        assert!(!fin);

        // peer (client) sends more data
        assert_eq!(helper.peer_client_send_body(0, &[1; 6], false), Ok(6));
        // advance the pipe only
        helper.pipe.advance().unwrap();
        // we drop the channel.
        drop(from_client);
        helper.advance_and_run_loop().unwrap();

        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::BodyBytesReceived {
                stream_id: 0,
                num_bytes: 5,
                fin: false
            })
        );
        assert_matches!(
            helper.controller.event_receiver_mut().try_recv(),
            Err(TryRecvError::Empty)
        );

        // Make sure the peer has received our STOP_SENDING frame
        assert_eq!(
            helper.peer_client_send_body(0, &[1; 7], false),
            Err(h3::Error::TransportError(quiche::Error::StreamStopped(
                REQUEST_CANCELED_ERR
            )))
        );
        helper.advance_and_run_loop().unwrap();

        // we still need to send a fin
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[42]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![42]));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(
            audit_stats.sent_stop_sending_error_code(),
            REQUEST_CANCELED_ERR as i64
        );
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 5);
        assert_eq!(audit_stats.downstream_bytes_sent(), 1);
        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    // Verify we don't send a STOP_SENDING frame if we've already processed a
    // fin
    #[test]
    fn server_driver_drop_channel_after_fin() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        let audit_stats = req.h3_audit_stats.clone();
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client reads response and sends body WITH fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 5], true), Ok(5));
        helper.advance_and_run_loop().unwrap();

        // server receives body
        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_client);
        assert_eq!(body, vec![1; 5]);
        assert!(fin);

        helper.advance_and_run_loop().unwrap();
        // we drop the channel.
        drop(from_client);
        helper.advance_and_run_loop().unwrap();

        // we still need to send a fin
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[42]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![42]));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 5);
        assert_eq!(audit_stats.downstream_bytes_sent(), 1);
        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    // Test the edge case where the driver has read a fin from the stream but
    // hasn't been able to deliver it before the channel is dropped.
    #[test]
    fn server_driver_drop_channel_after_fin_2() {
        const REQUEST_CANCELED_ERR: u64 =
            h3::WireErrorCode::RequestCancelled as u64;
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        let audit_stats = req.h3_audit_stats.clone();
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client reads response and sends body without fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 5], false), Ok(5));
        helper.advance_and_run_loop().unwrap();

        // peer (client) sends more data and fin
        assert_eq!(helper.peer_client_send_body(0, &[1; 6], true), Ok(6));
        helper.advance_and_run_loop().unwrap();
        // we drop the channel.
        drop(req.recv);
        helper.advance_and_run_loop().unwrap();

        assert_matches!(
            helper.driver_recv_core_event(),
            Ok(H3Event::BodyBytesReceived {
                stream_id: 0,
                num_bytes: 5,
                fin: false
            })
        );
        assert_matches!(
            helper.controller.event_receiver_mut().try_recv(),
            Err(TryRecvError::Empty)
        );

        // we still need to send a fin
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[42]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![42]));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        assert_eq!(audit_stats.recvd_stop_sending_error_code(), -1);
        assert_eq!(audit_stats.recvd_reset_stream_error_code(), -1);
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(
            audit_stats.sent_stop_sending_error_code(),
            REQUEST_CANCELED_ERR as i64
        );
        assert_eq!(audit_stats.recvd_stream_fin(), StreamClosureKind::None);
        assert_eq!(audit_stats.sent_stream_fin(), StreamClosureKind::Explicit);
        assert_eq!(audit_stats.downstream_bytes_recvd(), 5);
        assert_eq!(audit_stats.downstream_bytes_sent(), 1);
        assert_eq!(helper.driver.stream_map.len(), 0);
    }

    #[test]
    fn server_send_trailers() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // servers reads request and sends response headers
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        assert!(!req.read_fin);
        let to_client = req.send.get_ref().unwrap().clone();
        let mut from_client = req.recv;
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();

        // client reads response and sends body and fin
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
        assert_eq!(helper.peer_client_send_body(0, &[1; 5], true), Ok(5));
        helper.advance_and_run_loop().unwrap();

        // server receives body
        let (body, fin, _err) = helper.driver_try_recv_body(&mut from_client);
        assert_eq!(body, vec![1; 5]);
        assert!(fin);

        // server sends body
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[42]), false))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![42]));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Err(h3::Error::Done)
        );

        // server sends trailers
        to_client
            .try_send(OutboundFrame::Trailers(make_response_trailers(), None))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );

        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));
        assert_eq!(helper.peer_client_poll(), Err(h3::Error::Done));
    }

    /// Test that calling `H3Controller::shutdown_stream` with
    /// `StreamShutdown::Write` sends a RESET_STREAM frame to the peer.
    #[test]
    fn server_shutdown_stream_write_direction() {
        use crate::http3::driver::StreamShutdown;
        const CUSTOM_ERROR_CODE: u64 = 0x1234;

        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        // server reads request
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        let audit_stats = req.h3_audit_stats.clone();

        // Server calls shutdown_stream via the controller
        helper
            .controller
            .shutdown_stream(stream_id, StreamShutdown::Write {
                error_code: CUSTOM_ERROR_CODE,
            });

        helper.advance_and_run_loop().unwrap();

        // Client should receive the RESET_STREAM
        // Note: quiche::h3 reports RESET_STREAM via a TransportError when
        // trying to read from the stream
        assert_eq!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Reset(CUSTOM_ERROR_CODE)))
        );

        // Verify stats
        assert_eq!(
            audit_stats.sent_reset_stream_error_code(),
            CUSTOM_ERROR_CODE as i64
        );
        assert_eq!(audit_stats.sent_stop_sending_error_code(), -1);
    }

    /// Test that calling `H3Controller::shutdown_stream` with
    /// `StreamShutdown::Read` sends a STOP_SENDING frame to the peer.
    #[test]
    fn server_shutdown_stream_read_direction() {
        use crate::http3::driver::StreamShutdown;
        const CUSTOM_ERROR_CODE: u64 = 0x5678;

        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request without fin (expecting to send body)
        let stream_id = helper
            .peer_client_send_request(make_request_headers("POST"), false)
            .unwrap();

        // server reads request
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        let audit_stats = req.h3_audit_stats.clone();

        // Server calls shutdown_stream with Read direction (STOP_SENDING)
        helper
            .controller
            .shutdown_stream(stream_id, StreamShutdown::Read {
                error_code: CUSTOM_ERROR_CODE,
            });

        helper.advance_and_run_loop().unwrap();

        // Client tries to send body - should get StreamStopped error
        assert_eq!(
            helper.peer_client_send_body(0, &[1, 2, 3], false),
            Err(h3::Error::TransportError(quiche::Error::StreamStopped(
                CUSTOM_ERROR_CODE
            )))
        );

        // Verify stats
        assert_eq!(audit_stats.sent_reset_stream_error_code(), -1);
        assert_eq!(
            audit_stats.sent_stop_sending_error_code(),
            CUSTOM_ERROR_CODE as i64
        );
    }

    /// Test that calling `H3Controller::shutdown_stream` with
    /// `StreamShutdown::Both` sends both RESET_STREAM and STOP_SENDING
    /// frames to the peer.
    #[test]
    fn server_shutdown_stream_both_directions() {
        use crate::http3::driver::StreamShutdown;
        const READ_ERROR_CODE: u64 = 0xAAAA;
        const WRITE_ERROR_CODE: u64 = 0xBBBB;

        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // client sends a request without fin
        let stream_id = helper
            .peer_client_send_request(make_request_headers("POST"), false)
            .unwrap();

        // server reads request
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        let audit_stats = req.h3_audit_stats.clone();

        // Server calls shutdown_stream with Both directions
        helper
            .controller
            .shutdown_stream(stream_id, StreamShutdown::Both {
                read_error_code: READ_ERROR_CODE,
                write_error_code: WRITE_ERROR_CODE,
            });

        helper.advance_and_run_loop().unwrap();

        // Client should see STOP_SENDING when trying to send
        assert_eq!(
            helper.peer_client_send_body(0, &[1, 2, 3], false),
            Err(h3::Error::TransportError(quiche::Error::StreamStopped(
                READ_ERROR_CODE
            )))
        );

        // Client should see RESET_STREAM when trying to receive
        assert_eq!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Reset(WRITE_ERROR_CODE)))
        );

        // Verify stats
        assert_eq!(
            audit_stats.sent_reset_stream_error_code(),
            WRITE_ERROR_CODE as i64
        );
        assert_eq!(
            audit_stats.sent_stop_sending_error_code(),
            READ_ERROR_CODE as i64
        );
    }

    /// Verify that a GOAWAY received from the client does not affect
    /// in-flight response streams. The client sends GOAWAY with push
    /// ID 0 (the only value currently supported, since server push is
    /// not implemented). The server should surface the GoAway event
    /// and continue sending response data normally.
    ///
    /// Per RFC 9114 Section 5.2, when a client sends GOAWAY, the ID
    /// is a push ID indicating the range of pushes the client will
    /// accept. Since server push is unimplemented, the client always
    /// sends 0.
    #[test]
    fn server_receiving_goaway_keeps_connection_intact() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client sends a request.
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), true)
            .unwrap();
        assert_eq!(stream_id, 0);

        // Server receives the request and starts a streaming response.
        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => { incoming_headers }
        );
        assert_eq!(req.stream_id, stream_id);
        let to_client = req.send.get_ref().unwrap().clone();
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client receives response headers.
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );

        // Server sends first body chunk.
        to_client
            .try_send(OutboundFrame::Body(
                Bytes::copy_from_slice(&[1; 10]),
                false,
            ))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client receives the first body chunk.
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![1; 10]));

        // Client sends GOAWAY with push ID 0 (graceful shutdown).
        helper.peer.send_goaway(&mut helper.pipe.client, 0).unwrap();
        helper.advance_and_run_loop().unwrap();

        // Server driver surfaces the GoAway event.
        loop {
            match helper.driver_recv_core_event().unwrap() {
                H3Event::GoAway { id } => {
                    assert_eq!(id, 0);
                    break;
                },
                H3Event::BodyBytesReceived { .. } => continue,
                H3Event::StreamClosed { .. } => continue,
                other => panic!("unexpected event: {other:?}"),
            }
        }

        // Server continues sending response body — the connection is
        // still alive.
        to_client
            .try_send(OutboundFrame::Body(
                Bytes::copy_from_slice(&[2; 10]),
                false,
            ))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client still receives the data.
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![2; 10]));

        // Server finishes the response.
        to_client
            .try_send(OutboundFrame::Body(Bytes::copy_from_slice(&[3; 10]), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client receives the final chunk and fin.
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(helper.peer_client_recv_body_vec(0, 1024), Ok(vec![3; 10]));
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));
    }

    // Test that dropping the H3 event receiver when there are no active streams
    // and datagram flows causes the connection to close immediately.
    #[test]
    fn h3_controller_drop_closes_connection_when_maps_empty() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();

        assert!(helper.driver.stream_map.is_empty());
        assert!(helper.driver.flow_map.is_empty());
        assert!(helper.pipe.server.local_error().is_none());

        // drop the controller to trigger receiver drop detection
        drop(helper.controller);

        // run wait_for_data to detect the receiver drop
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();

        // connection closed with H3 NoError
        let local_error = helper
            .pipe
            .server
            .local_error()
            .expect("connection should be closing");
        assert!(local_error.is_app, "should be application-level close");
        assert_eq!(
            local_error.error_code,
            h3::WireErrorCode::NoError as u64,
            "should close with H3 NoError"
        );
    }

    // Test that dropping the H3Controller when there are active streams/flows
    // does NOT close the connection immediately (e.g. tunnel scenarios).
    #[test]
    fn h3_controller_drop_keeps_connection_alive_when_streams_exist() {
        let mut helper =
            DriverTestHelper::<ServerHooks>::with_pipe_and_http3_settings(
                quiche::test_utils::Pipe::with_config_and_buf(
                    &mut default_quiche_config(),
                )
                .unwrap(),
                Http3Settings {
                    enable_extended_connect: true,
                    ..Default::default()
                },
            )
            .unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // CONNECT-UDP request creates both a stream and a datagram flow
        let connect_headers = vec![
            h3::Header::new(b":method", b"CONNECT-UDP"),
            h3::Header::new(b":scheme", b"https"),
            h3::Header::new(b":authority", b"quic.tech"),
            h3::Header::new(b":path", b"/"),
            h3::Header::new(b"datagram-flow-id", b"0"),
        ];
        helper
            .peer_client_send_request(connect_headers, false)
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // Consume events to keep channels alive
        assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Core(H3Event::NewFlow { .. })
        );
        assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers { .. }
        );

        assert_eq!(helper.driver.stream_map.len(), 1);
        assert_eq!(helper.driver.flow_map.len(), 1);

        drop(helper.controller);
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();

        // Connection stays open (stream and flow still active)
        assert!(helper.pipe.server.local_error().is_none());
    }

    /// Test that a CONNECT request with `:protocol` does NOT create a
    /// datagram flow when extended CONNECT is disabled.
    #[test]
    fn protocol_without_extended_connect_closes_on_controller_drop() {
        // Default settings have enable_extended_connect: false
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // CONNECT with :protocol, but extended CONNECT is disabled
        let connect_headers = vec![
            h3::Header::new(b":method", b"CONNECT"),
            h3::Header::new(b":scheme", b"https"),
            h3::Header::new(b":authority", b"quic.tech"),
            h3::Header::new(b":path", b"/"),
            h3::Header::new(b":protocol", b"webtransport"),
        ];
        helper
            .peer_client_send_request(connect_headers, true)
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        // No NewFlow event — flow was not created
        assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers { .. }
        );

        assert_eq!(helper.driver.stream_map.len(), 1);
        assert_eq!(helper.driver.flow_map.len(), 0);

        // Drop controller, then run wait_for_data
        drop(helper.controller);
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();

        // Connection closes because stream_map and flow_map are empty
        let local_error = helper
            .pipe
            .server
            .local_error()
            .expect("connection should be closing");
        assert!(local_error.is_app, "should be application-level close");
        assert_eq!(
            local_error.error_code,
            h3::WireErrorCode::NoError as u64,
            "should close with H3 NoError"
        );
    }

    /// Drop the event receiver with an open stream, then close the
    /// stream via client fin. Verify the connection closes.
    #[test]
    fn controller_drop_then_stream_close_triggers_connection_close() {
        let mut helper = DriverTestHelper::<ServerHooks>::new().unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // Client sends a request the stream stays open
        let stream_id = helper
            .peer_client_send_request(make_request_headers("GET"), false)
            .unwrap();

        helper.advance_and_run_loop().unwrap();
        let req = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Headers{incoming_headers, ..} => {
                incoming_headers
            }
        );
        assert_eq!(req.stream_id, stream_id);
        let to_client = req.send.get_ref().unwrap().clone();

        // Send response headers + body with fin
        to_client
            .try_send(OutboundFrame::Headers(make_response_headers(), None))
            .unwrap();
        helper.advance_and_run_loop().unwrap();
        to_client
            .try_send(OutboundFrame::Body(Bytes::from_static(b"ok"), true))
            .unwrap();
        helper.advance_and_run_loop().unwrap();

        assert_eq!(helper.driver.stream_map.len(), 1);

        // Drop the stream channels so cleanup_stream can remove
        // the stream from the map
        drop(to_client);
        drop(req);

        // Client reads response and sends fin to close the stream
        helper.advance_and_run_loop().unwrap();
        assert_matches!(
            helper.peer_client_poll(),
            Ok((0, h3::Event::Headers { .. }))
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Data)));
        assert_eq!(
            helper.peer_client_recv_body_vec(0, 1024),
            Ok(vec![111, 107])
        );
        assert_eq!(helper.peer_client_poll(), Ok((0, h3::Event::Finished)));

        // Drop the controller
        drop(helper.controller);
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();

        // Connection should NOT close yet (stream still open)
        assert!(helper.pipe.server.local_error().is_none());

        // Client sends fin to close the stream
        assert_eq!(
            helper
                .peer
                .send_body(&mut helper.pipe.client, 0, b"done", true,),
            Ok(4)
        );
        // One IO worker iteration: deliver client fin, process it,
        // and close the connection.
        helper.pipe.advance().unwrap();
        helper
            .driver
            .process_reads(&mut helper.pipe.server)
            .unwrap();
        helper
            .driver
            .process_writes(&mut helper.pipe.server)
            .unwrap();
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();

        assert_eq!(helper.driver.stream_map.len(), 0);

        // Now the connection should close with NoError
        let local_error = helper
            .pipe
            .server
            .local_error()
            .expect("connection should be closing");
        assert!(local_error.is_app, "should be application-level close");
        assert_eq!(
            local_error.error_code,
            h3::WireErrorCode::NoError as u64,
            "should close with H3 NoError"
        );
    }

    /// Drop the event receiver with an autonomous flow open (a flow
    /// with no associated stream), then shut down the flow. Verify
    /// the connection closes.
    #[test]
    fn controller_drop_then_autonomous_flow_shutdown_triggers_connection_close() {
        let mut config = default_quiche_config();
        config.enable_dgram(true, 100, 100);

        let mut helper =
            DriverTestHelper::<ServerHooks>::with_pipe_and_http3_settings(
                quiche::test_utils::Pipe::with_config_and_buf(&mut config)
                    .unwrap(),
                Http3Settings {
                    enable_extended_connect: true,
                    ..Default::default()
                },
            )
            .unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        // Peer sends an H3 datagram for a flow_id with no associated
        // CONNECT-UDP stream. Wire format: varint(flow_id) || payload.
        let flow_id: u64 = 8;
        let payload: &[u8] = b"hi";
        let prefix_len = octets::varint_len(flow_id);
        let mut wire = vec![0u8; prefix_len + payload.len()];
        {
            let mut enc = octets::OctetsMut::with_slice(&mut wire);
            enc.put_varint(flow_id).unwrap();
            enc.put_bytes(payload).unwrap();
        }
        helper.pipe.client.dgram_send(&wire).unwrap();

        // process_available_dgrams creates an autonomous flow and
        // emits NewFlow.
        helper.advance_and_run_loop().unwrap();

        let flow_send = assert_matches!(
            helper.driver_recv_server_event().unwrap(),
            ServerH3Event::Core(H3Event::NewFlow { send, .. }) => send
        );
        let flow_sender = flow_send.get_ref().unwrap().clone();

        assert!(helper.driver.stream_map.is_empty());
        assert_eq!(helper.driver.flow_map.len(), 1);

        // Drop the controller. closed() fires, sets the flag, but
        // flow_map is non-empty so no close yet.
        drop(helper.controller);
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();
        assert!(helper.pipe.server.local_error().is_none());

        // Send FlowShutdown via the per-flow channel.
        flow_sender
            .try_send(OutboundFrame::FlowShutdown {
                flow_id,
                stream_id: flow_id,
            })
            .unwrap();

        // wait_for_data picks up the frame and calls dgram_ready.
        // shutdown_stream returns early (no stream), so the close
        // gate in cleanup_stream is never invoked.
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();
        drop(flow_sender);
        drop(flow_send);

        assert!(helper.driver.stream_map.is_empty());
        assert!(helper.driver.flow_map.is_empty());

        // closed() is gated off; no other arm can drive a close.
        tokio::task::unconstrained(
            helper.driver.wait_for_data(&mut helper.pipe.server),
        )
        .now_or_never();

        let local_error = helper
            .pipe
            .server
            .local_error()
            .expect("connection should be closing");
        assert!(local_error.is_app, "should be application-level close");
        assert_eq!(
            local_error.error_code,
            h3::WireErrorCode::NoError as u64,
            "should close with H3 NoError"
        );
    }

    /// Verify that datagrams are silently dropped and no flow is
    /// created when extended connect is disabled.
    #[test]
    fn process_dgram_skips_flow_creation_when_extended_connect_disabled() {
        let mut config = default_quiche_config();
        config.enable_dgram(true, 100, 100);

        // Default settings have enable_extended_connect: false
        let mut helper =
            DriverTestHelper::<ServerHooks>::with_pipe_and_http3_settings(
                quiche::test_utils::Pipe::with_config_and_buf(&mut config)
                    .unwrap(),
                Http3Settings::default(),
            )
            .unwrap();
        helper.complete_handshake().unwrap();
        helper.advance_and_run_loop().unwrap();

        let flow_id: u64 = 8;
        let payload: &[u8] = b"hi";
        let prefix_len = octets::varint_len(flow_id);
        let mut wire = vec![0u8; prefix_len + payload.len()];
        {
            let mut enc = octets::OctetsMut::with_slice(&mut wire);
            enc.put_varint(flow_id).unwrap();
            enc.put_bytes(payload).unwrap();
        }
        helper.pipe.client.dgram_send(&wire).unwrap();

        helper.advance_and_run_loop().unwrap();

        // No flow should be created
        assert!(
            helper.driver.flow_map.is_empty(),
            "flow_map should remain empty when extended connect is disabled"
        );
    }
}
