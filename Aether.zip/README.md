# Aether

![Aether](Docs/Aether.png)

### اینترنت آزاد برای همه:))
**[راهنمای فارسی](README.fa.md)** · **[English Guide](Docs/DOCS.en.md)** · **[راهنمای کامل فارسی](Docs/DOCS.fa.md)**

Telegram: https://t.me/CluvexStudio

Aether is a censorship circumvention client designed for heavily restricted networks. It automatically discovers reachable routes, establishes an encrypted tunnel, and exposes a local SOCKS5 proxy for your applications.

Unlike traditional VPN clients, Aether is built for environments where Deep Packet Inspection (DPI), protocol fingerprinting, UDP throttling, and endpoint blocking are common.

## Features

- Automatic endpoint discovery, with end-to-end data-plane validation so a gateway is only trusted once it actually passes traffic, not just once it answers the handshake
- MASQUE (HTTP/3 & HTTP/2), with optional TLS ClientHello fragmentation on HTTP/2
- sunnyquic: your own sunnyquic server dialled from inside the MASQUE tunnel (`--sunny`), or directly (`sunny-direct`, declared `sunnyquic` outbounds); a sunnyquic server inbound too
- Traffic obfuscation
- sing-box compatible routing (rules, rule actions, remote `.srs` rule sets, sniffing, process rules), written in TOML
- System-wide TUN on Linux and Windows, with fake-ip DNS
- The WARP tunnel starts only when the config needs it, so a plain sunnyquic server never registers or scans
- Upstream proxy support, so Aether can dial out through another VPN or proxy already running on the machine
- Automatic reconnection, and quick-reconnect to your last known-good gateway to skip rescanning
- Local SOCKS5 / HTTP / mixed proxies
- One TOML config file (`--config`, default `aether.toml`), command-line flags, environment variables, or interactive prompts — your choice
- Linux, Windows, macOS and Android (Termux)

## Download

Prebuilt binaries are on the [Releases](https://github.com/CluvexStudio/Aether/releases/latest) page. Pick the archive that matches your system:

| System | Archive |
| --- | --- |
| Windows x86_64 | `aether-windows-x86_64.zip` |
| macOS on Apple Silicon (M1 and later) | `aether-macos-arm64.tar.gz` |
| macOS on Intel | `aether-macos-x86_64.tar.gz` |
| Linux x86_64 / arm64 / armv7 (glibc 2.34 or newer) | `aether-linux-x86_64.tar.gz`, `aether-linux-arm64.tar.gz`, `aether-linux-armv7.tar.gz` |
| Linux with musl or an older glibc, fully static | `aether-linux-x86_64-musl.tar.gz`, `aether-linux-aarch64-musl.tar.gz`, `aether-linux-armv7-musl.tar.gz` |
| OpenWrt routers | the `-musl` archive for the router's CPU, see [OpenWrt](#openwrt) |
| Android (Termux) | the installer below |

Every archive has a matching `.sha256` file, and `SHA256SUMS.txt` lists them all. On a Mac, `uname -m` prints `arm64` or `x86_64`. The macOS binaries are not notarized, so clear the download quarantine once after extracting:

```bash
tar -xzf aether-macos-x86_64.tar.gz
xattr -d com.apple.quarantine aether
./aether
```

### Termux (Android) — one-line install

```bash
curl -fsSL https://raw.githubusercontent.com/CluvexStudio/aether/main/aether.sh -o aether.sh && chmod +x aether.sh && ./aether.sh install
```

This detects your device architecture, downloads the matching release, verifies its checksum, and installs `aether` into `$PREFIX/bin`. Run it afterwards with:

```bash
aether
```

To update later, run `./aether.sh update`. To remove it, run `./aether.sh uninstall`.

### OpenWrt

Aether runs on OpenWrt as a single static binary of 7 to 10 MB. Choose the archive by the output of `uname -m`:

| `uname -m` | Typical routers | Archive |
| --- | --- | --- |
| `aarch64` | MediaTek MT7981/MT7986 (e.g. Xiaomi AX3000T), Qualcomm IPQ807x, Raspberry Pi 4/5 | `aether-linux-aarch64-musl.tar.gz` |
| `armv7l` | Qualcomm IPQ40xx (e.g. Google Wifi), MediaTek MT7623, other Cortex-A7/A9/A15 boards | `aether-linux-armv7-musl.tar.gz` |
| `x86_64` | x86 mini PCs and VMs | `aether-linux-x86_64-musl.tar.gz` |

MIPS routers (`mips`/`mipsel`, e.g. MT7621) are not supported.

```sh
cd /tmp
A=aether-linux-aarch64-musl.tar.gz
wget https://github.com/CluvexStudio/Aether/releases/latest/download/$A
wget https://github.com/CluvexStudio/Aether/releases/latest/download/$A.sha256
sha256sum -c $A.sha256 && tar -xzf $A && mv aether /usr/bin/aether
mkdir -p /etc/aether
aether --config /etc/aether/aether.toml
```

Keep `--config` on persistent storage such as `/etc/aether`: `/tmp` is wiped at every reboot, and a lost identity means a new device registration on each boot, which Cloudflare rate limits. To share the proxy with your LAN, bind it to the router's LAN address, for example `--bind 192.168.1.1:1819`; it has no authentication, so never expose it on the WAN. If `wget` reports an SSL error, run `opkg update && opkg install ca-bundle`, or copy the file over with `scp`.

If the router also sends its own traffic into a tun front end (hev-socks5-tunnel, tun2socks), start Aether with `--mark 0xff` so every socket it opens to the internet carries that firewall mark, and let marked packets bypass the tun, for example with `ip rule add fwmark 0xff lookup main priority 100`. Setting a mark needs root.

## Build

### Requirements

- Rust 1.98 or newer
- C/C++ compiler
- CMake

The `quiche` repository must be placed alongside `aether`:

```text
<repo>/
  aether/
  quiche/
```

Build from the repository root; the Cargo manifest is `aether/Cargo.toml`, so enter that directory first:

```bash
cd aether
cargo build --release
```

Binary, relative to the repository root:

```text
aether/target/release/aether
```

## Docker

You can run Aether in an isolated environment using Docker. The official image is available on GitHub Container Registry (GHCR).

> **The SOCKS5 proxy has no authentication.** Anyone who can reach the port can use your tunnel. Every command below publishes the port to `127.0.0.1` only, so it stays reachable from your own machine and nothing else. Do not replace it with `-p 1819:1819`, because that form listens on every interface of the host and turns the proxy into an open relay. If you genuinely need to serve other machines, put an authenticated front end in front of it and firewall the port.

The `-v aether-data:/data` volume keeps the generated WARP identity between runs. Without it every start registers a brand new device, and Cloudflare begins rate limiting your address.

Pull and run the pre-built image (interactive mode is required for initial setup):

```bash
docker run -it -p 127.0.0.1:1819:1819 -v aether-data:/data ghcr.io/cluvexstudio/aether:latest
```

You can also bypass prompts by providing environment variables:

```bash
docker run -it -p 127.0.0.1:1819:1819 -v aether-data:/data \
  -e AETHER_PROTOCOL=masque \
  -e AETHER_SCAN=balanced \
  ghcr.io/cluvexstudio/aether:latest
```

If you prefer to build the image manually from source:

```bash
docker build -t aether .
docker run -it -p 127.0.0.1:1819:1819 -v aether-data:/data aether
```

## Usage

The examples below use the binary you built, run from inside `aether/`. With a release download, run `./aether` (or `aether.exe` on Windows) from the folder you extracted it to instead.

Run with no arguments and answer the prompts:

```bash
./target/release/aether
```

Or skip the prompts with flags:

```bash
./target/release/aether --masque -4 --scan turbo --noize firewall
```

On Windows, double-click `run-aether.bat` (included in the release zip) instead — it opens a terminal, runs `aether.exe`, and keeps the window open afterwards so you can read any errors.

Every prompt has a flag and an environment variable equivalent. Run `aether help` (or `--help`) for the full list — every flag, every variable, and what each one does — or see the guides linked below.

After startup, a SOCKS5 proxy will be available at:

```
127.0.0.1:1819
```

Example:

```bash
curl -x socks5h://127.0.0.1:1819 https://www.cloudflare.com/cdn-cgi/trace
```

## Supported Protocols

### MASQUE (Recommended)

Encapsulates traffic over HTTP/3 (QUIC) or HTTP/2 (TLS), making it resemble ordinary HTTPS traffic.

### sunnyquic over MASQUE (`--sunny`)

Your own sunnyquic server, reached from inside the MASQUE tunnel: your network sees only WARP, and traffic leaves from your server.

The sunnyquic protocol (client and server) is built into Aether (`aether/src/proxy/sunnyquic/`, ported from [shadowquic](https://github.com/spongebob888/shadowquic), MIT) and is wire-compatible with shadowquic's own sunnyquic client and server, so either side can be the upstream program.

```bash
./target/release/aether --sunny-server sq.example.com:443 --sunny-user alice --sunny-password 'PASSWORD'
```

## Configuration file

Everything can live in one TOML file, `--config` (default `aether.toml`): the WARP identity Aether registers and keeps up to date (written at the top, keeping your own tables and comments), `[sunny]` for the sunnyquic client, and `[[inbounds]]`, `[[outbounds]]`, `[route]` and `[dns]` with sing-box's field names. `--route-config` takes a second `.toml` file whose routing tables replace those of `--config`. JSON configs are not read.

```toml
[sunny]
server = "203.0.113.7:8443"
username = "alice"
password = "PASSWORD"
server_name = "www.bing.com"
ca = "cert.pem"

[route]
final = "proxy"

[[route.rules]]
ip_is_private = true
outbound = "direct"
```

A plain sunnyquic server that never starts WARP:

```toml
[[inbounds]]
type = "sunnyquic"
tag = "sunnyquic-inbound"
listen = "0.0.0.0"
listen_port = 8443
users = [{ name = "1114", password = "314" }]
tls = { server_name = "www.bing.com", certificate_path = "./cert.pem", key_path = "./key.pem", alpn = ["h3"] }

[route]
final = "direct"
```

```bash
./aether --config server.toml
```

Examples: [Docs/examples/](Docs/examples/). The full Chinese guide is [Docs/USAGE.zh.md](Docs/USAGE.zh.md).

## Documentation

Detailed documentation is available in:

- [Docs/GUIDE.en.md](Docs/GUIDE.en.md) — English guide
- [Docs/GUIDE.fa.md](Docs/GUIDE.fa.md) — راهنمای فارسی
- [Docs/USAGE.zh.md](Docs/USAGE.zh.md) — 中文完整指南（sunnyquic、TOML 配置、路由、TUN）

## Credits

Developed by **CluvexStudio**. :))

MASQUE support is built on top of Cloudflare's **Quiche** library.

The sunnyquic protocol is ported from **shadowquic** by spongebob888 (MIT); see `aether/src/proxy/sunnyquic/LICENSE-shadowquic`.


## Contributing

> **Experienced network developers and protocol engineers are welcome to contribute.**

> **Please keep the codebase clean, maintainable, and well-engineered. Low-quality or vibe-coded contributions will not be accepted.**

## Donate

If Aether has been useful to you, consider supporting its development:

- **TRX (Tron):** `TRxVSHcoADZnBfztFmFb2TQopusAwWYEVR`
- **BTC:** `bc1qnjnvzsa5avgj7n0uy383cv5zdxfjnvvp257egm`
- **TON:** `UQAH75bXaaRUhZMwiF0ZujOXFDDmvLSPASKoOsWF0HNasiaM`

## License

See the LICENSE file for licensing information.
