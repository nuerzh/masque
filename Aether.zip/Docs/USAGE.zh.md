---
title: "Aether（sunnyquic 版）使用指南"
subtitle: "WARP MASQUE、sunnyquic 客户端 / 服务端、sing-box 兼容路由、系统级 TUN；全部配置写在一个 YAML 文件里"
date: "2026-10-22"
---

# 1. 概览

这一版 Aether 只保留 **Cloudflare WARP MASQUE**（HTTP/3，或 `masque: { http2: true }` 的 HTTP/2）这一种 WARP 传输，在它之上加了：

- **sunnyquic 客户端**（[shadowquic](https://github.com/spongebob888/shadowquic) 的 sunnyquic 协议，QUIC + TLS 1.3 + 用户名/密码；协议由 Aether 自己实现，移植自 shadowquic，与上游客户端 / 服务端互通）：
  - `sunny`（`protocol: sunny`，下文称 **sunny 模式**）：**默认直连**——sunnyquic 的 QUIC 包从本机 UDP 直接发往你的服务器（开 TUN 时绑物理网卡），不需要 WARP，不触发扫描 / 提示 / 注册；`sunny` 段写 `detour: warp` 时改为在 WARP 隧道的用户态网络栈里发出——你的网络只看到 WARP，出口是你自己的服务器（即 2026-10-20 之前 sunny 模式的唯一行为）；
  - `sunny-direct` 与配置里声明的 `type: sunnyquic` 出站：QUIC 从本机直接发往服务器（`detour: direct`），或跑在 WARP 里（`detour: warp`）。
- **sunnyquic 服务端入站**：Aether 自己就能当 sunnyquic 服务器，收到的连接按路由走任意出站。
- **sing-box 兼容的路由**：规则、规则动作、`.srs` 远程规则集、嗅探、进程规则，字段名与 sing-box 1.14 相同，只是**写成 YAML**。
- **系统级 TUN**（`tun: { enabled: true }` 或 `type: tun` 入站，Linux / Windows），默认 fake-ip。
- **WARP 按需启动**：配置里没有东西需要 WARP 时（例如纯 sunnyquic 服务端），不扫描、不注册、不建隧道。

已经**删除**的旧模式：psiphon、tor、WireGuard（含 gool / warp-in-warp）、masque-in-masque（`--mim`），以及它们的参数、菜单项和出站。`protocol` 只接受 `masque` 和 `sunny`。

**命令行参数与 `AETHER_*` 环境变量都已取消**：每个选项都是配置文件里的一个键（第 2 章），命令行只剩 `-c <文件>` 和 `register`、`tun-cleanup`、`help`、`version` 几个命令；只有 `RUST_LOG` 仍然有效。

sunny 模式的流量路径（默认 `detour: direct`）：

```text
应用（浏览器 / curl / ...）
  │  SOCKS5 127.0.0.1:1819（bind）、http-proxy、配置里的入站、或 TUN
  ▼
Aether 入站 → 路由 → sunny 出站
  │  sunnyquic 客户端在进程内，QUIC 从本机 UDP socket 发出（开 TUN 时绑物理网卡，不进 TUN）
  ▼
你的 sunnyquic 服务器 ──► 互联网（出口 IP = 你的服务器）
```

`detour: warp` 时：

```text
Aether 入站 → 路由 → sunny 出站
  │  sunnyquic 客户端的 UDP socket 是 WARP 隧道网络栈上的 socket（本机不开任何中转端口）
  ▼
WARP MASQUE 隧道（HTTP/3 或 HTTP/2）   ← 你的网络只看得到这一段
  ▼
Cloudflare WARP 出口 ──UDP──► 你的 sunnyquic 服务器 ──► 互联网（出口 IP = 你的服务器）
```

要点：

- 走 `sunny` 的连接，发给服务器的是**域名**（socks5h / fake-ip），由服务器解析，本机不做 DNS 查询。
- `sunny` 段的 `server` 写域名时：直连模式用本机解析器解析（与 `sunny-direct` 相同，开 TUN 时走 `tun.direct-dns`）；`detour: warp` 时在 WARP 隧道内解析（`tunnel-dns`，默认 1.1.1.1、1.0.0.1），不在本地网络泄露。
- `detour: warp` 时外层重连本地监听端口不变，sunnyquic 客户端的 socket 自动挂到新隧道上。
- 出站是**严格**的：`sunny` 只会是 sunnyquic，`warp` 只会是 WARP，出站不可用时连接失败，绝不悄悄换成别的出站。

# 2. 配置文件（YAML）

## 2.1 命令行

命令行只剩下面这些：

```text
aether [-c <文件>]                按配置文件运行
aether [-c <文件>] register       注册 WARP MASQUE 身份后退出（不扫描、不建隧道；
                                  WARP 在该身份上启用成功后才保存，已有身份时保留不动）
aether [-c <文件>] tun-cleanup    清理被强杀的 TUN 运行留下的路由、规则、防火墙和网卡，然后退出
aether help                       显示帮助（含全部配置键概览）
aether version                    显示版本
```

- `-c` / `--config <文件>`：配置文件，YAML，**默认当前目录的 `aether.yaml`**。**文件不存在 = 全部选项取默认值**。`-c` 可以和命令写在任意顺序（`aether tun-cleanup -c y.yaml` 也行）。`-h` / `--help`、`-v` / `--version` 与 `help`、`version` 相同。
- 原来的 `--register masque` 改为命令 `register`，`--tun-cleanup` 改为命令 `tun-cleanup`。
- **其它旧参数写在命令行上会报错**，并提示它在配置文件里的写法，例如：

```text
$ ./aether --max-rtt 500
--max-rtt is no longer a command-line option: write it in the config file (-c, default aether.yaml) as
    scan: { max-rtt: 500 }
(aether help lists every key)
```

  完整对照见第 2.4 节。`--quick-reconnect` / `--no-quick-reconnect` 报「已删除」，`--route-block` / `--route-direct` / `--routes` 报「请改写成 route 规则」（第 9.1 节）。
- **所有 `AETHER_*` 环境变量都不再读取**（包括原来的 `AETHER_CONFIG`）。只有 `RUST_LOG` 仍有效，并优先于 `log-level`。
- 启动后用下面的命令检查代理：

```bash
curl -x socks5h://127.0.0.1:1819 https://www.cloudflare.com/cdn-cgi/trace
```

## 2.2 一个文件写全部

所有配置都写在这一个 YAML 文件里。顶层结构：

| 顶层 | 内容 | 谁写 |
|---|---|---|
| 选项键：`log-level`、`bind`、`protocol`……；选项段：`scan`、`masque`、`tls`、`zero-trust`、`tun`、`advanced` | 运行选项（原来的命令行参数和 `AETHER_*` 环境变量），见第 2.3 节 | 你 |
| `device_id`、`access_token`、`cert_pem`、`key_pem`、`cert_issued_at`、`ipv4`、`ipv6`、`wg_private_key`、`wg_peer_public_key`、`client_id`、`organization`、`gateway_proxy`、`assigned_endpoint` | WARP MASQUE 身份（顶层键，追加在文件末尾） | **Aether 自己**：第一次需要 WARP 时注册并写入，证书刷新时更新（第 2.5 节） |
| `sunny` | 内置 sunnyquic 客户端（`sunny`、`sunny-direct`）的设置，键同 `sunny-config` 文件（第 5 章） | 你 |
| `inbounds` | 额外的入站：`mixed`、`socks`、`http`、`tun`、`sunnyquic`（第 11 章） | 你 |
| `outbounds` | 自定义出站标签、`sunnyquic` 出站（第 9.2、11.4 节） | 你 |
| `route` | `final`、`default_domain_resolver`、`find_process`，以及 `rules`、`rule_set` 列表（第 9 章） | 你 |
| `dns` | 只读 `servers` 里各服务器的 `tag` / `type` / `address` / `detour`，用来判断 `resolve` 动作的 `server` 是不是本机解析 | 你 |

说明：

- **键名里 `-` 和 `_` 等价**（`max-rtt` 与 `max_rtt` 是同一个键；同一个键两种写法都写了会报错）。**列表**可以写成 YAML 列表 `[a, b]`，也可以写成逗号分隔的字符串 `"a,b"`。
- 选项段也可以只写一个布尔值：`tun: true` 等同 `tun: { enabled: true }`。
- **注意两个容易混的名字**：隧道内解析器的选项叫 `tunnel-dns`（原 `--dns`），因为顶层的 `dns` 是 sing-box 的 dns 段。
- **`exit-loc` 以 `!` 开头时必须加引号**（`exit-loc: "!IR,AZ"`）：`!` 在 YAML 里是标签记号。
- `inbounds`、`outbounds`、`route`、`dns` 的字段名、取值与 sing-box 相同（`listen_port`、`domain_suffix`、`download_detour`……），sing-box 的 JSON 逐字段写成 YAML 即可（第 2.8 节）。
- 选项段里写了不存在的键（如 `scan: { maxrtt: 5 }`）或值的类型不对（布尔键写了 `perhaps`、`scan.rounds: 0`、`warp-tunnel: maybe`……）时**启动即报错**，并列出该段可用的键。顶层不认识的键、`log`、`experimental`、`ntp`、`endpoints`、`services`、`certificate`、`providers` 这些 Aether 用不上的 sing-box 段落只记警告后忽略。
- **相对路径**：
  - 选项里的路径（`route-config`、`sunny-config`、`masque-config`、`route-cache-dir`）相对于**配置文件所在目录**；
  - 证书、`key_path`、本地规则集的 `path`、`initial_path` 相对于**它们所在文件**（主配置或 `route-config` 文件）的目录；
  - `sunny` 段的 `ca`：先按当前目录找，找不到再按配置文件目录。
- **JSON 配置不再读取**：`route-config` 指向 `.json` 文件时启动即报错并说明怎么改。
- 配置有错（YAML 语法错、未知出站标签、引用不存在的规则集、证书文件不存在、正则写错……）时**启动即退出**，报出文件名和位置，不会带着错误配置悄悄运行。
- 远程规则集仍然是 sing-box 发布的 `.srs`（二进制）或 `.json`（source 格式）——那是别人发布的数据，不是 Aether 的配置；**本地**规则集可以写成 `.yaml`（第 9.6 节）。
- 随文档附带的示例：`client-full.yaml`（完整客户端）、`server.yaml`（纯 sunnyquic 服务端）、`route.yaml`（第 9.8 节）、`tun-route.yaml`（第 10.5 节）。

一个最小的客户端配置：

```yaml
log-level: info
bind: 127.0.0.1:1819
scan:
  max-rtt: 800
masque:
  noize: firewall
```

## 2.3 完整键参考

「不写」表示该键缺省时的行为。布尔键写 `true` / `false`（也收 `0` / `1`）。

**顶层选项**

| 键 | 默认 | 说明 |
|---|---|---|
| `log-level` | `info` | `error` / `warn` / `info` / `debug` / `trace`；`RUST_LOG` 优先 |
| `perf` | 自动检测 | `low` / `medium` / `high`，性能档位 |
| `protocol` | 见说明 | `masque` / `sunny`（也收 `sunnyquic`）。不写时：`sunny` 段（或 `sunny-config` 文件）有 `server` 即 sunny 模式；写了 `masque.peer` 即 `masque`；否则有终端时弹出协议菜单（第 5.3 节），无终端时为 `masque` |
| `bind` | `127.0.0.1:1819` | SOCKS5 监听，入站 tag `socks` |
| `http-proxy` | 不开 | 另开 HTTP CONNECT 代理（如 `127.0.0.1:1820`），入站 tag `http` |
| `upstream` | 无 | 经本机已有的代理出去，如 `socks5://127.0.0.1:1080` |
| `mark` | TUN 下 `0x6165` | 所有出网 socket 的 `SO_MARK`（Linux / Android），写数字如 `255` 或 `0xff` |
| `ip` | `v4` | 扫描的 IP 版本：`v4` / `v6` / `both`（也收 `4` / `6` / `dual`）；不写且需要扫描时，有终端会询问 |
| `tunnel-dns` | `[1.1.1.1, 1.0.0.1]` | WARP 隧道内的解析器（原 `--dns`；顶层 `dns` 是 sing-box 的 dns 段） |
| `stats` | `false` | 每 `stats-secs` 秒记录流量与运行时间 |
| `stats-secs` | `60` | |
| `exit-loc` | 无 | `"!IR,AZ"`：拒绝这些国家的出口；`DE,SE`：只要这些。以 `!` 开头必须加引号 |
| `exit-loc-secs` | `60` | 出口检查间隔 |
| `warp-tunnel` | `auto` | `auto` / `on` / `off`：是否启动 WARP（第 11.3 节） |
| `route-config` | 无 | 另一个 YAML 文件，用它的 `inbounds` / `outbounds` / `route` / `dns` 代替本文件的（第 2.6 节） |
| `route-cache-dir` | Linux `~/.cache/aether/rule-sets`；Windows `%LOCALAPPDATA%\aether\rule-sets` | 远程规则集缓存目录 |
| `masque-config` | 无（身份写在本文件） | 把 MASQUE 身份放在这个文件 |
| `sunny-config` | 无（读本文件的 `sunny` 段） | sunnyquic 客户端设置从这个文件读 |
| `api-address` | API 自己的域名:443 | WARP API 调用连接到哪里，如 `188.114.97.6:443`；只改连接地址，ClientHello 与 HTTP Host 仍是 API 域名 |

**`scan`：网关扫描（第 15 章）**

| 键 | 默认 | 说明 |
|---|---|---|
| `scan.mode` | `balanced` | `turbo` / `balanced` / `thorough` / `verified`（别名 `stealth`）/ `ironclad` |
| `scan.ports` | `[500, 1701, 4500, 4443, 8443, 8095, 443]` | 扫描端口 |
| `scan.max-rtt` | `500` | 最高延迟（毫秒，完整校验总耗时），可写 `500`、`"500ms"`；`0` = 不限制 |
| `scan.rounds` | `3` | 扫描轮数 1–10 |
| `scan.switch` | `true` | 先启动、后台继续扫描、更快就热切换；`false` = 扫完再选 |
| `scan.prefilter` | `true` | 完整握手之前的快筛 |
| `scan.ironclad-port` | `80` | ironclad 模式真实 HTTP 探测用的端口 |

**`masque`：WARP MASQUE**

| 键 | 默认 | 说明 |
|---|---|---|
| `masque.http2` | 不写 | `true` = HTTP/2（TCP），`false` 或不写 = HTTP/3；只由配置决定，lastconn 不参与，第 11.3 节 |
| `masque.peer` | 无 | 固定网关 `ip:port`，不扫描 |
| `masque.h2-peer` | 同所选网关 | HTTP/2 承载单独指定的网关 |
| `masque.sni` | `www.cloudflare.com` | MASQUE 握手的 SNI（只能是域名） |
| `masque.noize` | `firewall` | `off` / `light` / `firewall` / `balanced` / `gfw` / `aggressive` |
| `masque.quic-v2` | `true` | QUIC v2 版本协商开场包 |
| `masque.data-check` | `true` | 端到端数据面检查 |
| `masque.validate-secs` | `10` | |
| `masque.startup-secs` | `30` | |
| `masque.reconnect-secs` | `2` | |
| `masque.mtu` | 自动（HTTP/3 1280，HTTP/2 1500） | 隧道 MTU，576–1500 |
| `masque.fragment` | `false` | 对 HTTP/2 与 WARP API 的 ClientHello 分片 |
| `masque.fragment-size` | `8-16` | |
| `masque.fragment-delay` | `2-10` | |
| `masque.fragment-sni` | `false` | 分片时在 SNI 处切开 |
| `masque.h2-keepalive-secs` | `15` | |
| `masque.h2-keepalive-timeout-secs` | `20` | |
| `masque.reprovision` | `true` | 已保存的身份被服务器拒绝时注册新身份替换；`false` = 不替换 |

**`tls`**

| 键 | 默认 | 说明 |
|---|---|---|
| `tls.ciphers` | 内置 | 如 `"ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256"` |
| `tls.groups` | 内置 | 如 `"P-256:X25519:P-384"` |
| `tls.grease` | `true` | `false` = 关闭 GREASE |
| `tls.ech` | 不用 | `auto` 或 base64 的 ECHConfigList；**只用于 WARP API 调用** |
| `tls.ech-dns` | 内置 | ECH 查询用的解析器，如 `udp://1.1.1.1` |
| `tls.ech-domain` | 内置 | 如 `cloudflare-ech.com` |
| `tls.verify` | `false` | 开启 TLS 证书校验 |

**`zero-trust`**

| 键 | 默认 | 说明 |
|---|---|---|
| `zero-trust.team` | 无 | 团队（组织）名 |
| `zero-trust.access-id` / `access-secret` | 无 | Access 服务令牌 |
| `zero-trust.access-token` | 无 | |
| `zero-trust.access-email` | 无 | |
| `zero-trust.gateway` | `false` | |

**`tun`：系统级 TUN（第 10 章；`tun: true` 等同 `tun: { enabled: true }`）**

| 键 | 默认 | 说明 |
|---|---|---|
| `tun.enabled` | `false` | 整机流量经 TUN 网卡 |
| `tun.name` | Linux `aether-tun`，Windows `Aether` | |
| `tun.address` | `[172.19.0.1/30, fdfe:dcba:9876::1/126]` | 无 IPv6 默认路由时只用 IPv4 |
| `tun.mtu` | `9000` | |
| `tun.dns` | `172.19.0.2` | 系统 DNS 指向的地址；`off` 不改 |
| `tun.auto-route` | `true` | |
| `tun.strict-route` | `false` | 局域网也进 TUN + 防泄漏防火墙（nftables / WFP） |
| `tun.include` / `tun.exclude` | 全部 / 无 | 进 / 不进 TUN 的网段 |
| `tun.dns-hijack` | `true` | 劫持进入 TUN 的 53 端口 |
| `tun.fakeip` | `true` | |
| `tun.fakeip-range` | `[198.18.0.0/15, fc00::/18]` | |
| `tun.direct-dns` | `system` | `system` / `tunnel` / 解析器列表（如 `223.5.5.5,119.29.29.29`） |
| `tun.allow-lan` | `true` | `false` = 不放行局域网（Windows 严格模式，原 `--tun-block-lan`） |
| `tun.table` | `1819` | Linux 策略路由表 |
| `tun.rule-priority` | `9180` | Linux 策略路由规则起始优先级 |

**`advanced`**

| 键 | 默认 | 说明 |
|---|---|---|
| `advanced.route-sniff` | `true` | 自动嗅探（第 9.5 节） |
| `advanced.route-sniff-ms` | `400` | |
| `advanced.route-wait` | `45`（秒） | 首次启动、规则集还没缓存时新连接最多等多久 |
| `advanced.max-clients` | 按性能档位 | 同时服务的客户端连接上限 |
| `advanced.half-close-secs` | `30` | 半关闭连接多久后结束 |
| `advanced.tcp-keepalive-secs` | `60` | |
| `advanced.tcp-connect-secs` | `30` | |
| `advanced.netstack-tcp-rx` / `netstack-tcp-tx` | 按性能档位 | 用户态协议栈 TCP 缓冲（字节，16 KiB–64 MiB） |

**`sunny`：内置 sunnyquic 客户端**（键表见第 5 章）：`server`、`username`、`password`、`server-name`、`alpn`、`ca`、`congestion-control`、`zero-rtt`、`over-stream`、`initial-mtu`、`min-mtu`、`mtu-discovery`、`keep-alive-interval`、`gso`、`cipher-suite-preference`、`handshake-secs`、`data-check`、`detour`。

**`inbounds`、`outbounds`、`route`（`rules`、`rule_set`、`final`、`default_domain_resolver`）、`dns`**：sing-box 字段名，YAML 写法（第 9、11 章）。

## 2.4 旧命令行参数 → 新键

旧参数在命令行出现会报错并给出下表右栏的写法（`a | b` 表示二选一）。`scan: { max-rtt: 500 }` 这种流式写法与块写法等价：

```yaml
scan:
  max-rtt: 500
```

| 旧参数 | 新写法 |
|---|---|
| `--config` / `-c` | 仍是 `-c <文件>`（默认 `aether.yaml`） |
| `--register masque` | 命令 `aether register` |
| `--tun-cleanup` | 命令 `aether tun-cleanup` |
| `--log-level` | `log-level: info` |
| `--verbose` | `log-level: debug` |
| `--perf` | `perf: low \| medium \| high` |
| `--bind` | `bind: 127.0.0.1:1819` |
| `--http-proxy` | `http-proxy: 127.0.0.1:1820` |
| `--upstream` | `upstream: socks5://127.0.0.1:1080` |
| `--mark` | `mark: 0xff` |
| `-4` / `-6` / `--dual` / `--ip` | `ip: v4` / `ip: v6` / `ip: both` |
| `--dns` | `tunnel-dns: [1.1.1.1, 1.0.0.1]` |
| `--stats` / `--stats-secs` | `stats: true` / `stats-secs: 60` |
| `--exit-loc` / `--exit-loc-secs` | `exit-loc: "!IR,AZ"` / `exit-loc-secs: 60` |
| `--warp-tunnel` | `warp-tunnel: auto \| on \| off` |
| `--no-warp` | `warp-tunnel: off` |
| `--route-config` | `route-config: route.yaml` |
| `--route-cache-dir` | `route-cache-dir: ...` |
| `--masque-config` | `masque-config: warp.yaml` |
| `--api-address` | `api-address: 188.114.97.6:443` |
| `--masque` | `protocol: masque` |
| `--sunny` / `--sunnyquic` | `protocol: sunny` |
| `--protocol` | `protocol: masque \| sunny` |
| `--sunny-server` | `sunny: { server: "host:port" }`（及 `protocol: sunny`） |
| `--sunny-user` / `--sunny-username` | `sunny: { username: ... }` |
| `--sunny-password` / `--sunny-pass` | `sunny: { password: ... }` |
| `--sunny-sni` / `--sunny-server-name` | `sunny: { server-name: ... }` |
| `--sunny-alpn` | `sunny: { alpn: [h3] }` |
| `--sunny-ca` / `--sunny-cert` | `sunny: { ca: ca.pem }` |
| `--sunny-cc` / `--sunny-congestion` | `sunny: { congestion-control: bbr }` |
| `--sunny-zero-rtt` / `--sunny-no-zero-rtt` | `sunny: { zero-rtt: true }` / `sunny: { zero-rtt: false }` |
| `--sunny-udp-over-stream` | `sunny: { over-stream: true }` |
| `--sunny-mtu` / `--sunny-min-mtu` | `sunny: { initial-mtu: 1250 }` / `sunny: { min-mtu: 1200 }` |
| `--sunny-mtu-discovery` | `sunny: { mtu-discovery: true }` |
| `--sunny-keepalive` | `sunny: { keep-alive-interval: 10000 }` |
| `--sunny-handshake-secs` | `sunny: { handshake-secs: 15 }` |
| `--sunny-no-data-check` | `sunny: { data-check: false }` |
| `--sunny-config` | `sunny-config: sunny.yaml` |
| `--sunny-detour` | `sunny: { detour: direct \| warp }` |
| `--scan` / `--balanced` | `scan: { mode: balanced }` |
| `--turbo` / `--thorough` / `--ironclad` | `scan: { mode: turbo }` / `thorough` / `ironclad` |
| `--verified` / `--stealth` | `scan: { mode: verified }` |
| `--scan-ports` | `scan: { ports: [500, 1701, 4500] }` |
| `--no-prefilter` | `scan: { prefilter: false }` |
| `--max-rtt` / `--scan-max-rtt` | `scan: { max-rtt: 500 }` |
| `--scan-rounds` | `scan: { rounds: 3 }` |
| `--no-scan-switch` / `--scan-switch` | `scan: { switch: false }` / `scan: { switch: true }` |
| `--peer` | `masque: { peer: "ip:port" }` |
| `--h2` / `--http2` | `masque: { http2: true }` |
| `--h3` / `--quic` | `masque: { http2: false }` |
| `--h2-peer` | `masque: { h2-peer: "ip:port" }` |
| `--masque-sni` | `masque: { sni: www.cloudflare.com }` |
| `--noize` | `masque: { noize: firewall }` |
| `--no-quic-v2` | `masque: { quic-v2: false }` |
| `--no-data-check` | `masque: { data-check: false }` |
| `--validate-secs` / `--startup-secs` / `--reconnect-secs` | `masque: { validate-secs: 10 }` / `startup-secs: 30` / `reconnect-secs: 2` |
| `--fragment` / `--fragment-size` / `--fragment-delay` | `masque: { fragment: true }` / `fragment-size: 8-16` / `fragment-delay: 2-10` |
| `--ech` / `--ech-dns` / `--ech-domain` | `tls: { ech: auto }` / `tls: { ech-dns: udp://1.1.1.1 }` / `tls: { ech-domain: cloudflare-ech.com }` |
| `--tls-ciphers` / `--tls-groups` | `tls: { ciphers: ... }` / `tls: { groups: "P-256:X25519:P-384" }` |
| `--disable-grease` | `tls: { grease: false }` |
| `--tls-verify` | `tls: { verify: true }` |
| `--team` / `--organization` | `zero-trust: { team: ... }` |
| `--access-id` / `--access-secret` / `--access-token` / `--access-email` | `zero-trust: { access-id: ... }` 等同名键 |
| `--gateway` | `zero-trust: { gateway: true }` |
| `--tun` | `tun: { enabled: true }`（或 `tun: true`） |
| `--tun-name` / `--tun-address` / `--tun-mtu` / `--tun-dns` | `tun: { name: aether-tun }` / `address: [172.19.0.1/30]` / `mtu: 9000` / `dns: 172.19.0.2` |
| `--tun-auto-route` / `--no-tun-auto-route` | `tun: { auto-route: true }` / `tun: { auto-route: false }` |
| `--tun-strict-route` | `tun: { strict-route: true }` |
| `--tun-include` / `--tun-exclude` | `tun: { include: [10.0.0.0/8] }` / `tun: { exclude: [192.168.0.0/16] }` |
| `--tun-dns-hijack` / `--no-tun-dns-hijack` | `tun: { dns-hijack: true }` / `tun: { dns-hijack: false }` |
| `--tun-fakeip` / `--no-tun-fakeip` | `tun: { fakeip: true }` / `tun: { fakeip: false }` |
| `--tun-fakeip-range` | `tun: { fakeip-range: [198.18.0.0/15] }` |
| `--tun-direct-dns` | `tun: { direct-dns: system }` |
| `--tun-block-lan` | `tun: { allow-lan: false }` |
| `--quick-reconnect` / `--no-quick-reconnect` | 已删除（第 15.1 节） |
| `--route-block` / `--route-direct` / `--routes` | 已删除，改写成 `route` 规则（第 9.1 节） |

原来只有环境变量、没有命令行参数的选项也都成了键（例如 `AETHER_ROUTE_WAIT` → `advanced.route-wait`，`AETHER_ROUTE_SNIFF` → `advanced.route-sniff`，`AETHER_MASQUE_MTU` → `masque.mtu`，`AETHER_SUNNY_GSO` → `sunny: { gso: false }`），见第 2.3 节。

## 2.5 身份存在哪里

- 默认：WARP MASQUE 身份就写在 `-c` 这个配置文件里，作为**顶层键追加在文件末尾**，上面有一行注释 `# WARP identity: written and kept up to date by Aether`。Aether 只增改那十几个身份键，你写的其它键、注释、顺序都保留；值没变的键连原来那几行都不动；内容完全没变时不重写文件。文件权限设为 0600（含密钥，`sunny` 段的密码也在这里）。
- 配置文件还没有身份字段（例如你刚写好的客户端配置）时视为**没有身份**，需要 WARP 时注册一个新的写进去；纯 sunnyquic 服务端这类不需要 WARP 的配置，永远不会被写入身份。`aether register` 只注册身份、不扫描不建隧道。
- **兼容旧版**：如果已经有 `<配置名>-masque.yaml`（例如 `aether.yaml` 旁边的 `aether-masque.yaml`，旧版把身份放在 `aether-masque.toml`，启动时已自动转成 `.yaml`），继续使用那个文件，不会重新注册，也不会搬动它。
- `masque-config: <路径>`：身份放在指定文件（相对路径相对于配置文件目录）。Zero Trust 团队身份在 `<配置名>-team-<团队>.yaml`。
- 上次可用网关的缓存在身份文件旁边，**HTTP/3 与 HTTP/2 各一份、互不共用**：`aether-lastconn-h3.yaml` / `aether-lastconn-h2.yaml`（身份在 `aether.yaml` 时，即 `<配置名>-lastconn-h3.yaml` / `-h2.yaml`）或 `aether-masque-lastconn-h3.yaml` / `-h2.yaml`（旧身份文件时）。里面有最近 8 个可用网关（`peer` + `recent`），以及 `rtt_ms` / `measured_at`：`peer` 最近一次实测的完整校验 RTT（毫秒）和测量时间（unix 秒），仅供对比，不作为切换基准；`history`：**RTT 历史**，每次实测都记一条（`peer`、`rtt_ms`、`at`），包括启动时测的历史网关、扫描选定和热切换的网关，最新在前，**只保留最新 20 条**。启动时按每个网关**最新那条**排序（避免用旧的好成绩），最快的为「历史最优」；校验不通过的网关从历史里删掉。想从头扫描就删掉当前承载那一份（第 15.1 节）。
- 出错时：
  - 配置文件 **YAML 语法错误** → 报错退出，**文件原样保留**，请修正语法。
  - 身份字段本身坏了（如 `wg_private_key` 不是 32 字节 base64）：文件里**只有身份**（例如旧的 `aether-masque.yaml`）时，改名为 `.corrupt` 并重新注册；文件里还有你自己的设置时，不动文件，报错提示删掉或修好那几个身份键。

## 2.6 `route-config`、`sunny-config`、`masque-config`

| 键 | 语义 |
|---|---|
| `-c <path>`（命令行） | 主配置（YAML，默认 `aether.yaml`）：选项 + 身份 + `sunny` + `inbounds` / `outbounds` / `route` / `dns` |
| `route-config: <path>` | 只收 `.yaml` / `.yml`（`.toml` 会先自动转换，第 2.7 节）。这个文件里的 `inbounds`、`outbounds`、`route`、`dns` **整体替代**主配置里的这四项（不合并）；其它键警告后忽略。选项、身份和 `sunny` 仍在主配置里。适合“同一份身份，切换几套路由” |
| `sunny-config: <path>` | YAML 文件，sunnyquic 客户端设置写在顶层或 `sunny:` / `sunnyquic:` 段里；给了它就**不读**主配置的 `sunny` 段 |
| `masque-config: <path>` | WARP MASQUE 身份放在这个文件，不写进主配置（第 2.5 节） |

三个路径都相对于配置文件所在目录。

“有路由配置”指主配置（或 `route-config` 文件）里出现了 `inbounds`、`outbounds`、`route`、`dns` 中的任何一个；只有 `inbounds` 时 `final` 默认 `proxy`。什么都没有时与传统用法一样：所有连接走 `proxy`（当前模式的隧道）。

## 2.7 旧版 TOML 配置自动迁移

上一版的配置是 TOML。新版启动时自动把它们转成 YAML，**每个文件只转一次**：

- `-c` 指向的配置（默认 `aether.toml` → `aether.yaml`）以及同目录的 `aether-*.toml`（`-masque`、`-team-<团队>`、`-lastconn`、`-lastconn-h3`、`-lastconn-h2`）都转换成**同名 `.yaml`**，键和值不变；原文件改名为 **`.toml.bak`**。转换出的文件第一行是 `# converted from xxx.toml by Aether <版本> (comments of the TOML file are not carried over)`——**TOML 里的注释不会带过来**。
- 旧版放在顶层的 `scan_max_rtt` / `scan_rounds` / `scan_switch`（含 `-` 写法）转换时移到 `scan.max-rtt` / `scan.rounds` / `scan.switch`。已经是 YAML 的文件里仍在顶层写这几个键时，只警告、不生效。
- `-c` 直接给 `.toml` 路径时，同样转换并使用同名 `.yaml`；`.yaml` 已经存在时直接用它，TOML 文件不读（记一条警告）。不写 `-c` 时找的是 `aether.yaml`，旁边只有 `aether.toml` 时就转换它。
- `route-config`、`sunny-config`、`masque-config` 给 `.toml` 路径（或给 `.yaml` 路径而旁边只有同名 `.toml`）时，同样自动转换后使用 `.yaml`。
- 本地规则集写的 `.toml` 文件同样自动转换成 `.yaml`（第 9.6 节）。
- TOML 本身有语法错误时无法转换，启动报错，提示手工改成 YAML。
- 旧版共用的 `aether-lastconn.toml` 先转成 `aether-lastconn.yaml`，再按承载拆成 `-lastconn-h3.yaml` / `-lastconn-h2.yaml`，原文件改名为 `.old`（第 11.3 节）。

迁移前后对照：

```toml
# 旧 aether.toml
scan_max_rtt = 800

[sunny]
server = "203.0.113.7:8443"
username = "alice"
password = "PASSWORD"
```

```yaml
# 新 aether.yaml（自动生成；首行另有一行 converted from 注释，键的顺序可能不同）
sunny:
  server: 203.0.113.7:8443
  username: alice
  password: PASSWORD
scan:
  max-rtt: 800
```

旧版写在命令行或环境变量里的参数不会自动迁移，请按第 2.4 节写进配置。

## 2.8 从 JSON（sing-box）配置迁移

sing-box JSON 的每个对象直接写成 YAML 即可，例如：

```json
{"route": {"rules": [{"domain_suffix": ["cn"], "outbound": "direct"}], "final": "proxy"}}
```

```yaml
route:
  final: proxy
  rules:
    - domain_suffix: [cn]
      outbound: direct
```

YAML 的规矩：用空格缩进（不能用 Tab），同一层级缩进一致；列表项以 `- ` 开头；含 `:`、`#`、开头是 `!` `*` `&` `[` `{` 等特殊字符的字符串加引号；`"1114"` 这类纯数字的用户名 / 密码要加引号才是字符串（不加也能读，但建议加）。旧的裸 `route` 对象（没有 `route` 外层、直接 `{"rules": ..., "final": ...}`）一律写在 `route:` 下。

旧版 `--sunny-*` 命令行参数全部搬进 `sunny` 段，见第 5 章。

# 3. 搭建 sunnyquic 服务器

sunnyquic 是标准 QUIC + TLS 1.3，服务器需要一张客户端能验证的证书：正式证书（域名 + Let's Encrypt），或者自签证书 / 自签 CA（客户端用 `sunny` 段的 `ca` 或出站的 `tls.certificate_path` 信任它）。

## 3.1 用 Aether 本身做服务端（推荐，配置同一套格式）

`server.yaml`（即随附示例）：

```yaml
# 纯 sunnyquic 服务端：一个 sunnyquic 入站，final 直连，不启动 WARP
log-level: info          # 排查时改成 trace

inbounds:
  - type: sunnyquic
    tag: sunnyquic-inbound
    listen: 0.0.0.0
    listen_port: 8443
    users:
      - { name: "1114", password: "314" }
    tls:
      server_name: www.bing.com
      certificate_path: ./cert.pem
      key_path: ./key.pem
      alpn: [h3]
    zero_rtt: true
    congestion_control: bbr

route:
  default_domain_resolver: { strategy: prefer_ipv4 }
  final: direct
```

启动：

```bash
./aether -c server.yaml
```

`final` 是 `direct`，没有规则、没有 `hijack-dns`、没有远程规则集，所以 WARP 按需判定为不需要：日志出现 `[+] the WARP tunnel is not started: nothing in the config ... needs it`，不扫描、不注册 WARP、不提问，也不会往 `server.yaml` 里写身份。证书路径相对于 `server.yaml` 所在目录。`bind`（默认 `127.0.0.1:1819`）照样打开、按同一路由出站（只在本机回环上）。放行服务器的 **UDP 8443**。

自签一张给 `www.bing.com` 的证书（客户端把 `cert.pem` 拷过去当 CA）：

```bash
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -days 3650 \
  -keyout key.pem -out cert.pem -subj "/CN=www.bing.com" \
  -addext "subjectAltName=DNS:www.bing.com" \
  -addext "basicConstraints=critical,CA:FALSE" -addext "extendedKeyUsage=serverAuth"
```

最后两个 `-addext` 不能省：`openssl req -x509` 默认生成的是 `CA:TRUE` 的证书，客户端（rustls / webpki）会以 `CaUsedAsEndEntity` 拒绝它当服务器证书。

`tls` 的两个路径都不写时，Aether 自动给 `server_name` 生成一张自签证书（存在规则集缓存目录下的 `sunnyquic-server/`，日志打印路径）。

想让服务端的出口走 WARP：把 `final` 改成 `warp`（这时会启动 WARP，身份追加在 `server.yaml` 末尾）。

## 3.2 用 shadowquic 官方服务端

```bash
curl -fsSLO https://raw.githubusercontent.com/spongebob888/shadowquic/main/scripts/linux_install.sh
bash linux_install.sh       # 默认生成的是 JLS 入站，请把 /etc/shadowquic/server.yaml 整个换成下面的
```

```yaml
inbounds:
  - tag: sunnyquic-in
    type: sunnyquic
    bind-addr: "0.0.0.0:443"
    users:
      - username: "alice"
        password: "换成一个长随机密码"
    server-name: "sq.example.com"       # 证书里的名字；客户端 server_name 必须一致
    cert-path: "/run/credentials/shadowquic@server.service/cert.pem"
    key-path: "/run/credentials/shadowquic@server.service/key.pem"
    alpn: ["h3"]
    zero-rtt: true
    congestion-control: bbr
    initial-mtu: 1200                   # 经 WARP 进来的路径 MTU 固定，关掉探测
    min-mtu: 1200
    mtu-discovery: false
    max-path-num: 0
outbounds:
  - tag: direct-out
    type: direct
    dns-strategy: prefer-ipv4
log-level: "info"
```

（这是 shadowquic 自己的配置格式，不是 Aether 的。）

官方 service 用 `DynamicUser=yes`，读不到 root 的 0600 私钥，用 systemd 凭据传入：

```bash
mkdir -p /etc/systemd/system/shadowquic@server.service.d
cat > /etc/systemd/system/shadowquic@server.service.d/certs.conf <<'EOF'
[Service]
LoadCredential=cert.pem:/etc/shadowquic/cert.pem
LoadCredential=key.pem:/etc/shadowquic/key.pem
EOF
systemctl daemon-reload && systemctl restart shadowquic@server
journalctl -u shadowquic@server -f
```

防火墙放行 **UDP** 端口（云厂商安全组也要）。

# 4. 编译

要求：Rust 1.98+（rustup）、CMake、C/C++ 编译器（quiche 内置 BoringSSL）、git。

```bash
cd aether
cargo build --release                       # 产物 target/release/aether
```

- 小内存机器：`CARGO_PROFILE_RELEASE_LTO=thin CARGO_PROFILE_RELEASE_CODEGEN_UNITS=16 cargo build --release -j2`。
- 静态 musl：`pip install --user ziglang cargo-zigbuild && rustup target add x86_64-unknown-linux-musl && cargo zigbuild --release --target x86_64-unknown-linux-musl`。
- Windows（本机）：VS 2022 Build Tools（C++ 桌面开发）+ CMake + NASM，`set RUSTFLAGS=-C target-feature=+crt-static` 后 `cargo build --release`。
- 在 Linux 上交叉编 Windows：

```bash
sudo apt-get install -y clang lld llvm cmake ninja-build nasm
rustup target add x86_64-pc-windows-msvc
cargo install --locked cargo-xwin
export PATH=/usr/lib/llvm-19/bin:$PATH XWIN_ACCEPT_LICENSE=1 XWIN_ARCH=x86_64
export CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_RUSTFLAGS="-C target-feature=+crt-static"
cargo xwin build --release --target x86_64-pc-windows-msvc
```

（这些是编译用的环境变量，与 Aether 运行时无关。）

cargo feature：`sunny`（sunnyquic，默认开启）。`--no-default-features` 时没有 sunnyquic，用到它会提示需要该 feature。

# 5. sunnyquic 客户端设置

## 5.1 `sunny` 段的键

sunnyquic 客户端的设置只来自配置文件：`sunny-config` 指定的文件（没有它时为主配置的 `sunny` 段）。原来的 `--sunny-*` 参数和 `AETHER_SUNNY_*` 环境变量都已取消。`sunny` 段（或 `sunny-config` 文件）里有 `server`，且没写 `protocol` 时，自动进入 sunny 模式（`proxy` = `sunny`）。`sunny` 默认直连，不需要 WARP；只有 `detour: warp` 时才需要。

| 键 | 默认 | 说明 |
|---|---|---|
| `detour` | `direct` | `sunny` 怎么到服务器：`direct` 本机 UDP（不需要 WARP）；`warp` 跑在 WARP MASQUE 里（会启动 WARP，首次就绪前连接最多等 30 秒）。其它值启动即报错 |
| `server`（或 `addr`） | 必填 | 端口必填；IPv6 写 `"[2001:db8::7]:443"`（加引号） |
| `username`（或 `user`） | 必填 | |
| `password` | 必填 | |
| `server-name`（或 `sni`） | server 的主机部分 | 等于服务端证书名 |
| `alpn` | `[h3]` | |
| `ca`（或 `cert-path`） | 无 | 额外信任的 CA / 自签证书 |
| `congestion-control` | `bbr` | `bbr`（BBRv3）、`bbr3`、`cubic`、`new-reno`；brutal 写成映射：`congestion-control: { brutal: { bandwidth: 100M } }` |
| `zero-rtt` | `true` | |
| `over-stream` | `false` | 大 UDP 包走 QUIC 流 |
| `initial-mtu` | 自动（H3 1252/1232，H2 1452） | |
| `min-mtu` | `1200` | |
| `mtu-discovery` | `false` | |
| `keep-alive-interval` | `10000` | 毫秒 |
| `handshake-secs` | `15` | |
| `data-check` | `true` | 启动后的出口自检 |
| `gso` | `true` | |
| `cipher-suite-preference` | | 例 `[chacha20-poly1305, aes128-gcm]` |

键名 `-` 和 `_` 都可以（`server_name` 就是 `server-name`；同一个键两种写法都写了会报错），未知键报错并列出可用的键。

`half-close-timeout` 已移除（从未生效）：旧配置里仍写着时只记一条警告并忽略，不影响启动；半关闭超时由 `advanced.half-close-secs` 决定。

## 5.2 `sunny` 段示例

```yaml
sunny:
  server: sq.example.com:8443
  username: "1114"
  password: "314"
  server_name: www.bing.com
  ca: cert.pem                     # 相对路径：先当前目录，再配置文件所在目录
  alpn: [h3]
  zero_rtt: true
  congestion_control: bbr
  # congestion_control: { brutal: { bandwidth: 100M } }
  # over_stream: true              # udp 大包
  # initial_mtu: 1232
  # keep_alive_interval: 10000
  # handshake_secs: 15
  # data_check: false
  # detour: warp                   # 缺省 direct：本机 UDP 直连；warp：跑在 WARP MASQUE 里
```

`sunny` 段同时服务两个内置出站：`sunny`（sunny 模式，默认直连，`detour: warp` 时经 WARP）和 `sunny-direct`（总是本机 UDP，不看 `detour`，不在 sunny 模式也能用）。没有终端时缺了必填项直接报错（`sunny-direct` 从不提问）。

## 5.3 交互式

没写 `protocol`、`sunny` 段没有 `server`、也没写 `masque.peer`，且有终端时，需要 WARP 时会弹出协议菜单：MASQUE（默认）/ sunnyquic over MASQUE / Zero Trust 登录。选 sunnyquic 后依次问服务器、用户名、密码（服务器是 IP 时还问 SNI）。没写 `ip` 且需要扫描时还会问扫描的 IP 版本。把这些写进配置文件就不会再问。

# 6. 客户端示例

## 6.1 最小配置（原命令行用法）

原来写在命令行上的几种用法，现在都写成 `aether.yaml`，然后 `./aether -c aether.yaml`（或直接 `./aether`，默认读当前目录的 `aether.yaml`）。

所有流量直连你的 sunnyquic 服务器（不启动 WARP：没有扫描、提示、注册）：

```yaml
sunny:
  server: sq.example.com:443
  username: alice
  password: PASSWORD
```

跑在 WARP 里（旧版 sunny 模式的行为）：HTTP/3 外层，自动扫描网关——在上面的基础上加：

```yaml
sunny:
  server: sq.example.com:443
  username: alice
  password: PASSWORD
  detour: warp
```

跑在 WARP 里、UDP 被封：外层 HTTP/2——再加：

```yaml
masque:
  http2: true
```

跑在 WARP 里、指定 WARP 网关、服务器只有 IP 且用自签证书：

```yaml
masque:
  peer: 162.159.198.1:443
sunny:
  server: 203.0.113.7:8443
  server-name: www.bing.com
  ca: ./cert.pem
  username: alice
  password: PASSWORD
  detour: warp
```

## 6.2 配置文件常用写法

`aether.yaml`：

```yaml
http-proxy: 127.0.0.1:1820
masque:
  http2: true
sunny:
  server: 203.0.113.7:8443
  username: alice
  password: PASSWORD
  server_name: www.bing.com
  ca: cert.pem
```

```bash
./aether                                   # 读当前目录的 aether.yaml
./aether -c /etc/aether/aether.yaml
```

## 6.3 不经 WARP、只按规则走自己的服务器

```yaml
outbounds:
  - type: sunnyquic
    tag: sq
    server: 203.0.113.7
    server_port: 8443
    username: "1114"
    password: "314"
    tls: { server_name: www.bing.com, certificate_path: cert.pem, alpn: [h3] }
    detour: direct

route:
  final: sq
  rules:
    - ip_is_private: true
      outbound: direct
```

`final` 走声明的 sunnyquic 出站、`detour: direct`，没有任何东西需要 WARP，所以 WARP 不启动、不注册。

## 6.4 完整客户端配置

随文档附带 `client-full.yaml`：全部选项段（大多注释掉，写着默认值）、全部入站（mixed / socks / http / tun）、出站 `sq-direct`（detour direct）/ `sq-via-warp`（detour warp）/ `warp` / `warp-local` / `direct` / `block`、内置 `sunny` 与 `sunny-direct`（都读 `sunny` 段）、各种规则动作和 3 个远程 `.srs` 规则集。启动：

```bash
sudo ./aether -c client.yaml          # Windows：管理员 PowerShell 里 .\aether.exe -c client.yaml
```

它用到了 `warp`、`sq-via-warp`，所以会启动 WARP（`sunny` 段有 `server`，即 sunny 模式；`sunny` 默认直连，本身不需要 WARP），第一次运行时把 WARP 身份追加到 `client.yaml` 末尾。

## 6.5 systemd

```ini
[Unit]
Description=Aether
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=/var/lib/aether
ExecStart=/usr/local/bin/aether -c /etc/aether/aether.yaml
Restart=always
RestartSec=3
# 只有 TUN 需要：
# AmbientCapabilities=CAP_NET_ADMIN
# KillSignal=SIGINT

[Install]
WantedBy=multi-user.target
```

所有选项都在 `/etc/aether/aether.yaml` 里，`ExecStart` 不再带其它参数，也不再需要 `Environment=AETHER_*`。配置文件里有密码和 WARP 密钥，`chmod 600`；Aether 改写时也会设成 0600。注意 Aether 需要能写这个文件（第一次注册 WARP、证书刷新时），旧版 TOML 自动迁移时还要能在同目录新建 `.yaml` 和改名 `.toml.bak`；放在只读目录时用 `masque-config` 把身份放到可写的地方。

# 7. 验证

```bash
curl -x socks5h://127.0.0.1:1819 https://www.cloudflare.com/cdn-cgi/trace   # sunny 模式：ip= 是你的服务器，warp=off
curl -x socks5h://127.0.0.1:1819 https://1.1.1.1/cdn-cgi/trace              # 走 warp 时 warp=on
curl https://www.cloudflare.com/cdn-cgi/trace                               # 对比：本机直连
```

用 `socks5h://`（不是 `socks5://`），域名才交给出站解析。调试时在配置里写 `log-level: debug`：每条连接打印 `[route] tcp 域名:端口 match[序号] => 动作`。

# 8. Windows

- `aether.exe` 静态链接 MSVC CRT，不需要 VC++ 运行库；`wintun.dll` 只有 TUN 用，和 `aether.exe` 放同一目录。
- 解压到你有写权限的目录（如 `C:\Users\你\aether`）：配置文件、WARP 身份和网关缓存都在这里；`Unblock-File .\aether.exe` 可减少 SmartScreen 拦截。没有代码签名，可能被杀软误报，核对 SHA-256 后再加排除项。
- 在 PowerShell 里写 `curl.exe`（`curl` 是 `Invoke-WebRequest` 的别名）。

```powershell
cd $HOME\aether
.\aether.exe -c aether.yaml
# TUN：管理员 PowerShell（client.yaml 里有 tun 入站或 tun: { enabled: true }）
.\aether.exe -c client.yaml
curl.exe -x socks5h://127.0.0.1:1819 https://www.cloudflare.com/cdn-cgi/trace
```

- 要 HTTP/2、HTTP 代理等，写进 `aether.yaml`（`masque: { http2: true }`、`http-proxy: 127.0.0.1:1820`），命令行不变。
- YAML 里的 Windows 路径：用单引号 `'C:\aether\cert.pem'`（单引号里反斜杠不转义），或双引号里写两个反斜杠 `"C:\\aether\\cert.pem"`，或正斜杠 `C:/aether/cert.pem`。`process_path` 同理。
- **系统代理**只认 HTTP：配置里写 `http-proxy: 127.0.0.1:1820`（或加 `type: http` / `type: mixed` 入站），「设置 → 网络和 Internet → 代理 → 手动设置代理」填 `127.0.0.1:1820`；用完关掉。
- 浏览器单独走代理：Firefox 手动配置 SOCKS v5 `127.0.0.1:1819` 并勾选「代理 DNS」；Chrome / Edge 用 ZeroOmega 一类扩展。
- 配合 v2rayN：添加 SOCKS 服务器 `127.0.0.1:1819`；用它的 TUN 模式时必须让进程 `aether.exe` 直连，否则形成回环。

| 现象 | 处理 |
|---|---|
| 防火墙弹窗 | 只监听 127.0.0.1 时点取消不影响本机；给局域网用（`listen: 0.0.0.0`）时选「专用网络」 |
| 端口被占用 | `Get-NetTCPConnection -LocalPort 1819` 找 PID，或在配置里换 `bind` 端口 |
| 双击窗口一闪而过 | 在 PowerShell / cmd 里运行看报错 |
| 关掉 Aether 后上不了网 | 系统代理还开着，关掉 |
| 日志偶尔 `os error 10054` | UDP 收到 ICMP 端口不可达，已处理，可忽略 |

# 9. 路由（sing-box `route` 兼容，YAML 写法）

每条经过入站的连接都按规则决定走哪个出站。规则语义照搬 sing-box 1.14 的 `route`；大多数 sing-box 配置的 `route` 部分逐字段写成 YAML 就能用，远程规则集可以直接用 SagerNet 的 `sing-geosite` / `sing-geoip`。

## 9.1 启用

在主配置里写 `route`（以及 `outbounds`、`inbounds`、`dns`），或者把这些写进另一个 `.yaml`，用 `route-config` 指定（第 2.6 节）。

| 键 | 默认 | 说明 |
|---|---|---|
| `route-config` | 无 | 第二个 YAML 文件，替代主配置的路由部分；相对配置文件目录 |
| `route-cache-dir` | Linux `~/.cache/aether/rule-sets`；Windows `%LOCALAPPDATA%\aether\rule-sets` | 远程规则集缓存 |
| `advanced.route-wait` | `45`（秒） | 首次启动、规则集还没缓存时新连接最多等多久 |
| `advanced.route-sniff` | `true` | `false` = 关闭自动嗅探（9.5） |

旧的 `--route-block` / `--route-direct` / `--routes` 已删除：出现时启动报错，提示改写成 `route` 规则，例如：

```yaml
route:
  rules:
    - domain_suffix: [ads.example]
      action: reject
    - ip_is_private: true
      outbound: direct
```

## 9.2 出站标签

不写 `outbounds` 也能用的内置标签：

| 标签 | 含义 |
|---|---|
| `direct` | 本机网络直连 |
| `warp`（别名 `masque`） | **只能是 WARP 隧道**（sunny 模式下也一样）。WARP 没连上时连接失败 |
| `warp-local` | **本机解析域名、连接走 WARP**：域名用与 `direct` 相同的本机解析器解析（不开 TUN：系统解析器；开 TUN：`tun.direct-dns`），把得到的 IP 经 WARP 连接。适合想走 WARP 出口、但要国内 / 就近 CDN 地址的站点。解析失败时连接失败 |
| `sunny`（别名 `sunnyquic`） | **只能是 sunny 模式的 sunnyquic 客户端**：默认本机 UDP 直连你的服务器（不需要 WARP）；`sunny` 段 `detour: warp` 时经 WARP。不在 sunny 模式时（没有 `protocol: sunny`，`sunny` 段也没有 `server`），配置里用到它（规则、`final`、`download_detour`）**启动即报错** |
| `sunny-direct` | 读 `sunny` 段建一个**独立**的 sunnyquic 客户端，QUIC 从本机 UDP 直发服务器（开 TUN 时绑物理网卡），不看 `detour`。任何模式可用（不需要 sunny 模式），不需要 WARP。`sunny` 直连时两者路径相同，但各自一条 QUIC 连接 |
| `block`（别名 `reject`） | 拒绝 |
| `proxy`（别名 `tunnel`） | **唯一随模式变化**：sunny 模式下 = `sunny`（随 `sunny` 直连或经 WARP），否则 = `warp`。`final` 不写时默认是它 |

自定义标签：

```yaml
outbounds:
  - type: direct
    tag: 直连
  - type: sunny
    tag: 家里服务器
  - type: warp
    tag: cf
  - type: warp-local
    tag: cf-本机解析
  - type: block
    tag: 拦截
  - type: dns            # 旧式 DNS 出站，等同 hijack-dns 动作
    tag: dns-out

route:
  final: 家里服务器
  rules:
    - ip_is_private: true
      outbound: 直连
```

`type` 可以是 `direct`、`block`、`warp`、`warp-local`、`sunny`、`sunny-direct`、`proxy`、`dns`，以及带 `server` 字段的 `sunnyquic`（独立的 sunnyquic 客户端出站，第 11.4 节；不带 `server` 时等同 `sunny`）。sing-box 的其它类型（`vless`、`selector`……）只定义未使用时警告；被用到时**启动报错**。

## 9.3 规则动作

规则按顺序匹配：非最终动作（`sniff`、`resolve`、`route-options`）执行后继续；第一个最终动作（`route`、`reject`、`hijack-dns`）结束；都不匹配走 `final`。只写 `outbound: ...` 等同 `action: route`。

| 动作 | 说明 |
|---|---|
| `route` | `outbound` 必填，可带 route-options 字段 |
| `route-options` | `override_address`、`override_port` 生效；`tls_fragment`、`tls_record_fragment` 只对 direct 生效；`network_strategy`、`udp_timeout`、`tls_spoof` 等接受但无效果（警告） |
| `direct` | 等同 route 到 direct |
| `bypass` | 有 `outbound` 时等同 route，否则跳过 |
| `reject` | `method: default` / `reply`：SOCKS5 回“不允许”、HTTP 403；`drop`：直接关闭 / 丢 UDP。已为嗅探提前应答过的连接直接关闭 |
| `hijack-dns` | DNS 查询改由隧道内 DNS（`tunnel-dns`）回答；TUN 开着 fake-ip 时 A / AAAA 直接用假地址应答 |
| `sniff` | `sniffer`（默认全部）、`timeout`（默认 300ms） |
| `resolve` | 解析域名供后面的 IP 规则匹配。`server: local`（或 `dns` 段里类型为 `local` / `dhcp` / detour 为 direct 的服务器）用本机解析，其它用隧道内 DNS；`strategy`、`timeout` 生效。**走 `sunny` 时发给服务器的仍是原域名**；`warp-local` 只用 `local` 的结果 |

`route` 本身：`rules`、`rule_set`、`final`、`default_domain_resolver`（字符串或 `{ server, strategy, timeout }`）、`find_process`；`auto_detect_interface`、`default_interface`、`default_mark` 等警告后忽略。

## 9.4 匹配字段

同一类之内“或”，不同类之间“与”，`invert` 取反：

- 源地址：`source_ip_cidr`、`source_ip_is_private`；源端口：`source_port`、`source_port_range`
- 目的地址：`domain`、`domain_suffix`、`domain_keyword`、`domain_regex`、`ip_cidr`、`ip_is_private`
- 目的端口：`port`、`port_range`（`"1000:2000"`、`":3000"`、`"4000:"`，要加引号）
- 其它（都要满足）：`inbound`、`ip_version`、`network`、`protocol`、`client`、`process_name`、`process_path`、`process_path_regex`、`rule_set`、`rule_set_ip_cidr_match_source`

逻辑规则：

```yaml
route:
  rules:
    - type: logical
      mode: and                     # 或 or；子规则不能带动作
      rules:
        - network: udp
        - { port: 443, invert: true }
      outbound: direct
```

| 字段 | 说明 |
|---|---|
| `domain*` | `domain_suffix: a.com` 匹配 a.com 及子域，`".a.com"` 只匹配子域；优先用嗅探到的域名 |
| `ip_cidr` / `ip_is_private` | 目标是域名时，只有 `resolve` 之后才匹配解析出的 IP |
| `inbound` | `bind` 是 `socks`，`http-proxy` 是 `http`，`tun.enabled` 是 `tun`，配置入站是各自的 `tag` |
| `protocol` | 需要先 `sniff`：`tls`、`http`、`quic`、`dns`、`stun`、`bittorrent`、`dtls`、`ssh`、`rdp`、`ntp` |
| `process_*` | Linux / Windows 本机连接（Windows 写 `chrome.exe`）；macOS 上永远不匹配 |
| `auth_user`、`package_name`、`wifi_ssid`、`clash_mode` 等 | 解析后警告，永远不匹配 |
| `geosite` / `geoip`（旧） | 报错，请用 `rule_set` |

## 9.5 嗅探

- 请求里是域名时直接用；是 IP 时需要 `action: sniff`：TCP 取 TLS SNI、HTTP Host，识别 DNS / BitTorrent / SSH / RDP；UDP 解 QUIC Initial 取 SNI，识别 DNS / STUN / BitTorrent / DTLS / NTP。
- 服务端先说话的端口（25、465、587、143、993、110、995）跳过嗅探。
- **自动嗅探**（Aether 扩展）：有域名或 `protocol` 条件却没有 `sniff` 动作时，在第一条规则前自动嗅探一次；要与 sing-box 一致就自己写 `sniff`，或设 `advanced: { route-sniff: false }`。
- UDP 按每个目的地址分别判定并缓存。

## 9.6 规则集

| 类型 | 字段 |
|---|---|
| `inline` | `tag`、`rules` |
| `local` | `tag`、`format`、`path`；文件修改后约 10 秒内自动重载 |
| `remote` | `tag`、`format`、`url`、`download_detour`、`update_interval`、`initial_path` |

- `format`：`binary`（`.srs`）、`source`（sing-box JSON source，远程规则集的发布格式）、`yaml`（**本地**规则集写成 YAML：顶层 `version` + `rules` 列表）。不写时按扩展名判断（`.srs` / `.json` / `.yaml` / `.yml`）。`.json`、`.srs` 规则集与以前完全相同。
- 旧版写成 `.toml` 的本地规则集会在加载时自动转成同名 `.yaml`（原文件改名 `.toml.bak`，第 2.7 节）；`format: toml` 按 `yaml` 处理。
- 本地 YAML 规则集示例 `my-rules.yaml`：

```yaml
version: 3
rules:
  - domain_suffix: [corp.example]
  - ip_cidr: [10.8.0.0/16]
```

```yaml
route:
  rule_set:
    - type: local
      tag: mine
      path: my-rules.yaml
  rules:
    - rule_set: mine
      outbound: direct
```

- `.srs`：完整实现 sing-box `common/srs` 解码（版本 1–5，zlib，succinct trie 域名、IP 区间表、AdGuard 规则）。
- `download_detour`：不写时走 `proxy`（当前模式的隧道）。`update_interval` 默认 `1d`（支持 `12h`、`7d`）。
- 缓存：`<tag>.srs` / `<tag>.json` + `<tag>.meta.json`，下次启动直接用，离线也能分流；过期时后台条件请求更新；新文件完整解析成功才替换；失败指数退避重试。
- `initial_path`：没有缓存时先用这个本地文件。

## 9.7 各模式下的行为

| 模式 | `warp` / `warp-local` | `sunny` | `proxy`（默认 final） |
|---|---|---|---|
| 普通 WARP（MASQUE HTTP/3 / HTTP/2） | WARP 隧道 | **配置报错** | `warp` |
| sunny 模式（默认 `detour: direct`） | WARP 隧道（需要时才启动，纯 MASQUE） | 本机 UDP → 你的服务器（不需要 WARP） | `sunny` |
| sunny 模式 + `sunny: { detour: warp }` | 外层 WARP 直出 | sunnyquic 在 WARP 里 → 你的服务器 | `sunny` |
| 配置不需要 WARP（WARP 未启动） | 选到即失败（`warp-tunnel: off` 时配置报错） | 同上 | 同上 |

`sunny-direct` 和 `detour: direct` 的 sunnyquic 出站在任何模式下都可用，不需要 WARP；sunny 模式的 `sunny` 默认也不需要。

## 9.8 示例：广告拦截 + 国内直连 + 其余走隧道（`route.yaml`）

```yaml
route:
  final: proxy
  rules:
    - action: sniff
    - ip_is_private: true
      outbound: direct
    - rule_set: geosite-category-ads-all
      action: reject
    - rule_set: [geosite-cn, geoip-cn]
      outbound: direct
    # 未启用的 warp-local 示例：本机解析、经 WARP 连接
    # - domain_suffix: [example-cdn.com]
    #   outbound: warp-local
  rule_set:
    - type: remote
      tag: geosite-cn
      format: binary
      url: https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-cn.srs
      download_detour: proxy
      update_interval: 1d
    - type: remote
      tag: geoip-cn
      format: binary
      url: https://raw.githubusercontent.com/SagerNet/sing-geoip/rule-set/geoip-cn.srs
      download_detour: proxy
      update_interval: 1d
    - type: remote
      tag: geosite-category-ads-all
      format: binary
      url: https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs
      download_detour: proxy
      update_interval: 1d
```

主配置 `aether.yaml` 里引用它：

```yaml
route-config: route.yaml
bind: 127.0.0.1:1819
http-proxy: 127.0.0.1:8118
```

```bash
./aether -c aether.yaml
curl -x socks5h://127.0.0.1:1819 -sI https://www.baidu.com | head -1        # 直连
curl -x socks5h://127.0.0.1:1819 -sI https://doubleclick.net                # 被拒：curl (35)
```

`warp-local` 配合本机 `resolve`（结果直接给 `warp-local` 用，不解析第二次）：

```yaml
route:
  rules:
    - domain_suffix: [example-cdn.com]
      action: resolve
      server: local
    - domain_suffix: [example-cdn.com]
      outbound: warp-local
```

`warp-local` 的域名会被本机网络看到，这是它与 `warp`（隧道内解析）的区别。

# 10. 系统级 TUN（`tun` 段）

接管整台机器的 TCP / UDP（Linux 需 root 或 `CAP_NET_ADMIN`，Windows 需管理员 + `wintun.dll`），每条流以入站标签 `tun` 进入路由。用户态协议栈是 geph5 使用的 `ipstack-geph`；建网卡、路由、DNS、防火墙的代码改编自 geph5（MPL-2.0）。

开启方式：配置里写 `tun: { enabled: true }`（或 `tun: true`），或写一个 `type: tun` 入站：

```yaml
inbounds:
  - type: tun
    tag: tun-in                        # 规则里 inbound: tun-in
    interface_name: aether-tun
    mtu: 1400
    auto_route: true
    strict_route: true
    route_address: [0.0.0.0/1, 128.0.0.0/1]     # 等同 tun.include（可省略）
    route_exclude_address: [10.0.0.0/8, 192.168.0.0/16]
```

入站字段映射到对应的 `tun` 段键（`interface_name` → `tun.name`，`route_address` → `tun.include`，`route_exclude_address` → `tun.exclude`……）；两处都写了时以 `tun` 段为准。

## 10.1 工作方式

- 协议栈先不回 SYN-ACK，等路由选好、出站拨通才完成握手：`reject` 立即 RST；拨号失败时程序可换地址重试。
- ICMP 不转发，`ping` 不通是正常的。
- 没有任何路由配置时全部流量走 `proxy`。
- TUN 不再等 WARP 隧道：启动后立即接管系统流量，`direct` 等出站立刻可用，走 WARP 的流等隧道（第 11.3 节）。Aether 自己的 socket（扫描、MASQUE、WARP API）都绑定物理网卡，不进 TUN。

## 10.2 DNS：劫持 + fake-ip（默认）

- 系统 DNS 设为 TUN 网段里的 `172.19.0.2`（`tun.dns`）；默认劫持所有进入 TUN 的 53 端口流量。
- **fake-ip**：A → `198.18.0.0/15` 的假地址（TTL 10 秒）；AAAA → `fc00::/18`（TUN 没接 IPv6 时回答空）；HTTPS / SVCB → 空；假地址 PTR → 域名；其它类型照旧经 WARP 问 `tunnel-dns`。
- 连接假地址时还原成域名再路由：`sunny` 发给服务器的是域名（本机无 DNS 查询）；`warp` 连接时在隧道内解析；`direct` / `warp-local` 由 Aether 自己经物理网卡问 `tun.direct-dns`。
- `tun.direct-dns`（默认 `system`）：TUN 接管前读到的本机网络 DNS（Windows 出口网卡的 DNS，Linux `/etc/resolv.conf`，systemd-resolved 时取上游）；`tunnel` = 经 WARP 问 `tunnel-dns`；或写 `[223.5.5.5, 119.29.29.29]`。默认 `system` 是因为 2026-10-17 真实 Windows 测试中，直连的 baidu 经 1.1.1.1 解析成海外节点打不开。
- fake-ip 下 `geoip-cn`、`ip_is_private` 只对直接用 IP 的连接生效；想按 IP 分流域名，前面加 `action: resolve`。
- `tun: { fakeip: false }` 回到真实地址 + 嗅探（不推荐：直连域名也会拿到经 WARP 查的地址）。

## 10.3 `tun` 段的键

| 键 | 默认 | 说明 |
|---|---|---|
| `tun.enabled` | `false` | |
| `tun.name` | Linux `aether-tun`，Windows `Aether` | |
| `tun.address` | `[172.19.0.1/30, fdfe:dcba:9876::1/126]`（无 IPv6 默认路由时只用 IPv4） | |
| `tun.mtu` | `9000` | |
| `tun.dns` | `172.19.0.2` | IP 或 `off` |
| `tun.auto-route` | `true` | |
| `tun.strict-route` | `false` | 局域网也进 TUN + 防泄漏防火墙（nftables / WFP） |
| `tun.include` / `tun.exclude` | 全部 / 无 | |
| `tun.dns-hijack` | `true`（劫持全部） | |
| `tun.fakeip` | `true` | |
| `tun.fakeip-range` | `[198.18.0.0/15, fc00::/18]` | |
| `tun.direct-dns` | `system` | |
| `tun.allow-lan` | `true` | `false` = 不放行局域网（Windows 严格模式） |
| `tun.table` / `tun.rule-priority` | `1819` / `9180` | Linux 策略路由表与规则优先级 |
| `mark`（顶层） | TUN 下 `0x6165` | Linux fwmark；`mark: 0` 会让 TUN 启动报错 |

清理被强杀后留下的路由 / 规则 / 防火墙 / 网卡：命令 `aether tun-cleanup`（第 10.6 节）。

## 10.4 防回环

- Linux：Aether 自己的 socket 统一打 `SO_MARK 0x6165`，策略路由 `9180: fwmark → main`、`9181: fwmark unreachable`、`9182: main suppress_prefixlength 0`（严格模式不加）、`9183: lookup 1819`（默认路由进 TUN）。
- Windows：自己的 socket 用 `IP_UNICAST_IF` 绑物理网卡，WinTUN 上加 `0.0.0.0/1`、`128.0.0.0/1`；严格模式用动态 WFP 会话（进程退出即自动删除）。

## 10.5 用法

全部走 WARP，最简单的 `tun.yaml`：

```yaml
tun: true
```

只让部分网段进 TUN、排除内网和你的服务器：

```yaml
tun:
  enabled: true
  include: [1.0.0.0/8]
  exclude: [10.0.0.0/8, 203.0.113.7]
```

配合 `route-config` 与 HTTP/2：

```yaml
tun: true
route-config: tun-route.yaml
masque:
  http2: true
```

```bash
sudo ./aether -c tun.yaml
curl https://www.cloudflare.com/cdn-cgi/trace         # 不需要代理参数
```

配置里已有的 `sunny` / `route` 照常生效，加一行 `tun: true` 即可。

TUN 用的路由示例（随附 `tun-route.yaml`，它自己就带 `tun: { enabled: true, strict-route: true }`，也可以直接 `sudo ./aether -c tun-route.yaml`）：

```yaml
tun:
  enabled: true
  strict-route: true
  # exclude: [192.168.0.0/16]

route:
  final: proxy
  rules:
    - action: sniff
    - protocol: dns
      action: hijack-dns
    - ip_is_private: true
      outbound: direct
    - inbound: [tun]
      process_name: [steam.exe, qbittorrent, qbittorrent.exe]
      outbound: direct
    - rule_set: ads
      action: reject
    - rule_set: [geosite-cn, geoip-cn]
      outbound: direct
    - network: udp
      port: 443
      action: reject            # 拒绝 QUIC，浏览器退回 TCP（可删）
  rule_set:
    - type: remote
      tag: ads
      format: binary
      url: https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs
    - type: remote
      tag: geosite-cn
      format: binary
      url: https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-cn.srs
    - type: remote
      tag: geoip-cn
      format: binary
      url: https://raw.githubusercontent.com/SagerNet/sing-geoip/rule-set/geoip-cn.srs
```

注意：作为 `route-config` 引用时，只有它的 `route`（以及 `inbounds` / `outbounds` / `dns`）被读取，`tun` 段要写在主配置里。

## 10.6 退出与故障排查

- Ctrl+C / SIGINT / SIGTERM / 关闭控制台：先恢复路由、规则、DNS、防火墙再退出。
- 被强杀后：Linux 一般会自己恢复，严格模式的 `inet aether_tun` 表会导致断网，运行 `sudo ./aether tun-cleanup`；Windows 的 `tun.exclude` 路由用管理员 `.\aether.exe tun-cleanup` 删除。下次开 TUN 启动也会先自动清理。

| 现象 | 处理 |
|---|---|
| `Operation not permitted` | Linux 需要 root / `CAP_NET_ADMIN` |
| `TUN mode needs Administrator rights` / `needs wintun.dll` | 管理员运行；`wintun.dll` 放到 exe 旁边 |
| `TUN mode needs a socket mark ...; mark: 0 turned it off` | 删掉配置里的 `mark: 0` |
| SSH 断了 | `tun: { exclude: [<你的客户端 IP>] }` |
| `dig` 返回 `198.18.x.x` | fake-ip，正常 |
| 规则是 direct，国内站点打不开 | 看日志 `[tun] direct dns:`，必要时 `tun: { direct-dns: [223.5.5.5, 119.29.29.29] }` |
| 与其它 TUN 软件同时用 | 不支持 |

# 11. 入站、出站、WARP 按需

```text
入站 inbound     bind（socks5）| http-proxy | inbounds：socks / http / mixed / tun / sunnyquic 服务端
   ▼
会话 session     嗅探 → 路由规则 → 判定
   ▼
出站 outbound    direct | block | warp | warp-local | sunny | sunny-direct | outbounds 的 sunnyquic
   ▼
传输 transport   WARP MASQUE（HTTP/3 / HTTP/2）的用户态网络栈；sunnyquic 客户端
```

## 11.1 配置里写入站

```yaml
inbounds:
  - type: mixed
    tag: mixed-in
    listen: 127.0.0.1
    listen_port: 2080
  - type: socks
    tag: lan-socks
    listen: 0.0.0.0
    listen_port: 1080
  - type: http
    tag: http-in
    listen: 127.0.0.1
    listen_port: 8080
  - type: sunnyquic
    tag: sq-in
    listen: "::"
    listen_port: 8443
    users:
      - { name: alice, password: 换成强密码 }
    tls: { server_name: sq.example.com, certificate_path: /etc/aether/cert.pem, key_path: /etc/aether/key.pem }

route:
  final: proxy
  rules:
    - inbound: sq-in
      outbound: warp
    - inbound: lan-socks
      domain_suffix: [cn]
      outbound: direct
```

| type | 说明 |
|---|---|
| `socks` / `socks5` | SOCKS5（CONNECT + UDP ASSOCIATE），无认证 |
| `http` | HTTP 代理（CONNECT 和明文） |
| `mixed` | 同一端口 SOCKS5 + HTTP |
| `tun` | 等同 `tun: { enabled: true }`（第 10 章） |
| `sunnyquic`（或 `sunny`） | sunnyquic 服务端（11.2） |

- `listen` 省略为 `127.0.0.1`；除 tun 外都要 `listen_port`。`::` 要加引号（`listen: "::"`）。这些入站是**额外**的，`bind`（默认 1819）、`http-proxy` 照旧；端口冲突启动即报错。其它 sing-box 入站类型警告并忽略。

## 11.2 sunnyquic 服务端入站

| 字段 | 说明 |
|---|---|
| `listen` / `listen_port` | UDP 监听 |
| `users` | `[{ name: ..., password: ... }]`，至少一个 |
| `tls.server_name` | 证书名，默认 `localhost` |
| `tls.certificate_path` / `tls.key_path` | PEM，相对配置文件目录；都不写时自动生成自签证书 |
| `tls.alpn` | 默认 `[h3]` |
| `zero_rtt` | 默认 `true` |
| `congestion_control` | `bbr`、`cubic`、`new-reno`，或 `{ brutal: { bandwidth: 100M } }` |
| `initial_mtu` / `min_mtu` / `mtu_discovery` | 默认 1300 / 1290 / 开（与上游 shadowquic 服务端相同） |

TCP 以入站 tag 进入路由；UDP 会话按目的地逐个路由（支持嗅探和 `hijack-dns`）。客户端发来的域名原样交给规则和出站。

## 11.3 WARP 按需启动：`warp-tunnel: auto | on | off`

| 写法 | 含义 |
|---|---|
| `auto`（默认） | 没有路由配置：照旧启动 WARP。有路由配置：只有某处**可能选到**需要 WARP 的东西才启动 |
| `on` | 总是启动 |
| `off` | 不启动；配置需要 WARP 时启动即报错并逐条列出原因 |

需要 WARP 的：规则 / `final`（默认 `proxy`）/ 远程规则集 `download_detour`（不写算 `proxy`）里出现 `warp`、`warp-local`、非 sunny 模式下的 `proxy`、`detour: warp` 时的 `sunny`（以及此时 sunny 模式下的 `proxy`）、`detour: warp` 的 sunnyquic 出站；`hijack-dns` 或 `dns` 出站；隧道内解析的 `resolve`；TUN 关闭 fake-ip 或 `tun.direct-dns: tunnel`。`default_domain_resolver` 本身不算。不需要的：`direct`、`block`、`sunny-direct`、`detour: direct` 的 sunnyquic 出站、默认（直连）的 `sunny` 和 sunny 模式下的 `proxy`。没有路由配置时：普通模式照旧启动 WARP（一切走 `proxy` = `warp`）；sunny 模式直连时不启动（一切走 `proxy` = `sunny`），`sunny: { detour: warp }` 时启动。

### 入站与 WARP 隧道相互独立

入站（`inbounds`、`bind`、`http-proxy`、TUN）总是**立即**开始服务，不等交互提示、扫描或隧道：

1. 启动顺序：路由加载 → 判断哪些出站需要 WARP → 打开所有入站（含 TUN）→（需要时）在后台启动 WARP：（有历史网关时）直接用历史网关启动，否则扫描、连接。
   - **HTTP/3 / HTTP/2 只由配置决定**：`masque: { http2: true }` 为 HTTP/2，`false` 或不写为 HTTP/3；不询问，也不再参考上次连接的承载。lastconn 文件只存连接信息（网关、最近网关、RTT 历史），不含承载字段：H3 只读写 `<配置名>-lastconn-h3.yaml`，H2 只读写 `<配置名>-lastconn-h2.yaml`，互不影响。旧文件里的 `carrier` 字段读取时忽略，下次写入时去掉。旧版共用的 `aether-lastconn.yaml` 启动时仍会自动拆成两份，原文件改名为 `.old`。
2. 不需要 WARP 的出站（`direct`、`block`、`sunny-direct`、`detour: direct` 的 sunnyquic 出站、直连的 `sunny`）从第一个连接起就能用，与扫描/提示无关。直连的 `sunny` 只等它的客户端建好（启动时读完 `sunny` 段即建好，缺必填项时在终端提问期间最多等 30 秒），不等任何隧道。
3. 需要 WARP 的出站（`warp`、`warp-local`、非 sunny 模式的 `proxy`、`detour: warp` 的 `sunny`、`detour: warp` 的 sunnyquic 出站）在**第一次**隧道就绪前每个连接最多等待 **30 秒**，隧道（`sunny` 则是 sunnyquic 客户端握手完成）一就绪就继续；超时报错 `<出站>: the WARP tunnel did not come up within 30s (still choosing the transport, scanning or connecting); it never falls back to another outbound`，绝不改走其他出站。隧道起来之后断线重连期间的等待仍是 5 秒。TUN 的 UDP 流同样等待，超时丢弃。
4. `auto` 模式下只有规则 / `final` / 规则集下载实际会选到需要 WARP 的出站时才启动 WARP（才有扫描）；`on` 总是启动；`off` 遇到需要 WARP 的配置在打开入站**之前**就报错退出。
5. **sunny 模式本身不需要 WARP**（2026-10-20 起）：`sunny` 默认从本机 UDP 直连你的服务器，路由到 `sunny`（或 sunny 模式下的 `proxy`）不会启动 WARP。只有 `sunny` 段写 `detour: warp` 时，`sunny` 才跑在 WARP MASQUE 里（用户 → WARP → 你的 sunnyquic 服务器），那时路由到它才要启动 WARP、要等隧道（第一次最多 30 秒），与旧版 sunny 模式相同。WARP 因为别的出站（`warp`、`warp-local`……）启动时，`sunny` 直连的情况下 WARP 隧道是纯 MASQUE，不承载 sunny。

启动日志（例：规则 3 → sunny，规则 4 → warp-local，final warp，`sunny` 默认直连）：

```text
[aether] these need the WARP tunnel: rule 4 routes to warp-local; final is warp; starting it: the gateway scan and the connect run alongside the inbounds, which serve right away; connections to those outbounds wait for the tunnel (at most 30s each), the others go now. sunny (and proxy) is the sunny sunnyquic client, which goes direct from this machine and needs no WARP (detour = "warp" in [sunny] / sunny.detour: warp puts it inside WARP MASQUE)
[aether] inbounds ready: socks5 127.0.0.1:1080; outbounds that need no WARP work now; the WARP tunnel comes up in the background
[inbound] socks5 server listening on 127.0.0.1:1080 (routed)
[masque] HTTP/3 (masque.http2: true for HTTP/2)
[warp] sunny goes direct (detour = "direct"): this WARP tunnel is plain MASQUE and carries only what needs WARP (warp, warp-local, ...), not sunny
[sunnyquic] sunny: sunnyquic to sq.example.com:8443 (203.0.113.7:8443) as 'alice' from a local udp socket (sni ..., alpn h3)
[route] the WARP tunnel is not up yet: connections to outbounds that ride it wait for it (at most 30s each); the other outbounds go now
```

同一配置的 `sunny` 段加 `detour: warp` 时第一行是 `these need the WARP tunnel: rule 3 routes to sunny (the sunny sunnyquic client has detour = "warp": it rides inside WARP MASQUE); rule 4 routes to warp-local; final is warp; starting it: ...`。

不需要 WARP 时：`[aether] the WARP tunnel is not started: nothing in the config ([route], [[inbounds]], [[outbounds]]) needs it (warp-tunnel: on starts it anyway); no scan, no registration`，接着 `inbounds ready: ...; every outbound works now`。（日志里个别地方仍沿用 `[route]`、`[[inbounds]]` 这类旧写法指代对应的段。）

注意：远程规则集**第一次**（还没有缓存）下载时，连接仍会按规则集的等待上限（`advanced.route-wait`，默认 45 秒）等它下完再路由，避免规则不全时把流量送错出站；如果规则集的 `download_detour` 走 WARP（不写算 `proxy`），这段等待就会跟 WARP 启动连在一起。规则集用 `download_detour: direct` 或已有缓存时没有这个问题。

## 11.4 不经 WARP 的 sunnyquic 出站

- 内置 `sunny-direct`：读 `sunny` 段（或 `sunny-config` 文件），不提问，第一次用到时握手。
- 声明任意多个：

```yaml
outbounds:
  - type: sunnyquic
    tag: hk
    server: 1.2.3.4
    server_port: 8443
    username: "1114"
    password: "314"
    tls: { server_name: www.bing.com, certificate_path: ca.pem, alpn: [h3] }
    congestion_control: bbr
    zero_rtt: true
    detour: direct
  - type: sunnyquic
    tag: us-via-warp
    server: us.example.com
    server_port: 443
    username: u
    password: p
    detour: warp

route:
  final: direct
  rules:
    - domain_suffix: [hk]
      outbound: hk
    - domain_suffix: [us]
      outbound: us-via-warp
```

| 字段 | 说明 |
|---|---|
| `server` / `server_port` | 必填；也可只写 `server: "host:port"` |
| `username`（或 `user`）/ `password` | 必填 |
| `tls.server_name` | 默认等于 `server` |
| `tls.certificate_path` | CA / 自签证书，相对配置文件目录；不存在启动即报错；不支持 `insecure` |
| `tls.alpn` | 默认 `[h3]` |
| `congestion_control` | `bbr`（默认）、`bbr3`、`cubic`、`new_reno` |
| `zero_rtt`（或 `zero_rtt_handshake`） | 默认 `true` |
| `udp_over_stream` | 默认 `false` |
| `detour` | `direct`（缺省，本机 UDP）或 `warp`（跑在 WARP 里，会让 auto 启动 WARP） |

tag 不能与内置标签重名。注意：`sunny` 段有 `server` 时 `proxy` 的含义是 `sunny`：默认直连，不启动 WARP；`sunny` 段写了 `detour: warp` 时 `proxy` 也经 WARP。

## 11.5 `bind` / `http-proxy`

启动时（隧道之前）就打开，跨越所有重连常驻，所有连接都经过路由；WARP 重连期间走 `warp` 的新连接最多等 5 秒。纯服务端也照样打开 `bind`。

## 11.6 `sunny` 默认直连、`detour: warp` 才经 WARP（2026-10-20）

| 写法 | `sunny`（与 sunny 模式下的 `proxy`） | 需要 WARP |
|---|---|---|
| `sunny` 段不写 `detour` / `detour: direct` | sunnyquic QUIC 从本机 UDP 直连服务器；开 TUN 时绑物理网卡（与 `sunny-direct` 同一路径）；`server` 是域名时本机解析 | 否：不扫描、不提示、不注册 |
| `sunny` 段 `detour: warp` | 跑在 WARP MASQUE 里（旧版 sunny 模式），WARP 需求判定计入，首次就绪前连接最多等 30 秒 | 是 |

- 直连时 `sunny` 客户端在入站打开之后、WARP 启动之前建好：先读 `sunny` 段（缺必填项且有终端时提问），然后在后台做第一次 QUIC 握手和出口自检（`data-check`），失败只记 warn，之后的连接会重新拨号；`sunny` 绝不改走 WARP。
- 设置不合法（缺必填项且没有终端、CA 文件不存在、`detour` 写错……）启动即报错。
- `sunny-direct` 保留，不合并：它不需要 sunny 模式，总是直连，不看 `detour`。`sunny` 直连时两者路径相同，但各自一条 QUIC 连接；同一配置里只用其中一个即可。
- 声明的 `outbounds` 里 `type: sunnyquic` 的 `detour` 语义不变。`warp-tunnel: auto | on | off` 语义不变：`on` 时 WARP 照样启动（纯 MASQUE，`sunny` 仍直连）。
- 非 sunny 模式下用到 `sunny` 仍然启动即报错：`sunny` 只指 sunny 模式的客户端，这一次运行没有它，而出站绝不悄悄换成别的。

典型用法（旧版写成 `.\aether.exe --masque-sni www.cloudflare-cn.com --masque --verbose --sunny --sunny-config sunny.toml --route-config route.toml --max-rtt 1400`），现在写成 `aether.yaml`：

```yaml
log-level: debug
protocol: sunny
sunny-config: sunny.yaml
route-config: route.yaml
scan:
  max-rtt: 1400
masque:
  sni: www.cloudflare-cn.com
```

```powershell
.\aether.exe -c aether.yaml
```

`route.yaml` 有 rule → `sunny`、rule → `warp-local`、`final: warp`（规则集都 `download_detour: direct`）：

- 旧版：`sunny` 跑在 WARP 里，WARP 需求列出 `rule N routes to sunny (... rides inside WARP MASQUE)`、`rule M routes to warp-local`、`final is warp`；`sunny` 的连接要等 WARP 扫描 + 隧道 + 内层 QUIC 握手。
- 新版：`sunny` 直连你的服务器，入站一打开就能用；WARP 仍然启动（因为 `warp-local` 和 `final: warp`），日志里只列 `rule M routes to warp-local; final is warp`，并说明 sunny 直连不需要 WARP；WARP 隧道是纯 MASQUE（`scan.max-rtt: 1400`、`masque.sni` 照常作用于它）。
- 想恢复旧行为：`sunny.yaml` 里加 `detour: warp`。
- 如果把 `final` 和 `warp-local` 规则也改成 `direct` / `sunny`，WARP 就完全不启动。

# 12. 故障排查

| 现象 | 处理 |
|---|---|
| `aether.yaml: not valid YAML: ... line N` | 配置语法错（常见：用了 Tab 缩进、缩进不齐、`!` 开头的值没加引号），按行号改；文件不会被移走 |
| `--xxx is no longer a command-line option: write it in the config file ... as ...` | 旧命令行参数，按提示（或第 2.4 节）写进配置文件 |
| `unknown option or command '...'` | 命令行只收 `-c <文件>`、`register`、`tun-cleanup`、`help`、`version` |
| `scan.maxrtt is not an option (the scan options are ...)` / `... must be true or false` / `... is given twice` | 选项段里键名拼错、值类型不对，或同一个键既写了 `-` 又写了 `_`；按提示改 |
| `aether.yaml: unknown key "xxx" ignored`（警告） | 顶层键拼错或不是选项；顶层的 `scan_max_rtt` 等要写进 `scan` 段 |
| `xxx.toml: not valid TOML: ...; convert it to YAML by hand` | 旧 TOML 文件本身有语法错，无法自动迁移（第 2.7 节）；修好 TOML 或手工写成 YAML |
| `route-config ...: a YAML file (.yaml) is expected; JSON route configs are not read` | JSON 配置已不支持，按第 2.8 节改成 YAML |
| `... sunny: unknown key 'xxx'; known keys: ...` / `given twice (with - and with _)` | `sunny` 段键名拼错，或同一个键既写了 `-` 又写了 `_` |
| `the sunny client (and sunny-direct) needs server in the sunny mapping of the config file ...` | `sunny` 段（或 `sunny-config` 文件）缺必填项，且没有终端可以提问 |
| `is not host:port` | 端口必填，IPv6 加方括号并加引号 |
| `no QUIC answer from ... within 15s` | 服务器没起、UDP 端口没放行、端口写错 |
| `invalid peer certificate: ... CaUsedAsEndEntity` | 自签证书是 `CA:TRUE`：按第 3.1 节加 `basicConstraints=critical,CA:FALSE` 重新生成 |
| Linux 开 TUN 第一次运行报 `api.cloudflareclient.com would be looked up outside the socket mark ... give api-address an IP address` | TUN 模式下 Aether 自己的 socket 带 fwmark，还没有 WARP 身份时注册请求的域名不能用系统解析：第一次在配置里写 `api-address: <IP>`（`dig +short api.cloudflareclient.com` 查一个），或先不开 TUN 运行一次 / 运行 `aether register` 完成注册（身份写进配置后以后不再需要） |
| `UnknownIssuer` / `NotValidForName` / `BadSignature` | 证书不被信任或名字不符：`server_name` 等于证书名；自签时 `ca` / `certificate_path` 必须是服务端**当前**那张证书（或签它的 CA），且服务端证书与私钥配对 |
| 握手成功但 `a test request through the sunnyquic server failed` | 多半是用户名 / 密码错（服务器直接关连接） |
| `... is sunny, the sunny sunnyquic client, which this run does not have` | 规则用了 `sunny`，但没有 `protocol: sunny`，`sunny` 段也没有 `server`；补上，或改用 `sunny-direct` / 声明的 sunnyquic 出站 |
| `sunny.detour "x": use direct or warp` / `detour = "x": use "direct" or "warp"` | `detour` 只能是 `direct` 或 `warp` |
| `the sunny client was not made within 30s` | 直连的 `sunny` 客户端还没建好（终端提问 `sunny` 段缺的必填项时没人回答）；与 WARP 无关 |
| `warp-tunnel off, but the route of the config needs the WARP tunnel: ...` | 按列出的原因改规则，或改回 `warp-tunnel: auto` |
| `the WARP tunnel did not come up within 30s (still choosing the transport, scanning or connecting)` | 启动阶段 WARP 隧道还没就绪（还在等你回答交互提示，或扫描/连接中），走 WARP 的连接等满 30 秒放弃；隧道就绪后重试即可。不走 WARP 的出站不受影响（第 11.3 节） |
| `fix or remove the identity keys ... ` | 配置里的 WARP 身份坏了；删掉文件末尾 `# WARP identity` 下面那些身份键，下次会重新注册 |
| 远程规则集没生效 | 首次经 `download_detour` 下载；可先下好 `.srs` 用 `initial_path` 或 `type: local` |
| 被 reject 的 HTTPS 站点 curl 报 `(35)` | 正常：嗅探后才拒绝，表现为连接被关闭 |
| 配置了 `tls.ech` 时扫不到网关 / `ECH_REJECTED` / CONNECT-IP 返回 400 | 新版已处理：`tls.ech` 只用于 WARP API 调用（注册 / enroll），MASQUE 握手（HTTP/3 与 HTTP/2）一律不带 ECH。WARP 的 MASQUE 网关不接受 ECH（返回 `ECH_REJECTED`），接受 ECH 的普通 CDN IP 不是 MASQUE 网关（CONNECT-IP 返回 400）。启动日志：`[tls] tls.ech applies to the WARP API calls only; the MASQUE handshakes go without ECH (the WARP gateways turn it down)` |
| `[scan] no gateway within max-rtt 500ms after N of 3 scan round(s) (... all slower); starting on the fastest so far ...`（`scan.switch: false` 时为 `... falling back to the fastest found ...`） | 一轮（关掉后台扫描时为整个扫描）都没有网关完整校验 RTT ≤ 上限，先用最快的那个（能连，只是慢）。网络本身延迟高时可调大 `scan: { max-rtt: 800 }`，或 `scan: { max-rtt: 0 }`（第一个可用即启动）；第 15 章 |
| `[masque] switching gateway A(...) -> B(...)` 之后连接断了一下 | 正常：后台扫描找到 RTT 不到当前一半的网关，隧道热切换过去。纯 MASQUE 模式下经旧网关的 TCP/UDP 连接会断开、需要重连；`detour: warp` 的 sunny QUIC 连接会跟着走（直连的 `sunny` 不经过网关，不受影响）。不想要可写 `scan: { switch: false }`（第 15.1 节） |
| 大流量卡顿 | 不要调大 `initial_mtu`（H3 外层最大 1252），保持 `mtu_discovery` 关闭 |

更多信息：配置里写 `log-level: debug`，或 `RUST_LOG=info,aether=debug ./aether -c aether.yaml`（sunnyquic 协议的日志在 `aether::proxy::sunnyquic` 下）。

# 13. 已知限制与测试情况

- `exit-loc`、`zero-trust.gateway`、`stats` 流量统计对 `sunny` 的流量不生效（`sunny` 直连时，WARP 若因别的出站启动，`exit-loc` / `zero-trust.gateway` 照常作用于那条 WARP 隧道）。SOCKS5 无认证，`listen: 0.0.0.0` 时只在可信网络用。
- 不支持 sunnyquic multipath；外层重连期间已有连接可能卡几秒；0-RTT 理论上可被重放（在意就 `zero_rtt: false`）。
- HTTP/2 外层（`masque.http2: true`）可用，但相当于 QUIC 跑在 TCP 上，丢包时有队头阻塞。
- macOS / Android 没有 TUN。
- `tls.ech`（`tls.ech-dns`、`tls.ech-domain`）只作用于 WARP API 调用；MASQUE 握手不带 ECH，`masque.sni` 的名字总是明文出现在 ClientHello 里。FFI / 库调用里的 `"ech": true`、`ScanRequest.ech_config_list`、`TunnelSpec.ech` 保留以兼容，但被忽略（只 warn 一次）。
- 下面是**配置还是 TOML 时**的测试记录，文件名和参数保持当时的写法；改为 YAML 配置、取消命令行参数之后的测试情况未在此记录。
- **2026-10-19（TOML 版）测试**：
  - `cargo test --lib`：453 通过、6 个 ignored；ignored 里除两个会访问真实 Cloudflare 的以外，4 个端到端测试逐个运行全部通过，其中 `sunny_direct_and_declared_sunnyquic_carry_tcp_and_udp_without_warp` 用一个 TOML 主配置（`[sunny]` + sunnyquic 服务端入站 + 声明的出站 + 路由）跑通 TCP 与 UDP，并断言不启动 WARP。`cargo check` 默认与 `--no-default-features` 均无警告。
  - debug 二进制实测（本机回环）：当时第 3.1 节的 `server.toml` 原样启动（证书按 3.1 节生成），日志 `the WARP tunnel is not started`，UDP 8443 监听，文件未被改动、没有生成身份文件；客户端 TOML（`final` 走 `detour = "direct"` 的声明 sunnyquic 出站）经它访问本机 HTTP 服务（TCP，目标写 IP 与域名都通，域名由服务端解析）和本机 DNS 服务（SOCKS5 UDP 里的 DNS 查询，目标写 IP 与域名都通）；只写 `[sunny]`、`final = "sunny-direct"`、不带任何命令行参数的客户端同样 TCP / UDP 都通。
  - `client-full.example.toml`（服务器换成本机地址）在独立网络命名空间里以 root 加载：18 条规则、3 个远程规则集解析通过，mixed / socks / http 入站和 `--bind` 都起来，TUN 入站完成准备（直连 DNS 取到系统服务器），WARP 按需判定列出需要它的规则后开始注册（命名空间无外网且 TUN 模式下需 `--api-address`，到此为止；TUN 网卡要等隧道连上才建立，所以没有实际接管流量）。这次加载发现并修复了一个旧问题：配置里的 `type = "tun"` 入站在 Linux 上会报 `--tun needs a socket mark`。
  - Windows：`cargo xwin check --release --target x86_64-pc-windows-msvc` 通过，未在真机运行。
- **2026-10-19（sunnyquic 协议并入 Aether）测试**：不再依赖 vendored shadowquic，协议在 `proxy/sunnyquic/`。`cargo test --lib` 466 通过、6 个 ignored（4 个可跑的端到端逐个运行全过）；`cargo check` 默认与 `--no-default-features` 无警告；`cargo xwin check` 通过。与上游 shadowquic 4406bb2 二进制互通（本机回环）：上游服务端 ↔ Aether 客户端、Aether 服务端 ↔ 上游客户端，TCP（小文件与 3 MB 校验）、UDP（回显与经 1.1.1.1 的 DNS），`udp_over_stream` 关 / 开，全部通过；错误密码两个方向都被拒。服务端证书改为启动时读取一次（上游会监视证书文件并热加载，Aether 现在需要重启才换证书）。
- **没有验证的**：真实 WARP + 公网 sunnyquic 服务器的端到端；`detour: warp` 的 sunnyquic 出站只有判定测试；真实 Windows 上的这一版。

# 14. 源码目录（`aether/src/`）

| 路径 | 内容 |
|---|---|
| `lib.rs`、`main.rs`、`error.rs` | 模块声明、入口、错误类型 |
| `bootstrap.rs` | 启动与收尾：日志、出站、DNS、路由器、入站、WARP 按需、退出 |
| `config/` | `cli.rs`（命令行：`-c` 与 `register` / `tun-cleanup` / `help` / `version`，帮助文本，旧参数报错）、`options.rs`（**选项表**：每个 YAML 键 ↔ 内部设置名，旧参数 → 新键对照）、`file.rs`（**YAML 配置文件**：读取、路由部分、`sunny`、键检查）、`yaml.rs`（YAML 解析与输出）、`migrate.rs`（旧 TOML 文件自动转成 YAML）、`identity.rs`（WARP 身份读写，追加在配置文件末尾、保留其余内容）、`settings.rs`（一次运行的设置）、`mode.rs`（协议 / 扫描选择、交互）、`mod.rs`（`Config`、加载设置与相对路径） |
| `proxy/inbound/` | `mod.rs`（`bind` / `http-proxy` 常驻监听）、`config.rs`（`inbounds`）、`socks5.rs`、`http.rs`、`mixed.rs`、`sunnyquic.rs`（服务端入站，接到路由）、`tun/`（`mod.rs`、`flows.rs`、`fakeip.rs`、`linux.rs`、`windows.rs`、`windows_firewall.rs`、`unsupported.rs`） |
| `proxy/session.rs`、`session_udp.rs`、`socks.rs` | 一条 TCP 流 / UDP 关联的嗅探 → 路由 → 转发；SOCKS5 / HTTP 细节 |
| `proxy/sunnyquic/` | sunnyquic 协议本身（移植自 shadowquic，MIT）：`proto.rs`（帧编解码）、`auth.rs`（凭据、用户表）、`quic.rs`（TLS / ALPN / 0-RTT / 拥塞控制 / MTU）、`brutal.rs`、`tcp.rs`、`udp.rs`（UDP 关联，datagram / stream 两种）、`client.rs`、`server.rs`、`tests.rs`、`LICENSE-shadowquic` |
| `proxy/outbound/` | `mod.rs`（`AnyOutbound`、注册表）、`direct.rs`、`block.rs`、`warp.rs`、`warp_local.rs`、`socks5.rs`、`sunnyquic/`（`settings.rs` 设置与 `sunny` 段、`client.rs`、`socket.rs` 隧道里的 UDP socket、`outbound.rs`：`sunny` / `sunny-direct` / 声明的出站） |
| `proxy/router/` | `mod.rs`（route 解析、`Router`、`warp_users`）、`rule.rs`、`ruleset.rs`（source / binary / yaml）、`srs.rs`、`sniff.rs`、`domain.rs`、`ipset.rs`、`process.rs`、`hostname.rs`、`legacy.rs`、`exits.rs` |
| `transport/warp/` | `manager.rs`（隧道管理）、`demand.rs`（按需启动判定）、`masque/{mod,quic,http2,proto}`、`netstack.rs`、`net/{tls,https,upstream}`、`consts.rs`、`scan.rs`、`prober.rs`（`prober/{cidr,quick,rounds,live}`：抽样、快筛、扫描轮次、后台扫描与热切换）、`account.rs`、`zerotrust.rs`、`identity.rs`（身份路径、注册）、`exitloc.rs`、`lastconn.rs`、`tunnelping.rs`、`common.rs` |
| `dns/`、`api/{mod,ffi}`、`utils/` | DoH / ECH；App 库接口与 C FFI；出网 socket（`egress.rs`）、统计、日志、分片、noize |

仓库根目录另有 `quiche/`（vendored，BoringSSL）。sunnyquic 协议不再依赖 vendored 的 shadowquic，而是 `proxy/sunnyquic/` 里 Aether 自己的实现（见上表）。

# 15. MASQUE 网关扫描：候选、最高延迟（`scan.max-rtt`）、后台扫描与热切换

**候选（种子选取）与上游 Aether 一致**（CluvexStudio/Aether `577a4c8`，即当前 main）：第 1 轮的候选列表 = 8 个种子网关在**主端口**上 → 14 个 IPv4 /24（IPv6 时 3 个 /48）各抽样（turbo 64、balanced 140、verified 48、ironclad 140 个；thorough 整段 254 个），按段交错排列、都在**主端口**上 → 种子网关在其余每个端口上各一次。与上游的差别只有主端口怎么选：

- 上游主端口 = 端口列表第一个（443）。本项目 443 排在默认端口最后（`500,1701,4500,4443,8443,8095,443`），主端口 = 端口检查（种子网关上每个端口发一个 QUIC Initial）回应最多的端口，**平局时 443 让位**；端口检查全无回应或 `scan.prefilter: false` 时用端口列表第一个（默认 500）。`scan.ports` 自己列端口时按列的顺序、443 不再让位。
- 两段式快筛（默认开，`scan: { prefilter: false }` 关）照旧：候选先过一遍快筛，有回应的按快筛 RTT 从快到慢做完整校验。

| 写法 | 位置 | 说明 |
|---|---|---|
| `scan: { max-rtt: 500 }` | 配置文件 `scan` 段 | 毫秒，可写 `500`、`"500ms"`；`0`（或 `off`）= 不限制。值不是数字时启动即报错并指出 `scan.max-rtt`。旧版顶层的 `scan_max_rtt` 迁移时自动移进来（第 2.7 节） |
| FFI `aether_scan_start` 的 JSON `"max_rtt_ms": 500` / `ScanRequest.max_rtt_ms` | 库调用 | 不给 = 默认 500，`0` = 不限制 |

扫描模式默认 **balanced**，启动时不询问（`scan: { mode: ... }` 指定其它模式）。

最高延迟：

- **所有扫描模式**（turbo、balanced、thorough、verified、ironclad）都适用，默认 **500 ms**。
- RTT 是**完整校验总耗时**（QUIC/TLS 握手 + CONNECT-IP + 数据面探测，含 noize 前置包；ironclad 为真实 HTTP 往返），不是 ping，通常是网络往返时间的数倍；比较上限、启动、切换都用它。设上限时留出余量。

## 15.1 先启动、后台继续扫描、更快就热切换（默认开）

0. **有历史网关**（当前承载自己的 `-lastconn-h3.yaml` / `-lastconn-h2.yaml`、端口在扫描端口内）：不询问，用与扫描**完全相同的完整校验**（同一校验、同一超时，即当前模式的单探测超时）：
   - 先**单独**测历史最优（RTT 历史里最快的）。RTT **低于 `scan.max-rtt` 的一半**：直接用它启动，**不再测其它历史、也不扫描**（日志 `under half of max-rtt … no scan`）。
   - 否则（或没有历史、它没通过）：RTT 历史里的其它网关加最近可用的网关（`recent`，最多 8 个），去重后**同时**测，连同历史最优的结果取 RTT 最低的启动。它低于 `scan.max-rtt` 一半：同样不扫描；否则以这次实测 RTT 为基准，照常后台扫描（第 2–4 条），找到更快的就切换。
   - `scan.max-rtt: 0`（无上限）时没有「一半」可比，有历史也总是后台扫描。全部不通过才走下面第 1 条正常扫描。
   - 不扫描时，之后网关断线/连续失败仍走原有重连、重扫逻辑。`--quick-reconnect` / `--no-quick-reconnect` 已删除（命令行写了会报错）；想不用历史就删掉配置文件旁边的 `-lastconn-h3.yaml` / `-lastconn-h2.yaml`。`masque.peer`、Zero Trust 指定端点不受影响。
1. **没有历史网关**：扫描中**第一个完整校验 RTT ≤ `scan.max-rtt` 的网关一出现，立即用它启动隧道**，不等扫描结束（`max-rtt: 0`：第一个通过完整校验的网关即启动）。
2. 扫描**在后台继续**，扫完所有候选、所有轮次（`scan.rounds`，默认 3 轮）。这时模式自己的提前结束条件（凑够 N 个、静默期、turbo 的首个即停）不再结束扫描；每一批完整校验仍受该模式的时限（balanced 120 s 等）约束。
3. 无论隧道是用历史网关（需要后台扫描时）还是扫描结果启动的，后台每发现一个 RTT **小于当前正在用的网关 RTT 的 50%**（严格小于一半）的网关就热切换过去，并以新网关作为后续比较基准。另外，**正在用的网关超过 `scan.max-rtt` 时**（历史网关变慢了，或下面第 5 条的回退启动），第一个 ≤ 上限的网关即切换，不要求快一半。满足条件的网关会**再做一次完整校验**，按两次中较慢的那次重新判断，仍满足才切换（避免一次测得偏快就切、断掉现有连接）；正在用的网关本身不会被当作候选。切换走现有的重连路径：旧隧道（及其用户态协议栈）关闭，新网关建隧道、重新发布协议栈；sunny 走 `detour: warp` 时 sunnyquic 客户端的 TunnelSocket 重新挂到新外层隧道上，QUIC 连接本身保留。
4. 切换后的新网关若在 60 秒内建隧道失败或断开，回到切换前的网关（先快速校验）。另外，同一网关上的隧道连续 2 次刚建立不久就断开时放弃这个网关、重新选择，它在 300 秒内不参与扫描。
5. **一轮结束**仍没有网关 ≤ 上限：立即用目前最快的那个启动并 warn（`starting on the fastest so far`），后台继续扫后面的轮次，出现 ≤ 上限的就按第 3 条切过去。一个网关都没通过：报 `NoCleanEndpoint`，稍后重扫。
6. 后台扫描属于本次运行：停止信号（Ctrl+C、库里停止 core、`aether_job_cancel`）会终止它；重新扫描（如网关连续失败）时旧的后台扫描先停掉。扫完打印汇总。

| 写法 | 位置 | 说明 |
|---|---|---|
| `scan: { switch: false }` | 配置文件 `scan` 段 | 关闭本节行为，恢复「扫完再选」：有上限时第一轮凑够目标数（balanced 6 个）+ 静默期后选最快，第一轮没有 ≤ 上限的才扫下一轮（第 15.2 节），全部没有则回退最快；turbo 为第一个 ≤ 上限的网关即选定。默认 `true`。旧版顶层的 `scan_switch` 迁移时自动移进来 |
| FFI `aether_scan_start` 的 JSON `"scan_switch": false` / `ScanRequest.scan_switch` | 库调用 | 扫描任务没有隧道可切换：默认（不给或 `true`）任务在出现第一个 ≤ 上限的网关时就结束并返回它（与 core 启动隧道的时机一致；都不在上限内则扫完返回最快），不在后台继续；`false` = 扫完再选。`aether_core_start` 跑的完整 core 有完整的后台扫描与热切换 |

日志（全部 info 级，默认就能看到）：

```
[scan] port check on 10 seed gateway(s) in 1.5s: 8443 (10 ok, 92ms), 443 (10 ok, 80ms), 500 (6 ok, 95ms)
[scan] scan mode=balanced ip=ipv4 candidates=2024 ports=[500, 1701, 4500, 4443, 8443, 8095, 443] primary=[8443] ... max_rtt=500ms rounds=3 (starts on the first gateway within max-rtt, then scans on in the background)
[scan] round 1/3 batch 1: quick pass of 2024 candidate(s) in 3s: 36 answered, 61 silent, 0 skipped in silent ranges; 1927 left in this round
[scan] started on 162.159.198.2:8443 rtt=310ms, scanning continues in background
[scan] selected MASQUE gateway 162.159.198.2:8443 (rtt 310ms)
[masque] using cloudflare edge 162.159.198.2:8443
[scan] round 1/3 batch 1: full check 36/36 done, 9 passed, fastest 162.159.198.2:8443(310ms); in use 162.159.198.2:8443(310ms), switches below 155ms
[scan] round 1/3 batch 2: quick pass of 1927 candidate(s) in 4s: 36 answered, 88 silent, 12 skipped in silent ranges; 1791 left in this round
[scan] round 1/3 batch 2: full check in progress, 20/36 checked, 3 passed; in use 162.159.198.2:8443(310ms), switches below 155ms
[scan] switching gateway 162.159.198.2:8443(310ms) -> 162.159.192.77:8443(140ms)
[masque] switching gateway 162.159.198.2:8443(310ms) -> 162.159.192.77:8443(140ms)
[scan] round 1/3 batch 2: full check 36/36 done, 7 passed, fastest 162.159.192.77:8443(140ms); in use 162.159.192.77:8443(140ms), switches below 70ms
...
[scan] round 1/3 batch 14: quick pass of 410 candidate(s) in 12s: nothing more answered (380 silent, 30 skipped in silent ranges); round ends with 0 not reached
[scan] round 1/3 finished in 251s: 2024 candidate(s), 13 batch(es), 468 answered the quick pass, 468 full-checked, 61 passed, fastest 162.159.192.77:8443(140ms), 0 not reached; in use 162.159.192.77:8443(140ms), switches below 70ms
[scan] background scan round 2/3: sampling 254 per /24 on ports [8443, 443, 500]: ... new candidate(s), ...
...
[scan] background scan finished in 13m12s: 3 round(s), 141 gateway(s) passed (137 within max-rtt 500ms), 1 switch(es); in use 162.159.192.77:8443(140ms)
```

- 后台扫描按「轮 → 批」进行：每批先快筛（`quick pass of N candidate(s)`：本批快筛了多少候选、几个有回应、几个沉默、几个因同一 /24 沉默被跳过、本轮还剩多少没探），再对有回应的做完整校验（`full check X/Y done`：本批验了几个、通过几个、本批最快）。每批完整校验结束都带上 **当前在用网关及其 RTT** 和 **切换门槛**（`switches below`＝在用 RTT 的一半，后台找到比它更快的才会热切换）。还没启动隧道时显示 `nothing in use yet (waiting for one within 500ms)`。
- 一批完整校验超过 30 秒还没结束，每 30 秒打一行 `full check in progress, 已验/总数 checked, 通过数 passed`，表示后台扫描仍在运行。
- 每轮结束一行 `round r/R finished in …s` 汇总本轮候选数、批数、快筛回应数、完整校验数、通过数、本轮最快和未探到的候选数；全部轮次结束一行 `background scan finished …`。看到这行之前，后台扫描一直在运行。
- 快筛的逐批原始统计行（`[scan] quick pass: N of M candidate(s) answered …`）在后台扫描里降为 debug；`scan.switch: false` 时仍是 info。
- `[scan] switching …` 是扫描做出的决定，`[masque] switching …` 是隧道真正切换（sunny 走 `detour: warp` 时随后有 `sunny ready: masque … carries sunnyquic`）。未在上限内的网关、没触发切换的网关只出 debug 行。
- `log-level: debug` 时每次完整校验开始会出一行 `[tls] tls verification: disabled …`（只有第一次是 info）。快筛不出这行，所以两批完整校验之间（快筛进行中，一次最长约 40 秒）看不到它，**不代表扫描停了**；以上面的 `round … batch …` 行为准。

风险与代价：

- **已有连接**：纯 MASQUE（SOCKS/HTTP 代理、`warp` 出站、TUN 经 WARP）每个隧道有自己的用户态协议栈，切换时经旧网关的 TCP 连接会被重置、UDP 会话丢失，应用需要重连；切换窗口内（新隧道握手，通常 1 秒内到数秒）新连接会失败或等待。sunny 走 `detour: warp`：sunnyquic 的 QUIC 连接在外层隧道之间保留，切换只造成短暂丢包，内层 TCP/UDP 一般不断；直连的 `sunny`（默认）不经过 WARP 网关，切换对它没有影响。
- **流量与耗时**：后台扫描默认扫完 3 轮：第 2 轮每个 /24 全部 254 个地址、第 3 轮再加所有端口，快筛包约数万个，完整校验数十到上百次；有快筛时通常几分钟扫完，`scan.prefilter: false` 时每批扫满时限，可能十几分钟。在严格网络上可能触发限速/封锁。想省流量：`scan: { rounds: 1 }`（只扫上游那一轮）或 `scan: { switch: false }`。
- 50% 的门槛较高，切换不会频繁；候选还要第二次校验确认，偶发的单次偏快不会触发切换。后台候选是在隧道占用上行时测的，历史网关是空闲时测的，比较会偏向少切换。
- 默认扫描模式为 **balanced**，启动时**不询问**扫描模式；`scan: { mode: thorough }` 等照常改。

## 15.2 扫描轮次（`scan.rounds`）

| 写法 | 位置 | 说明 |
|---|---|---|
| `scan: { rounds: 3 }` | 配置文件 `scan` 段 | 1–10 的整数，**默认 3**；`1` = 只扫第 1 轮（上游那一轮）。值不合法时启动即报错并指出 `scan.rounds`。旧版顶层的 `scan_rounds` 迁移时自动移进来 |
| FFI `aether_scan_start` 的 JSON `"scan_rounds": 3` / `ScanRequest.scan_rounds` | 库调用 | 不给 = 默认 3，超出 1–10 时夹到范围内 |

- 默认（后台扫描开）：**所有模式**都扫满全部轮次，这就是「全部完成」的范围；`max-rtt: 0` 也一样。
- `scan.switch: false`：有上限（`scan.max-rtt` 非 0）时所有模式都可能扫多轮：一轮结束仍没有网关 ≤ 上限才扫下一轮，任何一轮有了就结束（第 2 轮起首个合格后静默期结束）；`max-rtt: 0` 只扫一轮。

每轮做什么（以默认端口、IPv4 为例）：

| 轮次 | 每个 /24 抽样 | 扫描端口 | 种子网关 |
|---|---|---|---|
| 第 1 轮（上游方式） | 模式的抽样数（balanced 140；thorough 整段） | 主端口 1 个 | 主端口上探，再在其余每个端口上各探一次 |
| 中间轮（第 2 … N−1 轮） | 上一轮的 2 倍（第 k 轮 ×2^(k−1)，最多 254 = 整段） | 主端口 + 端口检查里**所有**有回应的端口 | 不再探 |
| 最后一轮（N ≥ 2） | **整段 254 个地址全扫** | 再加上其余所有扫描端口（`scan.ports` 或默认 7 个） | 不再探 |

- 后续轮次**排除前面所有轮已探过的 (地址, 端口)**：完整校验过的、以及快筛里没有回应的；同一地址换了新端口仍算新候选。种子与已验证网关（162.159.199.1/.2 等）只在第 1 轮。IPv6 每个 /48 的抽样数也逐轮翻倍（最多第 1 轮的 8 倍）。
- 后台扫描时每轮分批：快筛交出最快的一批（最多 6× 目标数，至少 24 个）做完整校验，然后快筛继续处理本轮还没探到的，直到本轮没有剩余候选或快筛再无回应；被 /24 静默剪枝跳过的本轮不再探，下一轮可再试。
- 快筛每批最多 40 秒；完整校验每批受模式时限约束（balanced 120 s）。

最坏情况耗时：`scan.switch: false` 时约 端口检查 1.5 s + N ×（快筛 ≤ 40 s + 完整校验 ≤ 120 s）；后台扫描时每轮可能有多批，总时长更长，但隧道早已启动，只影响后台流量。

# 16. 许可证

- **Aether**：AGPL-3.0-only；修改后的程序同样按 AGPL-3.0 提供，分发二进制或作为网络服务提供时须提供对应源码。商标政策见 `TRADEMARK.md`。
- **shadowquic**：MIT。`proxy/sunnyquic/` 移植自 shadowquic（上游 `4406bb20`）的 sunnyquic 部分，文件头注明来源，版权与许可声明见 `proxy/sunnyquic/LICENSE-shadowquic`。
- **geph5**（VPN 部分）：MPL-2.0；`proxy/inbound/tun/linux.rs`、`windows.rs`、`windows_firewall.rs` 改编自 geph5，文件头注明来源，继续按 MPL-2.0 授权（与 AGPL-3.0 兼容）。
- **ipstack-geph**：Apache-2.0。
- **WinTUN**（`wintun.dll`，仅 Windows，未修改）：WireGuard LLC 预编译二进制许可证，运行时动态加载。
