# Aether

Aether is a user-space proxy client for Cloudflare WARP. It builds a tunnel out
of a filtered network and exposes a local SOCKS5 proxy on `127.0.0.1:1819`.
Point a browser, a terminal, or a system proxy at that address and the traffic
leaves through the tunnel.

It needs no root and installs no network driver. Everything happens inside the
process: the tunnel, a user-space TCP/IP stack, and the proxy.

## Contents

- [Running it](#running-it)
- [Transports](#transports)
- [Finding an endpoint](#finding-an-endpoint)
- [Obfuscation](#obfuscation)
- [TLS](#tls)
- [Zero Trust](#zero-trust)
- [Routing rules](#routing-rules)
- [Upstream proxy](#upstream-proxy)
- [sunnyquic](#sunnyquic)
- [Config file](#config-file)
- [Firewall mark](#firewall-mark)
- [Proxy limits and timeouts](#proxy-limits-and-timeouts)
- [Identity files](#identity-files)
- [Using Aether as a library](#using-aether-as-a-library)
- [Environment variables](#environment-variables)

## Running it

Run `aether` with no arguments and it asks a few questions, or pass flags and it
asks nothing. Every flag also has an environment variable, so the same settings
work in a container or a service unit. `aether --help` lists all of them.

```sh
aether
aether --masque --scan balanced
aether --h2 --noize aggressive --bind 127.0.0.1:1080
```

Check that it works:

```sh
curl -x socks5h://127.0.0.1:1819 https://www.cloudflare.com/cdn-cgi/trace
```

The reply should show a Cloudflare colo and `warp=on`.

For clients that cannot speak SOCKS, add an HTTP CONNECT proxy:

```sh
aether --http-proxy 127.0.0.1:1820
```

Both listeners serve the same tunnel. Bind them to `0.0.0.0` only if you mean to
share the tunnel with your network; nothing authenticates the callers.

## Transports

| Transport | Flag | Carrier |
| --- | --- | --- |
| MASQUE | `--masque` (default) | QUIC/HTTP-3 on UDP 443, or HTTP/2 on TCP 443 |
| sunnyquic over MASQUE | `--sunny` | your own sunnyquic server, dialled from inside the MASQUE tunnel |

MASQUE is the default because it looks like ordinary HTTPS traffic and Cloudflare
treats it as the primary protocol. This version carries WARP over MASQUE only;
`--protocol` takes `masque` or `sunny`.

MASQUE has two carriers. HTTP/3 over QUIC is the default. If UDP 443 is blocked
outright, `--h2` moves the same tunnel onto TCP 443, which survives networks that
drop QUIC entirely.

```sh
aether --masque --h2
```

### QUIC v2 opener

Some networks block QUIC v1 on every port while letting QUIC v2 through, because
their filter only learned to recognise v1. Before each HTTP/3 handshake Aether
sends one opener packet that carries the QUIC v2 version number but is otherwise a
plain long-header Initial. The filter sees a v2 flow and lets it pass; the
Cloudflare edge does not speak v2 and answers with a Version Negotiation pointing
back to v1; Aether then runs the ordinary v1 handshake on that same socket, which
the filter now treats as an allowed flow. On an open network this only adds one
short round trip. Combine it with a non-443 port (the scan already tries 443, 500,
1701, 4500, 4443, 8443 and 8095) where 443 is the one being blocked. Turn it off
with `--no-quic-v2` or `AETHER_QUIC_V2=0`. It does not apply to `--h2`, which is
TCP.

## Finding an endpoint

Cloudflare answers on many edge addresses and a filtered network usually blocks
some of them, so Aether does not ship a single fixed address. It sweeps the
documented ranges, verifies candidates, and keeps the one that carries real
traffic. A handshake alone is not enough: a candidate has to pass an end-to-end
data check before the proxy opens.

| Mode | Behaviour |
| --- | --- |
| `turbo` | stops at the first candidate that answers |
| `balanced` | default, collects a few and keeps the fastest |
| `thorough` | sweeps whole ranges, best when everything looks blocked |
| `stealth` | few probes in flight, for networks that notice scanning |
| `ironclad` | full tunnel and a real HTTP request per candidate |

Skip the scan when you already know a good address:

```sh
aether --peer 162.159.196.1:443
```

The last working endpoint is saved, and `--quick-reconnect` reuses it without a
new sweep. An endpoint that just failed is held on a cooldown so the next attempt
does not land on it again.

## Obfuscation

Some networks fingerprint the first packets of a handshake. Aether can pad and
reshape them so the opening exchange does not match a known pattern.

| Profile | Use it when |
| --- | --- |
| `off` | the network does no inspection |
| `light` | mild interference, lowest overhead |
| `balanced` | default, a good starting point |
| `aggressive` | the handshake is being fingerprinted |

```sh
aether --noize aggressive
```

One extra concerns the TLS ClientHello: `--fragment` splits it on MASQUE's HTTP/2
carrier, which defeats inspectors that read the SNI from a single packet, and on
the calls to the WARP API, whatever the transport. `--fragment-size` and
`--fragment-delay` tune both. Without `--fragment`, both go whole.

## TLS

Four kinds of TLS handshake carry the tunnel and its setup: MASQUE on HTTP/3 and on
HTTP/2, the calls to the WARP API, and the DNS-over-HTTPS lookup of the ECH config.
All four send Chrome's ClientHello as BoringSSL writes it: TLS 1.3 and 1.2, Chrome's
cipher suites, GREASE values (RFC 8701), the extensions in a new order on every
handshake, signed certificate timestamps and OCSP asked for. They offer `h2` then
`http/1.1`, as Chrome does, but `h3` over QUIC, which carries TLS 1.3 alone; the
HTTP/2 carrier speaks HTTP/2, which Cloudflare picks. Certificates are not checked.
Zero Trust sign-in and the exit-location lookup keep
a TLS of their own. Three options change the fingerprint of all four:

- `--tls-ciphers` sets the TLS 1.2 cipher suites, listed after the TLS 1.3 ones,
  which stay as they are: names separated by `:`, as BoringSSL reads a cipher
  string. HTTP/3 lists none. Without it they are Chrome's, from Chrome's own rule
  `ALL:!aPSK:!ECDSA+SHA1:!3DES`, in Chrome's order: AES-GCM first on hardware with
  AES instructions, ChaCha20 first elsewhere.
- `--tls-groups` sets the groups, in order, the first one getting a key share
  (default `P-256:X25519:P-384`).
- `--disable-grease` leaves out the GREASE values, which all four otherwise put in
  the cipher suites, the extensions, the groups, the key shares and the versions.

A cipher or group name BoringSSL does not know stops the core as it starts, with
the option named.

The MASQUE handshakes, on both carriers, put `www.cloudflare.com` in their
ClientHello as the server name; `--masque-sni <name>` puts another one there, such
as `consumer-masque.cloudflareclient.com`, the one the WARP client sends. Only the
TLS name changes: the HTTP host, the `:authority` of the CONNECT request, stays
`cloudflareaccess.com`. The name goes into every MASQUE handshake: the scans and
checks of gateways and the tunnel. It always goes in the clear: the MASQUE
handshakes never offer ECH. A value that is no domain name, an IP address among them, stops the
core as it starts.

`--ech auto` fetches an Encrypted Client Hello config and hides the server name of
the calls to the WARP API (register and enroll), when the network permits it. It
applies to those calls only: the MASQUE handshakes, on both carriers, go without
ECH whatever `--ech` says, because the WARP MASQUE gateways turn it down
(`ECH_REJECTED`), and the Cloudflare addresses that do take it are no MASQUE
gateways (their CONNECT-IP answers 400). With `--ech` given, the core says so as it
starts: `[tls] --ech applies to the WARP API calls only; the MASQUE handshakes go
without ECH (the WARP gateways turn it down)`. It asks `udp://1.1.1.1` for the HTTPS
record of `cloudflare-ech.com`; `--ech-dns` names another resolver
(`udp://ip[:port]` or `tcp://ip[:port]`, on port 53 unless one is given, or a
DNS-over-HTTPS `https://` URL, on port 443 unless it names one) and `--ech-domain`
another domain. After a DNS-over-HTTPS URL, `@address=` sends the connection to
another IP address or domain, on the URL's port, and `@sni=` puts another name in
the ClientHello, while the URL's host stays the HTTP host:
`https://doq.dns4all.eu/dns-query@address=2.2.2.2@sni=google.com` connects to
2.2.2.2, names google.com in the ClientHello and asks doq.dns4all.eu over HTTP.
That lookup goes without ECH, as the config it fetches is the one ECH needs.
`--ech <base64>` takes the config itself instead, as the `ech` value of such a
record shows it. Without a config it can offer, because the lookup failed or the
config is not one the TLS library can use, the API's name does not go out in the
clear: the WARP API is not asked, and the core says why. A library job that asks
for ECH on its MASQUE handshakes (`"ech": true`, or a key in the scan request or
tunnel spec) goes without it; the core warns once.

## Zero Trust

With `--team <name>` Aether enrols as a managed device on your organization's
Cloudflare Zero Trust account instead of registering an anonymous consumer
device.

Three ways to sign in:

| Method | Flags | Suits |
| --- | --- | --- |
| Email code | `--access-email <addr>` | a person at a keyboard |
| Service token | `--access-id`, `--access-secret` | servers and CI |
| Existing token | `--access-token <jwt>` | a token you already hold |

```sh
aether --team acme --access-email me@example.com
```

Cloudflare emails a one-time code and Aether asks for it. The code can be typed
into a terminal or fed on standard input, which is how the desktop and Android
clients answer it. You get three attempts. The resulting token is cached for the
life of the process, so a reconnect does not ask again.

`--gateway` sends HTTP and HTTPS through the organization's Gateway proxy so its
filtering and logging apply. It is off by default because it adds a hop inside
the tunnel and records your browsing. If the proxy stops answering, Aether falls
back to direct tunnel egress rather than breaking every connection.

## Routing rules

Routing is written in the `[route]` table of the config file (see
[Config file](#config-file)), with sing-box's field names: rules, rule actions,
rule sets and per-process rules. The old `--route-block`, `--route-direct` and
`--routes` lists (and `AETHER_ROUTE_BLOCK`, `AETHER_ROUTE_DIRECT`,
`AETHER_ROUTES_FILE`) were removed; Aether refuses to start when one is given and
says how to write it as a rule. What they did, as rules:

```toml
[route]
rules = [
  { domain_suffix = ["ads.example.com"], action = "reject" },
  { port = 25, action = "reject" },
  { ip_is_private = true, outbound = "direct" },
  { domain_suffix = ["bank.ir"], outbound = "direct" },
]
```

Rules apply to TCP and UDP.

### Name rules behind a tun

Name rules also match when the proxy is handed an address instead of a name, which
is what a tun front end does. Aether reads the name from the TLS server name or the
HTTP `Host` header of the first bytes and decides on that; address and port rules
still apply when no name is found.

The name is used for the decision only, so the connection still goes to the address
the client asked for.

| Variable | Default | Sets |
| --- | --- | --- |
| `AETHER_ROUTE_SNIFF` | on | `0` turns it off |
| `AETHER_ROUTE_SNIFF_MS` | `400` | how long to wait for those first bytes |

## Upstream proxy

`--upstream` sends everything Aether dials through another proxy, which is how you
chain it behind a VPN or proxy app already running on the machine.

```sh
aether --upstream socks5://127.0.0.1:1080
aether --upstream socks5://alice:s3cret@127.0.0.1:1080
aether --upstream http://proxy.example:8080
```

A bare `host:port` is read as SOCKS5. Bracket an IPv6 address. Percent-encode a
password containing `@` or `:`, so `p@ss` is written `p%40ss`. Aether speaks plain
HTTP to an `http://` or `https://` upstream, so an `https://` one with a password is
refused rather than sending the password in the clear.

| Proxy | Carries |
| --- | --- |
| SOCKS5 with UDP associate | every transport: MASQUE on HTTP/3 and HTTP/2, and `--sunny` |
| HTTP CONNECT | the HTTP/2 carrier only, since CONNECT cannot carry UDP |

With an HTTP proxy, add `--h2` so the whole tunnel stays on TCP:

```sh
aether --masque --h2 --upstream http://proxy.example:8080
```

The endpoint scan, the obfuscation packets, the registration and Zero Trust sign-in
calls and the ECH lookup go through the proxy too, and a SOCKS5 proxy resolves the
API host names itself. A destination routed to the `direct` outbound does not, because
that rule exists to bypass the tunnel.

The same setting is available as `AETHER_UPSTREAM`.

## sunnyquic

`--sunny` dials your own sunnyquic server (spongebob888/shadowquic, or Aether's own
sunnyquic server inbound; the protocol is built into Aether and wire-compatible) from inside the
MASQUE tunnel: your network sees only WARP, and traffic leaves from your server. The
client's settings come from `--sunny-*`, `AETHER_SUNNY_*`, or the `[sunny]` table of
the config file (keys as shadowquic writes them, `-` or `_` alike); naming a server
in any of them selects the mode.

```toml
[sunny]
server = "203.0.113.7:8443"
username = "alice"
password = "PASSWORD"
server_name = "www.bing.com"
ca = "cert.pem"
```

The outbound `sunny-direct` is the same client on a local UDP socket, without WARP;
`[[outbounds]]` of `type = "sunnyquic"` declare more (`detour = "direct"` or
`"warp"`), and a `type = "sunnyquic"` inbound makes Aether a sunnyquic server.

## Config file

One TOML file, `--config` (default `aether.toml`), holds the identity, `[sunny]`,
and the routed config in sing-box's field names: `[[inbounds]]` (mixed, socks, http,
tun, sunnyquic), `[[outbounds]]`, `[route]` with `[[route.rules]]` and
`[[route.rule_set]]`, and `[dns]`. `--route-config <file.toml>` replaces those four
with another file's. JSON configs are not read. When nothing in the routed config
needs WARP, the tunnel is not started (`--warp-tunnel auto|on|off`).

```toml
[[inbounds]]
type = "sunnyquic"
tag = "sunnyquic-inbound"
listen = "0.0.0.0"
listen_port = 8443
users = [{ name = "1114", password = "314" }]
tls = { server_name = "www.bing.com", certificate_path = "./cert.pem", key_path = "./key.pem", alpn = ["h3"] }

[route]
final = "direct"
```

See `Docs/USAGE.zh.md` and `Docs/examples/` for the full reference.

## Firewall mark

On a Linux router that sends its own traffic into a tun front end (hev-socks5-tunnel,
tun2socks), Aether's outgoing connections would loop back into that tun. `--mark`
puts a firewall mark (`SO_MARK`) on every socket Aether opens to the internet: the
tunnels, the endpoint scan, the upstream proxy and `direct` connections.
Rules can then let marked packets bypass the tun:

```sh
aether --mark 0xff
ip rule add fwmark 0xff lookup main priority 100
```

The mark is a decimal or `0x` number and needs root or `CAP_NET_ADMIN`; Aether stops
at startup if it cannot set it, rather than send unmarked traffic. It only works on
Linux and Android. The calls to the WARP API and the DoH lookup of the ECH config
are marked as well, but the system resolver looks a name up outside the mark:
without `--upstream`, `--api-address` then takes an IP address only (see
[Where the WARP API is asked](#where-the-warp-api-is-asked)), and a DoH URL of
`--ech-dns` should name an IP address, or give one with `@address=`. The same
setting is available as `AETHER_MARK`.

## Proxy limits and timeouts

These keep a busy proxy from running out of file descriptors or memory. The defaults
suit most setups.

| Variable | Default | What it does |
| --- | --- | --- |
| `AETHER_MAX_CLIENTS` | 512 to 8192, by resources | clients served at once; past it new ones wait for a free slot |
| `AETHER_HALF_CLOSE_SECS` | `30` | how long a connection the client has finished sending on may stay silent before it is closed |
| `AETHER_TCP_KEEPALIVE_SECS` | `60` | idle time before a keep-alive checks the other end of a connection; three unanswered ones close it |
| `AETHER_TCP_CONNECT_SECS` | `30` | how long a connection through the tunnel may take to open |

Aether also raises its own open-file limit to the system's hard limit at startup. A
listen address that is already taken, or reserved by Windows (see `netsh interface
ipv4 show excludedportrange protocol=tcp`), stops Aether at startup with an error.

## Identity files

The first time a run needs WARP, Aether registers a device and writes its MASQUE
identity (`device_id`, `access_token`, `cert_pem`, `key_pem`, ...) as top-level keys
of the config file, `--config` (default `aether.toml`). It rewrites only those keys:
your own tables, keys and comments stay as they are, and a file whose content did
not change is not written again. Keep them: deleting them registers a new device. A
config with no identity keys has no identity yet; a run that never needs WARP (a
plain sunnyquic server) never writes one.

| File | Holds |
| --- | --- |
| `aether.toml` | your settings and, at the top, the MASQUE identity |
| `aether-masque.toml` | the MASQUE identity of an earlier version; used as before when it exists |
| `aether-team-<name>.toml` | one identity per Zero Trust team |
| `aether-lastconn.toml`, `aether-*-lastconn.toml` | the last working endpoint |

`--masque-config` keeps the identity in a file of its own. The files contain
private keys and are written owner-readable only. A config that is not valid TOML
is reported and left untouched; only a file holding nothing but an identity is moved
aside (`.corrupt`) when its identity cannot be read.

### When an identity stops being accepted

Cloudflare can stop accepting a device that is still in your file. The handshake
keeps succeeding in that state and no traffic passes, so Aether checks the saved
identity on startup and reports it:

```text
[-] cloudflare no longer accepts the saved identity for device <id>
[-] the tunnel will handshake but carry no traffic until this identity is replaced
```

It then registers a fresh device and rewrites the file. Set `AETHER_REPROVISION=0`
to be told without anything being replaced.

Only the account API refusing the device counts. Being offline or rate limited does
not discard an identity.

### Where the WARP API is asked

Registering a device, enrolling its MASQUE key and refreshing a profile are calls
to the WARP API, `api.cloudflareclient.com`, made as described under TLS above.
`--api-address` sends them to another address, an IP address or a domain name,
on port 443 unless a port follows it, an IPv6 address then in brackets:
`188.114.97.6`, `188.114.97.6:2053`, `[2606:4700::1]:8443`. Only the connection goes
there: the API's name stays the server name of the ClientHello and the HTTP host,
which carries no port. A name is looked up first, by the proxy with `--upstream`
and by the system resolver otherwise; with `--mark` and no `--upstream` only an IP
address is taken, since that lookup would leave outside the mark and loop back into
the tunnel. With `--ech` the API's name goes only inside the encrypted ClientHello,
and an IP address for `--api-address` keeps it out of the DNS lookup as well.

```sh
aether --register all --ech auto --api-address 141.101.113.10
```

## Using Aether as a library

Besides the `aether` binary, the crate builds `libaether.a` and `libaether.so`
with a C API, so a host application can link the core instead of spawning it.
This is what the iOS client needs, and it lets a Go program use Aether through
cgo.

The manifest is `aether/Cargo.toml`, so from the repository root enter the crate first. The binary and the libraries land in `aether/target/release/`.

```sh
cd aether
cargo build --release            # binary and both libraries
cargo build --release --bin aether   # binary only
```

The C API is handle based and polled rather than callback based, so it is safe to
call from any language runtime. `aether_core_start` runs the whole pipeline and
returns a job handle; `aether_job_poll` reports progress; `aether_job_cancel`
stops it. Separate entry points cover the individual steps: identity, Zero Trust
sign-in, endpoint scan, verification, and the tunnel. Every reply is JSON, every
returned string is released with `aether_string_free`, and no panic crosses the
boundary. The header is `ios/Shared/aether.h` in the Oblivion client.

The data path is channel based and contains no tun device code, so an embedder
feeds packets in and reads them out directly.

## Environment variables

Every flag has an equivalent variable. Flags win when both are set.

| Variable | Sets |
| --- | --- |
| `AETHER_SOCKS` | SOCKS5 listen address |
| `AETHER_HTTP_PROXY` | HTTP CONNECT listen address |
| `AETHER_PROTOCOL` | `masque`, `sunny` |
| `AETHER_SCAN` | scan mode |
| `AETHER_NOIZE` | obfuscation profile |
| `AETHER_IP` | `4`, `6`, `dual` |
| `AETHER_PEER`, `AETHER_WG_PEER` | force an endpoint |
| `AETHER_ROUTE_SNIFF`, `AETHER_ROUTE_SNIFF_MS` | reading the server name off the first bytes |
| `AETHER_MASQUE_H2_KEEPALIVE_SECS`, `_TIMEOUT_SECS` | HTTP/2 keepalive |
| `AETHER_IRONCLAD_PORT` | port the ironclad scan makes its real request to |
| `AETHER_REPROVISION` | replace an identity Cloudflare refused |
| `AETHER_QUICK_RECONNECT` | reuse the saved endpoint |
| `AETHER_MASQUE_HTTP2`, `AETHER_MASQUE_H2_PEER` | HTTP/2 carrier; `--h3` sets it to `0` |
| `AETHER_QUIC_V2` | `0` turns off the QUIC v2 opener (on by default) |
| `AETHER_MASQUE_SNI` | server name of the MASQUE ClientHello (default `www.cloudflare.com`); the HTTP host stays |
| `AETHER_ECH` | `auto` or a base64 config, for the WARP API calls only (not MASQUE) |
| `AETHER_ECH_DNS` | resolver `--ech auto` asks (`udp://`, `tcp://` or `https://`) |
| `AETHER_ECH_DOMAIN` | domain whose ECH config `--ech auto` takes |
| `AETHER_MASQUE_H2_FRAGMENT`, `_SIZE`, `_DELAY` | ClientHello fragmenting |
| `AETHER_MASQUE_STARTUP_SECS` | startup deadline |
| `AETHER_MASQUE_VALIDATE_SECS`, `AETHER_WG_VALIDATE_SECS` | data-check timeout |
| `AETHER_MASQUE_NO_DATA_CHECK`, `AETHER_WG_NO_DATA_CHECK` | skip the data check |
| `AETHER_MASQUE_RECONNECT_SECS`, `AETHER_WG_RECONNECT_SECS` | reconnect delay |
| `AETHER_DNS` | resolvers used inside the tunnel |
| `AETHER_TEAM` | Zero Trust team name |
| `AETHER_ACCESS_EMAIL` | email for the one-time code |
| `AETHER_ACCESS_CLIENT_ID`, `AETHER_ACCESS_CLIENT_SECRET` | service token |
| `AETHER_ACCESS_TOKEN` | an enrolment token you already hold |
| `AETHER_GATEWAY` | route HTTP through the organization gateway |
| `AETHER_ROUTE_SNIFF`, `AETHER_ROUTE_SNIFF_MS` | reading the name off the first bytes |
| `AETHER_UPSTREAM` | dial out through another proxy |
| `AETHER_MARK` | firewall mark for outgoing sockets |
| `AETHER_MAX_CLIENTS`, `AETHER_HALF_CLOSE_SECS` | proxy client limit and half-closed timeout |
| `AETHER_TCP_KEEPALIVE_SECS`, `AETHER_TCP_CONNECT_SECS` | keep-alive and connect timeout inside the tunnel |
| `AETHER_REPROVISION` | replace an identity Cloudflare refuses |
| `AETHER_CONFIG`, `AETHER_WG_CONFIG`, `AETHER_MASQUE_CONFIG` | identity paths |
| `AETHER_API_ADDRESS` | where the calls to the WARP API go |
| `AETHER_TLS_GROUPS` | TLS groups (see TLS) |
| `AETHER_TLS_CIPHERS` | TLS 1.2 cipher suites (see TLS) |
| `AETHER_DISABLE_GREASE` | `1` leaves GREASE out (see TLS) |
| `AETHER_PERF_PROFILE` | `low`, `medium`, `high` |
| `AETHER_LOG_LEVEL` | `error` to `trace` |
